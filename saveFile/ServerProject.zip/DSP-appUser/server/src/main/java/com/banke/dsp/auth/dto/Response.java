package com.banke.dsp.auth.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Response {

    @JsonProperty("RetCode")
    private String retCode;

    @JsonProperty("RetMsg")
    private String retMsg;

}

package com.banke.dsp.auth.dto;

import com.banke.bkc.framework.po.BasePO;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.Data;
import lombok.NonNull;

import java.time.LocalDateTime;

/**
 * Describe:
 * Created by zhangyong on 2017/8/28.
 */
@Data
public class ApplyInfoDTO extends BasePO {

    // 客户姓名
    private String clientName;

    // 申请时间
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDateTime applyDate;
}

package com.banke.dsp.auth.po;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Describe:
 * Created by zhangyong on 2017/8/28.
 */
@Data
@NoArgsConstructor
@RequiredArgsConstructor
@Entity
@Table(name = "apply_info")
public class ApplyInfo implements Serializable {
    private static final long serialVersionUID = 0x20161228;

    // 申请编号
    @Id
    private String applyNo;

    // 申请金额
    private BigDecimal applyAmount;

    // 客户经理编号
    private String advisorNo;

    // 业务员编码
    private String agentNo;

    // 申请时间
    @NonNull
    @Column
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime applyDate;

    // 状态
    private String applyStatus;

    // 城市
    private String cityId;

    // 业务机构(分公司)
    private String inputOrgId;

    // 流程编号
    private String taskId;

}

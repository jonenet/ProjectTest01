package com.banke.dsp.auth.service;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.bkc.service.util.ContextHolder;
import com.banke.dsp.auth.dto.*;
import com.banke.dsp.auth.po.AddressInfo;
import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.util.DateUtil;
import com.banke.dsp.auth.util.HttpMultipartUtils;
import com.banke.dsp.auth.util.RegexUtil;
import com.google.common.collect.Lists;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by ex-zhongbingguo on 2017/8/21.
 */
@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AppUserDashboardService {

    @Value("${appuserSave.businessCitys}")
    private String appuserBusinessCitys;

    @Autowired
    private UserRoleInfoService userRoleInfoService;

    @Autowired
    private AppUserInfoService appUserInfoService;

    @Autowired
    private BaseInfoService baseInfoSaoService;

    @Autowired
    private StaffInfoService staffInfoSaoService;

    @Autowired
    private BranchInfoService branchInfoService;
    @Autowired
    private AppuserAscriptionLogService appuserAscriptionLogService;

    @Autowired
    private AppUserInfoUtilService appUserInfoUtilService;

    @Autowired
    private AddressInfoService addressInfoService;

    @Autowired
    private BaseInfoService baseInfoService;

    /**
     * 查询用户列表
     * @param request 查询条件
     * @return         分页结果集
     */
    public PageResult<AppUserQueryResult> listData(AppUserQueryParameter request){
        String userId = ContextHolder.getUserId();
        log.info("当前用户 usrId：{}", userId);
        List<String> roles = userRoleInfoService.getValidRolesByUserId(userId);
        Page<AppUserInfo> result;
        String role;
        if (roles.contains(StaffInfoRoleEnum.H_OQ.getCode())){
            // 总部运营岗，可以查看所有的用户
            role = StaffInfoRoleEnum.H_OQ.getCode();
            result = appUserInfoService.findByCondition(request);
        }else if(roles.contains(StaffInfoRoleEnum.B_BTL.getCode())){
            // 团队长，可以查看其下所有地推人员所对应的用户
            role = StaffInfoRoleEnum.B_BTL.getCode();
            StaffInfoDTO staffInfoDTO = staffInfoSaoService.getStaffInfoByUserId(userId);
            //根据机构查询所有的客户经理
            List<String> list = staffInfoSaoService.getUserIds(staffInfoDTO.getBranchNo());
            log.info("地推人员列表: {}", list);
            //如果团队长下没有地推人员，直接返回
            if (CollectionUtils.isEmpty(list)) {
                return new PageResult<>();
            }
            request.setLists(list);
            result = appUserInfoService.findByCondition(request);
        }else if (roles.contains(StaffInfoRoleEnum.B_GPS.getCode())){
            // 地推人员，只能查看其下所对应的用户
            role = StaffInfoRoleEnum.B_GPS.getCode();
            List<String> list = Lists.newArrayList(userId.toUpperCase(),userId.toLowerCase());
            request.setLists(list);
            result = appUserInfoService.findByCondition(request);
        }else{
            return new PageResult<>();
        }
        return this.resultConvert(result, request.getPageNum(), role);
    }

    private PageResult<AppUserQueryResult> resultConvert(Page<AppUserInfo> args, long pageNow, String role){
        //账户名，手机号，账号状态，是否高级用户，分公司，客户经理,用户归属
        List<AppUserQueryResult> result = Lists.newArrayList();
        for (AppUserInfo app : args.getContent()){
            AppUserQueryResult target = new AppUserQueryResult();
            BeanUtils.copyProperties(app, target);
            // 账号状态
            String enabledDes;
            if (app.getEnableEecommendation() == null || app.getEnabled() == null){
                enabledDes = "正常";
            }else{
                enabledDes = !app.getEnableEecommendation() ? "禁止进件" : app.getEnabled() ? "正常"  : "禁止";
            }
            target.setEnabledDes(enabledDes);

            //查询分公司/归属城市
            String businessCityid = app.getBusinessCityid();
            if (StringUtils.isNotEmpty(businessCityid)){
                //查询分公司
                BranchInfoDTO branchInfo = branchInfoService.getBranchByBranchNo(SysIdEnum.WRK.getValue(), businessCityid);
                BranchInfoDTO businessCity = branchInfoService.getBusinessCity(branchInfo, BranchInfoDTO.BranchType.BRANCH_COMPANY.name());
                target.setBusinessCityName(businessCity.getName());
                target.setBusinessCityid(businessCity.getBranchNo());
                //归属城市
                BranchInfoDTO ascriptionCity = branchInfoService.getBusinessCity(branchInfo, BranchInfoDTO.BranchType.CITY.name());
                target.setAscriptionCityid(ascriptionCity.getBranchNo());
            }

            //注册城市
            if (StringUtils.isNotEmpty(app.getRegisterCityid())) {
                BaseInfoDto baseInfo = baseInfoService.getBaseInfoBySysIdAndTypeAndCode(SysIdEnum.WRK.getValue(), BaseInfoTypeEnum.CITIEID.getType(), app.getRegisterCityid());
                if (baseInfo == null){
                    baseInfo = baseInfoService.getBaseInfoBySysIdAndTypeAndCode(SysIdEnum.WRK.getValue(), BaseInfoTypeEnum.AREA.getType(), app.getRegisterCityid());
                }
                target.setRegisterCityName(baseInfo.getValue());
            }

            //类别
            target.setUserType(app.getAppRoles().contains("SUPER_AGENT") ? "高级用户" : "普通用户");
            //是否高级用户
            target.setSuperAgent(app.getAppRoles().contains("SUPER_AGENT"));
            //注册时间
            target.setCreatedDataAt(DateUtil.localDateTimeToString(app.getCreatedAt()));
            //staffInfo 中 userId 为小写
            if (StringUtils.isNotEmpty(target.getReferrer())){
                target.setReferrer(target.getReferrer().toLowerCase());
            }

            //角色判断
            target.setRole(role);
            //归属状态
            target.setAscriptionStatusDesc(app.getAscriptionStatus() == null || app.getAscriptionStatus()?"正常":"禁止");

            /* ***************** 用户管理 ******************/
            //是否绑定微信
            target.setHasWeChat(StringUtils.isNotEmpty(app.getOpenid()));

            /* ***************** 用户变更 ******************/
            //居住地址
            AddressInfo live = addressInfoService.findByAgentNoAndAddressType(app.getMongoId(), "02");
            if (live != null){
                target.setLiveProvince(live.getProvince());
                target.setLiveCity(live.getCity());
                target.setLiveArea(live.getArea());
                target.setLiveAddress(live.getAddress());
            }

            //工作地址
            AddressInfo work = addressInfoService.findByAgentNoAndAddressType(app.getMongoId(), "03");
            if (work != null) {
                target.setWorkProvince(work.getProvince());
                target.setWorkCity(work.getCity());
                target.setWorkArea(work.getArea());
                target.setWorkAddress(work.getAddress());
            }
            result.add(target);
        }

        PageResult<AppUserQueryResult> pageResult = new PageResult<>();
        pageResult.setList(result);
        pageResult.setPageCount(args.getTotalPages());
        pageResult.setPageNow(pageNow);
        pageResult.setRowCount(args.getTotalElements());
        return pageResult;
    }

    /**
     * 用户管理
     */
    public ResponseInfo<?> saveManage(AppUserManageRequest request){
        String userId = ContextHolder.getUserId();
        log.info("当前用户 usrId：{}", userId);
        List<String> roles = userRoleInfoService.getValidRolesByUserId(userId);
        if (!roles.contains(StaffInfoRoleEnum.H_OQ.getCode())) {
            return new ResponseInfo<>("999", "非总部运营岗无此权限", false);
        }

        AppUserInfo result = appUserInfoService.findByCellphone(request.getCellphone());
        String oldAscription = result.getAscription();  //旧归属
        String newAscription = null;                    //新归属
        BeanUtils.copyProperties(request,result);
        result.setReferrer(request.getReferrer().toUpperCase());
        if (StringUtils.isNotEmpty(request.getReferrer())) {
            StaffInfoDTO staffInfoDTO = staffInfoSaoService.getStaffInfoByUserId(request.getReferrer());
            if (staffInfoDTO != null) {
                result.setRefererName(staffInfoDTO.getStaffName());
                //根据客户经理查询部门
                BranchInfoDTO branchInfo = branchInfoService.getBranchByBranchNo(SysIdEnum.WRK.getValue(), staffInfoDTO.getBranchNo());
                newAscription = branchInfo.getAscription();
                //归属日志
                appuserAscriptionLogService.add(result.getMongoId(), newAscription, oldAscription, null);
                result.setAscription(newAscription);
                result.setAscriptionStatus(true);
            }
        }
        result.setBusinessCityid(request.getBusinessCityid());
        return ResponseInfo.success(appUserInfoUtilService.updateAppUser(result));
    }

    /**
     * 信息变更
     */
    public ResponseInfo<?> saveDetail(AppUserDetailRequest request) {
        String userId = ContextHolder.getUserId();
        log.info("当前用户 usrId：{}", userId);
        List<String> roles = userRoleInfoService.getValidRolesByUserId(userId);
        if (!roles.contains(StaffInfoRoleEnum.H_OQ.getCode())) {
            return new ResponseInfo<>("999", "非总部运营岗无此权限", false);
        }
        //校验身份证号
        String identityNumber = request.getIdentityNumber();
        if (StringUtils.isNotEmpty(identityNumber) && !RegexUtil.checkIdentityNumber(identityNumber)) {
            return new ResponseInfo<>("0001", "请输入合法的身份证号", null);
        }

        AppUserInfo appUser = appUserInfoService.findById(request.getId());
        BeanUtils.copyProperties(request,appUser);
        AppUserInfo userInfo = appUserInfoUtilService.updateAppUser(appUser);

        //居住地址
        addressInfoService.save(appUser.getMongoId(), request.getLiveProvince(), request.getLiveCity(),
                request.getLiveArea(), request.getLiveAddress(), "02");

        //工作地址
        addressInfoService.save(appUser.getMongoId(), request.getWorkProvince(), request.getWorkCity(),
                request.getWorkArea(), request.getWorkAddress(), "03");
        return ResponseInfo.success(userInfo);
    }

    /**
     *  禁止/激活进件
     * @param id    主键id
     * @param enableEecommendation  true/false
     * @return 用户信息
     */
    public ResponseInfo<?> enableRecommendation(Long id, Boolean enableEecommendation){
        if (StringUtils.isEmpty(id.toString())) return ResponseInfoDTO.error("参数不能为空");
        String userId = ContextHolder.getUserId();
        log.info("当前用户 usrId：{}", userId);
        List<String> roles = userRoleInfoService.getValidRolesByUserId(userId);
        boolean isH_OQ = roles.contains(StaffInfoRoleEnum.H_OQ.getCode());
        if (!isH_OQ) {
            return ResponseInfoDTO.error("非总部运营岗无此权限");
        }

        AppUserInfo result = appUserInfoService.findById(id);
        result.setEnableEecommendation(enableEecommendation);
        return ResponseInfo.success(appUserInfoService.save(appUserInfoUtilService.updateAppUser(result)));
    }

    public List<BaseInfoDto> initBusinessCity(String sysId, String type){
        return baseInfoSaoService.getBaseInfoBySysIdAndType(sysId, type);
    }

    public List<StaffInfoDTO> getStaffInfoByBranchNo(String branchNo){
        return staffInfoSaoService.getStaffInfoByBranchNo(StaffInfoRoleEnum.B_GPS.getCode(), branchNo);
    }

    public ResponseInfo<?> getBusinessCity(String branchNo){
        BranchInfoDTO branchInfo = branchInfoService.getBranchByBranchNo(SysIdEnum.WRK.getValue(), branchNo);
        if (branchInfo == null){
            return new ResponseInfo<>("9999", "未查出到对应的业务城市", false);
        }
        BranchInfoDTO businessCity = branchInfoService.getBusinessCity(branchInfo, BranchInfoDTO.BranchType.BRANCH_COMPANY.name());
        return ResponseInfo.success(businessCity.getBranchNo());
    }

    public ResponseInfo<?> batchUpdateReferer(String flag, HttpServletRequest reqeust) {
        try {
            InputStream inputStream = getInputStream(reqeust);
            return ResponseInfo.success(this.analyseExcel(inputStream, flag));
        }catch (Exception e){
            return ResponseInfoDTO.error(e.getMessage());
        }
    }

    public ResponseInfo<?> batchUpdateIscredit(String flag, HttpServletRequest reqeust) {
        try {
            InputStream inputStream = this.getInputStream(reqeust);
            return ResponseInfo.success(this.analyseExcel(inputStream, flag));
        }catch (Exception e){
            return ResponseInfoDTO.error(e.getMessage());
        }
    }

    private InputStream getInputStream(HttpServletRequest reqeust) throws Exception {
        String userId = ContextHolder.getUserId();
        log.info("当前用户 usrId：{}", userId);
        List<String> roles = userRoleInfoService.getValidRolesByUserId(userId);
        boolean isH_OQ = roles.contains(StaffInfoRoleEnum.H_OQ.getCode());
        if (!isH_OQ) {
            throw new Exception("非总部运营岗无此权限！");
        }

        MultipartFile multipartFile = HttpMultipartUtils.getMultipartFile(reqeust);
        if (multipartFile.isEmpty() ) {
            throw new Exception("请上传文件！");
        }
        return multipartFile.getInputStream();
    }

    private String analyseExcel(InputStream fileInputStream, String flag) throws IOException {
        Workbook wb = new XSSFWorkbook(fileInputStream);
        if (wb.getNumberOfSheets() < 0) {
            throw new RuntimeException("没有工作表");
        }
        Sheet sheet = wb.getSheetAt(0);
        StringBuilder message = new StringBuilder("");

        int succeedCount = 0;
        int failedCount = 0;
        List<String> errorMsgs = new ArrayList<>();

        for (int rowNum = 1; rowNum <= sheet.getLastRowNum(); rowNum++) {
            Row row = sheet.getRow(rowNum);
            try {
                Cell cell = row.getCell(0);
                if (cell==null){
                    throw new RuntimeException("人员不存在");
                }
                cell.setCellType(CellType.STRING);
                String cellphone = cell.getStringCellValue();
                if (StringUtils.isEmpty(cellphone.trim())) {
                    break;
                }
                AppUserInfo appUser = appUserInfoService.findByCellphone(cellphone.trim());
                if (appUser == null) {
                    throw new RuntimeException("人员不存在");
                }

                if ("1".equals(flag)){      // 批量导入修改客户经理
                    appUser  = this.getReferer(row, appUser);
                }else {                     //批量修改客户信用标志
                    appUser = this.getIsCredit(row, appUser);
                }
                appUserInfoUtilService.updateAppUser(appUser);
                succeedCount++;
            }
            catch (Exception e) {
                failedCount++;
                errorMsgs.add("第" + rowNum+ "行导入失败,原因：" + e.getMessage() + "<br/>");
            }
        }
        message.append("导入完毕<br/>");
        message.append("成功" + succeedCount + "条<br/>");
        if (failedCount > 0) {
            message.append("失败" + failedCount + "条<br/>");
            message.append("<hr/><br/>");
            for (String errorMsg : errorMsgs) {
                message.append(errorMsg);
            }
        }
        return message.toString();
    }

    private AppUserInfo getReferer(Row row, AppUserInfo appUser) {
        String referer = row.getCell(1) == null ? "" : row.getCell(1).getStringCellValue();
        if (StringUtils.isNotEmpty(referer.trim())) {
            StaffInfoDTO staffInfoDTO = staffInfoSaoService.getStaffInfoByUserId(referer.trim());
            if (staffInfoDTO != null) {
                appUser.setReferrer(staffInfoDTO.getUserId().toUpperCase());
                appUser.setRefererName(staffInfoDTO.getStaffName());

                //用户归属
                String oldAscription = appUser.getAscription();     //旧归属
                BranchInfoDTO branchInfo = branchInfoService.getBranchByBranchNo(SysIdEnum.WRK.getValue(), staffInfoDTO.getBranchNo());
                String newAscription = branchInfo.getAscription();
                appUser.setAscription(newAscription);                //新归属
                appUser.setAscriptionStatus(true);
                appuserAscriptionLogService.add(appUser.getMongoId(), newAscription, oldAscription, null);

                ResponseInfo<?> responseInfo = this.getBusinessCity(staffInfoDTO.getBranchNo());
                if (responseInfo.isSuccess()){
                    appUser.setBusinessCityid(responseInfo.getData().toString());
                }else {
                    throw new RuntimeException("未查出到对应的业务城市");
                }
            }else{
                throw new RuntimeException("未查出到对应的地推人员");
            }
        }else{
            throw new RuntimeException("请输入地推人员信息");
        }
        return appUser;
    }

    private AppUserInfo getIsCredit(Row row, AppUserInfo appUser) {
        String iscredit = "";
        if(row.getCell(1)!=null){
            iscredit = row.getCell(1).getStringCellValue();
        }
        if (StringUtils.isNotEmpty(iscredit)) {
            appUser.setIscredit(iscredit.trim());
        }else{
            appUser.setIscredit("N");
        }
        return appUser;
    }

    public ResponseInfo<?> listToPush(AppUserQueryParameter request) {
        List<String> ascriptions = null;    //归属集合
        List<String> businessCityids = null;  //业务城市集合
        if (StringUtils.isNotEmpty(request.getAscription())) {
            String[] arr = StringUtils.split(request.getAscription(), ",");
            ascriptions = Arrays.asList(arr);
        }
        if (StringUtils.isNotEmpty(request.getBusinessCityid())) {
            String[] arr = StringUtils.split(request.getBusinessCityid(), ",");
            businessCityids = Arrays.asList(arr);
        }
        request.setAscriptions(ascriptions);
        request.setBusinessCityids(businessCityids);
        Page<AppUserInfo> args = appUserInfoService.findByCondition(request);

        PageResult<AppUserInfo> pageResult = new PageResult<>();
        pageResult.setList(args.getContent());
        pageResult.setPageCount(args.getTotalPages());
        pageResult.setPageNow(request.getPageNum());
        pageResult.setRowCount(args.getTotalElements());
        return ResponseInfo.success(pageResult);
    }

}

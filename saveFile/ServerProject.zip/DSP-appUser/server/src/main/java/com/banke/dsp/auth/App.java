package com.banke.dsp.auth;

import com.banke.bkc.framework.starter.Starter;
import com.banke.bkc.message.annotation.EnableMessage;
import com.banke.bkc.service.annotation.EnableService;

@SuppressWarnings("WeakerAccess")
@EnableMessage // 不使用消息总线时去掉
@EnableService
public class App {
    public static void main(String[] args) {

        Starter.run(args);
    }
}

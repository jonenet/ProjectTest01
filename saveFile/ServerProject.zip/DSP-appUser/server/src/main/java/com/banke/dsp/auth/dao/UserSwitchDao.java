package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.po.UserSwitchInfo;
import org.springframework.data.repository.CrudRepository;

import java.util.List;


public interface UserSwitchDao extends CrudRepository<UserSwitchInfo,Long> {

    UserSwitchInfo findByAgentNoAndName(String agentNo, String name);

    List<UserSwitchInfo> findAllByAgentNo(String agentNo);

    UserSwitchInfo findUserSwitchByAgentNoAndName(String agentNo, String name);
}

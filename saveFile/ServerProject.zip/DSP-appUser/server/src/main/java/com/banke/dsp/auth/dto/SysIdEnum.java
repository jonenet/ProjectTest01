package com.banke.dsp.auth.dto;

/**
 *  系统类型
 * Created by ex-zhongbingguo on 2017/9/18.
 */
public enum SysIdEnum {
    WRK(10, "WRK"),
    DSP(20, "DSP");

    private Integer code;
    private String value;

    SysIdEnum(Integer code, String value) {
        this.code = code;
        this.value = value;
    }

    public Integer getCode() {
        return code;
    }

    public String getValue() {
        return value;
    }
}

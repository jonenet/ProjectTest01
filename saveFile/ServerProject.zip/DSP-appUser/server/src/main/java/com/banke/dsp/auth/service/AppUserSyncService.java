package com.banke.dsp.auth.service;

import com.banke.bkc.message.annotation.QueueConfig;
import com.banke.bkc.message.handler.MessageSender;
import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.util.SyncHelper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AppUserSyncService {

    @QueueConfig(queue = "dsp.appUser.sync")
    private MessageSender<AppUserInfo> messageSender;

    @SuppressWarnings("unused")
    public void setMessageSender(MessageSender<AppUserInfo> messageSender) {
        this.messageSender = messageSender;
        SyncHelper.setSyncService(this);
    }

    public void sendMessage(AppUserInfo target, String operation){
        messageSender.send("appUser", operation, target);
    }
}

package com.banke.dsp.auth.util;

import com.banke.dsp.auth.util.com.qcloud.Module.Wenzhi;
import com.banke.dsp.auth.util.com.qcloud.QcloudApiModuleCenter;
import com.banke.dsp.auth.util.com.qcloud.Utilities.Json.JSONObject;
import org.apache.commons.lang3.StringUtils;

import java.util.TreeMap;

public class TextSensitivity {

    public static final String SECRET_ID = "AKIDwnndQBwNisqdEn9YmqjVDk5FH7xcnPWS";
    public static final String SECRET_KEY = "tb8UkstncHl3C9vcAapuoX5SehYEmGes";

    public static boolean checkSensitive(String content) {
        try {

            if (StringUtils.isNotBlank(content)) {
                /* 如果是循环调用下面举例的接口，需要从此处开始你的循环语句。切记！ */
                JSONObject json_result;
                double sensitive;
                double nonsensitive;
                do {
                    TreeMap<String, Object> config = new TreeMap<String, Object>();
                    config.put("SecretId", SECRET_ID);
                    config.put("SecretKey", SECRET_KEY);
                /* 请求方法类型 POST、GET */
                    config.put("RequestMethod", "POST");
                /* 区域参数，可选: gz:广州; sh:上海; hk:香港; ca:北美;等。 */
                    config.put("DefaultRegion", "sz");
                    QcloudApiModuleCenter module = new QcloudApiModuleCenter(new Wenzhi(), config);
                    TreeMap<String, Object> params = new TreeMap<>();
                    params.put("content", content);
                    params.put("type", 2);
                /* call 方法正式向指定的接口名发送请求，并把请求参数params传入，返回即是接口的请求结果。 */
                    json_result = new JSONObject(module.call("TextSensitivity", params));
                    System.out.println(json_result);
                } while (json_result.get("code").equals("0"));
                sensitive = (double) json_result.get("sensitive");
                nonsensitive = (double) json_result.get("nonsensitive");
                return sensitive > nonsensitive ? true : false;
            }
        } catch (Exception e) {
            System.out.println("error..." + e.getMessage());
        }
        return false;
    }
}

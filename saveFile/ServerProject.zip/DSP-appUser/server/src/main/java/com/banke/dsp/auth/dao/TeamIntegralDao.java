package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.dto.team.MemberShowInfo;
import com.banke.dsp.auth.po.TeamIntegral;
import com.banke.dsp.auth.po.TeamMemberInfo;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import javax.transaction.Transactional;
import java.util.List;


public interface TeamIntegralDao extends CrudRepository<TeamIntegral, Long>, JpaSpecificationExecutor {



    /**
     * 获取团队积分(一个季度) 首页
     * @param teamNo
     * @return
     */
    @Query(value = "select sum(t.new_integral) from team_integral t where t.team_no =?1 and "+
            "QUARTER(t.created_date)=QUARTER(now()) and  YEAR(t.created_date)=YEAR(NOW())", nativeQuery = true)
    Integer getTeamIntegralSumIndex(String teamNo);

    /**
     * 获取每个团队总积分(一个季度) 首页
     * @return
     */
    @Query(value = "select sum(t.new_integral) as totalIntegral,t.team_no  from team_integral t ,team_info m where t.team_no = m.team_no and m.status <> 'DELETE' "+
            " and QUARTER(t.created_date)=QUARTER(now()) and YEAR(t.created_date)=YEAR(NOW()) group by t.team_no", nativeQuery = true)
    List<Object[]>  getTeamIntegralSumOrderBy();

    /**
     * 获取每个团队积分详情(一个季度)
     * @return
     */
    @Query(value = "select * from team_integral t where QUARTER(t.created_date)=QUARTER(now()) "+
            " and  YEAR(t.created_date)=YEAR(NOW()) "+
            " and t.team_no = ?1 order by t.created_date desc limit 100", nativeQuery = true)
    List<TeamIntegral>  getTeamIntegralInfoByTeamNo(String teamNo);


}

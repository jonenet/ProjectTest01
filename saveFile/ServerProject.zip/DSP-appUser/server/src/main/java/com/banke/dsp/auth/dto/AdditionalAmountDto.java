package com.banke.dsp.auth.dto;

import com.banke.bkc.framework.util.CodeEnum;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Transient;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Created by ex-taozhangyi on 2018/3/9.
 */
@Data
public class AdditionalAmountDto {
    /**
     * 业务员编码(客户)
     */
    private String agentNo;


    /**
     * 电话号码
     */
    private String agentPhone;


    /**
     * 奖励类型
     */

    @Enumerated(EnumType.STRING)
    private AwardType awardType;


    /**
     * 奖励金额
     */
    private BigDecimal awardAmount;


    /**
     * 客户身份证号
     */
    private String clientIdNo;


    /**
     * 客户姓名
     */
    private String clientName;


    /**
     * 放款金额
     */
    private BigDecimal loanAmount;


    /*备注*/
    private String remark;

    /*费用归属 手动录入时需要*/
    private String homeOwner;


    /**
     * 录入人
     */

    private String enteringUserId;


    /**
     * 录入时间
     */

    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime enteringDate;


    /**
     * 业务机构(分公司)
     */
    private String inputOrgId;


    /**
     * 保存信息
     */
    @Transient
    private String msg;

    /**
     * 序号
     */
    @Transient
    private Integer sque;


    /**
     * 是否保存成功
     */
    @Transient
    private Boolean isSucess;

    /**
     * 奖励类型
     */
    public enum AwardType {
        SIGN("SIGN")/*面签奖励*/,
        LOAN("LOAN") /*放款奖励*/,
        ACTIVITIES("ACTIVITIES")/*活动奖励*/,
        TASK("TASK")/*任务奖励*/,
        RED("RED") /*红包奖励*/,
        INVITATION("INVITATION")/*邀请奖励*/,
        LIVELY("LIVELY")/*活跃奖励*/,
        OFFLINE("OFFLINE"),/*线下佣金*/
        WITHHOLDING("WITHHOLDING"),/*代扣佣金*/
        LEADER("LEADER"),/*团队长佣金*/
        ZOFFLINE("ZOFFLINE"),/*转线下佣金*/
        THREEPRD("THREEPRD"),/*三方产品佣金*/
        WXLOAN("WXLOAN"),
        MEMBER("MEMBER");//团员佣金
        ;

        AwardType(String val) {
            CodeEnum.init(this, val);
        }
    }

}

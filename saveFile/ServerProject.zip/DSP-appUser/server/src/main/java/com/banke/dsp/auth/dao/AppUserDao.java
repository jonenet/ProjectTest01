package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.po.AppUserInfo;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface AppUserDao extends CrudRepository<AppUserInfo, Long> ,JpaSpecificationExecutor<AppUserInfo> {

    //通过token查询用户信息
    AppUserInfo findByToken(String token);

    //用户名查询用户信息
    AppUserInfo findByCellphone(String userName);

    //用户名查询用户信息
    AppUserInfo findByMongoId(String mongoId);

    AppUserInfo findByUserName(String userName);

    AppUserInfo findById(Long id);

    List<AppUserInfo> findAll();

    Page<AppUserInfo> findAll(Pageable pageReq);

    @Query("select a from AppUserInfo a where 1=1 " +
            " and (:#{#star==null} = true or a.star=:star) " +
            " and (:#{#appRoles.isEmpty()} = true or a.appRoles=:appRoles) " +
            " and (:#{#popularizeTypeId.isEmpty()} = true or a.popularizeTypeId=:popularizeTypeId) "+
            " and (:#{#businessCityid.isEmpty()} = true or a.businessCityid=:businessCityid) "+
            " and (:#{#job.isEmpty()} = true or a.job=:job)")
    //type  star   role popularizeType businessCityId  jobCode
    Page<AppUserInfo> getAppuserByList(@Param("star") Integer star,
                                       @Param("appRoles") String appRolesappRoles,
                                       @Param("popularizeTypeId") String popularizeTypeId,
                                       @Param("businessCityid") String businessCityid,
                                       @Param("job") String job,Pageable pageReq);

    @Query("select a from AppUserInfo a where a.mongoId in :agentNoList and a.appRoles not like :appRoles")
    List<AppUserInfo> findByAgentNoList(@Param("agentNoList") List<String> agentNoList, @Param("appRoles") String appRoles);

    /**
     *  查询客户经理 用户的权限信息
     * @param referrer 客户经理（汉字或者拼音大写）
     * @return
     */
    @Query(value = " select a.referer_name,a.referrer,a.credit_way,count(a.referrer) from appuser_info a " +
            "where (:#{#manager.isEmpty()}=true or  a.referrer in (upper(:manager),lower(:manager)) )" +
            " and (:#{#referrer.isEmpty()}=true or  a.referer_name = :referrer ) " +
            "     group by a.referer_name,a.referrer,a.credit_way ",nativeQuery = true)
    List<Object[]> findByReferrerUsers(@Param("referrer") String referrer,@Param("manager") String manager);

    /**
     * 根据 客户经理和权限状态修改 权限  （creditWay 是null）
     * @param newcreditWay 新的权限
     * @param updatedBy  修改人
     * @param referrer  要去修改的客户经理全拼
     * @return
     */
    @Modifying
    @Query("update AppUserInfo set isNeedCredit = 1,creditWay = :newcreditWay,updatedBy = :updatedBy,updatedDate =now() " +
            " where referrer=:referrer and creditWay is null")
    Integer updateReferrerUsersNull(@Param("newcreditWay") String newcreditWay,@Param("updatedBy") String updatedBy,
                                @Param("referrer") String referrer);

    /**
     * 根据 客户经理和权限状态修改 权限
     * @param newcreditWay 新的权限
     * @param updatedBy  修改人
     * @param referrer  要去修改的客户经理全拼
     * @return
     */
    @Modifying
    @Query("update AppUserInfo set isNeedCredit = 1,creditWay = :newcreditWay,updatedBy = :updatedBy,updatedDate =now() " +
            " where referrer=:referrer and creditWay = :oldcreditWay")
    Integer updateReferrerUsers(@Param("newcreditWay") String newcreditWay,@Param("updatedBy") String updatedBy,
                                @Param("referrer") String referrer,@Param("oldcreditWay") String oldcreditWay);

    AppUserInfo findByOpenid(String openid);
}

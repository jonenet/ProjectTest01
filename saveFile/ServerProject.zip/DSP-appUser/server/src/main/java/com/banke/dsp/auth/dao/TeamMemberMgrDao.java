package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.dto.team.MemberShowInfo;
import com.banke.dsp.auth.po.TeamMemberInfo;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import javax.transaction.Transactional;
import java.util.List;

/**
 * 团队管理-运营后台使用
 */
public interface TeamMemberMgrDao extends CrudRepository<TeamMemberInfo, Long>, JpaSpecificationExecutor {

    /**
     * 根据团队编号和团队角色查询，此处仅用来查询leader
     * @param teamNo
     * @param teamRole
     * @param status
     * @return
     */
    TeamMemberInfo findByTeamNoAndTeamRoleAndStatus(String teamNo, String teamRole, String status);

    /**
     * 根据团队编号和成员状态查询
     * @param teamNo
     * @param status
     * @return
     */
    List<TeamMemberInfo> findByTeamNoAndStatus(String teamNo, String status);

    /**
     * 根据用户编号及团队角色查询，用于确认该成员是否存在对应的角色
     * @param agentNo
     * @param teamRole
     * @param status
     * @return
     */
    TeamMemberInfo findByAgentNoAndTeamRoleAndStatus(String agentNo, String teamRole, String status);

    /**
     * 更新团员的团队状态
     * @param teamNo
     * @param agentNo
     * @return
     */
    @Transactional
    @Modifying
    @Query("update TeamMemberInfo set status='DELETE',leave_date=now() where team_no=?1 and agent_no=?2 and status!='DELETE'")
    int removeTeamMember(String teamNo, String agentNo);

    /**
     * 根据团队编号及团员id更新他的团队身份
     * @param teamRole
     * @param teamNo
     * @param agentNo
     * @return
     */
    @Modifying
    @Query("update TeamMemberInfo set team_role=?1 where team_no=?2 and agent_no=?3")
    int updateTeamRole(String teamRole, String teamNo, String agentNo);

    /**
     * 更新团队下所有成员的状态，用于团队解散时
     * @param teamNo
     * @return
     */
    @Modifying
    @Query("update TeamMemberInfo set status='DELETE', operation_type='OPT_BY_OPERATE', leave_date=now() where team_no=?1 and status!='DELETE'")
    int removeAllTeamMember(String teamNo);

    long countByTeamNo(String teamNo);

    long countByTeamNoAndStatusNot(String teamNo,String status);

    /**
     * 查询团队本月推单数
     * @param teamNo
     * @return
     */
    @Query(value = "select count(1) from team_member_info m left join apply_info a on m.agent_no = a.agent_no " +
            " where m.team_no=?1 and a.apply_date>m.join_date and DATE_FORMAT(a.apply_date,'%Y%m')=DATE_FORMAT(CURDATE(),'%Y%m') " +
            "and (m.leave_date is null || a.apply_date>m.leave_date)" +
            "  and m.status <> 'DELETE' "+
            " and (" +
            "(a.task_id = '02' and a.apply_status = 'FFF') " +
            "or (a.task_id = '05' and a.apply_status in ('F00','F01','F02','F03','F04','FFF')) " +
            "or (a.task_id = '07' and a.apply_status in ('F00','F01','F02','F03','F04','FFF')) " +
            "or (a.task_id not in ('02','05','07') and a.apply_status not in ('000','C00','U01','CCL','R01'))" +
            ")", nativeQuery = true)
    int getApplyCountByTeam(String teamNo);

    /**
     * 查询团队本月放款总额
     * @param teamNo
     * @return
     */
    @Query(value = "select sum(o.trans_amount) from team_member_info m left join order_info o on m.agent_no=o.agent_no " +
            "where m.team_no=?1 and o.trans_date>m.join_date and DATE_FORMAT(o.trans_date,'%Y%m')=DATE_FORMAT(CURDATE(),'%Y%m') " +
            "  and m.status <> 'DELETE' "+
            "and o.order_status = 'FFF' and (m.leave_date is null || o.trans_date>m.leave_date)", nativeQuery = true)
    Double getOrderAmountByTeam(String teamNo);

    /**
     *团队成功放款笔数   FFF  （本月）
     * @param teamNo
     * @return
     */
    @Query(value = "select count(1) from team_member_info m left join order_info o on m.agent_no=o.agent_no"+
            "  where m.team_no=?1 "+
            "  and o.trans_date>m.join_date "+
            "  and m.status <> 'DELETE' "+
            "  and o.order_status ='FFF' "+
            "  and (m.leave_date is null || o.trans_date>m.leave_date)"+
            "  and DATE_FORMAT(o.trans_date,'%Y%m')=DATE_FORMAT(CURDATE(),'%Y%m')", nativeQuery = true)
    int countSuccessLoanM(String teamNo);

    /**
     * 查询个人本月推单数
     * @param agentNo
     * @return
     */
    @Query(value = "select count(1) from apply_info where agent_no=?1 " +
            "and apply_status not in ('000','C00','U01','CCL','R01') and DATE_FORMAT(apply_date,'%Y%m')=DATE_FORMAT(CURDATE(),'%Y%m') ", nativeQuery = true)
    long getApplyCountByAgent(String agentNo);

    /**
     * 查询个人本月放款总额
     * @param agentNo
     * @return
     */
    @Query(value = "select sum(trans_amount) from order_info where agent_no=?1 and order_status = 'FFF' and DATE_FORMAT(trans_date,'%Y%m')=DATE_FORMAT(CURDATE(),'%Y%m')", nativeQuery = true)
    Double getOrderAmountByAgent(String agentNo);

    /**
     * 查询成员信息
     * @param cellphone
     * @return
     */
    @Query("select NEW com.banke.dsp.auth.dto.team.MemberShowInfo(t.mongoId, t.cellphone, t.businessCityid, " +
            "m.id, m.teamNo, m.teamRole, m.status)" +
            " from AppUserInfo t left join TeamMemberInfo m on t.mongoId=m.agentNo where  m.status <> 'DELETE' and t.cellphone=?1")
    List<MemberShowInfo> searchMemberInfo(String cellphone);

    /**
     * 查询团队近三个月推单数
     * @param teamNo
     * @return
     */
    @Query(value = "select count(1) from team_member_info m left join apply_info a on m.agent_no = a.agent_no " +
            " where m.team_no=?1 and a.apply_date>m.join_date " +
            " and (m.leave_date is null || a.apply_date>m.leave_date)" +
            "  and m.status <> 'DELETE' "+
            " and (" +
            " (a.task_id = '02' and a.apply_status = 'FFF') " +
            " or (a.task_id = '05' and a.apply_status in ('F00','F01','F02','F03','F04','FFF')) " +
            " or (a.task_id = '07' and a.apply_status in ('F00','F01','F02','F03','F04','FFF')) " +
            " or (a.task_id not in ('02','05','07') and a.apply_status not in ('000','C00','U01','CCL','R01')))" +
            " and QUARTER(a.apply_date)=QUARTER(now()) and  YEAR(a.apply_date)=YEAR(NOW())", nativeQuery = true)
    int getApplyCountByTeamAndTime(String teamNo);


//    /**
//     * 查询团队近三个月推单数(第三方)
//     * @param teamNo
//     * @return
//     */
//    @Query(value = "select count(1) from team_member_info m left join apply_info a on m.agent_no = a.agent_no " +
//            " where m.team_no=?1 and a.apply_date>m.join_date and DATE_FORMAT(a.apply_date,'%Y%m')>=DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL ?2 MONTH),'%Y%m') " +
//            "and (m.leave_date is null || a.apply_date>m.leave_date)" +
//            " and a.product_no not in (?3)"+
//            " and (" +
//            "(a.task_id = '02' and a.apply_status = 'FFF') " +
//            "or (a.task_id = '05' and a.apply_status in ('F00','F01','F02','F03','F04','FFF')) " +
//            "or (a.task_id not in ('02','05') and a.apply_status not in ('000','C00','U01','CCL'))" +
//            ")", nativeQuery = true)
//    int getApplyCountByTeamAndTimeThird(String teamNo,int m,String[] array);



    /**
     *团队成功放款笔数   FFF  （本季度）
     * @param teamNo
     * @return
     */
    @Query(value = "select count(1) from team_member_info m left join order_info o on m.agent_no=o.agent_no"+
            "  where m.team_no=?1 "+
            "  and o.trans_date>m.join_date "+
            "  and o.order_status ='FFF' "+
            "  and m.status <> 'DELETE' "+
            "  and (m.leave_date is null || o.trans_date>m.leave_date)"+
            "  and QUARTER(o.trans_date)=QUARTER(now()) and  YEAR(o.trans_date)=YEAR(NOW())", nativeQuery = true)
    int countSuccessLoanQuarter(String teamNo);

    /**
     *团队成功放款笔数(第三方)   FFF
     * @param teamNo
     * @return
     */
    @Query(value = "select count(1) from team_member_info m left join order_info o on m.agent_no=o.agent_no"+
            "  where m.team_no=?1 "+
            "  and o.trans_date>m.join_date "+
            "  and o.order_status ='FFF' "+
            "  and o.product_no not in (?2) "+
            "  and m.status <> 'DELETE' "+
            "  and (m.leave_date is null || o.trans_date>m.leave_date)"+
            "  and QUARTER(o.trans_date)=QUARTER(now()) and  YEAR(o.trans_date)=YEAR(NOW())", nativeQuery = true)
    int countSuccessThirdLoan(String teamNo,String [] array);

    /**
     * 查询团队推单数(第三方)  （季度）
     * @param teamNo
     * @return
     */
    @Query(value = "select count(1) from team_member_info m left join order_info a on m.agent_no = a.agent_no"+
            "  where m.team_no = ?1 and a.apply_date > m.join_date"+
            "  and m.status <> 'DELETE' "+
            "  and (m.leave_date is null || a.apply_date>m.leave_date)"+
            "  and a.product_no not in (?2)"+
            "  and QUARTER(a.apply_date)=QUARTER(now()) and  YEAR(a.apply_date)=YEAR(NOW())", nativeQuery = true)
    int getApplyCountByTeam(String teamNo,String [] array);


    /**
     * 查询团队本季度活跃人数
     * @param teamNo
     * @return
     */
    @Query(value = "select t.agent_no from apply_info t, team_member_info m where t.agent_no = m.agent_no and m.team_no = ?1 and t.apply_date > m.join_date "+
            " and (m.leave_date is null || t.apply_date>m.leave_date)"+
            " and m.`status`<>'DELETE'"+
            " and ((t.task_id = '02' and t.apply_status = 'FFF')"+
            " or (t.task_id = '05' and t.apply_status in ('F00','F01','F02','F03','F04','FFF'))"+
            " or (t.task_id = '07' and t.apply_status in ('F00','F01','F02','F03','F04','FFF'))"+
            " or (t.task_id = '01' and t.apply_status not in ('000','C00','U01','CCL','R01')) "+
            " or (t.task_id = '03' and t.apply_status not in ('000','C00','U01','CCL','R01')) "+
            " and QUARTER(t.apply_date)=QUARTER(now()) and  YEAR(t.apply_date)=YEAR(NOW()))"+
            " group by t.agent_no ", nativeQuery = true)
    List<String> getApplyCountByTeamActive(String teamNo);

}

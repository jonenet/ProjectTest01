package com.banke.dsp.auth.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Created by ex-taozhangyi on 2018/3/9.
 */
@Data
public class TeamCommissionDto {
    /**
     * 用户手机号
     */
    private String cellphone;

    /**
     * 团长或团员ID
     */
    private String agentNo;


    /**
     * 团队编号
     */
    private String teamNo;

    /**
     * 佣金产生时间
     */
    @JsonFormat(pattern = "yyy-MM-dd HH:mm:ss")
    private LocalDateTime generationTime;

    /**
     * 佣金金额
     */
    private BigDecimal amount;

    /**
     * 金额类型
     */
    private AdditionalAmountDto.AwardType payType;


    /**
     * 申请号
     */
    private String applyNo;


    /**
     * 订单
     */
    private String orderNo;


    /**
     * 业务机构(分公司)
     */
    private String inputOrgId;


    //实际放款金额
    private BigDecimal transAmount;


    //该笔放款奖励比例
    private BigDecimal transAwardRange;

    //业务城市
    private String cityId;

    //状态 (00:未计算,01:已经计算,02:已经超过限额)
    private String state;

    private String remark;

    //最大返佣限额
    private BigDecimal maxRebate;

    //来源
    private String sourceAgentNo;

}

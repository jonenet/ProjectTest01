package com.banke.dsp.auth.po;

import com.banke.bkc.framework.po.BasePO;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Created by ex-zhongbingguo on 2018/3/14.
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "address_info")
public class AddressInfo extends BasePO {
    private String agentNo;

    /**地址类型,02:居住住址;03:工作地址*/
    private String addressType;

    /**省*/
    private String province;

    /**市*/
    private String city;

    /**区*/
    private String area;

    /**详细地址*/
    private String address;

    public AddressInfo() {
    }

    public AddressInfo(String agentNo, String addressType, String province, String city, String area, String address) {
        this.agentNo = agentNo;
        this.addressType = addressType;
        this.province = province;
        this.city = city;
        this.area = area;
        this.address = address;
    }
}

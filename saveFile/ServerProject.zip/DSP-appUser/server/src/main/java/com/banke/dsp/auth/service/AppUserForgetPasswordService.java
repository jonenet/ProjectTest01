package com.banke.dsp.auth.service;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dao.AppUserDao;
import com.banke.dsp.auth.dto.ForgetPasswordRequestDTO;
import com.banke.dsp.auth.dto.RegisterRequestDTO;
import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.sao.SendSMSRequestRepositorySao;
import com.banke.dsp.auth.security.Base64;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by luoyifei on 2017/5/31.
 */
@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AppUserForgetPasswordService {

    @NonNull
    private SendSMSRequestRepositorySao sendSMSRequestRepositorySao;

    @NonNull
    private AppUserDao appUserDao;

    public ResponseInfo<?> sendForgetPasswordPasscode(@RequestParam("telphone") String telphone, @RequestParam("requestId") String requestId) {
        if (StringUtils.isEmpty(telphone)) {
            throw new RuntimeException("手机号码不能为空");
        }
        // 根据手机号码查询数据库
        AppUserInfo getUserInfo = appUserDao.findByCellphone(telphone);
        log.info("根据手机号码查询是否已注册: {}", getUserInfo);
        if (null == getUserInfo) {
            // 说明数据库中没有这个手机号码
            return ResponseInfo.success(null);
        }
        return sendSMSRequestRepositorySao.sendForgetPasswordPasscode(telphone, requestId);
    }

    public ResponseInfo<?> resetPassword(@RequestParam("telphone") String telphone, @RequestParam("requestId") String requestId, @RequestParam("passCode") String passCode, @RequestParam("password") String password) {
        Map<String, String> returnMap = new HashMap<>();
        if (StringUtils.isEmpty(passCode)) {
            throw new RuntimeException("验证码不能为空");
        }
        if (StringUtils.isEmpty(password)) {
            throw new RuntimeException("密码不能为空");
        }
        if (StringUtils.isEmpty(passCode)) {
            throw new RuntimeException("验证码不能为空");
        }
        if (StringUtils.isEmpty(password)) {
            throw new RuntimeException("密码不能为空");
        }
        if (StringUtils.isEmpty(telphone)) {
            // throw new RuntimeException("手机号不能为空");
            returnMap.put("code", "0002");
            returnMap.put("msg", "手机号不能为空");
            return ResponseInfo.success(returnMap);
        }
        if (StringUtils.isEmpty(requestId)) {
            // throw new RuntimeException("验证码请求不能为空");
            returnMap.put("code", "0003");
            returnMap.put("msg", "验证码请求不能为空");
            return ResponseInfo.success(returnMap);
        }

        AppUserInfo oldUserInfo = appUserDao.findByCellphone(telphone);
        if (null == oldUserInfo) {
            // throw new RuntimeException("手机号码未注册");
            returnMap.put("code", "0004");
            returnMap.put("msg", "手机号码未注册");
            return ResponseInfo.success(returnMap);
        }
        ResponseInfo<ForgetPasswordRequestDTO> returnData = sendSMSRequestRepositorySao.findForgetPasswordRequestByRequestId(requestId);
        log.info("调用短信服务注册接口返回的数据： {}", returnData);
        if (returnData.isSuccess()) {
            ForgetPasswordRequestDTO forgetPasswordRequestDTO = returnData.getData();
            log.info("调用短信服务注册接口获取到的请求dto: {}", forgetPasswordRequestDTO);
            if (null == forgetPasswordRequestDTO) {
                // throw new RuntimeException("验证码错误，请重新获取验证码！");
                returnMap.put("code", "0001");
                returnMap.put("msg", "验证码错误，请重新获取验证码！");
                return ResponseInfo.success(returnMap);
            }
            String expectedPasscode = passCode;
            log.info("用户输入的验证码: {}", expectedPasscode);
            log.info("数据库中对应的验证码: {}", forgetPasswordRequestDTO.getPassCode());
            if (!forgetPasswordRequestDTO.getPassCode().equals(expectedPasscode)) {
                // throw new RuntimeException("验证码错误，请重新获取验证码！");
                returnMap.put("code", "0001");
                returnMap.put("msg", "验证码错误，请重新获取验证码！");
                return ResponseInfo.success(returnMap);
            }
            Long exchangeExpiredAt = Date.from(forgetPasswordRequestDTO.getExpiredAt().atZone(ZoneId.systemDefault()).toInstant()).getTime();
            if (System.currentTimeMillis() > exchangeExpiredAt) {
                // throw new RuntimeException("验证码已过期，请重新获取验证码！");
                returnMap.put("code", "0005");
                returnMap.put("msg", "验证码已过期，请重新获取验证码！");
                return ResponseInfo.success(returnMap);
            }

            oldUserInfo.setPassword(Base64.getBase64(password));
            oldUserInfo.setPasswordEncoder("base64");
            oldUserInfo.setPasswordSalt("");
            appUserDao.save(oldUserInfo);
            returnMap.put("code", "0000");
            returnMap.put("msg", "重置密码成功");
            returnMap.put("requestId", requestId);
            return ResponseInfo.success(returnMap);
        } else {
            // throw new RuntimeException("获取验证码信息出错");
            returnMap.put("code", "0006");
            returnMap.put("msg", "获取验证码信息出错");
            return ResponseInfo.success(returnMap);
        }
    }
}
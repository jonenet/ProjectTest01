package com.banke.dsp.auth.service;

import com.alibaba.fastjson.JSONObject;
import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.bkc.message.annotation.QueueConfig;
import com.banke.bkc.message.handler.MessageSender;
import com.banke.bkc.service.util.ContextHolder;
import com.banke.dsp.auth.dao.AppuserUpgradeDao;
import com.banke.dsp.auth.dto.AppRole;
import com.banke.dsp.auth.dto.UpgradeUserRequest;
import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.po.AppuserUpgrade;
import com.banke.dsp.auth.sao.SendSMSRequestRepositorySao;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Created by ex-zhongbingguo on 2017/9/5.
 */
@Slf4j
@Service
public class AppUserUpgradeService {

    @Autowired
    private AppuserUpgradeDao appuserUpgradeDao;

    @Autowired
    private AppUserInfoUtilService appUserInfoUtilService;

    @Autowired
    private RegisterRequestService registerRequestInfoService;

    @QueueConfig(queue = "msg.sms.pool")
    private MessageSender<Object> smsSender;
    public void setSmsSender(MessageSender<Object> smsSender) {
        this.smsSender = smsSender;
    }

    @Autowired
    private SendSMSRequestRepositorySao sendSMSSao;

    @Autowired
    private AppUserInfoService appUserInfoService;

    /**
     * 新版补全高级用户资料
     * @param request  参数对象
     * @return    boolean
     */
    public ResponseInfo<?> uploadSuperAgentNew(UpgradeUserRequest request){
        log.info("AppUserUpgradeService@uploadSuperAgentNew2,参数: {}",request);

        //开户人户名
        String realName = request.getRealName();
        //开户人身份证号
        String identityNumber = request.getIdentityNumber();
        //银行账号
        String bankAccountCardNumber = request.getBankAccountCard();

        if (StringUtils.isNotEmpty(identityNumber) && identityNumber.length() > 18){
            return new ResponseInfo<>("9999", "身份证号不能大于18位!", null);
        }
        if (StringUtils.isNotEmpty(identityNumber) && identityNumber.contains(" ")){
            return new ResponseInfo<>("9999", "身份证号不能有空格!", null);
        }
        if (StringUtils.isNotEmpty(bankAccountCardNumber) && bankAccountCardNumber.contains(" ") ){
            return new ResponseInfo<>("9999", "银行卡号不能有空格!", null);
        }
        if ( StringUtils.isNotEmpty(bankAccountCardNumber) && StringUtils.replace(bankAccountCardNumber, " ","").length() > 19 ){
            return new ResponseInfo<>("9999", "银行卡号不能大于19位!", null);
        }

        String mongoId = ContextHolder.getAgentNo();
        log.info("当前用户mongoId : {}", mongoId);
        AppUserInfo appUserInfo = appUserInfoService.findByMongoId(mongoId);

        //判断版本号
        String cv = request.getCv();
        log.info("版本信息cv： {}", cv);
        int cvInt;
        try {
            cvInt = Integer.parseInt(cv);
        } catch (NumberFormatException e) {
            return new ResponseInfo<>("9999", "请升级最新版本客户端", null);
        }
        if(cvInt <= 17){
            return new ResponseInfo<>("9999", "请升级最新版本客户端", null);
        }

        if(cvInt > 17){
            String requestId = request.getRequestId();
            String otpCode = request.getPassCode();
            String phone = appUserInfo.getCellphone();
            log.info("验证码id：{}，验证码：{}，手机号：{}", requestId, otpCode, phone);

            //t003 升级高级用户短信模板编号， 10 有效期10分钟
            if(StringUtils.isNotBlank(otpCode) && StringUtils.isNotBlank(phone)){
                ResponseInfo<?> checkVerifyCode = sendSMSSao.checkVerifyCode(phone, otpCode, "t003", "10");
                if(!checkVerifyCode.isSuccess()){
                    return checkVerifyCode;
                }
            }
//            if(StringUtils.isNotEmpty(requestId) && StringUtils.isNotEmpty(passCode)){
//                RegisterRequestDTO byId = registerRequestInfoService.findRegisterRequestByRequestId(requestId);
//                if(byId == null || StringUtils.isEmpty(passCode) || !byId.getPassCode().equals(passCode)
//                        || System.currentTimeMillis() > DateUtil.localDateTimeToDate(byId.getExpiredAt()).getTime()){
//                    return new ResponseInfo<>("9999", "验证码错误，请重新获取验证码!", null);
//                }
//            }
//            if(StringUtils.isEmpty(requestId) && StringUtils.isNotEmpty(passCode)){
//                return new ResponseInfo<>("9999", "验证码错误，请重新获取验证码!", null);
//            }
        }

        //校验年龄18岁
        if(StringUtils.isNotEmpty(identityNumber)){
            if(!checkAge(identityNumber)){
                return new ResponseInfo<>("9999", "该身份证用户小于18岁", null);
            }
        }
        if (StringUtils.isNotEmpty(realName) && StringUtils.isEmpty(appUserInfo.getRealName())){
            appUserInfo.setRealName(realName);
        }
        if (StringUtils.isNotEmpty(identityNumber) && StringUtils.isEmpty(appUserInfo.getIdentityNumber())){
            appUserInfo.setIdentityNumber(identityNumber);
        }
        if (StringUtils.isNotEmpty(bankAccountCardNumber) && StringUtils.isEmpty(appUserInfo.getBankCardNumber())){
            appUserInfo.setBankCardNumber(bankAccountCardNumber);
        }
        // 保存信息到用户表
        appUserInfoUtilService.updateAppUser(appUserInfo);
        // 保存信息到用户升级表
        AppuserUpgrade appuserUpgrade;
        try {
            appuserUpgrade = this.addAppUserUpgrade(appUserInfo,request);
        } catch (Exception e){
            log.error("用户升级信息保存异常,{}", e);
            return new ResponseInfo<>("9999", "用户升级信息保存失败", null);
        }
        return ResponseInfo.success(true);
    }

    private AppuserUpgrade addAppUserUpgrade(AppUserInfo appUserInfo, UpgradeUserRequest request) throws Exception {
        AppuserUpgrade appuserUpgrade = appuserUpgradeDao.findByAgentNo(appUserInfo.getMongoId());
        if (appuserUpgrade == null) {
            appuserUpgrade = new AppuserUpgrade();
        }
        appuserUpgrade.setAgentNo(appUserInfo.getMongoId());
        if (StringUtils.isNotEmpty(request.getRealName())){
            appuserUpgrade.setRealName(request.getRealName());
        }
        if (StringUtils.isNotEmpty(request.getIdentityNumber())){
            appuserUpgrade.setIdentityNumber(request.getIdentityNumber());
        }
        if (StringUtils.isNotEmpty(request.getBankAccountCard())){
            appuserUpgrade.setBankCardNumber(request.getBankAccountCard());
        }
        if (StringUtils.isNotEmpty(request.getReservedMobile())){
            appuserUpgrade.setCellphone(request.getReservedMobile());
        }
        if (StringUtils.isNotEmpty(request.getOtherInfo())){
            appuserUpgrade.setOtherInfo(request.getOtherInfo());
        }
        try{
            String creditImageid = request.getCreditImageid();
            if (StringUtils.isNotEmpty(creditImageid)){
                String[] split = StringUtils.split(creditImageid, "-");
                log.info("身份证图片id: {}",split);
                appuserUpgrade.setIdentityZmImageId(split[0]);
                appuserUpgrade.setIdentityFmImageId(split[1]);
                appuserUpgrade.setIdentityTxImageId(split[2]);
            }
        }catch (RuntimeException e){
            log.info("身份证图片拆分异常");
            throw new RuntimeException("身份证图片拆分异常");
        }
        return appuserUpgradeDao.save(appuserUpgrade);
    }
    
    /**
     *  新版升级高级用户
     * @return ResponseInfo
     */
    public ResponseInfo<?> userUpgrade(){
        String mongoId = ContextHolder.getAgentNo();
        log.info("当前用户mongoId : {}", mongoId);
        AppUserInfo appUserInfo = appUserInfoService.findByMongoId(mongoId);
        this.updateAppUser(appUserInfo);
        return ResponseInfo.success(true);
    }

    private void updateAppUser(AppUserInfo appUserInfo) {
        List<AppRole> appRoles = appUserInfoUtilService.getAppRoles(appUserInfo.getAppRoles());
        appRoles.add(AppRole.ROLE_SUPER_AGENT);
        appUserInfo.setAppRoles(appRoles.toString());
        appUserInfoUtilService.updateAppUser(appUserInfo);
    }

    /**
     * 新版升级高级用户（微服务调用）
     */
    public ResponseInfo<?> userUpgradeToMicroService(String agentNo, String status) throws Exception{
        log.info("参数： agentNo:{}, status:{} ",agentNo, status);
        AppUserInfo appUser = appUserInfoService.findByMongoId(agentNo);

        this.updateAppUser(appUser);
        return ResponseInfo.success(true);
    }

    private Boolean checkAge(String idNo){
        boolean flag = true; // 默认大于18岁
        try {
            String strYear = idNo.substring(6, 10);// 年份
            String strMonth = idNo.substring(10, 12);// 月份
            String strDay = idNo.substring(12, 14);// 日
            //年份+18
            strYear = String.valueOf((Integer.parseInt(strYear) + 18));

            String birthday = strYear + "-" + strMonth + "-" + strDay;
            LocalDate birthDate = LocalDate.parse(birthday, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            LocalDate time = LocalDate.now();
            LocalDateTime now = LocalDateTime.now();
            flag = time.isAfter(birthDate); //如果小于18岁则返回false
        } catch (NumberFormatException e) {
            log.info("补全资料身份证转化错误 idNo:"+idNo,e);
        }
        return flag;
    }

    public void sendOtpCode(String cellphone) {
        //验证码
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("mobileNo",cellphone);
        jsonObject.put("effectiveTime","10");
        jsonObject.put("templetNo","t003");
        jsonObject.put("messageType","1");
        smsSender.send("sendSMS","otpCode",jsonObject);
    }

    public ResponseInfo<?> checkVerifyCode(String phone, String otpCode){
        return sendSMSSao.checkVerifyCode(phone, otpCode, "t003", "10");
    }

}

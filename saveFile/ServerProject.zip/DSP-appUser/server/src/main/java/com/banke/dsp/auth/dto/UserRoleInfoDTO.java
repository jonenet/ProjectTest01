package com.banke.dsp.auth.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class UserRoleInfoDTO {


	/**
     * 角色id
     */
    private String roleId;

    /**
     * 用户ID
     */
    private String userId;

    /**
     * 开始时间
     */
    private LocalDate startDate;

    /**
     * 结束时间
     */
    private LocalDate endDate;

}

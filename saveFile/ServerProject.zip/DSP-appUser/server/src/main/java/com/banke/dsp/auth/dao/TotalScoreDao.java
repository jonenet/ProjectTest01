package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.po.TotalScore;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by ex-zhongbingguo on 2017/11/2.
 */
public interface TotalScoreDao extends CrudRepository<TotalScore, Long> {

    TotalScore findBycellphone(String cellphone);
}

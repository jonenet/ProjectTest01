package com.banke.dsp.auth.sao;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dto.ClientInfoDTO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Describe:
 * Created by zhangyong on 2017/8/29.
 */
@FeignClient(value = "CIF-clientInfo")
public interface CifClientInfoSao {

    @RequestMapping("/api/queryByClientNo")
    public ResponseInfo<ClientInfoDTO> queryByClientNo(@RequestParam("clientNo") String clientNo);
}

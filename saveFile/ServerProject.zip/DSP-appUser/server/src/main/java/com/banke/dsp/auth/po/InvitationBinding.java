package com.banke.dsp.auth.po;


import com.banke.bkc.framework.po.BasePO;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "invitation_binding")
public class InvitationBinding extends BasePO{

    //邀请人手机号码
    private String invitePeople;

    //被邀请人手机号码
    private String beInvitedPeople;

}

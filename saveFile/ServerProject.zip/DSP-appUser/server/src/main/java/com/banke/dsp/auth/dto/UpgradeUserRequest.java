package com.banke.dsp.auth.dto;

import lombok.Data;

/**
 * Created by ex-zhongbingguo on 2017/8/23.
 */
@Data
public class UpgradeUserRequest {

    // 客户姓名
    private String realName;

    // 身份证
    private String identityNumber;

    // 银行卡号
    private String bankAccountCard;

    //版本号
    private String cv;

    //验证码id
    private String requestId;

    //验证码
    private String passCode;

    //身份证图片
    private String creditImageid;

    //银行预留手机号码
    private String reservedMobile;

    //身份证其他信息
    private String otherInfo;
}

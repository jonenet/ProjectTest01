package com.banke.dsp.auth.dto;


import com.banke.bkc.framework.po.BasePO;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class ProductInfo{


    private String productNo;//产品编号


    private String parentNo;//大类产品编号


    private String cooperationId;//合作方ID 或者公司ID


    private String cProductId;//合作方产品编号



    private String productName;//产品名称


    private LocalDate effectiveDate;//产品生效时间


    private LocalDate failureDate;//产品失效时间


    private String guaranteeMode;//担保方式


    private String loanType;//贷款类型 01-抵押,02-信用


    private String repaymentMode;// 还款方式

    private String repaymentCycle;// 还款周期


    private String maxLoanTerm;// 最长贷款期限


    private String minLoanTerm;//最小贷款期限


    private BigDecimal loanRate;//贷款利率


    private BigDecimal loanAmountUpperLimit;//贷款金额上限

    private BigDecimal loanAmountLowerLimit;//贷款金额下限

    private Long sortNo;//排序

    private Boolean isCredit;//是否需要征信
    private String creditSource;///征信获取方式(all 全需要，notAll 都不需要，bank 银行,upload 上传)
    private String procedureNo;//流程编号\
    private Boolean isPartnerProducts;//是否合作方产品
    private String creditDegree;

}

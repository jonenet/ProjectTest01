package com.banke.dsp.auth.dto;

import lombok.Data;

/**
 *  用户管理
 * Created by ex-zhongbingguo on 2017/8/25.
 */
@Data
public class AppUserManageRequest {

    private String cellphone;

    //账号状态
    private boolean enabled;

    //信用标志
    private String iscredit;

    //业务城市
    private String businessCityid;

    //地推人员id
    private String referrer;

}

package com.banke.dsp.auth.dto;

import lombok.Data;
/**
 * 银行信息
 * @author ex-panhuayu
 *
 */
@Data
public class Bank{

	private String id;
	
    private String code;
    
    private String name;
    
    private String bankCardFormat;
    
    private String sortNO;
    
    private String parentCode;
    
}

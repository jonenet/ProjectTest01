package com.banke.dsp.auth.dto;

import com.banke.bkc.framework.po.BasePO;
import com.banke.bkc.framework.util.CodeEnum;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.Data;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class OrderInfo extends BasePO {


    /**
     * 订单号
     */
    private String orderNo;


    /**
     * 申请编号
     */
    private String applyNo;


    /**
     * 申请时间
     */
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime applyDate;


    /**
     * 状态流转编号
     */
    private String taskId;

    /**
     * 客户编号
     */
    private String clientNo;


    /**
     * 客户经理编号
     */
    private String advisorNo;

    /**
     * 业务员编码
     */
    private String agentNo;

    /**
     * 查询征信机构(银行)
     */
    private String bankId;

    /**
     * 业务机构(分公司)
     */
    private String inputOrgId;

    /**
     * 渠道名称
     */
    private String channel;


    //贷款期限
    private Integer loanTerm;


    //最高可贷金额
    private BigDecimal highLoan;

    /**
     * 产品
     */
    private String productNo;


    /**
     * 实际面签时间
     */
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime signCompleteDate;


    //面签金额
    private BigDecimal signAmount;


    /**
     * 面签产品
     */
    private String signProductNo;

    /**
     * 审批时间
     */
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime approveCompleteDate;

    /**
     * 审批产品
     */
    private String approveProductNo;


    //审批金额
    private BigDecimal approveAmount;


    //放款时间
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime transDate;

    /**
     * 放款产品
     */
    private String transProductNo;

    //放款金额
    private BigDecimal transAmount;


    //产品优选ID
    private Long chooseId;


    /**
     * 订单创建人
     */
    private String ordCreateUser;


    /**
     * 订单创建时间
     */
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime ordCreateDate;


    /**
     * 状态变更时间
     */
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime statusDate;


    /**
     * 备注
     */
    private String remark;

    /**
     * 状态 (创建,待预约,待提交,待面签,待审核,待审批,待放款,已放款)<br>
     * (面签不通过/审核不通过)
     */
    @Enumerated(EnumType.STRING)
    private Status orderStatus;


    public enum Status {
        CREATE("000")/*创建*/, UN_BOOKING("B00")/*待预约*/, UN_CONFIRM("C00")/*待提交*/, UN_SIGN("S00")/*待面签*/,
        UN_APPROVE("P00")/*待审批*/, UN_TRANS("R00")/*待放款*/, SIGN_FAIL("S01")/*面签失败*/, GIVE_UP("G00")/*客户放弃*/,
        APPROVE_FAIL("P01")/*审批不通过*/, TRANS_FAIL("R01")/*放款失败*/, FINISH("FFF")/*完成*/;

        Status(String val) {
            CodeEnum.init(this, val);
        }
    }
}

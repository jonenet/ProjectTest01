package com.banke.dsp.auth.dto;

import com.banke.bkc.framework.util.ResponseInfo;
import lombok.Data;

/**
 * Created by ex-zhongbingguo on 2017/10/16.
 */
@Data
public class ResponseInfoDTO<T> extends ResponseInfo<T> {
    public ResponseInfoDTO(String code, String message, T data) {
        super(code, message, data);
    }

    public static <T> ResponseInfoDTO<T> error(String message) {
        return new ResponseInfoDTO<>(CODE_ERROR, message, null);
    }
}

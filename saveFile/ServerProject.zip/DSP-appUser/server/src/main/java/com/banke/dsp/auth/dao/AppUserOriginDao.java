package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.po.AppUserOrigin;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by ex-zengfanxi on 2017/10/17.
 */
public interface AppUserOriginDao extends CrudRepository<AppUserOrigin, Long>,JpaSpecificationExecutor<AppUserOrigin> {

}

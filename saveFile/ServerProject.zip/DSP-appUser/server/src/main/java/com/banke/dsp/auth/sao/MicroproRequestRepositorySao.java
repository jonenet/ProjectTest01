package com.banke.dsp.auth.sao;

import com.alibaba.fastjson.JSONObject;
import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dto.ForgetPasswordRequestDTO;
import com.banke.dsp.auth.dto.RegisterRequestDTO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Created by luoyifei on 2017/5/23.
 */
@FeignClient(value = "ADT-wx")
public interface MicroproRequestRepositorySao {

    @RequestMapping("/api/microprorequest/sendRedPacKage")
    public ResponseInfo sendRedPacKage(@RequestParam("openid") String openid, @RequestParam("type") String type);

    @RequestMapping("/api/microprorequest/getAllUserInfoWithUnionID")
    public JSONObject getAllUserInfoWithUnionID(@RequestParam("openid") String openid);

    @RequestMapping("/api/microprorequest/getFansOpenid")
    public JSONObject getFansOpenid(@RequestParam(value = "next_openid") String next_openid);
}

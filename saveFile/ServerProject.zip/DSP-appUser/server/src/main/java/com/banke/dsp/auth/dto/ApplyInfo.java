package com.banke.dsp.auth.dto;

import com.banke.bkc.framework.util.CodeEnum;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class ApplyInfo {

    /**
     * 流程编号
     */
    private String taskId;

    /**
     * 申请编号
     */
    private String applyNo;


    /**
     * 申请时间
     */
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime applyDate;


    /**
     * 一级产品(产品大类)
     */
    private String primaryProductNo;

    /**
     * 二级产品
     */
    private String productNo;

    /**
     * 是否允许推荐其他产品
     */
    private Boolean isAllowOtherProduct;


    /**
     * 查询征信机构(银行)
     */
    private String bankId;

    /**
     * 业务机构(分公司)
     */
    private String inputOrgId;

    /**
     * 渠道名称
     */
    private String channel;


    /**
     * 业务员编码
     */
    private String agentNo;

    /**
     * 业务员是否可信任（免见证）
     */
    private Boolean isTrustAgent;

    /**
     * 客户编号
     */
    private String clientNo;

    /**
     * 客户经理编号
     */
    private String advisorNo;

    /**
     * 状态 (创建/待见证/待影像核查/待征信查询/待信息确认/已提交)<br>
     * (已取消/见证不通过/核查不通过/征信查询失败/无法联系/资质不符/挂起/客户放弃)
     */
    private Status applyStatus;

    /**
     * 状态变更时间
     */
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime statusDate;


    /**
     * 备注
     */
    private String remark;


    public enum Status {
        CREATE("000")/*创建*/,
        UN_IMGCHK_TASK("C00") /*待分配影像核查处理人*/,
        UN_IMGCHK_PROCESS("U01")/*待影像核查处理人处理*/,
        UN_IMGCHK_HANG("UIH")/*挂起待处理*/,
        UN_TRUST("T00")/*待信任*/,
        UN_WITNESS("W00") /*待见证*/,
        UN_CREDIT("R00")/*待征信查询*/, CREDIT_SCORE_NOT("CSN")/*征信查询评分不通过*/,
        UN_CREDIT_ENTRY_TASK("UCET")/*征信录入-待分配*/,
        UN_CREDIT_ENTRY_PROCESS("UCEP")/*征信录入-待处理*/,
        UN_CREDIT_SCORE("UCS")/*待评分*/,
        UN_CONFIRM_TASK("F00")/*待分配信息确认处理人*/,
        UN_CONFIRM_PROCESS("F01")/*待信息确认处理人处理*/,
        UN_QUESTIONNAIRE_CONFIRM("UQC")/*待问卷提交*/,
        UN_USER_CONFIRM("UUC")/*待用户提交*/,
        UN_ENTRY_TASK("UET")/*待切片分配*/,
        UN_ENTRY_PROCESS("UEP")/*待切片处理*/,
        UN_ENTRY_AUDIT("UEA")/*切片退回审核-重切*/,
        UN_ENTRY_AUDIT_MODIFY("UEAM")/*切片评分异常修，待修改数据*/,
        UN_THIRD_PARTY_INPUT("UTPI")/*等待第三方录入*/,
        CONFIRM_GIVE_UP("F02")/*信息确认-放弃*/,
        CONFIRM_NOT_REACHED("CNR")/*信息确认-无法联系*/,
        CONFIRM_KEEP_TOUCH("CKT")/*信息确认-再联系*/,
        CONFIRM_LOST("F03")/*信息确认-失联*/,
        CONFIRM_NOT_MATCH("F04")/*信息确认-资质不符*/,
        RETURN("R01")/*退回待重新处理*/,
        CANCEL("CCL")/*已取消*/,
        SUBMITTED("FFF")/*已提交*/,
        END_06("E06")/*06流程结束*/;

        Status(String val) {
            CodeEnum.init(this, val);
        }
    }
}

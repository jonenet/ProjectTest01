package com.banke.dsp.auth.dto;

import lombok.Data;

/**
 * Created by zhaxiaokun on 2017/6/20.
 */
@Data
public class TokenDto {
    private String version;
    private String merchantId;
    private String uid; //平安付会员号
    private String mid; //mongoId
    private String status;
    private String token;
    private String signature;
    private String customerId; //平安付会员号
}

package com.banke.dsp.auth.dto;

import com.banke.bkc.framework.po.BasePO;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.Data;

import javax.persistence.Column;
import java.time.LocalDateTime;

/**
 * 流程记录表
 */
@Data
public class WrokflowLog extends BasePO {

    /**
     * 业务号
     */
    private String businessNo;


    /**
     * 标识业务类型(apply/order)
     */
    private String taskGroup;

    /**
     * 流程号
     */
    private String groupNo;


    /**
     * 每次任务的唯一id
     */
    private String taskId;

    /**
     * 节点
     */
    private String node;

    /**
     * 发送数据
     */
    private String sendData;

    /**
     * 发送时间
     */
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime sendDate;


    /**
     * 接收-处理标识
     */
    private String way;

    /**
     * 接收-数据
     */
    private String receiveData;

    /**
     * 接收-时间
     */
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime receiveDate;


    /**
     * 是否处理
     */
    @Column(name = "is_process")
    private Boolean isProcess;


    /**
     * 处理结束时间
     */
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime processEndDate;

    /**
     * 下一个任务点
     */
    private String nextNode;


    /**
     * 下一个任务编号
     */
    private String nextTaskId;

    /**
     * 上一个任务点
     */
    private String preNode;

    /**
     * 上一个任务编号
     */
    private String preTaskId;


}

package com.banke.dsp.auth.util;

import java.util.regex.Pattern;

/**
 * Created by ex-zhongbingguo on 2018/4/9.
 */
public class RegexUtil {
    /**
     *  校验身份证是否合法
     */
    public static boolean checkIdentityNumber(String identityNumber) {
        String mobileFormat = "^\\d{17}[0-9X]$";
        Pattern pattern = Pattern.compile(mobileFormat);
        return pattern.matcher(identityNumber).matches();
    }

    /**
     * 校验手机号码规范性
     */
    public static boolean checkCellPhone(String userName) {
        String mobileFormat = "^1[34578]\\d{9}$";
        Pattern pattern = Pattern.compile(mobileFormat);
        return pattern.matcher(userName).matches();
    }
}

package com.banke.dsp.auth.sao;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dto.BranchInfoDTO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 *  组织机构表/业务城市 sao
 * Created by ex-zhongbingguo on 2017/9/18.
 */
@FeignClient(name = "UMS-branch")
public interface UmsBranchSao {

    @RequestMapping("/api/branchInfo/getBranchByBranchNo")
    ResponseInfo<BranchInfoDTO> getBranchByBranchNo(@RequestParam("sysId") String sysId, @RequestParam("branchNo") String branchNo);

    @RequestMapping("/api/branchInfo/getBranchSysIdAndBranchType")
    ResponseInfo<List<BranchInfoDTO>> getBranchSysIdAndBranchType(@RequestParam("sysId") String sysId,
                                                               @RequestParam("branchType") String branchType);
}

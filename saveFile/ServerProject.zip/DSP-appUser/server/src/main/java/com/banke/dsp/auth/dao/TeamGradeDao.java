package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.po.TeamGrade;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by ex-zhongbingguo on 2017/12/8.
 */
public interface TeamGradeDao extends CrudRepository<TeamGrade, Long>, JpaSpecificationExecutor<TeamGrade> {

    TeamGrade findByBusinessCityidAndGradeCode(String businessCityid, String gradeCode);
}

package com.banke.dsp.auth.po;

import com.banke.bkc.framework.po.BasePO;
import com.banke.dsp.auth.util.SyncHelper;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@RequiredArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "appuser_info")
public class AppUserInfo extends BasePO {

    @NonNull
    @Column(nullable = false)
    private String mongoId;

    @NonNull//app角色
    @Column(nullable = false)
    private String appRoles;

    //app版本
    @Column(nullable = false)
    private String appVersion;

    @Column(nullable = false)
    private Boolean archived;

    //银行编码
    @Column(nullable = false)
    private String bankId;

    //银行账户名
    @Column(nullable = false)
    private String bankAccountName;

    //银行机构
    @Column(nullable = false)
    private String bankBranchId;

    //银行卡号
    @Column(nullable = false)
    private String bankCardNumber;

    //分公司
    @Column(nullable = false)
    private String businessCityid;

    //手机号码
    @Column(nullable = false)
    private String cellphone;

    //注册日期
    @Column(nullable = false)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdAt;

    //用户进件权限
    @Column(nullable = false)
    private Boolean enableEecommendation;

    //是否有效
    @Column(nullable = false)
    private Boolean enabled;

    //是否过期
    @Column(nullable = false)
    private Boolean expired;

    //身份证号
    @Column(nullable = false)
    private String identityNumber;

    //job
    @Column(nullable = false)
    private String job;

    //locked
    @Column(nullable = false)
    private Boolean locked;

    //操作时间
    @Column(nullable = false)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime modifiedAt;

    //操作系统版本
    @Column(nullable = false)
    private String osVersion;

    @NonNull //密文密码
    @Column(nullable = false)
    private String password;

    //加码方式
    @Column(nullable = false)
    private String passwordEncoder;

    @NonNull //盐
    @Column(nullable = false)
    private String passwordSalt;

    //推荐人用户名
    @Column(nullable = false)
    private String refererName;

    //referrer
    @Column(nullable = false)
    private String referrer;

    //注册设备
    @Column(nullable = false)
    private String registerDevice;

    //注册id
    @Column(nullable = false)
    private String registerId;

    //用户星级
    @Column(nullable = false)
    private Integer star;

    //用户名
    @Column(nullable = false)
    private String userName;

    //公司名称
    @Column(nullable = false)
    private String companyName;

    //是否集团用户
    @Column(nullable = false)
    private String groupFlag;

    //所属集团
    @Column(nullable = false)
    private String groupName;

    //推广方式
    @Column(nullable = false)
    private String popularizeTypeId;

    //真实名称
    @Column(nullable = false)
    private String realName;

    //地址
    @Column(nullable = false)
    private String address;

    //邮箱
    @Column(nullable = false)
    private String email;

    //推荐人手机号
    @Column(nullable = false)
    private String refMobilePhone;

    //微信用户名
    @Column(nullable = false)
    private String wechatUsername;

    //achived
    @Column(nullable = false)
    private String achived;

    //渠道Id
    @Column(nullable = false)
    private String channelId;

    //是否是授信标志
    @Column(nullable = false)
    private String iscredit;

    //生成token
    @Column(nullable = false)
    private String token;

    //token生成时间
    @Column(nullable = false)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime tokenDate;

    //是否推荐更多产品
    @Column(nullable = false)
    private String commendMore;

    //征信获取方式(all 全需要，notAll 都不需要，bank 银行,upload 上传)
    @Column(nullable = false)
    private String creditWay;

    //是否需要征信
    @Column(nullable = false)
    private Boolean isNeedCredit;

    // 来源
    @Column(nullable = false)
    private String source;

    //CV
    @Column(nullable = false)
    private String cv;

//	@OneToOne
//	@JoinColumn(name="cellphone",referencedColumnName = "mid",updatable = false ,insertable = false)
//	private WalletInfo walletInfo;

//    @PostUpdate
//    public void preUpdate() {
//        SyncHelper.sync(this, "update");
//    }
//
//    @PostPersist
//    public void prePersist() {
//        SyncHelper.sync(this, "insert");
//    }

    //用户归属code
    @Column(nullable = false)
    private String ascription;

    //用户归属是否激活
    @Column(nullable = false)
    private Boolean ascriptionStatus;

    //注册城市
    @Column(nullable = false)
    private String registerCityid;

    //微信openid
    @Column(nullable = false)
    private String openid;

    //微信昵称
    @Column(nullable = false)
    private String nickname;

    //头像图片id
    @Column(nullable = false)
    private String headImageId;

    //性别,M:男；F:女
    @Column(nullable = false)
    private String sex;

    //婚姻状况,S:未婚;M:已婚
    @Column(nullable = false)
    private String marriage;

    //收入水平01-05
    @Column(nullable = false)
    private String incomeLevel;

    //用户行业
    @Column(nullable = false)
    private String userIndustry;
}

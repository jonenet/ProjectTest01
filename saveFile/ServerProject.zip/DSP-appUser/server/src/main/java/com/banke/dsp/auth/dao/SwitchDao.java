package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.po.SwitchInfo;
import org.springframework.data.repository.CrudRepository;

public interface SwitchDao extends CrudRepository<SwitchInfo,Long> {
    SwitchInfo findByName(String name);
}

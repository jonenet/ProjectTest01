package com.banke.dsp.auth.service;

import com.banke.dsp.auth.dao.InvitationBindingDao;
import com.banke.dsp.auth.po.InvitationBinding;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by ex-zhongbingguo on 2017/11/2.
 */
@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class InvitationBindingService {

    @Autowired
    private InvitationBindingDao invitationBindingDao;

    InvitationBinding findBybeInvitedPeople(String beInvitedPeople){
        return invitationBindingDao.findBybeInvitedPeople(beInvitedPeople);
    }

}

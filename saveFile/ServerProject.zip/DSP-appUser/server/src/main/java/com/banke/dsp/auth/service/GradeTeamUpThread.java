package com.banke.dsp.auth.service;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dao.*;
import com.banke.dsp.auth.dto.ProductInfo;
import com.banke.dsp.auth.dto.TeamGradeEnum;
import com.banke.dsp.auth.dto.TeamStatusEnumDto;
import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.po.TeamChargeMessage;
import com.banke.dsp.auth.po.TeamGradeHistory;
import com.banke.dsp.auth.po.TeamInfo;
import com.banke.dsp.auth.sao.PdtDefSao;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Created by ex-taozhangyi on 2018/2/9.
 */
@Slf4j
public class GradeTeamUpThread implements Runnable{
    private String type;
    private TeamInfoDao teamInfoDao;
    private TeamGradeDownService teamGradeDownService;

    public GradeTeamUpThread(String type,TeamInfoDao teamInfoDao,TeamGradeDownService teamGradeDownService ){
        this.type = type;
        this.teamInfoDao = teamInfoDao;
        this.teamGradeDownService = teamGradeDownService;
    }

    @Override
    public void run() {
       //白银
      if(type.equals(TeamGradeEnum.BY.getCode())){
          byGradeTeamDown();
        //黄金
        }else if(type.equals(TeamGradeEnum.HJ.getCode())){
            hjGradeTeamDown();
        //钻石
        }else if(type.equals(TeamGradeEnum.ZS.getCode())){
            zsGradeTeamDown();
        }

    }

    //白银降级
    public void byGradeTeamDown(){
        //查询等级为白银的团队
        List<TeamInfo> listTeamInfo = teamInfoDao.findByGradeAndStatusNot(TeamGradeEnum.BY.getCode(),TeamStatusEnumDto.DELETE.toString());
        if(null != listTeamInfo && listTeamInfo.size() > 0 ){
            log.info("by listTeamInfo:{}",listTeamInfo.size());
            for (TeamInfo teamInfo:listTeamInfo) {
                if(null != teamInfo.getDowngradeDate()){
                    //获取当前用户注册时间
                    LocalDateTime localDateTime = teamInfo.getDowngradeDate();
                    //两个时间差的天
                    Duration duration = Duration.between(localDateTime, LocalDateTime.now());
                    long day = duration.toDays();
                    if(day >7){
                        teamGradeDownService.byGradeTeam(teamInfo);
                    }else {
                        log.info("{}团队在7天之内降级过",teamInfo.getTeamNo());
                    }
                }else{
                    teamGradeDownService.byGradeTeam(teamInfo);
                }
            }
        }
    }

    //黄金降级
    public void hjGradeTeamDown(){
        //查询等级为黄金的团队
        List<TeamInfo> listTeamInfo = teamInfoDao.findByGradeAndStatusNot(TeamGradeEnum.HJ.getCode(),TeamStatusEnumDto.DELETE.toString());
        if(null != listTeamInfo && listTeamInfo.size() >0){
            log.info("hj listTeamInfo:{}",listTeamInfo.size());
            for (TeamInfo teamInfo:listTeamInfo) {
                if(null != teamInfo.getDowngradeDate()){
                    //获取当前用户注册时间
                    LocalDateTime localDateTime = teamInfo.getDowngradeDate();
                    //两个时间差的天
                    Duration duration = Duration.between(localDateTime, LocalDateTime.now());
                    long day = duration.toDays();
                    if(day >7){
                        teamGradeDownService.hjGradeTeam(teamInfo);
                    }else {
                        log.info("{}团队在7天之内降级过",teamInfo.getTeamNo());
                    }
                }else{
                    teamGradeDownService.hjGradeTeam(teamInfo);
                }
            }
        }
    }

    //钻石降级，没有升级
    public void zsGradeTeamDown(){
        //查询等级为钻石的团队
        List<TeamInfo> listTeamInfo = teamInfoDao.findByGradeAndStatusNot(TeamGradeEnum.ZS.getCode(),TeamStatusEnumDto.DELETE.toString());
        if(null != listTeamInfo && listTeamInfo.size() > 0 ){
            log.info("zs listTeamInfo:{}",listTeamInfo.size());
            for (TeamInfo teamInfo :listTeamInfo) {
                if(null != teamInfo.getDowngradeDate()){
                    //获取当前用户注册时间
                    LocalDateTime localDateTime = teamInfo.getDowngradeDate();
                    //两个时间差的天
                    Duration duration = Duration.between(localDateTime, LocalDateTime.now());
                    long day = duration.toDays();
                    if(day >7){
                        teamGradeDownService.zsGradeTeam(teamInfo);
                    }else {
                        log.info("{}团队在7天之内降级过",teamInfo.getTeamNo());
                    }
                }else{
                    teamGradeDownService.zsGradeTeam(teamInfo);
                }
            }
        }
    }
}

package com.banke.dsp.auth.po;

import com.banke.bkc.framework.po.BasePO;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Created by ex-taozhangyi on 2018/2/28.
 */
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "team_integral_ranking")
public class TeamIntegralRanking extends BasePO {
    private String teamNo;
    private String teamName;
    private Integer totalIntegral;
    private Integer lastTeamRanking;
}

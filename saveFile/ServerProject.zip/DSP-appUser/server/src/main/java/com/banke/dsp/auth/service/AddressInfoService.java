package com.banke.dsp.auth.service;

import com.banke.dsp.auth.dao.AddressInfoDao;
import com.banke.dsp.auth.po.AddressInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by ex-zhongbingguo on 2018/3/14.
 */
@Service
@Slf4j
public class AddressInfoService {

    @Autowired
    private AddressInfoDao addressInfoDao;

    public void save(String mongoId, String province, String city, String area, String address, String addressType){
        AddressInfo addressInfo = this.findByAgentNoAndAddressType(mongoId, addressType);
        if (addressInfo == null) {
            addressInfo = new AddressInfo();
        }
        addressInfo.setAgentNo(mongoId);
        addressInfo.setProvince(province);
        addressInfo.setCity(city);
        addressInfo.setArea(area);
        addressInfo.setAddress(address);
        addressInfo.setAddressType(addressType);
        addressInfoDao.save(addressInfo);
    }

    public AddressInfo findByAgentNoAndAddressType(String agentNo, String addressType){
        log.info("查询用户地址：agentNo：{},addressType: {}", agentNo, addressType);
        return addressInfoDao.findByAgentNoAndAddressType(agentNo, addressType);
    }
}

package com.banke.dsp.auth.dao;


import com.banke.dsp.auth.po.TeamInfo;
import org.springframework.data.repository.CrudRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface TeamInfoDao extends CrudRepository<TeamInfo,Long> {

    TeamInfo findByAgentNoAndStatusNot(String agentNo, String status);

    TeamInfo findByAgentNoAndStatus(String agentNo, String status);

    TeamInfo findByTeamNo(String teamNo);

    TeamInfo findByTeamNoAndStatus(String teamNo, String status);

    TeamInfo findByTeamNoAndStatusNot(String teamNo, String status);

    TeamInfo findByTeamNameAndStatusNot(String name, String status);

    List<TeamInfo> findByStatus(String status);

    List<TeamInfo> findByStatusNot(String status);

    List<TeamInfo> findByGradeNotAndStatusNot(String grade,String status);

    List<TeamInfo> findByGradeAndStatusNot(String grade,String status);
}

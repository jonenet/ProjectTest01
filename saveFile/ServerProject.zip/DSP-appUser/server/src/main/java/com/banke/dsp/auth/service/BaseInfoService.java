package com.banke.dsp.auth.service;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dto.BaseInfoDto;
import com.banke.dsp.auth.sao.QryListSao;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by ex-zhongbingguo on 2017/8/31.
 */
@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BaseInfoService {

    @Autowired
    private QryListSao qryListSao;

    BaseInfoDto getBaseInfoBySysIdAndTypeAndCode(String sysId, String type, String code){
        ResponseInfo<BaseInfoDto> response = qryListSao.getBaseInfoBySysIdAndTypeAndCode(sysId, type, code);
        BaseInfoDto data = new BaseInfoDto();
        if (response.isSuccess()){
            data = response.getData();
        }
        return data;
    }

    List<BaseInfoDto> getBaseInfoBySysIdAndType(String sysId, String type){
        ResponseInfo<List<BaseInfoDto>> response = qryListSao.getBaseInfoBySysIdAndType(sysId, type);
        log.info("result to BaseInfo: {}", response);
        if (response != null && response.isSuccess()){
            return response.getData();
        }
        return null;
    }
}

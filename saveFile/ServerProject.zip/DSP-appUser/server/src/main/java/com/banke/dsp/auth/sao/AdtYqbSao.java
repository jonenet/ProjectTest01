package com.banke.dsp.auth.sao;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dto.BankListDTO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * Created by ex-liqiaoyong on 2017/8/15.
 */
@FeignClient(value = "ADT-yqb")
public interface AdtYqbSao {

    @RequestMapping("/api/yqb/checkBank")
    ResponseInfo<Boolean> checkBank(@RequestParam("cid") String cid, @RequestParam("mid") String mid);
    @RequestMapping("/api/yqb/getBank")
    ResponseInfo<List<BankListDTO>> getBank(@RequestParam("token") String token);
    @RequestMapping("/api/yqb/getBalance")//查霄鲲
    public ResponseInfo<Long>getBalance(@RequestParam(value = "token") String agentNo);

}

package com.banke.dsp.auth.service;

import com.alibaba.fastjson.JSONObject;
import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dto.BranchInfoDTO;
import com.banke.dsp.auth.sao.UmsBranchSao;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by ex-zhongbingguo on 2017/9/18.
 */
@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BranchInfoService {

    @Autowired
    private UmsBranchSao umsBranchSao;

    /**
     *  根据系统id 和机构编号 查询 组织机构
     * @param sysId     系统id
     * @param branchNo  机构编号
     * @return           组织机构
     */
    BranchInfoDTO getBranchByBranchNo(String sysId, String branchNo){
        ResponseInfo<BranchInfoDTO> response = umsBranchSao.getBranchByBranchNo(sysId, branchNo);
        log.info("根据系统id 和机构编号查询组织机构：结果：{}", JSONObject.toJSONString(response));
        if (response.isSuccess()){
            return response.getData();
        }
        return null;

    }

    /**
     *  根据组织机构获取 分公司/归属城市
     *  type: CITY --> 归属城市
     *        BRANCH_COMPANY --> 分公司
     * @param branchInfo   组织机构
     * @return              归属城市/分公司
     */
    BranchInfoDTO getBusinessCity(BranchInfoDTO branchInfo, String type){
        if (branchInfo.getBranchType().toString().equals(type)) {
            return branchInfo;
        }else{
            List<BranchInfoDTO> parentData = branchInfo.getParentData();
            if (CollectionUtils.isNotEmpty(parentData)){
                for (BranchInfoDTO dto : parentData){
                    BranchInfoDTO.BranchType branchType = dto.getBranchType();
                    if (branchType.toString().equals(type)) {
                        return dto;
                    }
                }
            }
        }
        return branchInfo;
    }
}

package com.banke.dsp.auth.dto;

import lombok.Data;

/**
 * Created by ex-zhongbingguo on 2017/8/29.
 */
@Data
public class BaseInfoDto {
    private Long id;

    private String sysId;

    private String type;

    private String code;

    private String value;

    private String sort;

    private Long parentId;
}

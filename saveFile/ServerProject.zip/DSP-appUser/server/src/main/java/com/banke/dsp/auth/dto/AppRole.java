package com.banke.dsp.auth.dto;


import org.apache.commons.lang.StringUtils;

/**
 */
public enum AppRole{

    ROLE_SUPER_AGENT {
        
        public String getName() {
            return "SUPER_AGENT";
        }
    },
    ROLE_AGENT {
        public String getName() {
            return "AGENT";
        }
    },
    ROLE_USER {
        public String getName() {
            return "USER";
        }
    },
    //@since 渠道管理
    ROLE_CHANNEL_MGR {
        public String getName() {
            return "CHANNEL_MGR";
        }
    },
    //@since 渠道管理
    ROLE_CHANNEL_USER {
        public String getName() {
            return "CHANNEL_USER";
        }
    };

    //update by zhongbingguo 17/8/16
    public static AppRole getAppRoleByCode(String code){
        if (StringUtils.isNotEmpty(code)){
            for(AppRole appRole : AppRole.values()){
                if(code.equals(appRole.name().toString())){
                    return appRole;
                }
            }
        }
        return null;
    }
    
}

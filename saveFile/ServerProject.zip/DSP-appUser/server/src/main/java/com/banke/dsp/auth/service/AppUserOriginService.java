package com.banke.dsp.auth.service;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dao.AppUserDao;
import com.banke.dsp.auth.dao.AppUserOriginDao;
import com.banke.dsp.auth.dao.TeamMemberMgrDao;
import com.banke.dsp.auth.dto.AppUserOriginDTO;
import com.banke.dsp.auth.dto.TeamStatusEnumDto;
import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.po.AppUserOrigin;
import com.banke.dsp.auth.po.TeamMemberInfo;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by ex-zengfanxi on 2017/10/17.
 */
@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AppUserOriginService {

	@NonNull
	private AppUserOriginDao appUserOriginDao;

	@NonNull
	private final AppUserDao appUserDao;

	@NonNull
	private TeamMemberMgrDao teamMemberMgrDao;

	@Autowired
	private TeamService teamService;


	public ResponseInfo<?> updateAppUserReferrerORinsertOrigin(AppUserOriginDTO appUserOrigin){
		ResponseInfo responseInfo = new ResponseInfo("1001", "", new HashMap());
		Map<String, String> returnMap = new HashMap<>();
		//注册用户
		String cellphone = appUserOrigin.getCellphone();
		AppUserInfo appUserInfo = appUserDao.findByCellphone(cellphone);
		if(appUserInfo == null){
			log.debug("updateAppUserReferrerORinsertOrigin>>>>>>>>根据手机号码找不到用户cellphone"+cellphone);
			responseInfo.setMessage("根据手机号码找不到用户");
			return responseInfo;
		}
		//推荐人用户
		String teamNo = appUserOrigin.getTeamNo();
		String roleLeader = TeamStatusEnumDto.ROLE_OF_LEADER.name();
		TeamMemberInfo teamMemberInfo = teamMemberMgrDao.findByTeamNoAndTeamRoleAndStatus(teamNo,roleLeader,TeamStatusEnumDto.NORMAL.toString());
		if(teamMemberInfo == null){
			log.info("updateAppUserReferrerORinsertOrigin>>>>>>>>根据团队编号找不到团长teamNo"+teamNo+",roleLeader:"+roleLeader+",NORMAL:"+TeamStatusEnumDto.NORMAL.toString());
			responseInfo.setMessage("根据团队编号找不到团长teamNo"+teamNo);
			return responseInfo;
		}
		String agentNo = teamMemberInfo.getAgentNo();
		AppUserInfo appUserInfoOne = appUserDao.findByMongoId(agentNo);
		if(appUserInfoOne == null){
			log.info("updateAppUserReferrerORinsertOrigin>>>>>>>>该团团长用户信息不存在teamNo:"+teamNo+",MongoId: +"+agentNo);
			responseInfo.setMessage("该团团长用户信息不存在teamNo:"+teamNo+",MongoId: +"+agentNo);
			return responseInfo;
		}
		log.info("判断被邀请人与邀请人是否是同一业务城市  是才修改被邀请人的客户经理  BusinessCityid： "+appUserInfoOne.getBusinessCityid().equals(appUserInfo.getBusinessCityid()));
		if(appUserInfoOne.getBusinessCityid().equals(appUserInfo.getBusinessCityid())){
			//执行修改
			log.info("updateAppUserReferrerORinsertOrigin>>>>>>>>teamNo："+teamNo+",MongoId:"+appUserInfoOne.getMongoId() +"正在修改MongoId："+appUserInfo.getMongoId()+"的客户经理RefererName："+appUserInfoOne.getRefererName()
					+",Referrer:"+appUserInfoOne.getReferrer()+"开始");
			appUserInfo.setRefererName(appUserInfoOne.getRefererName());
			appUserInfo.setReferrer(appUserInfoOne.getReferrer());
			appUserDao.save(appUserInfo);
			log.info("updateAppUserReferrerORinsertOrigin>>>>>>>>teamNo："+teamNo+",MongoId:"+appUserInfoOne.getMongoId() +"正在修改MongoId："+appUserInfo.getMongoId()+"的客户经理RefererName："+appUserInfoOne.getRefererName()
					+",Referrer:"+appUserInfoOne.getReferrer()+"完成");
		}
		AppUserOrigin newAppUserOrigin = new AppUserOrigin();
		newAppUserOrigin.setMongoId(appUserInfo.getMongoId());
		newAppUserOrigin.setInvitationId(appUserInfoOne.getMongoId());
		newAppUserOrigin.setSource(appUserOrigin.getSource());
		newAppUserOrigin.setInvitationDate(LocalDateTime.now());
		appUserOriginDao.save(newAppUserOrigin);
		log.info("updateAppUserReferrerORinsertOrigin>>>>>>>>向appUserOrigin表中插入推荐人关系数据");
		responseInfo.setCode("0000");
		responseInfo.setMessage("成功");
		return responseInfo;
	}
}

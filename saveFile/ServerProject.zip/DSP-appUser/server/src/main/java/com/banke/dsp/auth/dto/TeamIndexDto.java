package com.banke.dsp.auth.dto;


import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class TeamIndexDto {

    public TeamIndexDto(String teamNo, String teamName, String status, String notice, String teamRole) {
        this.teamNo = teamNo;
        this.teamName = teamName;
        this.status = status;
        this.notice = notice;
        this.teamRole = teamRole;
    }

    public TeamIndexDto(String teamRole) {
        String data = "";
        this.teamNo = data;
        this.teamName = data;
        this.status = data;
        this.notice = data;
        this.teamRole = teamRole;
    }


    //团队编号
    private String teamNo;

    //团队名称
    private String teamName;

    //团队状态
    private String status;

    //团队公告
    private String notice;

    //团队角色
    private String teamRole;


}

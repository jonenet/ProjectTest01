package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.po.AddressInfo;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by ex-zhongbingguo on 2018/3/14.
 */
public interface AddressInfoDao extends CrudRepository<AddressInfo, Long> {

    AddressInfo findByAgentNoAndAddressType(String agentNo, String addressType);
}

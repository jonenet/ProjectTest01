package com.banke.dsp.auth.service;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dao.AppUserDao;
import com.banke.dsp.auth.dao.ApplyInfoDao;
import com.banke.dsp.auth.dto.ApplyInfoDTO;
import com.banke.dsp.auth.dto.ClientInfoDTO;
import com.banke.dsp.auth.dto.OrderApplyInfoDto;
import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.po.ApplyInfo;
import com.banke.dsp.auth.sao.CifClientInfoSao;
import com.banke.dsp.auth.sao.OrdOrderSao;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Describe:
 * Created by zhangyong on 2017/8/28.
 */
@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ApplyInfoService {

    @Value("${beforeCheckImg.process}")
    private String beforeCheckImgProcess;

    @Value("${afterConfirmMes.process}")
    private String afterConfirmMesProcess;

    @Value("${afterSubmitRecommend.process}")
    private String afterSubmitRecommendProcess;

    @NonNull
    private ApplyInfoDao applyInfoDAO;

    @NonNull
    private OrdOrderSao ordOrderSao;

    @NonNull
    private CifClientInfoSao cifClientInfoSao;
    @NonNull
    private AppUserDao appUserDao;

    /**
     * App 团队长查看团员的推单信息
     *
     * @param teamNo  团队编号
     * @param agentNo 业务员编码
     * @return
     */
    public ResponseInfo<?> findApplyInfoByAgentNo(String teamNo, String agentNo) {
        List<ApplyInfoDTO> applyInfoDTOList = new ArrayList<ApplyInfoDTO>();
        Map<String,Object> map = new HashMap<>();
        try {
            String nickName = "";
            AppUserInfo appUserInfo = appUserDao.findByMongoId(agentNo);
            if (null != appUserInfo) {
                nickName = appUserInfo.getNickname();  //昵称
            }
            // 查询所有符合的 订单信息
            List<ApplyInfo> applyInfoList = applyInfoDAO.findApplyInfoByLimit(teamNo, agentNo, beforeCheckImgProcess.split(","),
                    afterConfirmMesProcess.split(","), afterSubmitRecommendProcess.split(","));
            // 查询客户的 名字
            for (ApplyInfo applyInfo : applyInfoList) {
                // 申请时间
                ApplyInfoDTO applyInfoDTO = new ApplyInfoDTO();
                applyInfoDTO.setApplyDate(applyInfo.getApplyDate());
                // 查询客户的编号
                ResponseInfo<OrderApplyInfoDto> orderApplyInfoDtoResponseInfo = ordOrderSao.findByApplyNo(applyInfo.getApplyNo());
                OrderApplyInfoDto orderApplyInfoDto = null;
                if (orderApplyInfoDtoResponseInfo != null) {
                    orderApplyInfoDto = orderApplyInfoDtoResponseInfo.getData();
                }
                // 查询客户的姓名
                if (orderApplyInfoDto != null) {
                    ResponseInfo<ClientInfoDTO> clientInfoDTOResponseInfo = cifClientInfoSao.queryByClientNo(orderApplyInfoDto.getClientNo());
                    if (clientInfoDTOResponseInfo != null) {
                        ClientInfoDTO clientInfoDTO = clientInfoDTOResponseInfo.getData();
                        String customerName = clientInfoDTO != null ? clientInfoDTO.getClientName() : "";
                        applyInfoDTO.setClientName(customerName);
                    }
                }
                applyInfoDTOList.add(applyInfoDTO);
            }
            map.put("nickName",nickName);
            map.put("applyInfoDTOList",applyInfoDTOList);
        } catch (Exception e) {
            return ResponseInfo.error(null);
        }
        return ResponseInfo.success(map);
    }


}

package com.banke.dsp.auth.api;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.bkc.service.util.ContextHolder;
import com.banke.dsp.auth.dto.TokenDto;
import com.banke.dsp.auth.service.AppWalletService;
import com.banke.dsp.auth.service.YqbPayService;
import com.google.common.collect.Maps;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by ex-panhuayu on 2017/6/26.
 */
@RestController
@RequestMapping(value = "/api/", method = {RequestMethod.GET, RequestMethod.POST})
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class WalletApi {

    @NonNull
    private final AppWalletService appWalletService;
    @NonNull
    private final YqbPayService yqbPayService;

    /**
     * disp token查询用户信息
     * * @param token
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("/saveWallet")
    public ResponseInfo<?> saveWallet(@RequestBody TokenDto token) {
        return appWalletService.saveWallet(token);
    }

    /**
     * disp 根据mongoId查询平安付用户会员号
     *
     * @param mongoId
     * @return
     * @throws Exception
     */
    @RequestMapping("/getWalletUid")
    public ResponseInfo<?> getWalletUid(@RequestParam("mongoId") String mongoId) {
        return appWalletService.findByMidAndIsVaildIsTrue(mongoId);
    }


    /**
     * disp 根据用户token查询yqb token
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("/getYqbToken")
    public ResponseInfo<?> getYqbToken(String cv, String agentNo) {

        Map yqbToken = appWalletService.getYqbToken(cv, agentNo);
        String cv1 = (String) yqbToken.get("cv");
        if (!StringUtils.isEmpty(cv1) && cv1.equals("LOWVERSION")) {
            HashMap<String, Object> map = Maps.newHashMap();
            map.put("token", "");
            return new ResponseInfo("1002", "版本过低", map);
        }

        return ResponseInfo.success(yqbToken);
    }

    /**
     * 查询佣金计算中的金额和可提现金额
     * CreateBy lingsuzhi
     *
     * @return map
     */
    @RequestMapping("/appuser/findSettlementAndBalance")
    public ResponseInfo<Map> findPaySumAmount() {
        String agentNo = ContextHolder.getAgentNo();

        String settlement = yqbPayService.findPaySumAmount(agentNo);
        if(settlement==null)settlement = "0.00";

        String balance = yqbPayService.getBalance(agentNo);
        if(balance==null)balance = "0.00";

        Map<String, String> map = Maps.newHashMap();
        map.put("settlement", settlement);//结算中
        map.put("balance", balance);//可提现
        return ResponseInfo.success(map);
    }
}

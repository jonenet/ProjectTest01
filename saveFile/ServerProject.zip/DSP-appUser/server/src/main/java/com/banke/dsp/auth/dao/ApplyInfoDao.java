package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.po.ApplyInfo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Describe:
 * Created by zhangyong on 2017/8/28.
 */
public interface ApplyInfoDao extends CrudRepository<ApplyInfo, Long> {

    /**
     * App 团队长查看团员的推单信息
     * @param agentNo 业务员编码
     * @param beforeCheckImgProcess  图片核查通过前的 流程
     * @param afterConfirmMesProcess  信息确认完成后的 流程
     * @param afterSubmitRecommendProcess  用户提交推荐前的 流程
     * @return
     */
    @Query(value = "select a from ApplyInfo a,TeamMemberInfo t" +
            "  where  a.agentNo = t.agentNo " +
            "  and (  ((a.taskId = '01' or a.taskId = '03') and a.applyStatus not in (:beforeCheckImgProcess) )" +
            "   or (a.taskId = '02' and a.applyStatus in (:afterConfirmMesProcess) )" +
            "   or (a.taskId = '05' and a.applyStatus in (:afterSubmitRecommendProcess) )" +
            "   or (a.taskId = '07' and a.applyStatus in (:afterSubmitRecommendProcess) )" +
            "   ) " +
            "   and a.agentNo = :agentNo " +
            "   and t.teamNo = :teamNo " +
            "   and a.applyDate > t.joinDate" +
            "   and t.status != 'DELETE' order by a.applyDate DESC " )
    public List<ApplyInfo> findApplyInfoByLimit(@Param("teamNo")String teamNo,@Param("agentNo")String agentNo, @Param("beforeCheckImgProcess")String[] beforeCheckImgProcess,
                                                  @Param("afterConfirmMesProcess")String[] afterConfirmMesProcess,
                                                  @Param("afterSubmitRecommendProcess")String[] afterSubmitRecommendProcess);
}

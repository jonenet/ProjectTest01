package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.po.RegisterConstraintLog;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by ex-zhongbingguo on 2017/11/3.
 */
public interface RegisterConstraintLogDao extends CrudRepository<RegisterConstraintLog, Long> {


}

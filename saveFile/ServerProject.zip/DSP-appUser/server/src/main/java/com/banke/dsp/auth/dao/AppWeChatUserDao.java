package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.po.AppWeChatUser;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by ex-zengfanxi on 2018/02/27.
 */
public interface AppWeChatUserDao extends CrudRepository<AppWeChatUser, Long> {

	AppWeChatUser findByOpenid(String openid);
}

package com.banke.dsp.auth.po;


import com.banke.bkc.framework.po.BasePO;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Lob;
import javax.persistence.Table;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "appuser_upgrade")
public class AppuserUpgrade extends BasePO{

    private String agentNo;

    //真实姓名
    private String realName;

    //身份证号
    private String identityNumber;

    //银行卡号
    private String bankCardNumber;

    //银行预留手机号码
    private String cellphone;

    //身份证正面图片Id
    private String identityZmImageId;

    //身份证反面图片Id
    private String identityFmImageId;

    //头像图片Id
    private String identityTxImageId;

    //身份证其他信息
    @Lob
    @Column(name="other_info",columnDefinition="TEXT")
    private String otherInfo;

}

package com.banke.dsp.auth.service;

import com.banke.dsp.auth.dao.TeamChargeMessageDao;
import com.banke.dsp.auth.dao.TeamInfoDao;
import com.banke.dsp.auth.po.TeamChargeMessage;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by ex-taozhangyi on 2018/2/27.
 */
@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class TeamChargeMessageService {
    @NonNull
    private TeamChargeMessageDao teamChargeMessageDao;


    /**
     * 读取冲锋哈
     * @param teamNo
     * @param mongoId
     * @param msgStatus
     * @return
     */
    public TeamChargeMessage findByteamNoAndmongoIdAndmsgStatus(String teamNo,String mongoId,String msgStatus){
        return teamChargeMessageDao.findByTeamNoAndMongoIdAndMsgStatus(teamNo,mongoId,msgStatus);
    }

    public  void save(TeamChargeMessage teamChargeMessage){
        teamChargeMessageDao.save(teamChargeMessage);
    }

    public List<TeamChargeMessage> getTeamChargeMessageBy(String agentNo){
        return teamChargeMessageDao.getTeamChargeMessageBy(agentNo);
    }
}

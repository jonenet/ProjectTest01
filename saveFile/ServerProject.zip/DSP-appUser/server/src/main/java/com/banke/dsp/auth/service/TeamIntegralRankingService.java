package com.banke.dsp.auth.service;

import com.banke.dsp.auth.dao.TeamInfoDao;
import com.banke.dsp.auth.dao.TeamIntegralRankingDao;
import com.banke.dsp.auth.dto.TeamStatusEnumDto;
import com.banke.dsp.auth.po.TeamInfo;
import com.banke.dsp.auth.po.TeamIntegralRanking;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by ex-taozhangyi on 2018/2/28.
 */
@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class TeamIntegralRankingService {
    @NonNull
    private TeamIntegralRankingDao teamIntegralRankingDao;
    @NonNull
    private TeamInfoDao teamInfoDao;

    public List<Object[]> getTeamIntegralRankingOrderBy(String teamNo){
        return teamIntegralRankingDao.getTeamIntegralRankingOrderBy(teamNo);
    }

    public List<Map<String,Object>> getTeamIntegralRankingByRowNoIn(String ranking){
        log.info("---------排名："+ranking);
        int count = teamIntegralRankingDao.countBy();
        int[] tmp = null;
        if(StringUtils.isNotEmpty(ranking)){
             int pm = Integer.parseInt(ranking);
             //判断总数小于等于10，
             if(count <= 10){
                 tmp = new int[count];
                 for(int i=1;i<=count;i++){
                    tmp[i-1]=i;
                 }
             }else{
                 //前7排名取前10排名显示
                 if(pm <= 7){
                     tmp = new int[10];
                     for(int i=1;i<=10;i++){
                         tmp[i-1] =i;
                     }
                   //排名后4区后7位
                 }else if((pm+3) >= count){
                     tmp = new int[10];
                     tmp[0] = 1;
                     tmp[1] = 2;
                     tmp[2] = 3;
                     for(int i=0;i<7;i++){
                         tmp[i+3] = count-6+i;  //区后7位排名
                     }
                  //中间排名，取排名前后3位排名
                 }else{
                     tmp = new int[10];
                     tmp[0] = 1;
                     tmp[1] = 2;
                     tmp[2] = 3;
                     for(int i=0;i<7;i++){
                         tmp[i+3] = pm -3+i;//取前后3位排名
                     }
                 }
             }

        }
        DecimalFormat format = new DecimalFormat("0");
        List<Map<String,Object>> listMap = new ArrayList<Map<String,Object>>();
        List<Object[]>  listObj = teamIntegralRankingDao.getTeamIntegralRankingByRownoIn(tmp);
        if(null != listObj && listObj.size() > 0 ){
            for (Object[] obj:listObj) {
                Map<String,Object> map = new HashMap<String,Object>();
                if(null != obj[1]){
                    TeamInfo teamInfo = teamInfoDao.findByTeamNoAndStatusNot(obj[1].toString(), TeamStatusEnumDto.DELETE.toString());
                    //判断团队是否存在
                    if(null != teamInfo){
                        map.put("grade",teamInfo.getGrade());
                        map.put("ranking",format.format(obj[4]));
                        map.put("teamName",obj[2]);
                        map.put("teamIntegral",obj[3]);
                        listMap.add(map);
                    }
                }
            }
        }
        return listMap;
    }

    public TeamIntegralRanking findByTeamNo(String teamNo){
        return teamIntegralRankingDao.findByTeamNo(teamNo);
    }
}

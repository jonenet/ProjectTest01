package com.banke.dsp.auth.po;

import com.banke.bkc.framework.po.BasePO;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * Created by ex-zengfanxi on 2018/02/27.
 */
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "app_wechat_user")
public class AppWeChatUser extends BasePO {


	//接口调用凭证
	private String accessToken;

	//access_token接口调用凭证超时时间
	private String expiresIn;

	//用户刷新access_token
	private String refreshToken;

	//授权用户唯一标识
	private String openid;

	//用户授权的作用域，使用逗号（,）分隔
	private String scope;

	//当且仅当该移动应用已获得该用户的userinfo授权时，才会出现该字段
	private String unionid;

	//微信注册时间
	@JsonSerialize(using = LocalDateTimeSerializer.class)
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime signDate;

}

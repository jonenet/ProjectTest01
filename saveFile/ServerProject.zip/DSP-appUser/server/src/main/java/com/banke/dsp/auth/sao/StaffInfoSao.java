package com.banke.dsp.auth.sao;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dto.StaffInfoDTO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * Created by ex-zhongbingguo on 2017/8/15.
 */
@FeignClient(name = "WRK-staff")
public interface StaffInfoSao {

    @RequestMapping("/api/staffInfo/getStaffInfoByUserId")
    ResponseInfo<StaffInfoDTO> getStaffInfoByUserId(@RequestParam(name = "userId") String userId);

    @RequestMapping("/api/staffInfo/getStaffInfoByBranchNo")
    ResponseInfo<List<StaffInfoDTO>> getStaffInfoByBranchNo(@RequestParam(name = "branchNo") String branchNo);

    @RequestMapping("/api/staffInfo/queryStaffInfo")
    ResponseInfo<List<StaffInfoDTO>> queryStaffInfo(@RequestParam(value = "roleId", required = false) String roleId,@RequestParam(value = "branchNo", required = false)String branchNo,
                                                    @RequestParam(value = "userId", required = false) String userid,@RequestParam(value= "staffName", required = false) String staffName );
}

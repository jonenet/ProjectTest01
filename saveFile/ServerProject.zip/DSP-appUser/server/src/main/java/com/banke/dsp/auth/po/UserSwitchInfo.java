package com.banke.dsp.auth.po;


import com.banke.bkc.framework.po.BasePO;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "user_switch_info")
public class UserSwitchInfo extends BasePO {
    //用户代理id
    private String agentNo;

    //开关名称
    private String name;

    //开关值
    private String value;

    //开关类型
    private String type;
}

package com.banke.dsp.auth.dto;

import com.banke.dsp.auth.po.TeamGrade;
import lombok.Data;

/**
 * Created by ex-zhongbingguo on 2017/12/8.
 */
@Data
public class TeamGradeQueryResult extends TeamGrade {

    private String businessCityiName;

    private String keepRule;

    private String promoteRule;
}

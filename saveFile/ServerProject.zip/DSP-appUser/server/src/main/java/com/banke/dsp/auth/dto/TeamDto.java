package com.banke.dsp.auth.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Created by ex-liqiaoyong on 2017/7/24.
 */
@Data
@NoArgsConstructor
public class TeamDto {

    public TeamDto(String teamNo, String teamName, String status, String notice, String teamRole){
        this.teamNo = teamNo;
        this.teamName = teamName;
        this.status = status;
        this.notice = notice;
        this.teamRole = teamRole;
    }

    //总数
    private String cnt;

    //团队编号
    private String teamNo;

    //团长ID
    private String agentNo;

    //团队名称
    private String teamName;

    //团队状态
    private String status;

    //团队公告
    private String notice;

    //删除
    private String delete;

    //手机号
    private String cellPhone;

    //团队角色
    private String teamRole;

    //成立时间
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime establishDate;

    //解散时间
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime disbandDate;
}

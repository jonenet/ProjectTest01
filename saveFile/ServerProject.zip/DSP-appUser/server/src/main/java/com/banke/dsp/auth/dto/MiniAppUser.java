package com.banke.dsp.auth.dto;

import lombok.Data;

import javax.persistence.Column;
import java.time.LocalDateTime;

/**
 * Created by luoyifei on 2017/5/24.
 */
@Data
public class MiniAppUser {

    @Column
    private Long id;

    /**
     * 对应用户
     */
    @Column
    private Long userId;

    @Column
    private String openid;

    @Column
    private String token;

    @Column
    private LocalDateTime tokenDate;

    @Column
    private String avatarUrl; // 微信头像

    @Column
    private String city; // 所在城市

    @Column
    private String gender; // 性别（1：man 2： woman）

    @Column
    private String nickName; // 微信名

    @Column
    private String province; // 所在省

    @Column
    private String latitude; // 纬度

    @Column
    private String longitude; // 经度

}

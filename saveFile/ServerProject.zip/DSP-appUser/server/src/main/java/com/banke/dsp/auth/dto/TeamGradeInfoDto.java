package com.banke.dsp.auth.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Created by ex-taozhangyi on 2018/2/5.
 */
@Data
public class TeamGradeInfoDto {
    private String gradeCode;         //等级编码
    private String gradeName;         //等级人数
    private Integer maxMemNum;        //最大输入
    private BigDecimal tlRebateRatio;  //团长返佣比例
    private BigDecimal tnRebateRatio;  //团员返佣比例
    private BigDecimal maxRebate;  //最大返佣基数

    private Map<String,Integer> byNumber;    //白银成员数
    private Map<String,Integer> byAnnouncement; //公告
    private Map<String,Integer> byChargeNumber; //冲锋号


    private Map<String,Integer> hjNumber;    // 累计邀请5位评估神新用户入团
    private Map<String,Integer> hjTeamIntegral;  // 团队积分达2500分
    private Map<String,Integer> hjFinishLoan;   //团队成功放款两笔及以上
    private Map<String,Integer> hjFinishThird;   //有效推荐一笔及以上第	三方产品

    private Map<String,Integer> zsNumber;   //成员数达到15个人及以上
    private Map<String,Integer> zsTeamIntegral;  //团队积分达3000分
    private Map<String,Integer> zsFinishLoan;   //团队总放款笔数10笔及以上
    private Map<String,Integer> zsFinishThird; //团队第三方产品成功放款3笔及以上
    private Map<String,Integer> zsActiveNumber;  //团队当月活跃用户人数10人及以上

    private Integer remainingGrade;  //  剩余任务


}

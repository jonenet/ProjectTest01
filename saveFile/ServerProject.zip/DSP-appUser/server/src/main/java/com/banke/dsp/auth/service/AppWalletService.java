package com.banke.dsp.auth.service;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.bkc.service.util.ContextHolder;
import com.banke.dsp.auth.dao.AppUserDao;
import com.banke.dsp.auth.dao.AppWalletDao;
import com.banke.dsp.auth.dao.AppuserUpgradeDao;
import com.banke.dsp.auth.dto.AppRole;
import com.banke.dsp.auth.dto.BankListDTO;
import com.banke.dsp.auth.dto.TokenDto;
import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.po.AppuserUpgrade;
import com.banke.dsp.auth.po.WalletInfo;
import com.banke.dsp.auth.sao.AdtYqbSao;
import com.banke.dsp.auth.sao.QueryDispSao;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by ex-panhuayu on 2017/6/26.
 */
@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AppWalletService {

    @NonNull
    private final AppWalletDao appWalletDao;

    @NonNull
    private final AppUserDao appUserDao;

    @NonNull
    private QueryDispSao queryDispSao;

    @NonNull
    private AdtYqbSao adtYqbSao;

    @NonNull
    private AppuserUpgradeDao appuserUpgradeDao;

    @Autowired
    private AppUserUpgradeService appUserUpgradeService;

    @Value("${yqb.switch}")
    private String yqbSwitch;

    /**
     * 保存用户和平安付的关联关系
     *
     * @param token
     * @return
     */
    public ResponseInfo<?> saveWallet(TokenDto token) {
        //用户 id及mogoID
        String mid = token.getMid();
        //平安付会员号
        String uid = token.getUid();
        //token
        String tokenStr = token.getToken();

        if (StringUtils.isEmpty(mid) || StringUtils.isEmpty(uid) || StringUtils.isEmpty(tokenStr)) {
            return ResponseInfo.error("入参不能为空");
        }

        AppUserInfo user = appUserDao.findByMongoId(mid);
        if (user == null) {
            return ResponseInfo.error(mid + "该用户ID查询不到对应用户");
        }

        WalletInfo wall = appWalletDao.findByMid(mid);
        if (wall == null) {
            wall = new WalletInfo();
        }

        wall.setToken(tokenStr);
        wall.setMid(mid);
        wall.setUid(uid);

        wall.setMerchantId(token.getMerchantId());
        wall.setSignature(token.getSignature());
        wall.setCustomerId(token.getCustomerId());
        if ("T".equals(token.getStatus())) {
            wall.setIsVaild(true);
        } else if ("U".equals(token.getStatus())) {
            wall.setIsVaild(false);
        }
        appWalletDao.save(wall);
        return ResponseInfo.success("成功");
    }


    /**
     * 根据mongoid平安付会员账号
     *
     * @param mongoId
     * @return
     */
    public ResponseInfo<?> findByMidAndIsVaildIsTrue(String mongoId) {
        WalletInfo walletInfo = appWalletDao.findByMidAndIsVaildIsTrue(mongoId);
        if (null != walletInfo) {
            return ResponseInfo.success(true);
        } else {
            return ResponseInfo.success(false);
        }
    }


    /**
     * 根据用户token获取壹钱包token
     *
     * @param
     * @return
     */
    public Map getYqbToken(String cv, String agentNo) {
        log.info("AppWalletService@getYqbToken  cv:{}, agentNo:{}", cv, agentNo);
        int cvInt = 0;
        if(!StringUtils.isEmpty(cv)){
            try {
                cvInt = Integer.valueOf(cv);
            } catch (NumberFormatException e) {
                log.error("AppWalletService@getYqbToken cv转化失败");
            }
        }

        if(cvInt < 17 ){
            return ImmutableMap.of("cv","LOWVERSION");
        }

        String mongoId = ContextHolder.getAgentNo();
        log.info("获取用户mongoId：{}" + mongoId);
        String isSuperAgent = "N";
        AppUserInfo appUserInfo = appUserDao.findByMongoId(mongoId);
        if(appUserInfo == null){
            appUserInfo = appUserDao.findByMongoId(agentNo);
        }
        if (appUserInfo == null) {
            log.info("{}appUserInfo：{}", mongoId, appUserInfo);
            return ImmutableMap.of("token", "");
        }

        //数据验证
        String realName = appUserInfo.getRealName() == null ? "" : appUserInfo.getRealName();
        String identityNumber = appUserInfo.getIdentityNumber() == null ? "" : appUserInfo.getIdentityNumber();
        String bankAccountCard = appUserInfo.getBankCardNumber() == null ? "" : appUserInfo.getBankCardNumber();
        String canPassCode = "N";
        String isBindBankCard = "N"; //是否绑定银行卡

        //判断是否超过24小时展示邀请码
        if(cvInt > 17){
            try {
                LocalDateTime createdDate = appUserInfo.getCreatedAt();
                LocalDate date = LocalDate.of(createdDate.getYear(), createdDate.getMonth(), createdDate.getDayOfMonth());
                Period between = Period.between(date, LocalDate.now());
                if(between.getDays() >= 1){
                    canPassCode = "Y";
                }
            } catch (Exception e) {
                canPassCode = "Y";
                log.error("24小时验证错误");
            }
        }

        //设空值返回，安卓插件需要
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("token","");
        map.put("isSuperAgent","");
        map.put("realName","");
        map.put("identityNumber","");
        map.put("bankAccountCard","");
        map.put("canPassCode",canPassCode);
        map.put("isBindBankCard", isBindBankCard);
        map.put("otherInfo", "");

        //判断是否为高级用户
        isSuperAgent = getSuperAgent(isSuperAgent, appUserInfo);
        WalletInfo walletInfo = appWalletDao.findByMidAndIsVaildIsTrue(appUserInfo.getMongoId());

        if (null == walletInfo) {
            log.info("{},walletInfo：(壹钱包用户信息为空)", mongoId);
            return map;
        }

        String token = walletInfo.getToken() == null ? "" : walletInfo.getToken();


        //有token， 但不是高级用户
        //调接口判断是否绑卡
//        boolean flag = checkBank(walletInfo.getCustomerId(), walletInfo.getMid());
        boolean flag = false;
        Map bank = Maps.newHashMap();
        if ("new".equals(yqbSwitch)){
            //新需求，返回整个对象
            bank = getBank(walletInfo.getToken());
            flag = (boolean) bank.get("flag");
        }else{
            flag = checkBank(walletInfo.getToken());
        }

        if(flag){
            //成功
            //queryDispSao.userUpgrade(appUserInfo.getMongoId());
            //绑卡成功但不是高级用户，调微服务升级高级用户
//            if(isSuperAgent.equals("N")){
//                try {
//                    userUpgrade(appUserInfo.getMongoId(), "");
//                } catch (Exception e) {
//                    log.info("已绑定银行卡但不是高级用户升级失败 agentNo:{}",appUserInfo.getMongoId());
//                }
//            }
            isSuperAgent = "Y";
            isBindBankCard = "Y";
        }

        //身份证其他信息
        AppuserUpgrade appuserUpgrade = appuserUpgradeDao.findByAgentNo(appUserInfo.getMongoId());
        if(appuserUpgrade != null){
            map.put("otherInfo", appuserUpgrade.getOtherInfo());
        }

        map.put("realName",realName);
        map.put("identityNumber",identityNumber);
        map.put("bankAccountCard",bankAccountCard);
        map.put("isBindBankCard", isBindBankCard);
        map.put("token",token);
        map.put("isSuperAgent",isSuperAgent);
        map.put("canPassCode",canPassCode);
        //新需求
        if ("new".equals(yqbSwitch)){
            map.put("bankCode", bank.get("bankCode"));  // 银行code
            map.put("bankName", bank.get("bankName"));  // 银行名称
            map.put("cardNo", bank.get("cardNo"));      //  银行卡号
            map.put("cardType", bank.get("cardType"));      //  银行卡号
        }
        return map;

    }

    public void userUpgrade(String mid, String status){
        try {
            appUserUpgradeService.userUpgradeToMicroService(mid,status);
        } catch (Exception e) {
            log.info("已有token但不是高级用户升级失败 agentNo:{}",mid);
        }
    }

    private boolean checkBank(String token) {
        boolean flag = false;
        try {
            //ResponseInfo<Boolean> booleanResponseInfo = adtYqbSao.checkBank(cid, mid);
            ResponseInfo<List<BankListDTO>> listResponseInfo = adtYqbSao.getBank(token);
            if(listResponseInfo.isSuccess() && !CollectionUtils.isEmpty(listResponseInfo.getData())){
                flag = true;
            }
        } catch (Exception e) {
            log.error("AppWalletService@checkBank 校验绑卡信息异常 token：{} ",token, e);
        }
        return flag;
    }

    private Map getBank(String token) {
        HashMap<Object, Object> map = Maps.newHashMap();
        boolean flag = false;
        try {
            ResponseInfo<List<BankListDTO>> jsonObject = adtYqbSao.getBank(token);
            log.info("调用壹钱包getBank,结果：{}",jsonObject);
            if(jsonObject.isSuccess() && !CollectionUtils.isEmpty(jsonObject.getData())){
                BankListDTO bankListDTO = jsonObject.getData().get(0);
                map.put("bankCode", bankListDTO.getBankCode());
                map.put("bankName", bankListDTO.getBankName());
                map.put("cardNo", bankListDTO.getCardNo());
                map.put("cardType", bankListDTO.getCardType());
                flag = true;
            }
            map.put("flag", flag);
        } catch (Exception e) {
            log.error("AppWalletService@getBank 获取绑卡信息异常 token：{} ",token, e);
        }
        return map;
    }

    private String getSuperAgent(String isSuperAgent, AppUserInfo appUserInfo) {

        if(appUserInfo.getAppRoles().contains(AppRole.ROLE_SUPER_AGENT.toString())){
            isSuperAgent = "Y";
        }

        return isSuperAgent;
    }


}

package com.banke.dsp.auth.dto;

import lombok.Data;

/**
 * 注册邀请码管理实例
 * Created by ex-zhongbingguo on 2017/8/15.
 */
@Data
public class RegisterConstraintInstenceDTO {
    private  Long id;

    //验证码id
    private  String registerId;

    //验证码
    private  String registerCode;

    //地推人员id
    private  String clientManagerId;

    //地推人员name
    private  String clientManagerName;

    //已使用次数
    private  int usedCount;

    //是否启用
    private  boolean enabled;

    //业务机构id
    private  String branchNo;

    //业务机构名称
    private  String branchName;
}

package com.banke.dsp.auth.dto;

import lombok.Data;

@Data
public class Channel{
    
	private String id;
	
    private String code;
    
    private String cityCode;
    
    private String name;
    
    private String sortNo;
    
    private String status;
    
}

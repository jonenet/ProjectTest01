package com.banke.dsp.auth.sao;

import com.alibaba.fastjson.JSONObject;
import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dto.TeamCommissionDto;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.math.BigDecimal;
import java.util.List;

@FeignClient(value = "BKG-calc")
public interface TeamSao {

    @RequestMapping("/api/team/findTeamCommission")
    ResponseInfo<List<TeamCommissionDto>> findTeamCommission(@RequestParam("teamNo") String teamNo, @RequestParam("agentNo") String agentNo);

    @RequestMapping("/api/team/findTeamCommissionAmount")
    ResponseInfo<BigDecimal> findTeamCommissionAmount(@RequestParam("teamNo") String teamNo, @RequestParam("agentNo") String agentNo);
}

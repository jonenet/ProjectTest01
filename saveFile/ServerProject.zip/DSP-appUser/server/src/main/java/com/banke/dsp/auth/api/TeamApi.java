package com.banke.dsp.auth.api;

import com.banke.bkc.framework.exception.BusinessException;
import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.bkc.service.util.ContextHolder;
import com.banke.dsp.auth.dto.*;
import com.banke.dsp.auth.po.*;
import com.banke.dsp.auth.sao.OrdOrderSao;
import com.banke.dsp.auth.service.*;
import com.banke.dsp.auth.util.EmojiUtil;
import com.google.common.collect.Maps;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Slf4j
@RestController
@RequestMapping(value = "/api", method = {RequestMethod.GET, RequestMethod.POST})
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class TeamApi {
    @NonNull
    private TeamService teamService;
    @NonNull
    private TeamInfoService teamInfoService;
    @NonNull
    private TeamGradeService teamGradeService;
    @NonNull
    private TeamChargeMessageService teamChargeMessageService;
    @NonNull
    private AppUserService appUserService;
    @NonNull
    private AppUserOriginService appUserOriginService;
    @NonNull
    private TeamIntegralService teamIntegralService;
    @NonNull
    private OrdOrderSao ordOrderSao;
    @NonNull
    private TeamIntegralRankingService teamIntegralRankingService;
    private ResponseInfo responseInfo = new ResponseInfo("1001", "", new HashMap());

    public static String trimRight(String sString) {
        String sResult;
        if (sString.startsWith(" ")) {
            sResult = sString.substring(0, sString.indexOf(sString.trim().substring(0, 1))
                    + sString.trim().length());
        } else {
            sResult = sString;
        }
        return sResult;
    }

    /**
     * 获取团队列表
     *
     * @return
     */
    @RequestMapping("/getTeamListForMember")
    public ResponseInfo<?> getTeamListForMember() {
        String agentNo = ContextHolder.getAgentNo();
        log.info("TeamApi@getTeamListForMember agentNo:" + agentNo);
        if (StringUtils.isBlank(agentNo)) {
            responseInfo.setMessage("哎呀出错了，请稍后重试！");
            return responseInfo;
        }

        Map teamListForMember = teamService.getTeamListForMember(agentNo);
        return ResponseInfo.success(teamListForMember);
    }

    /**
     * 创建团队
     */
    @RequestMapping("/createTeam")
    public ResponseInfo<?> createTeam(@RequestParam String teamName) {
        String agentNo = ContextHolder.getAgentNo();
        log.info("TeamApi@createTeam agentNo:{}", agentNo);
        //校验用户编号
        if (StringUtils.isBlank(agentNo)) {
            responseInfo.setMessage("哎呀出错了，请稍后重试！");
            return responseInfo;
        }
        //过滤表情
        teamName = EmojiUtil.filterEmoji(teamName);
        //校验用户是否具备创建团队的资格
        if (!teamService.checkCreateTeamOfUser(agentNo)) {
            responseInfo.setMessage("你已创建团队，不能再创建");
            return responseInfo;
        }


        //校验用户名长度
        if (teamName.length() < 2 || teamName.length() > 12) {
            responseInfo.setMessage("团队名称长度不正确");
            return responseInfo;
        }

        //校验团队名是否存在
        TeamInfo duplicateTeamName = teamService.findByTeamNameAndStatusNot(teamName, TeamStatusEnumDto.DELETE.toString());
        if (null != duplicateTeamName) {
            responseInfo.setMessage("团队名已存在");
            return responseInfo;
        }

        //校验用户名敏感词
        String msg = teamService.checkSensitiveWords(teamName);
        if (StringUtils.isNotBlank(msg)) {
            responseInfo.setMessage("团队名含敏感词");
            return responseInfo;
        }

        TeamInfo teamInfo = teamService.createTeam(agentNo, teamName, TeamStatusEnumDto.OPT_BY_LEADER.toString());

        return ResponseInfo.success(teamInfo);
    }

    /**
     * 根据团队编号查询团队信息
     */
    @RequestMapping("/getTeamInfoByTeamNo")
    public ResponseInfo<?> getTeamInfoByTeamNo(@RequestParam String teamNo) {

        TeamInfo byTeamNo = null;
        if (teamNo.length() != 6) {
            //传入的是手机号查人员信息
            AppUserInfo userInfo = appUserService.findByCellphone(teamNo);
            if (userInfo == null) {
                responseInfo.setMessage("未搜索到该团队");
                return responseInfo;
            }
            byTeamNo = teamService.findByAgentNoAndStatus(userInfo.getMongoId(), TeamStatusEnumDto.NORMAL.toString());
        } else {
            byTeamNo = teamService.findByTeamNoAndStatus(teamNo, TeamStatusEnumDto.NORMAL.toString());
        }

        if (byTeamNo == null) {
            responseInfo.setMessage("未搜索到该团队");
            return responseInfo;
        }
        int MAX_MEMBER = teamService.getTeamMaxNumber(byTeamNo);
        if (teamService.findMemberCnt(byTeamNo.getTeamNo()) > MAX_MEMBER) {
            responseInfo.setMessage("该团队成员已满");
            return responseInfo;
        }

        return ResponseInfo.success(byTeamNo);
    }

    /**
     * H5获取团队信息
     *
     * @param teamNo
     * @return
     */
    @RequestMapping("/getTeamInfoByTeamNoForH5")
    public ResponseInfo<?> getTeamInfoByTeamNoForH5(@RequestParam String teamNo) {
        Map<String, Object> map = new HashMap<String, Object>();
        TeamInfo byTeamNo = teamService.findByTeamNoAndStatus(teamNo, TeamStatusEnumDto.NORMAL.toString());
        map.put("userName", "");
        if (byTeamNo == null) {
            responseInfo.setMessage("未搜索到该团队");
            return responseInfo;
        }
        int memberCnt = teamService.findMemberCnt(byTeamNo.getTeamNo());
        int MAX_MEMBER = teamService.getTeamMaxNumber(byTeamNo);
        if (memberCnt > MAX_MEMBER) {
            responseInfo.setMessage("该团队成员已满");
            return responseInfo;
        }
        AppUserInfo userInfo = appUserService.findByAgentNo(byTeamNo.getAgentNo());
        if (userInfo != null) {
            map.put("userName", userInfo.getUserName());
        }
        map.put("teamName", byTeamNo.getTeamName());
        map.put("memberCnt", memberCnt);

        return ResponseInfo.success(map);
    }

    /**
     * H5判断手机号信息
     *
     * @param phone
     * @return
     */
    @RequestMapping("/checkPhoneForH5")
    public ResponseInfo<?> checkPhoneForH5(@RequestParam String phone, @RequestParam String teamNo) {
        //判断该手机号是否评估神用户
        AppUserInfo byCellphone = appUserService.findByCellphone(phone);
        if (byCellphone == null) {
            return new ResponseInfo("2001", "你输入的手机号尚未注册评估神", "");
        }

        if (teamService.checkExistTeamOfMember(byCellphone.getMongoId(), teamNo)) {
            return new ResponseInfo("2003", "你已加入该团队", "");
        }

        //判断该手机号是否加入过其他团队
        if (teamService.joinOrtherTeam(byCellphone.getMongoId())) {
            return new ResponseInfo("2002", "你已加入其它团队", "");
        }

        return ResponseInfo.success("");
    }

    /**
     * 加入团队
     *
     * @param teamNo
     * @return
     */
    @RequestMapping("/joinTeam")
    public ResponseInfo<?> joinTeam(@RequestParam String teamNo) {
        teamNo = EmojiUtil.filterEmoji(teamNo);
        String agentNo = ContextHolder.getAgentNo();
        log.info("TeamApi@joinTeam agentNo:{}, teamNo:{}", agentNo, teamNo);

        if (StringUtils.isBlank(agentNo)) {
            responseInfo.setMessage("哎呀出错了，请稍后重试！");
            return responseInfo;
        }

        if (StringUtils.isBlank(teamNo)) {
            responseInfo.setMessage("请输入团队ID或团长手机号");
            return responseInfo;
        }
        TeamInfo byTeamNo = null;

        if (teamNo.length() != 6) {
            //传入的是手机号查人员信息
            AppUserInfo userInfo = appUserService.findByCellphone(teamNo);
            if (userInfo == null) {
                responseInfo.setMessage("未搜索到该团队");
                return responseInfo;
            }

            byTeamNo = teamService.findByAgentNoAndStatus(userInfo.getMongoId(), TeamStatusEnumDto.NORMAL.toString());
        } else {
            byTeamNo = teamService.findByTeamNoAndStatus(teamNo, TeamStatusEnumDto.NORMAL.toString());
        }

        if (byTeamNo == null) {
            responseInfo.setMessage("未搜索到该团队");
            return responseInfo;
        }
        teamNo = byTeamNo.getTeamNo(); //重赋值

        if (teamService.checkExistTeamOfMember(agentNo, teamNo)) {
            responseInfo.setMessage("你已经申请过加入该团队");
            return responseInfo;
        }

        if (teamService.joinOrtherTeam(agentNo)) {
            responseInfo.setMessage("你已经申请过加入其它团队");
            return responseInfo;
        }
        int MAX_MEMBER = teamService.getTeamMaxNumber(byTeamNo);
        if (teamService.findMemberCnt(teamNo) >= MAX_MEMBER) {
            responseInfo.setMessage("该团队成员已满");
            return responseInfo;
        }
        ResponseInfo<?> responseInfo = teamService.pushJoinTeamMessage(agentNo, teamNo);
        String teamId = null;
        Map<String, String> map = new HashMap<String, String>();
        map.put("teamNo", teamNo);
        if (responseInfo.isSuccess()) {
            teamId = responseInfo.getData().toString();
            map.put("id", teamId);
            map.put("teamText", "已发出入团申请");
        } else {
            map.put("teamText", "发出入团申请失败");
        }
        return ResponseInfo.success(map);
    }

    /**
     * @return 团长同意或不同意加入团队
     */
    @RequestMapping(value = "/agree/joinTeam", method = RequestMethod.POST)
    @ResponseBody
    public ResponseInfo<?> agreeJoinTeam(@RequestBody AgreeJoinTeam agreeJoinTeam) throws BusinessException {
        String agentNo = ContextHolder.getAgentNo();
        //判断是否加入过其他团队
        if (teamService.joinOrtherTeam(agreeJoinTeam.getApplySerialNO())) {
            responseInfo.setMessage("该团员已经申请加入其它团队");
            return responseInfo;
        }
        String teamNo = teamService.argeeJoinTeam(agreeJoinTeam, agentNo);
        //判断是否同意加入团队
        if (null != agreeJoinTeam && "agree".equals(agreeJoinTeam.getAgree())) {
            //调用升级接口
            teamInfoService.teamGradeProcess(teamNo);
        }
        return ResponseInfo.success(teamNo);
    }

    /**
     * 加入团队团长邀请
     *
     * @param cellPhone
     * @param teamNo
     * @return
     */
    @RequestMapping("/joinTeamByTeamLeader")
    public ResponseInfo<?> joinTeamByTeamLeader(@RequestParam String cellPhone, @RequestParam String teamNo, String opt) {
        if (StringUtils.isBlank(cellPhone) || StringUtils.isBlank(teamNo)) {
            log.info("TeamApi@joinTeamByTeamLeader 参数不能为空 cellPhone:{}, teamNo{}", cellPhone, teamNo);
            responseInfo.setMessage("参数不能为空");
            return responseInfo;
        }
        //校验该手机号是不是评估神用户
        AppUserInfo userInfo = appUserService.findByCellphone(cellPhone);
        if (userInfo == null) {
            responseInfo.setMessage("你输入的手机号尚未注册评估神");
            return responseInfo;
        }

        if (teamService.checkExistTeamOfMember(userInfo.getMongoId(), teamNo)) {
            responseInfo.setMessage("你已加入该团队");
            return responseInfo;
        }

        if (teamService.joinOrtherTeam(userInfo.getMongoId())) {
            responseInfo.setMessage("你已加入其它团队");
            return responseInfo;
        }
        TeamInfo byTeamNo = teamService.findByTeamNoAndStatus(teamNo, TeamStatusEnumDto.NORMAL.toString());
        if (null == byTeamNo) {
            responseInfo.setMessage("团队编号不存在");
            return responseInfo;
        }
        int MAX_MEMBER = teamService.getTeamMaxNumber(byTeamNo);
        if (teamService.findMemberCnt(teamNo) >= MAX_MEMBER) {
            responseInfo.setMessage("该团队成员已满");
            return responseInfo;
        }

        String optUser = StringUtils.isEmpty(opt) ?
                TeamStatusEnumDto.OPT_BY_LEADER.toString() : TeamStatusEnumDto.OPT_BY_OPERATE.toString();

        TeamMemberInfo teamMemberInfo = teamService.joinTeam(userInfo, teamNo,
                TeamStatusEnumDto.ROLE_OF_MEMBER.toString(), optUser);

        //邀请用户奖励积分100
        teamIntegralService.save(userInfo.getMongoId(), 1);
        log.info("邀请用户奖励积分");

        //调用升级接口
        teamInfoService.teamGradeProcess(teamNo);

        return ResponseInfo.success(teamMemberInfo);
    }

    /**
     * 修改团队信息
     *
     * @return
     */
    @RequestMapping("/updateTeam")
    public ResponseInfo<?> updateTeam(@RequestParam(required = false) String teamName,
                                      @RequestParam String teamNo,
                                      @RequestParam(required = false) String notice,
                                      String opt) {
        log.info("TeamApi@updateTeam 团队名字，编号 teamName:{},teamNo:{}", teamName, teamNo);
        log.info("TeamApi@updateTeam 团队公告参数 notice:{} ", notice);
        log.info("TeamApi@updateTeam opt opt:{} ", opt);
        //非空判断
        if (StringUtils.isBlank(teamName) && StringUtils.isBlank(notice)) {
            responseInfo.setMessage("参数不能为空");
            return responseInfo;
        }

        //校验团队名
        if (StringUtils.isNotBlank(teamName)) {
            //校验用户名长度
            if (teamName.trim().length() < 2 || teamName.trim().length() > 12) {
                responseInfo.setMessage("团队名称长度不正确");
                return responseInfo;
            }
            //校验用户名敏感词
            String msg = teamService.checkSensitiveWords(teamName);
            if (StringUtils.isNotBlank(msg)) {
                responseInfo.setMessage("团队名含敏感词");
                return responseInfo;
            }
            //校验团队名是否存在
            if (teamService.checkTeamNameExist(teamName)) {
                responseInfo.setMessage("该团队名已存在");
                return responseInfo;
            }
        }

        if (StringUtils.isNotBlank(notice)) {

            //过滤表情符号
            notice = EmojiUtil.filterEmoji(notice);
            notice = trimRight(notice);
            //校验公告长度
            if (notice.length() > 200) {
                responseInfo.setMessage("团队公告不能大于200个字");
                return responseInfo;
            }
            //校验公告敏感词
            String msg = teamService.checkSensitiveWords(notice);
            if (StringUtils.isNotBlank(msg)) {
                responseInfo.setMessage("公告包含敏感词");
                return responseInfo;
            }
        }

        //校验团队
        TeamInfo teamInfo = teamService.findByTeamNo(teamNo);
        if (teamInfo == null) {
            responseInfo.setMessage("未搜索到该团队");
            return responseInfo;
        }

        TeamDto teamDto = new TeamDto();
        teamDto.setTeamName(teamName);
        teamDto.setNotice(notice);
        teamDto.setTeamNo(teamNo);

        String optUser = StringUtils.isEmpty(opt) ?
                TeamStatusEnumDto.OPT_BY_LEADER.toString() : TeamStatusEnumDto.OPT_BY_OPERATE.toString();

        //修改团队
        teamInfo = teamService.updateTeam(teamInfo, teamDto, optUser);


        return ResponseInfo.success(teamInfo);
    }

    /**
     * 删除团队
     *
     * @return
     */
    @RequestMapping("/deleteTeam")
    public ResponseInfo<?> deleteTeam(@RequestParam String teamNo) {
        TeamInfo teamInfo = teamService.deleteTeam(teamNo);
        return ResponseInfo.success(teamInfo);
    }

    /**
     * 删除成员
     *
     * @return
     */
    @RequestMapping("/deleteMember")
    public ResponseInfo<?> deleteMember(@RequestParam String agentNo, @RequestParam String teamNo,
                                        @RequestParam(required = false) String delete) {
        TeamMemberInfo teamMemberInfo = teamService.deleteMember(agentNo, teamNo, delete);
        return ResponseInfo.success(teamMemberInfo);
    }

    /**
     * 团长首页
     *
     * @return
     */
    @RequestMapping("/getTeamLeaderIndex")
    public ResponseInfo<?> getTeamLeaderIndex() {

        String agentNo = ContextHolder.getAgentNo();
        log.info("TeamApi@getTeamLeaderIndex agentNo:{}", agentNo);

        if (StringUtils.isBlank(agentNo)) {
            responseInfo.setMessage("哎呀出错了，请稍后重试！");
            return responseInfo;
        }

        TeamInfo teamInfo = teamService.findByAgentNoAndStatusNot(agentNo, TeamStatusEnumDto.DELETE.toString());
        if (teamInfo == null) {
            responseInfo.setMessage("哎呀出错了，请稍后重试！");
            return responseInfo;
        }

        Map<String, Object> map = teamService.setFullTeamInfo(teamInfo);
        //外快
        String commission = teamService.findMyCommission(teamInfo.getTeamNo(), agentNo);
        map.put("commission", teamService.formatNumber2(commission));

        return ResponseInfo.success(map);
    }

    /**
     * 团员首页
     *
     * @param teamNo
     * @return
     */
    @RequestMapping("/getTeamMemberIndex")
    public ResponseInfo<?> getTeamMemberIndex(@RequestParam String teamNo) {
        String agentNo = ContextHolder.getAgentNo();
        log.info("TeamApi@getTeamMemberIndex teamNo:{}, agentNo:{}", teamNo, agentNo);
        if (StringUtils.isBlank(teamNo) || StringUtils.isBlank(agentNo)) {
            responseInfo.setMessage("哎呀出错了，请稍后重试！");
            return responseInfo;
        }

        TeamInfo teamInfo = teamService.findByTeamNo(teamNo);
        if (teamInfo == null) {
            responseInfo.setMessage("哎呀出错了，请稍后重试！");
            return responseInfo;
        }

        Map<String, Object> map = teamService.setFullTeamInfo(teamInfo);
        //外快
        String commission = teamService.findMyCommission(teamInfo.getTeamNo(), agentNo);
        map.put("commission", teamService.formatNumber2(commission));

        return ResponseInfo.success(map);
    }


    /**
     * 根据用户编号和时间， 判断该用户是否在团队中
     *
     * @param agentNo
     * @param date
     * @return
     */
    @RequestMapping("/getTeamInfo")
    public ResponseInfo<?> getTeamInfo(@RequestParam("agentNo") String agentNo, @RequestParam("date") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime date) {
        responseInfo.setMessage("TeamApi@getTeamInfo agentNo:" + agentNo + " date:" + date);
        if (StringUtils.isBlank(agentNo) || date == null) {
            responseInfo.setMessage("参数不能为空 agentNo:" + agentNo + " date:" + date);
            return responseInfo;
        }
        //查询团员信息
        AppUserInfo userInfo = appUserService.findByAgentNo(agentNo);
        if (userInfo == null) {
            log.info("查询团员信息异常 agentNo:{}", agentNo);
            responseInfo.setMessage("查询团员信息异常");
            return responseInfo;
        }
        TeamMemberInfo teamMemberInfo = teamService.getTeamInfo(agentNo, date);
        if (teamMemberInfo == null || teamMemberInfo.getTeamRole().equals(TeamStatusEnumDto.ROLE_OF_LEADER.toString())) {
            responseInfo.setMessage("此用户不在团队中");
            return responseInfo;
        }


        TeamGrade teamGrade = teamGradeService.findByTeamNo(teamMemberInfo.getTeamNo());
        if (null == teamGrade) {
            log.info("查询团队等级信息异常 teamNo:{}", teamMemberInfo.getTeamNo());
            responseInfo.setMessage("查询团队等级信息异常");
            return responseInfo;
        }
        //团长信息
        AppUserInfo appUser = teamService.getTeamLeaderInfo(teamMemberInfo.getTeamNo());
        if (appUser == null) {
            log.info("查询团队长信息异常 teamNo:{}", teamMemberInfo.getTeamNo());
            responseInfo.setMessage("查询团队长信息异常");
            return responseInfo;
        }
        Map<String, Object> map = Maps.newHashMap();
        map.put("callPhone", appUser.getCellphone());  //团长手机号
        map.put("memberCallPhone", userInfo.getCellphone()); //团员手机号
        map.put("agentNo", appUser.getMongoId());  //团长ID
        map.put("teamNo", teamMemberInfo.getTeamNo()); //团队编号
        map.put("teamGrade", teamGrade);  //团队等级信息

        return ResponseInfo.success(map);
    }

    /**
     * 获取成员列表
     *
     * @param teamNo
     * @return
     */
    @RequestMapping("/getMemberList")
    public ResponseInfo<?> getMemberList(@RequestParam(required = true) String teamNo) {

        Map<String, Object> teamMemberInfo = teamService.getMemberListByTeamNo(teamNo);

        return ResponseInfo.success(teamMemberInfo);
    }

    @RequestMapping("/getMemberInfo")
    public ResponseInfo<?> getMemberInfo(String agentNo, String teamNo) {
        TeamMemberInfo teamMemberInfo = teamService.findByAgentNoAndTeamNoAndStatusNot(agentNo, teamNo, TeamStatusEnumDto.DELETE.toString());
        return ResponseInfo.success(teamMemberInfo);
    }

    //团队外快
    @RequestMapping("/getAmountMemberList")
    public ResponseInfo<?> getAmountMemberList(@RequestParam String teamNo, @RequestParam String agentNo) {
        // 调接口获取佣金成员列表
        ResponseInfo responseInfo = teamService.getAmountMemberList(teamNo, agentNo);
        return responseInfo;
    }

    @RequestMapping("/clearCache")
    public ResponseInfo<?> clearCache(@RequestParam String key) {
        teamService.clearCache(key);
        return ResponseInfo.success("");
    }

    @RequestMapping("/getCache")
    public ResponseInfo<?> getCache(@RequestParam String key) {
        Object cache = teamService.getCache(key);
        return ResponseInfo.success(cache);
    }

    @RequestMapping("/updateAppUserReferrer")
    public ResponseInfo<?> updateAppUserReferrerORinsertOrigin(@RequestBody AppUserOriginDTO appUserOrigin) {
        String teamNo = appUserOrigin.getTeamNo();
        String source = appUserOrigin.getSource();
        String cellphone = appUserOrigin.getCellphone();
        if (StringUtils.isBlank(teamNo) || StringUtils.isBlank(source) || StringUtils.isBlank(cellphone)) {
            responseInfo.setMessage("存在空值teamNo：" + teamNo + ",source:" + source + ",cellphone:" + cellphone);
            return responseInfo;
        }
        return appUserOriginService.updateAppUserReferrerORinsertOrigin(appUserOrigin);
    }

    /**
     * 团队等级接口
     */
    @RequestMapping("/getTeamGrade")
    public ResponseInfo<?> getTeamGrade(@RequestParam String teamNo) throws BusinessException {
        if (StringUtils.isEmpty(teamNo)) {
            responseInfo.setMessage("团队编号不能为空！");
            return responseInfo;
        }
        TeamGradeInfoDto teamGradeInfoDto = teamService.findByTeamGradeInfoDto(teamNo);
        return ResponseInfo.success(teamGradeInfoDto);
    }


    /**
     * 团队积分新增接口
     * type  指积分来源类型
     *
     * @return
     */
    @RequestMapping("/addTeamIntegral")
    public ResponseInfo<?> addTeamIntegral(@RequestParam int type) {
        String agentNo = ContextHolder.getAgentNo();
        if (type == 2) {
            AppUserInfo appUserInfo = appUserService.findByAgentNo(agentNo);
            if (null != appUserInfo) {
                //获取当前用户注册时间
                LocalDateTime localDateTime = appUserInfo.getCreatedAt();
                //两个时间差的天
                Duration duration = Duration.between(localDateTime, LocalDateTime.now());
                long day = duration.toDays();
                log.info("{}:用户注册到第一次推单时间为：{}", agentNo, day);
                //          2  邀请新用户：100
                //          4  新用户首次推单：200
                if (day <= 7) {
                    ResponseInfo<Integer> responseInfo = ordOrderSao.getAgentNoCnt(agentNo);
                    log.info("responseInfo:{}", responseInfo);
                    if (responseInfo.isSuccess()) {
                        if (responseInfo.getData() == 1) {
                            type = 4;
                        }
                    }
                }
            }
        }
        teamIntegralService.save(agentNo, type);
        return ResponseInfo.success(true);
    }

    /**
     * 测试团队升级接口
     *
     * @return
     */
    @RequestMapping("/testTeamUp")
    public ResponseInfo<?> testTeamUp() {
        log.info("---------------团队等级调整--------------------------");
        teamService.executeTeamUpgradeJob();
        return ResponseInfo.success(true);
    }

    /**
     * 测试等级排序接口
     *
     * @return
     */
    @RequestMapping("/testTeamIntegralRanking")
    public ResponseInfo<?> testTeamIntegralRanking() {
        log.info("---------------等级排序接口--------------------------");
        teamIntegralService.executeTeamIntegralRankingJob();
        return ResponseInfo.success(true);
    }

    /**
     * 团队冲锋号
     *
     * @return
     */
    @RequestMapping("/teamChargeNumber")
    public ResponseInfo<?> teamChargeNumber(@RequestParam String teamNo, @RequestParam String agentNo) {
        log.info("--------teamNo-------" + teamNo);
        log.info("--------agentNo-------" + agentNo);
        //判断本周是否发起过冲锋号
        List<TeamChargeMessage> teamChargeMessageList = teamChargeMessageService.getTeamChargeMessageBy(agentNo);
        if (null != teamChargeMessageList && teamChargeMessageList.size() > 0) {
            responseInfo.setMessage("本周内您已经对该团员发起过冲锋号！");
            return responseInfo;
        } else {
            teamService.teamChargeNumber(teamNo, agentNo);
            //调用升级接口
            teamInfoService.teamGradeProcess(teamNo);
            return ResponseInfo.success(true);
        }
    }

    /**
     * 读取团队冲锋号
     *
     * @return
     */
    @RequestMapping("/readTeamChargeNumber")
    public ResponseInfo<?> readTeamChargeNumber(@RequestParam String teamNo) {
        log.info("--------teamNo-------" + teamNo);
        if (StringUtils.isEmpty(teamNo)) {
            responseInfo.setMessage("团队编号不能为空！");
            return responseInfo;
        }
        //获取用户号
        String agentNo = ContextHolder.getAgentNo();
        log.info("agentNo:" + agentNo);

        TeamChargeMessage teamChargeMessage = teamChargeMessageService.findByteamNoAndmongoIdAndmsgStatus(teamNo, agentNo, "UNREAD");
        if (null != teamChargeMessage) {
            //修改状态为已读
            teamChargeMessage.setMsgStatus("READ");
            teamChargeMessageService.save(teamChargeMessage);

            return ResponseInfo.success(teamChargeMessage);
        } else {
            return ResponseInfo.error(teamChargeMessage);
        }
    }

    /**
     * 团队等级排名详情
     * ranking 排名
     *
     * @return
     */
    @RequestMapping("/teamGradeRankingInfo")
    public ResponseInfo<?> teamGradeRankingInfo(@RequestParam String ranking) {
        List<Map<String, Object>> listMap = teamIntegralRankingService.getTeamIntegralRankingByRowNoIn(ranking);
        return ResponseInfo.success(listMap);
    }

    /**
     * 积分详情
     *
     * @return
     */
    @RequestMapping("/teamIntegralInfo")
    public ResponseInfo<?> teamIntegralInfo(@RequestParam String teamNo) {
        return teamIntegralService.teamIntegralInfo(teamNo);
    }
}

package com.banke.dsp.auth.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * Created by luoyifei on 2017/6/13.
 */
@Data
public class AllMiniAppUserInfo {

    //手机号码
    private String cellphone;

    //注册日期
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdAt;

    //身份证号
    private String identityNumber;

    //真实名称
    private String realName;

    /**
     * 对应用户
     */
    private Long userId;

    private String openid;

    private String avatarUrl; // 微信头像

    private String city; // 所在城市

    private String gender; // 性别（1：man 2： woman）

    private String nickName; // 微信名

    private String province; // 所在省



}

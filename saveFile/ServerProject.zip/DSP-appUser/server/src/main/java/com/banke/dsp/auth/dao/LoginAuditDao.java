package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.po.LoginAudit;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by ex-zhongbingguo on 2017/11/7.
 */
public interface LoginAuditDao extends CrudRepository<LoginAudit, Long> {
}

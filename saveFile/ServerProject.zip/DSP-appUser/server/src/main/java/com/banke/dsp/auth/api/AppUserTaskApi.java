package com.banke.dsp.auth.api;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dto.AppUserTaskDTO;
import com.banke.dsp.auth.service.AppUserTaskService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * Created by ex-zhongbingguo on 2018/3/16.
 */
@RestController
@RequestMapping(value = "/api/appUser/task", method = {RequestMethod.GET, RequestMethod.POST})
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AppUserTaskApi {

    @Autowired
    private AppUserTaskService appUserTaskService;

    @RequestMapping("/query")
    public ResponseInfo<AppUserTaskDTO> query(@RequestParam String mongoId){
        return ResponseInfo.success(appUserTaskService.query(mongoId));
    }

    @RequestMapping("/queryNewDatas")
    ResponseInfo<List<Map<String, String>>> queryNewDatas(@RequestParam(name = "startTime") String startTime,
                                                          @RequestParam(name = "endTime") String endTime){
        return  ResponseInfo.success(appUserTaskService.queryNewDatas(startTime, endTime));
    }

    @RequestMapping("/update")
    public ResponseInfo<?> update(AppUserTaskDTO task){
        return appUserTaskService.update(task);
    }
}

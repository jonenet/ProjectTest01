package com.banke.dsp.auth.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * Created by luoyifei on 2017/5/23.
 *
 * 发送注册邀请码请求
 */

@Data
public class RegisterRequestDTO {

    @Column
    private Long id;

    @Column
    private String requestId;

    @Column
    private String passCode;

    /**
     * 过期时间
     */
    @Column
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime expiredAt;

    /**
     * 重复请求验证码的时间
     */
    @Column
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime requestedAt;

    /**
     * 手机号码
     */
    @Column
    private String telphone;

    @Column
    private Integer counter;
}

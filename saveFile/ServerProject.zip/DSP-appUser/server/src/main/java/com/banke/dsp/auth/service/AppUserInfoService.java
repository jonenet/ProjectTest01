package com.banke.dsp.auth.service;

import com.banke.dsp.auth.dao.AppUserDao;
import com.banke.dsp.auth.dto.AppUserQueryParameter;
import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.util.DateUtil;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by ex-zhongbingguo on 2017/8/21.
 */
@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AppUserInfoService {

    @NonNull
    private final AppUserDao appUserDao;

    public AppUserInfo save(AppUserInfo appUserInfo){
        return appUserDao.save(appUserInfo);
    }

    public AppUserInfo findById(Long id){
        return  appUserDao.findOne(id);
    }

    public AppUserInfo findByCellphone(String cellphone){
        return  appUserDao.findByCellphone(cellphone);
    }

    public AppUserInfo findByUserName(String userName){
        return  appUserDao.findByUserName(userName);
    }

    public AppUserInfo findByOpenid(String openid){
        return  appUserDao.findByOpenid(openid);
    }

    public AppUserInfo findByMongoId(String mongoId){
        return appUserDao.findByMongoId(mongoId);
    }

    public Page<AppUserInfo> findByCondition(AppUserQueryParameter request) {
        Specification<AppUserInfo> specification = new Specification<AppUserInfo>() {
            @Override
            public Predicate toPredicate(Root<AppUserInfo> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (StringUtils.isNotEmpty(request.getCellphone())){
                    list.add(cb.like(root.get("cellphone").as(String.class),"%" + request.getCellphone() + "%"));
                }
                if (StringUtils.isNotEmpty(request.getUserName())){
                    list.add(cb.like(root.get("userName").as(String.class),"%" + request.getUserName() + "%"));
                }
                if (StringUtils.isNotEmpty(request.getRefererName())){
                    list.add(cb.like(root.get("refererName").as(String.class),"%" + request.getRefererName() + "%"));
                }
                if (StringUtils.isNotEmpty(request.getRealName())){
                    list.add(cb.like(root.get("realName").as(String.class), "%" + request.getRealName() + "%"));
                }
                if (StringUtils.isNotEmpty(request.getCreatedAtBegin())){
                    list.add(cb.greaterThanOrEqualTo(root.get("createdAt"), DateUtil.stringToLocalDateTime(request.getCreatedAtBegin())));
                }
                if (StringUtils.isNotEmpty(request.getCreatedAtEnd())){
                    list.add(cb.lessThanOrEqualTo(root.get("createdAt"), DateUtil.dateToLocalDateTime(DateUtils.addDays(DateUtil.stringToDate(request.getCreatedAtEnd()),1))));
                }
                if (StringUtils.isNotEmpty(request.getIdentityNumber())){
                    list.add(cb.like(root.get("identityNumber").as(String.class), "%" + request.getIdentityNumber() + "%"));
                }
                if (StringUtils.isNotEmpty(request.getUserType())){
                    if ("ROLE_SUPER_AGENT".equals(request.getUserType())){
                        list.add(cb.like(root.get("appRoles").as(String.class), "%" + request.getUserType() + "%"));
                    }else{
                        list.add(cb.notLike(root.get("appRoles").as(String.class), "%" + "ROLE_SUPER_AGENT" + "%"));
                    }
                }
                if (request.getEnabled() != null ){
                    list.add(cb.equal(root.get("enabled").as(Boolean.class), request.getEnabled()));
                }
                if (StringUtils.isNotEmpty(request.getBusinessCityid()) && CollectionUtils.isEmpty(request.getBusinessCityids()) ){
                    list.add(cb.equal(root.get("businessCityid").as(String.class), request.getBusinessCityid()));
                }
                if (CollectionUtils.isNotEmpty(request.getBusinessCityids())){
                    list.add(root.get("businessCityid").in(request.getBusinessCityids()))  ;
                }
                if (StringUtils.isNotEmpty(request.getSource())){
                    list.add(cb.equal(root.get("source").as(String.class), request.getSource()));
                }
                if (StringUtils.isNotEmpty(request.getReferrer())){
                    list.add(cb.equal(root.get("referrer").as(String.class), request.getReferrer()));
                }
                if(CollectionUtils.isNotEmpty(request.getLists())){
                    list.add(root.get("referrer").in(request.getLists()))  ;
                }
                if (StringUtils.isNotEmpty(request.getAscription()) && CollectionUtils.isEmpty(request.getAscriptions())){
                    list.add(cb.equal(root.get("ascription").as(String.class), request.getAscription()));
                }
                if(CollectionUtils.isNotEmpty(request.getAscriptions())){
                    list.add(root.get("ascription").in(request.getAscriptions()));
                }
                if (request.getAscriptionStatus() != null){
                    list.add(cb.equal(root.get("ascriptionStatus").as(Boolean.class), request.getAscriptionStatus()));
                }
                Predicate[] p = new Predicate[list.size()];
                return cb.and(list.toArray(p));
            }
        };

        Sort sort = new Sort(Sort.Direction.DESC, "createdAt");
        if (request.getPageNum() == -1){
            List<AppUserInfo> all = appUserDao.findAll(specification, sort);
            return new PageImpl(all);
        }

        Pageable pageable = new PageRequest(request.getPageNum(), request.getPageSize(), sort);
        return appUserDao.findAll(specification, pageable);
    }

}

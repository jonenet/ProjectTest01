package com.banke.dsp.auth.api;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dto.team.TeamSearchParam;
import com.banke.dsp.auth.service.TeamMgrService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 后台-团队管理
 * Created by linzhimou on 2017/7/26.
 */
@RestController
@Slf4j
@RequestMapping(value = "/api/console/team/", method = {RequestMethod.GET, RequestMethod.POST})
public class TeamMgrApi {

    @Autowired
    private TeamMgrService teamMgrService;

    /**
     * 查询团队列表
     * @param teamSearch 查询条件
     * @return
     */
    @RequestMapping("/list")
    public ResponseInfo<?> getTeamList(TeamSearchParam teamSearch){
        PageRequest pageReq = new PageRequest(
                teamSearch.getPageNum(),teamSearch.getPageSize(),null);
        return teamMgrService.getTeamList(teamSearch, pageReq);
    }

    /**
     * 导出数据时查询团队数据
     * @param teamSearch 查询条件
     * @return
     */
    @RequestMapping("/listDownload")
    public ResponseInfo<?> getTeamListDownload(TeamSearchParam teamSearch){
        return teamMgrService.getTeamList(teamSearch, null);
    }

    /**
     * 团队成员列表
     * @param teamSearch 查询条件
     * @return
     */
    @RequestMapping("/members")
    public ResponseInfo<?> getTeamMembers(TeamSearchParam teamSearch){
        return teamMgrService.getTeamMembers(teamSearch);
    }

    /**
     * 立即解散团队
     * @param teamNo 团队编号
     * @return
     */
    @RequestMapping("/disband")
    public ResponseInfo<?> disbandTeam(@RequestParam(required = true) String teamNo){
        teamMgrService.disbandTeam(teamNo);
        return ResponseInfo.success("");
    }

    /**
     * 移除团队成员
     * @param teamNo 团队编号
     * @param agentNo 成员id
     * @return
     */
    @RequestMapping("/removeMember")
    public ResponseInfo<?> removeTeamMember(@RequestParam(required = true) String teamNo,
                                          @RequestParam(required = true)String agentNo){
        int updateRows = teamMgrService.removeTeamMember(teamNo, agentNo);
        if(updateRows == 0){
            return ResponseInfo.error("该团员不在团队中或已移除");
        }
        return ResponseInfo.success("");
    }

    /**
     * 更换团长
     * @param teamNo
     * @param agentNo
     * @return
     */
    @RequestMapping("/changeLeader")
    public ResponseInfo<?> changeTeamLeader(@RequestParam(required = true) String teamNo,
                                            @RequestParam(required = true)String agentNo){
        ResponseInfo result = teamMgrService.changeTeamLeader(teamNo, agentNo);
        return result;
    }

    /**
     * 查询当月推单数和放款金额
     * @param teamNo
     * @return
     */
    @RequestMapping("/applyAndOrder")
    public ResponseInfo<?> getApplyAndOrderInfo(@RequestParam(required = true)String teamNo){
        ResponseInfo result = teamMgrService.getApplyAndOrderInfo(teamNo);
        return result;
    }

    /**
     *  根据手机号查询团队成员信息
     * @param cellphone
     * @return
     */
    @RequestMapping("/searchMember")
    public ResponseInfo<?> searchMemberInfo(@RequestParam(required = true)String cellphone){
        ResponseInfo result = teamMgrService.searchMemberInfo(cellphone);
        return result;
    }

    /**
     * 更换团队
     * @param memberId
     * @param newTeamNo
     * @param newTeamNo
     * @return
     */
    @RequestMapping("/changeTeam")
    public ResponseInfo<?> changeTeam(@RequestParam(required = true)Long memberId,
                                      @RequestParam(required = true)String newTeamNo,
                                      String newTeamRole){
        ResponseInfo result = teamMgrService.changeTeam(memberId, newTeamNo, newTeamRole);
        return result;
    }

}

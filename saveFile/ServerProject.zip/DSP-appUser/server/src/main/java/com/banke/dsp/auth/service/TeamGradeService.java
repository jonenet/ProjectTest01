package com.banke.dsp.auth.service;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dao.TeamGradeDao;
import com.banke.dsp.auth.dao.TeamInfoDao;
import com.banke.dsp.auth.dto.*;
import com.banke.dsp.auth.po.TeamGrade;
import com.banke.dsp.auth.po.TeamInfo;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by ex-zhongbingguo on 2017/12/8.
 */
@Service
@Slf4j
public class TeamGradeService {

    @Autowired
    private TeamGradeDao teamGradeDao;
    @Autowired
    private TeamInfoDao teamInfoDao;

    @Autowired
    private BranchInfoService branchInfoService;

    /**
     * 查询每个等级的佣金比例
     * @return
     */
    public TeamGrade findByTeamNo(String teamNo){
        //查询团队信息
        TeamInfo teamInfo = teamInfoDao.findByTeamNoAndStatusNot(teamNo,TeamStatusEnumDto.DELETE.toString());
        log.info("----teamInfo---"+teamInfo);
        if(null != teamInfo){
            /**
             * 老团队默认等级为BY
             */
            String  gradeCode = teamInfo.getGrade();
            //判断是否为老团队
            if(StringUtils.isEmpty(gradeCode)){
                gradeCode = "BY";
            }

            //城市
            String cityCode = teamInfo.getCityCode();
            TeamGrade teamGrade = teamGradeDao.findByBusinessCityidAndGradeCode(cityCode,teamInfo.getGrade());
            if(null == teamGrade){
                teamGrade =teamGradeDao.findByBusinessCityidAndGradeCode("ALL", gradeCode);
            }
            return  teamGrade;
        }else{
            return null;
        }


    }

    public ResponseInfo<?> delete(Long id){
        log.info("TeamGradeService@delete: {}", id);
        teamGradeDao.delete(id);
        return ResponseInfo.success(true);
    }

    public ResponseInfo<?> save(TeamGrade teamGrade){
        log.info("TeamGradeService@insert: {}", teamGrade);

//        String s = ParamValidatorUtil.validNullAndBlank(teamGrade, "businessCityid", "gradeCode", "maxMemNum", "tlRebateRatio", "maxRebate");
//        if (s != null) return ResponseInfoDTO.error(s);

        TeamGrade tg = teamGradeDao.findByBusinessCityidAndGradeCode(teamGrade.getBusinessCityid(), teamGrade.getGradeCode());
        if (tg != null) return ResponseInfoDTO.error("该业务城市，"+ TeamGradeEnum.getDesc(teamGrade.getGradeCode())+"等级已经存在");

        //String data = pinyinSao.covertToPinYin(teamGrade.getGradeName()).getData();
        //teamGrade.setGradeCode(data);
        teamGrade.setGradeName(TeamGradeEnum.getDesc(teamGrade.getGradeCode()));
        return ResponseInfo.success(teamGradeDao.save(teamGrade));
    }

    public ResponseInfo<?> update(TeamGrade teamGrade){
        log.info("TeamGradeService@update: {}", teamGrade);

//        String s = ParamValidatorUtil.validNullAndBlank(teamGrade);
//        if (s != null) return ResponseInfoDTO.error(s);

        TeamGrade tg = teamGradeDao.findOne(teamGrade.getId());
        BeanUtils.copyProperties(teamGrade, tg, "gradeCode","businessCityid");
        return ResponseInfo.success(teamGradeDao.save(tg));
    }


    public List<TeamGrade> list(String businessCityid, String gradeCode) {
        log.info("TeamGradeService@list=> businessCityid:{}, gradeName:{}", businessCityid, gradeCode);
        return this.listByCondition(businessCityid, gradeCode);
    }

    private Page<TeamGrade> pageByCondition(TeamGradeQueryParameter request) {
        Specification<TeamGrade> specification = new Specification<TeamGrade>() {
            @Override
            public Predicate toPredicate(Root<TeamGrade> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (StringUtils.isNotEmpty(request.getGradeName())){
                    list.add(cb.like(root.get("gradeName").as(String.class),"%" + request.getGradeName() + "%"));
                }
                if (StringUtils.isNotEmpty(request.getGradeCode())){
                    list.add(cb.like(root.get("gradeCode").as(String.class),request.getGradeCode()));
                }
                if (StringUtils.isNotEmpty(request.getBusinessCityid())){
                    list.add(cb.like(root.get("businessCityid").as(String.class),request.getBusinessCityid()));
                }
                Predicate[] p = new Predicate[list.size()];
                return cb.and(list.toArray(p));
            }
        };

        Sort sort = new Sort(Sort.Direction.DESC, "createdBy");
        Pageable pageable = new PageRequest(request.getPageNum(), request.getPageSize(), sort);
        return teamGradeDao.findAll(specification, pageable);
    }

    private List<TeamGrade> listByCondition(String businessCityid, String gradeCode){
        return teamGradeDao.findAll(new Specification<TeamGrade>() {
            @Override
            public Predicate toPredicate(Root<TeamGrade> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = Lists.newArrayList();

                if (StringUtils.isNotEmpty(businessCityid)){
                    list.add(cb.equal(root.get("businessCityid").as(String.class), businessCityid));
                }
                if (StringUtils.isNotEmpty(gradeCode)){
                    list.add(cb.equal(root.get("gradeCode").as(String.class), gradeCode));
                }

                Predicate[] p = new Predicate[list.size()];
                return cb.and(list.toArray(p));
            }
        });
    }



}

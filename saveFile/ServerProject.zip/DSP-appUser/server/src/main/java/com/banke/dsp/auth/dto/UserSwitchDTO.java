package com.banke.dsp.auth.dto;

import lombok.Data;

@Data
public class UserSwitchDTO {
    //用户代理id
    private String agentNo;

    //开关名称
    private String name;

    //开关值
    private String value;

    //开关类型
    private String type;
}

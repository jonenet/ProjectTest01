package com.banke.dsp.auth.dto;

import lombok.Data;

/**
 * 注册时用户信息
 * @author luoyifei
 *
 */
@Data
public class AppUserRegisterDTO {
	
	/**
	 * 手机号码
	 */
	private String telphone;

	/**
	 * 请求ID
	 */
	private String requestId;

	private String passCode;

	private String password;
}

package com.banke.dsp.auth.service;

import com.alibaba.fastjson.JSONObject;
import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dto.RegisterRequestDTO;
import com.banke.dsp.auth.sao.SendSMSRequestRepositorySao;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by ex-zhongbingguo on 2017/9/5.
 */
@Service
@Slf4j
public class RegisterRequestService {

    @Autowired
    private SendSMSRequestRepositorySao sendSMSRequestRepositorySao;

    /**
     *  根据 requestId 查询验证码
     * @param requestId        验证码id
     */
    public RegisterRequestDTO findRegisterRequestByRequestId(String requestId){
        ResponseInfo<RegisterRequestDTO> response = sendSMSRequestRepositorySao.findRegisterRequestByRequestId(requestId);
        log.info("result to registerRequestInfo: {}", JSONObject.toJSONString(response));
        if (response!= null && response.isSuccess()){
            return response.getData();
        }
        return null;
    }

}

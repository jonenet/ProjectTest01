package com.banke.dsp.auth.po;

import com.banke.bkc.framework.po.BasePO;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Created by ex-taozhangyi on 2018/2/6.
 */
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "team_integral")
public class TeamIntegral extends BasePO {
    private String teamNo;  //团队编号
    private Integer newIntegral;  //新增积分
    private String integralSource;  //积分来源
    private String agentNo; //用户ID
}

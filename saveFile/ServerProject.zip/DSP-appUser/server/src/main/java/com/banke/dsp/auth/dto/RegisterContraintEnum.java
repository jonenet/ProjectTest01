package com.banke.dsp.auth.dto;

/**
 * Created by ex-zhongbingguo on 2017/11/2.
 */
public enum RegisterContraintEnum {
    PUBLISHED_ID(10, "1"),
    PENDING_ID(20, "2");

    int code;
    String value;

    RegisterContraintEnum(int code, String value) {
        this.code = code;
        this.value = value;
    }

    public int getCode() {
        return code;
    }

    public String getValue() {
        return value;
    }
}

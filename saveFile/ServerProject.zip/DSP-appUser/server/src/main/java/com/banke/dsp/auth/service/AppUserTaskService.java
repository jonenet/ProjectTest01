package com.banke.dsp.auth.service;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dao.AppUserDao;
import com.banke.dsp.auth.dto.*;
import com.banke.dsp.auth.po.AddressInfo;
import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.util.DateUtil;
import com.banke.dsp.auth.util.RegexUtil;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.Tuple;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.List;
import java.util.Map;

/**
 * Created by ex-zhongbingguo on 2018/3/16.
 */

@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AppUserTaskService {

    @Autowired
    private AppUserDao appUserDao;

    @Autowired
    private BaseInfoService baseInfoService;

    @Autowired
    private AddressInfoService addressInfoService;

    @Autowired
    private BranchInfoService branchInfoService;

    @Autowired
    private StaffInfoService staffInfoSaoService;

    @Autowired
    private AppuserAscriptionLogService appuserAscriptionLogService;


    //@PersistenceContext
    @Autowired
    private EntityManager entityManager;

    public AppUserTaskDTO query(String mongoId){
        AppUserInfo appUser = appUserDao.findByMongoId(mongoId);
        AppUserTaskDTO task = new AppUserTaskDTO();
        BeanUtils.copyProperties(appUser, task);
        task.setCreatedAt(DateUtil.localDateTimeToString(appUser.getCreatedAt()));
        task.setHasWeChat(StringUtils.isNotEmpty(appUser.getOpenid()));

        //注册城市
        if (StringUtils.isNotEmpty(appUser.getRegisterCityid())){
            BaseInfoDto baseInfo = baseInfoService.getBaseInfoBySysIdAndTypeAndCode(SysIdEnum.WRK.getValue(), BaseInfoTypeEnum.CITIEID.getType(), appUser.getRegisterCityid());
            if (baseInfo == null){
                baseInfo = baseInfoService.getBaseInfoBySysIdAndTypeAndCode(SysIdEnum.WRK.getValue(), BaseInfoTypeEnum.AREA.getType(), appUser.getRegisterCityid());
            }
            task.setRegisterCity(baseInfo.getValue());
        }

        //居住地址
        AddressInfo live = addressInfoService.findByAgentNoAndAddressType(mongoId, "02");
        if (live != null) {
            task.setLiveProvince(live.getProvince());
            task.setLiveCity(live.getCity());
            task.setLiveArea(live.getArea());
            task.setLiveAddress(live.getAddress());
        }

        //工作地址
        AddressInfo work = addressInfoService.findByAgentNoAndAddressType(mongoId, "03");
        if (work != null){
            task.setWorkProvince(work.getProvince());
            task.setWorkCity(work.getCity());
            task.setWorkArea(work.getArea());
            task.setWorkAddress(work.getAddress());
        }

        return task;
    }

    @Transactional(rollbackFor=Exception.class)
    public ResponseInfo update(AppUserTaskDTO task){
        //校验身份证号
        String identityNumber = task.getIdentityNumber();
        if (StringUtils.isNotEmpty(identityNumber) && !RegexUtil.checkIdentityNumber(identityNumber)) {
            return new ResponseInfo<>("0001", "请输入合法的身份证号", null);
        }

        AppUserInfo appUser = appUserDao.findByMongoId(task.getMongoId());
        BeanUtils.copyProperties(task, appUser,"registerCityid", "createdAt", "cellphone", "source");

        //修改用户归属
        String oldAscription = appUser.getAscription();  //旧归属
        String newAscription = null;                    //新归属
        StaffInfoDTO staffInfoDTO = staffInfoSaoService.getStaffInfoByUserId(task.getReferrer());
        if (staffInfoDTO != null) {
            appUser.setRefererName(staffInfoDTO.getStaffName());
            //根据客户经理查询部门
            BranchInfoDTO branchInfo = branchInfoService.getBranchByBranchNo(SysIdEnum.WRK.getValue(), staffInfoDTO.getBranchNo());
            newAscription = branchInfo.getAscription();
            //归属日志
            appuserAscriptionLogService.add(appUser.getMongoId(), newAscription, oldAscription, null);
            appUser.setAscription(newAscription);
            appUser.setAscriptionStatus(true);
        }

        appUserDao.save(appUser);

        //新增居住地址
        addressInfoService.save(task.getMongoId(), task.getLiveProvince(), task.getLiveCity(),
                task.getLiveArea(),task.getLiveAddress(),"02");

        //新增工作地址
        addressInfoService.save(task.getMongoId(), task.getWorkProvince(), task.getWorkCity(),
                task.getWorkArea(),task.getWorkAddress(),"03");
        return ResponseInfo.success(true);
    }

    public List<Map<String, String>> queryNewDatas(String startTime, String endTime) {
//        return appUserDao.findAll((root, query, cb) -> {
//            Predicate predicate = cb.conjunction();
//            predicate.getExpressions().add(cb.greaterThanOrEqualTo(root.get("createdAt"), LocalDateTime.of(LocalDate.from(startTime), LocalTime.MIN)));
//            predicate.getExpressions().add(cb.lessThanOrEqualTo(root.get("createdAt"), LocalDateTime.of(LocalDate.from(endTime), LocalTime.MAX)));
//            predicate.getExpressions().add(cb.isNull(root.get("referrer").as(String.class)));
//            return predicate;
//        });
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Tuple> criteriaQuery = criteriaBuilder.createTupleQuery();
        //拼接 查询指定字段
        Root<AppUserInfo> appUerInfo = criteriaQuery.from(AppUserInfo.class);
        criteriaQuery.multiselect(
                appUerInfo.get("mongoId").alias("mongo_id"),
                appUerInfo.get("registerCityid").alias("register_cityid"),
                appUerInfo.get("source").alias("source")
        );

        //拼接 查询条件
        List<Predicate> predicatesList = Lists.newArrayList();
        predicatesList.add(
                criteriaBuilder.and(
                        criteriaBuilder.greaterThanOrEqualTo(appUerInfo.get("createdAt"), DateUtil.stringToLocalDateTime2(startTime)),
                        criteriaBuilder.lessThanOrEqualTo(appUerInfo.get("createdAt"), DateUtil.stringToLocalDateTime2(endTime)),
                        criteriaBuilder.or(
                                criteriaBuilder.isNull(appUerInfo.get("referrer")),
                                criteriaBuilder.like(appUerInfo.get("refererName"), "%虚拟客户经理%")
                        )
                )
        );
        criteriaQuery.where(predicatesList.toArray(new Predicate[predicatesList.size()]));
        List<Tuple> tupleList = entityManager.createQuery(criteriaQuery).getResultList();

        List<Map<String, String>> result = Lists.newArrayList();
        for (Tuple t : tupleList) {
            Map<String, String> map = Maps.newHashMap();
            map.put("mongoId", (String) t.get("mongo_id"));
            map.put("registerCityid", (String) t.get("register_cityid"));
            map.put("source", (String) t.get("source"));
            result.add(map);
        }
        return result;
    }
}

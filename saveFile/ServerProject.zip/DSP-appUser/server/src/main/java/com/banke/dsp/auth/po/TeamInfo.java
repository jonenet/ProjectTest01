package com.banke.dsp.auth.po;

import com.banke.bkc.framework.po.BasePO;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.*;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@Entity
@Table(name = "team_info")
public class TeamInfo extends BasePO{
    //团队编号
    @NonNull
    private String teamNo;

    //团长ID
    @NonNull
    private String agentNo;

    //团队名称
    @NonNull
    private String teamName;

    //团队状态
    @NonNull
    private String status;

    //团队公告
    private String notice;

    //成立时间
    @NonNull
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime establishDate;

    //解散时间
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime disbandDate;


    //团队等级
    private String grade;
    //团队序列
    private String gradeSort;
    //业务城市
    private String cityCode;
    //是否降级
    private Boolean isDowngrade;
    //降级原因
    private String downgradePoint;
    //降级时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime downgradeDate;

    private Boolean silverMember;
    private Boolean silverAnnounce;
    private Boolean silverCrash;
    private Boolean goldMember;
    private Boolean goldIntegral;
    private Boolean goldLoan;
    private Boolean goldLoanThird;
    private Boolean diamondMember;
    private Boolean diamondLoanThird;
    private Boolean diamondLoan;
    private Boolean diamondActiveMember;
    private Boolean diamondIntegral;

}

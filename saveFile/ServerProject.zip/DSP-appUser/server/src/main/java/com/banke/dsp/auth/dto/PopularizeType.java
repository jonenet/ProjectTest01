package com.banke.dsp.auth.dto;

import org.apache.commons.lang.StringUtils;

/**
 * 推广方式
 * @author ex-panhuayu
 *
 */
public enum PopularizeType {
    
    // 地推零散获客
    MANAGER_GET("地推零散获客"),
    // 合作开发
    COOPERATIVE("合作开发"),
    // 用户转介
    USER_REFERRAL("用户转介"),
    // 兼职推广
    PARTTIME_PROMOTION("兼职推广"),
    // 用户主动咨询
    USER_ACTIVE("用户主动咨询"),
    //TRA
    //@since 201603a
    TRA("TRA");
    
    private final String description;
    
    private PopularizeType(String value) {
        description = value;
    }
    
    public String getDescription() {
        return description;
    }

    //update by zhongbingguo 17/8/16
    public static PopularizeType getPopularizeTypeByCode(String description){
        if (StringUtils.isNotEmpty(description)){
            for(PopularizeType type : PopularizeType.values()){
                if(description.equals(type.name())){
                    return type;
                }
            }
        }
        return null;
    }
}

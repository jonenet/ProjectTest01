package com.banke.dsp.auth.dto;

import lombok.Data;

/**
 *  用户信息变更
 * Created by ex-zhongbingguo on 2017/8/25.
 */
@Data
public class AppUserDetailRequest {

    //主键id
    private Long id;

    //手机号码
    private String cellphone;

    /**真实姓名*/
    private String realName;

    /**身份证号*/
    private String identityNumber;

    /**性别*/
    private String sex;

    //婚姻状况,S:未婚;M:已婚
    private String marriage;

    //收入水平01-05
    private String incomeLevel;

    //用户行业
    private String userIndustry;

    //居住地址
    private String liveProvince;
    private String liveCity;
    private String liveArea;
    private String liveAddress;

    //工作地址
    private String workProvince;
    private String workCity;
    private String workArea;
    private String workAddress;

}

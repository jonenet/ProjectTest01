package com.banke.dsp.auth.sao;

import com.banke.bkc.framework.util.ResponseInfo;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Map;

@FeignClient(value = "ADT-disp")
public interface SendTeamMessageSao {

    @RequestMapping("/api/sendDispMessage")
    ResponseInfo<?> sendDispMessage(@RequestBody Map<String, Object> message);

}

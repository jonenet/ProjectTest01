package com.banke.dsp.auth.service;

import com.banke.dsp.auth.dao.ScoreDetailsDao;
import com.banke.dsp.auth.dao.TotalScoreDao;
import com.banke.dsp.auth.po.ScoreDetails;
import com.banke.dsp.auth.po.TotalScore;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by ex-zhongbingguo on 2017/11/2.
 */
@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class TotalScoreService {

    @Autowired
    private TotalScoreDao totalScoreDao;

    @Autowired
    private ScoreDetailsDao scoreDetailsDao;

    public void saveTotalScore(TotalScore ts,ScoreDetails sd) {
        TotalScore getTotalScore = totalScoreDao.findBycellphone(ts.getCellphone());
        if(getTotalScore==null){
            totalScoreDao.save(ts);
            scoreDetailsDao.save(sd);
        }else{
            String numScore = getTotalScore.getNumScore();
            int score = StringUtils.isNotEmpty(numScore) ? Integer.parseInt(numScore) : 0;
            String tempScore = sd.getScore();
            int tempScoreInt = StringUtils.isNotBlank(tempScore) ? Integer.parseInt(tempScore) : 0;
            score = score+tempScoreInt;
            getTotalScore.setNumScore(String.valueOf(score));

            totalScoreDao.save(getTotalScore);
            scoreDetailsDao.save(sd);
        }
    }
}

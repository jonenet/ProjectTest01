package com.banke.dsp.auth.dto;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import com.banke.bkc.framework.util.CodeEnum;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;

import lombok.Data;

/**
 * 用户角色信息
 * @author ex-panhuayu
 *
 */
@Data
public class AppUser{
    
	private String id;
    
    private String username;
    
    private String realName;
    
    private String cellphone;
    
    private String email;
    
	private String address;
    
	private String wechatUsername;

	private String devOpsUserMobile;// 地推人员的手机号码
    
    private List<String> tags;
    
    private String canUserApp;// 是否可以使用新版APP
    
    private String cantUseReason;// 不能使用的原因描述
    
    private String iscredit;// 是否是授信标志，Y/N，为N时DSPC必须等征信材料交回页面才能查询客户的征信报告
    
    private String achived;

    private String channelType;

    private String identityNumber;//身份证号
    
    private String password;
    
    private String passwordSalt;
    
    private String passwordEncoder;
    
    private BusinessCity businessCity;
    
    private Bank bank;
    
    private Bank bankBranch;
    
    private String bankAccountName;
    
    private String bankCardNumber;
    
    private String canUpgrade;
    
//    @JsonSerialize(using = LocalDateTimeSerializer.class)
//    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createdAt;//注册日期
    
//    @JsonSerialize(using = LocalDateTimeSerializer.class)
//    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date modifiedAt;
    
    private String registerId;
    
    private boolean expired;
    
    private boolean locked;
    
    private boolean enabled;
    
    private Integer star;
    
    private List<AppRole> appRoles;
    
    private String osVersion;

    private String appVersion;
    
    private String registerDevice;
    
    private String referrer;
    
    private String refererName;
    
    private String job;
    
    private String refMobilePhone;
    
    private String groupFlag;
    
    private String groupName;

    private boolean archived = false;//是否归档，归档后，用户的账户名和手机号后面均加上后缀（已归档）
    
    private Channel channel;//用户渠道
    
    private String companyName;// 公司名称

    private PopularizeType popularizeType;// 推广方式
    
    private Boolean enableRecommendation = Boolean.TRUE;// 用户进件权限
    
    private String deviceId;// 设备号
    
    //是否推荐更多产品 
    private String commendMore;
    
    //征信获取方式(all 全需要，notAll 都不需要，bank 银行,upload 上传)
    private String creditWay;
    
    //是否需要征信
    private boolean isNeedCredit;

    public enum UserSource {
        APP("app"), MINI("mini");

        UserSource(String val) {
            CodeEnum.init(this, val);
        }
    }
    //cv
    private String cv;

    //用户来源
    private String source;
}

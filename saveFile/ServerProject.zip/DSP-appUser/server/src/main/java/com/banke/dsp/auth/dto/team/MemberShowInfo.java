package com.banke.dsp.auth.dto.team;

import lombok.Data;

/**
 * Created by linzhimou on 2017/8/2.
 */
@Data
public class MemberShowInfo {

    public MemberShowInfo(String agentNo, String cellphone, String businessCityId,
                          Long memberId, String teamNo, String teamRole, String memberStatus) {
        this.agentNo = agentNo;
        this.cellphone = cellphone;
        this.businessCityId = businessCityId;
        this.teamNo = teamNo;
        this.teamRole = teamRole;
        this.memberStatus = memberStatus;
        this.memberId = memberId;
    }

    private Long memberId;
    private String cellphone;
    private String businessCityId;
    private String teamNo;
    private String agentNo;
    private String teamRole;
    private String memberStatus;
    private String teamName;
    private long applyCount;
    private Double orderTransAmount;

}

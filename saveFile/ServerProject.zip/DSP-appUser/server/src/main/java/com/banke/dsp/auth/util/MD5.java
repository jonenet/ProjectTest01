package com.banke.dsp.auth.util;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Created by ex-zhongbingguo on 2017/11/6.
 */
public class MD5 {

    public static String generatedSaltedPasswordMD5(String password, String salt) throws Exception {
        if(StringUtils.isEmpty(salt)) {
            return org.apache.commons.codec.binary.Base64.encodeBase64String(password.getBytes());
        }
        return md5(password, salt);
    }

    private static String md5(String str, String salt) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        return md5(str + "{" + salt + "}");
    }

    private static String md5(String str) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        MessageDigest md5=MessageDigest.getInstance("MD5");
        //加密后的字符串
        String newstr= Base64.encodeBase64String(md5.digest(str.getBytes()));
        return newstr;
    }

}

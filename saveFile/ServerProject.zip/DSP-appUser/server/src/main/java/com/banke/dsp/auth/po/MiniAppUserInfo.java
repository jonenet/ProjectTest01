package com.banke.dsp.auth.po;

import com.banke.bkc.framework.po.BasePO;
import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * Created by luoyifei on 2017/5/25.
 */
@Data
@NoArgsConstructor
@RequiredArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "mini_appuser_info")
public class MiniAppUserInfo extends BasePO {
    @Column
    private Long id;

    /**
     * 对应用户
     */
    @NonNull
    @Column
    private Long userId;

    @NonNull
    @Column(nullable = true, length = 36)
    private String openid;

    @NonNull
    @Column(nullable = true, length = 40)
    private String token;

    @NonNull
    @Column
    private LocalDateTime tokenDate;

    @NonNull
    @Column(nullable = true, length = 40)
    private String avatarUrl; // 微信头像

    @NonNull
    @Column(nullable = true, length = 40)
    private String city; // 所在城市

    @NonNull
    @Column(nullable = true, length = 40)
    private String gender; // 性别（1：man 2： woman）

    @NonNull
    @Column(nullable = true, length = 40)
    private String nickName; // 微信名

    @NonNull
    @Column(nullable = true, length = 40)
    private String province; // 所在省

    @NonNull
    @Column(nullable = true, length = 40)
    private String latitude; // 纬度

    @NonNull
    @Column(nullable = true, length = 40)
    private String longitude; // 经度

    @NonNull
    @Column(nullable = true, length = 50)
    private String unionId;
    
    @NonNull
    @Column(nullable = true, length = 50)
    private String publicopenid;
}

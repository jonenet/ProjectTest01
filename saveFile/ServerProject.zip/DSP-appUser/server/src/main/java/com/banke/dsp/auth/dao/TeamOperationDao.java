package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.po.TeamOperationLog;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by ex-liqiaoyong on 2017/7/26.
 */
public interface TeamOperationDao extends CrudRepository<TeamOperationLog,Long>{

}

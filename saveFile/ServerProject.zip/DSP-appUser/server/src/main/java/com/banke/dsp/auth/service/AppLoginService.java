package com.banke.dsp.auth.service;

import com.alibaba.fastjson.JSONObject;
import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.bkc.framework.util.UUIDUtil;
import com.banke.dsp.auth.dto.SendOtpCodeDto;
import com.banke.dsp.auth.dto.SmsOtpDTO;
import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.po.LoginAudit;
import com.banke.dsp.auth.sao.SendSMSRequestRepositorySao;
import com.banke.dsp.auth.security.Base64;
import com.banke.dsp.auth.service.login.AppToken;
import com.banke.dsp.auth.service.login.AppTokenEntity;
import com.banke.dsp.auth.util.MD5;
import com.banke.dsp.auth.util.RegexUtil;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 *  app 用户登入
 * Created by ex-zhongbingguo on 2017/11/7.
 */
@Service
@Slf4j
public class AppLoginService {

    @Resource(name = "redisTemplate")
    private RedisTemplate<String, String> redisTemplate;

    @Autowired
    private AppUserInfoService appUserInfoService;

    @Autowired
    private LoginAuditService loginAuditService;

    @Autowired
    private SendSMSRequestRepositorySao sendSMSRequestRepositorySao;

    @Autowired
    private SendSMSRequestRepositorySao sendSMSSao;

    @Autowired
    private AppUserProfileService appUserProfileService;

    //code勿更改，前端使用页面跳转
    private static final String NO_REGISTER_ERR = "4444";

    public ResponseInfo<?> login(HttpServletRequest request){
        Map<String, Object> result = Maps.newHashMap();
        result.put("token", "");
        result.put("MSG", "登录成功！");
        //参数非空校验
        String userName = request.getParameter("username");
        if(StringUtils.isEmpty(userName)){
            return new ResponseInfo<>("9999", "请输入用户名", null);
        }
        String passWord = request.getParameter("password");
        if(StringUtils.isEmpty(passWord)){
            return new ResponseInfo<>("9999", "请输入用户密码", null);
        }

        //校验用户名/登入密码
        AppUserInfo loginUser = appUserInfoService.findByCellphone(userName);
        if (loginUser == null) {
            //兼容登录名
            loginUser = appUserInfoService.findByUserName(userName);
        }

        if (loginUser == null ){
            return new ResponseInfo<>("9999", "账户名或密码错误,请重新登入", null);
        }

        try {
            String base64 = Base64.getBase64(passWord);
            String md5 = MD5.generatedSaltedPasswordMD5(passWord, loginUser.getPasswordSalt());
            if (loginUser.getPassword().equals(base64) || loginUser.getPassword().equals(md5)){
                String newToken = UUIDUtil.getUid("P@");
                AppToken appToken = AppTokenEntity.create(loginUser, 864000 * 30);

                //将token放入redis中
                this.tokenLogin(userName, newToken, appToken);
                //保存登录记录
                this.auditLogin(request, null);
                loginUser.setToken(newToken);
                loginUser.setTokenDate(LocalDateTime.now());
                appUserInfoService.save(loginUser);

                result.put("token", newToken);
                return ResponseInfo.success(result);
            }else{
                return new ResponseInfo<>("9999", "账户名或密码错误,请重新登入", null);
            }
        }catch (Exception e){
            log.info("md5密码加密失败！");
            return new ResponseInfo<>("9999", "登入失败", null);
        }
    }

    /**
     *  退出
     */
    public ResponseInfo<Map> logout(HttpServletRequest request) {
        Map<String, Object> result = Maps.newHashMap();
        result.put("succeed", Boolean.TRUE);
        result.put("message", "退出成功");
        String userName = request.getParameter("username");
        if(StringUtils.isEmpty(userName)){
            return new ResponseInfo<>("9999","用户名不能为空", null);
        }
        String oldToken = redisTemplate.opsForValue().get("Token:" + userName);
        log.info("退出>> oldToken: {}", oldToken);
        if(!StringUtils.isEmpty(oldToken)){
            redisTemplate.delete("AppToken:"+oldToken);
        }
        return ResponseInfo.success(result);
    }

    /**
     *  将token放入redis中
     */
    private void tokenLogin(String userName,String token, AppToken appToken){
        //删除原token
        String oldToken = redisTemplate.opsForValue().get("Token:" + userName);
        log.info("登入>> 删除原Token: {}", oldToken);
        if(!StringUtils.isEmpty(oldToken)){
            redisTemplate.delete("AppToken:"+oldToken);
        }
        //添加新token
        redisTemplate.opsForValue().set("Token:" + userName, token, 30, TimeUnit.DAYS);
        redisTemplate.opsForValue().set("AppToken:"+token, JSONObject.toJSONString(appToken), 30, TimeUnit.DAYS);

        log.info("登入>> 新Token: {}",  redisTemplate.opsForValue().get("Token:" + userName));
        log.info("登入>> 新AppToken: {}",  redisTemplate.opsForValue().get("AppToken:" + token));
    }

    /**
     * 登录记录
     */
    private void auditLogin(HttpServletRequest request, String cellphone){
        LoginAudit loginAudit = new LoginAudit();
        loginAudit.setUsername(cellphone == null ? request.getParameter("username") : cellphone);
        loginAudit.setOsVersion(request.getParameter("osVersion"));
        loginAudit.setAppVersion(request.getParameter("appVersion"));
        loginAudit.setIpAddress(getRemoteAddress(request));
        loginAudit.setDevice(request.getParameter("device"));
        loginAudit.setDeviceId(request.getParameter("deviceId"));
        loginAudit.setAuthenticated(true);
        loginAuditService.save(loginAudit);
    }

    private String getRemoteAddress(HttpServletRequest request) {
        String ip = request.getHeader("x-forwarded-for");
        if (ip == null || ip.length() == 0
                || ip.equalsIgnoreCase("unknown")) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0
                || ip.equalsIgnoreCase("unknown")) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0
                || ip.equalsIgnoreCase("unknown")) {
            ip = request.getRemoteAddr();
        }
        return ip;
    }

    /**
     *  登入: 密码登入/验证码登入
     */
    public ResponseInfo<?> loginNew(HttpServletRequest request){
        Map<String, Object> data = Maps.newHashMap();
        data.put("token", "");
        data.put("message", "");
        data.put("firstLogin", "N");

        String userName = request.getParameter("username");         //用户名
        String passWord = request.getParameter("password");         //密码
        String passcode = request.getParameter("passcode");         //验证码
        String city = request.getParameter("city");                 //手机定位城市
        String province = request.getParameter("province");         //手机定位省份
        String cityId = request.getParameter("cityId");             //手机定位城市id
        String openid = request.getParameter("openid");             //微信openid
        String nickname = request.getParameter("nickname");         //微信昵称
        String loginType = request.getParameter("loginType");       //001：账号密码; 002：验证码

        if(StringUtils.isEmpty(userName)){
            return new ResponseInfo<>("0001", "请输入账号", null);
        }

        //校验手机号码规范性
        if (!RegexUtil.checkCellPhone(userName)) {
            return new ResponseInfo<>("0002", "请输入正确的手机号码", null);
        }

        AppUserInfo loginUser = appUserInfoService.findByCellphone(userName);

        log.info("##登入方式，loginType：{}", loginType);
        //方式一：密码登入
        if ("001".equals(loginType)){
            if (StringUtils.isEmpty(passWord)){
                return new ResponseInfo<>("0003", "请输入密码", null);
            }
            if (loginUser == null ){
                //code勿更改，前端使用页面跳转
                return new ResponseInfo<>(NO_REGISTER_ERR, "该账号未注册", null);
            }
            if (StringUtils.isEmpty(loginUser.getPassword())) {
                return new ResponseInfo<>("0005", "账号密码错误，请重新输入", null);
            }
            if (!loginUser.getPassword().equals(Base64.getBase64(passWord))){
                return new ResponseInfo<>("0006", "密码错误，请重新输入", null);
            }
            this.auditLogin(request, null);
            String token = this.setToken(loginUser);
            data.put("message", "登录成功");
            data.put("token", token);
            return ResponseInfo.success(data);
        }else if ("002".equals(loginType)){  //验证码登入
            //校验验证码
            ResponseInfo<?> responseInfo = sendSMSSao.checkVerifyCode(userName, passcode, "t002", "10");
            if (!responseInfo.isSuccess()){
                return responseInfo;
            }

            //禁止同一个手机号重复绑定微信
            if (loginUser != null && !StringUtils.isEmpty(openid) &&!StringUtils.isEmpty(loginUser.getOpenid())){
                return new ResponseInfo<>("0007", "绑定失败，该手机号已绑定其他微信", null);
            }

            //新用户，先注册
            String message = "登录成功";
            if(loginUser == null) {
                message = "注册成功，已登录";
                //用户注册
                loginUser = appUserProfileService.register(userName, city, province, cityId, openid, nickname, "app");
            }

            //老用户微信登录绑定openid 和 nickname
            if (!StringUtils.isEmpty(openid)){
                loginUser.setOpenid(openid);
                loginUser.setNickname(nickname);
            }

            //判断是否首次登录
            if (StringUtils.isEmpty(loginUser.getToken())) {
                data.put("firstLogin", "Y");
            }

            //保存登录记录
            this.auditLogin(request, null);
            //更新token
            String token = this.setToken(loginUser);
            data.put("message", message);
            data.put("token", token);
            return ResponseInfo.success(data);
        }else {
            return new ResponseInfo<>("0008", "账号密码错误，请重新输入", null);
        }
    }

    /**
     * 更新token
     * @param loginUser 用户信息
     * @return token     新token
     */
    private String setToken(AppUserInfo loginUser) {
        String newToken = UUIDUtil.getUid("P@");
        AppToken appToken = AppTokenEntity.create(loginUser, 864000 * 30);
        //将token放入redis中
        this.tokenLogin(loginUser.getCellphone(), newToken, appToken);
        loginUser.setToken(newToken);
        loginUser.setTokenDate(LocalDateTime.now());
        appUserInfoService.save(loginUser);
        return newToken;
    }

    /**
     * 发送登录短信验证码
     */
    public ResponseInfo<Object> sendPasscode(SendOtpCodeDto sendOtpCode) {
        String cellphone = sendOtpCode.getCellphone();
        if(StringUtils.isEmpty(cellphone)){
            return ResponseInfo.error("手机号不能为空");
        }
        return sendSMSRequestRepositorySao.sendSmsForPGS(new SmsOtpDTO(cellphone, "t002", "10", "1"));
    }

    /**
     *  微信登录
     * @param request 手机版本信息
     * @return  登录成功/失败信息
     */
    public Map<String, Object> loginByWeChat(HttpServletRequest request,String openid,String nickname){
        log.info("微信登入参数openid:{}", openid);
        Map<String, Object> data = Maps.newHashMap();
        data.put("token", "");
        data.put("message", "");
        data.put("firstLogin", "N");

        log.info("微信登入openid：{}", openid);
        AppUserInfo appUser = appUserInfoService.findByOpenid(openid);
        if (appUser == null){
            log.info(">>>>>>>>>>>微信的登录，用户没有找到");
            data.put("message", "登录失败");
            return data;
        }
        appUser.setNickname(nickname);
        //更新token
        String token = this.setToken(appUser);
        data.put("token", token);
        data.put("message", "登入成功");
        data.put("firstLogin", "N");

        if (StringUtils.isEmpty(appUser.getToken())) {
            data.put("firstLogin", "Y");
        }
        //保存登录记录
        this.auditLogin(request, appUser.getCellphone());
        return data;
    }

}

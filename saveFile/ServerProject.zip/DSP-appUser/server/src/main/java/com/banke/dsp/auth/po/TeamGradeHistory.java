package com.banke.dsp.auth.po;

import com.banke.bkc.framework.po.BasePO;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Created by ex-taozhangyi on 2018/2/9.
 */
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "team_grade_history")
public class TeamGradeHistory extends BasePO {
    private String teamNo;
    private String grade;
    private String operationType;
}

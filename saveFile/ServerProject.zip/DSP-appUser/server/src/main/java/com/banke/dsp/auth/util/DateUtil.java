package com.banke.dsp.auth.util;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

@Slf4j
public class DateUtil {

    /**
     * date 转 localDateTime
     */
    public static LocalDateTime dateToLocalDateTime(Date date) {
        if (date == null) return null;
        Instant instant = date.toInstant();
        ZoneId zone = ZoneId.systemDefault();
        return LocalDateTime.ofInstant(instant, zone);
    }

    /**
     *  localDateTime 转 date
     */
    public static Date localDateTimeToDate(LocalDateTime time) {
        if (time == null) return null;
        ZoneId zoneId = ZoneId.systemDefault();
        ZonedDateTime zdt = time.atZone(zoneId);
        return Date.from(zdt.toInstant());
    }

    /**
     * localDateTime 转 String，去掉T ：例如：2017-03-27 11:57:32
     */
    public static String localDateTimeToString(LocalDateTime time){
        return StringUtils.replace(time.toString(), "T", " ");
    }

    /**
     *  string 转 localDateTime
     */
    public static LocalDateTime stringToLocalDateTime(String str){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date = sdf.parse(str);
            return dateToLocalDateTime(date);
        }catch (Exception e){
            log.info("string 转 localDateTime 异常，{}",e);
        }
        return null;
    }

    /**
     *  string 转 localDateTime
     */
    public static LocalDateTime stringToLocalDateTime2(String str){
        DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return LocalDateTime.parse(str,f);
    }

    /**
     * string 转 date
     */
    public static Date stringToDate(String str){
        try {
            SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd hh:mm");
            return sdf.parse(str);
        } catch (Exception e){
            log.info("string 转 date 异常，{}",e);
        }
        return null;
    }

}

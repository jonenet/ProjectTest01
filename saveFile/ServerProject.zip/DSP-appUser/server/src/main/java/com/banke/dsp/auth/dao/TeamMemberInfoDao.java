package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.dto.TeamDto;
import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.po.TeamMemberInfo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Created by ex-liqiaoyong on 2017/7/26.
 */
public interface TeamMemberInfoDao extends CrudRepository<TeamMemberInfo,Long>{

    TeamMemberInfo findByAgentNoAndTeamNoAndStatusNot(String agentNo, String teamNo, String s);

    TeamMemberInfo findByAgentNoAndTeamNoAndStatus(String agentNo, String teamNo, String status);

    @Query(value = "select a.nickname,a.head_image_id ,a.openid from appuser_info a, (select count(ai.apply_no) cnt, ai.agent_no agno from apply_info ai, (SELECT tmi.agent_no agentNo, tmi.join_date joinDate  FROM team_member_info tmi WHERE tmi.team_no = :teamNo and tmi.`status` <> 'DELETE' and tmi.team_role = 'ROLE_OF_MEMBER') bb where ai.agent_no = bb.agentNo and ai.apply_date > bb.joinDate and ai.apply_date > :startDate and ((ai.task_id not in ('02','05') and ai.apply_status NOT IN ('000','C00','U01','CCL')) or (ai.task_id = '05' and ai.apply_status  IN ('F00','F01','F02','F03','F04','FFF')) or (ai.task_id = '02' and ai.apply_status = 'FFF')) group by ai.agent_no) aa where a.mongo_id = aa.agno order by aa.cnt desc limit 1", nativeQuery = true)
    List<Object[]> getBestMemberOfOrder(@Param("teamNo")String teamNo, @Param("startDate")String startDate);

    @Query(value = "select a.nickname,a.head_image_id,a.openid from appuser_info a, (select sum(ai.trans_amount) cnt, ai.agent_no agno from order_info ai, (SELECT tmi.agent_no agentNo, tmi.join_date joinDate  FROM team_member_info tmi WHERE tmi.team_no = :teamNo and tmi.`status` <> 'DELETE' and tmi.team_role = 'ROLE_OF_MEMBER') bb where ai.agent_no = bb.agentNo and ai.apply_date > bb.joinDate and ai.apply_date > :startDate AND ai.order_status = 'FFF' group by agno ) aa where a.mongo_id = aa.agno order by aa.cnt desc limit 1", nativeQuery = true)
    List<Object[]> getBestMemberOfAmount(@Param("teamNo")String teamNo, @Param("startDate")String startDate);

    @Query(value = "SELECT NEW com.banke.dsp.auth.dto.TeamDto(ti.teamNo, ti.teamName, ti.status, ti.notice, tmi.teamRole)" +
                    " FROM TeamInfo ti" +
                    " LEFT JOIN TeamMemberInfo tmi ON ti.teamNo = tmi.teamNo" +
                    " WHERE tmi.status <> 'DELETE' AND ti.status <> 'DELETE' AND tmi.agentNo = :agentNo")
    List<TeamDto> getTeamListForMember(@Param("agentNo")String agentNo);

    /**
     * 获取成员列表
     * @param teamNo
     * @return
     */
    @Query(value = "select m.agent_no, m.status, a.cellphone, m.operation_type, DATEDIFF(CURDATE(),m.join_date)," +
                    "(select count(1) from apply_info ap where ap.agent_no=m.agent_no and ap.apply_date>=m.join_date " +
            "and ap.apply_date>=(DATE_SUB(CURDATE(),INTERVAL 3 MONTH)) and (" +
            "(ap.task_id = '02' and ap.apply_status = 'FFF') " +
            "or (ap.task_id = '05' and ap.apply_status in ('F00','F01','F02','F03','F04','FFF')) " +
            "or (ap.task_id = '07' and ap.apply_status in ('F00','F01','F02','F03','F04','FFF')) " +
            "or (ap.task_id not in ('02','05','07') and ap.apply_status not in ('000','C00','U01','CCL','R01')))" +
            ") cont,a.nickname" +
                    " from team_member_info m left join appuser_info a on a.mongo_id=m.agent_no" +
                    " where m.team_no=?1 and m.status<>'DELETE' order by m.team_role asc,cont desc", nativeQuery = true)
    List<Object[]> getMemberListByTeamNo(String teamNo);

    int countByAgentNo(String agentNo);

    int countByTeamNo(String teamNo);

    int countByTeamNoAndStatusNot(String teamNo,String status);
    int countByTeamNoAndTeamRoleNotAndStatusNot(String teamNo,String teamRole,String status);
    @Query(value = "SELECT t.agentNo FROM TeamMemberInfo t where t.teamNo = ?1 and t.status=?2")
    List<String> findByTeamNoAndStatusquery(String teamNo, String status);

    @Query(value = "SELECT t.agentNo FROM TeamMemberInfo t where t.teamNo = ?1 and t.status<> 'DELETE'")
    List<String> findByTeamNoAndStatusNotquery(String teamNo);

    TeamMemberInfo findByAgentNoAndStatusAndTeamRole(String agentNo,String status, String teamRole);

    @Query("SELECT t FROM TeamMemberInfo t, TeamInfo ti" +
            " WHERE t.teamNo = ti.teamNo AND ti.status <> 'DELETE' AND t.status <> 'DELETE' " +
            " AND t.joinDate < :date AND t.agentNo = :agentNo AND t.teamRole = 'ROLE_OF_MEMBER'")
    TeamMemberInfo getTeamInfo(@Param("agentNo") String agentNo, @Param("date") LocalDateTime date);


    int countByAgentNoAndStatusNotAndTeamRole(String agentNo, String status, String teamRole);

    @Query(value = "select count(*) from apply_info t where t.agent_no = ?1 and t.apply_date > ?2 and t.apply_status not in ('000','C00','U01','CCL','R01')", nativeQuery = true)
    int getCountOrder(String agentNo, LocalDate minusMonths);

    List<TeamMemberInfo> findByStatus(String status);

    List<TeamMemberInfo> findByTeamNoAndStatus(String teamNo, String status);

    List<TeamMemberInfo> findByTeamNoAndStatusNot(String teamNo, String status);

    @Query("SELECT a from TeamInfo t, AppUserInfo a where t.agentNo = a.mongoId and t.teamNo = ?1")
    AppUserInfo getTeamLeaderInfo(String teamNo);

    TeamMemberInfo findById(String id);

    List<TeamMemberInfo> findByAgentNoAndStatusNot(String agentNo,String s);

    int countByTeamNoAndOperationTypeAndStatusNot(String teamNo,String opt,String s);


    /**
     * 新注册评估神用户或注册未满7天的用户。
     */
    @Query(value = "select count(1) from team_member_info t where  DATEDIFF(date_format(t.join_date,'%Y-%m-%d'),date_format(t.register_date,'%Y-%m-%d')) <7 and t.team_no = ?1 and t.status <> 'DELETE' ", nativeQuery = true)
    int getTeamMemberRegister(String teamNo);
}

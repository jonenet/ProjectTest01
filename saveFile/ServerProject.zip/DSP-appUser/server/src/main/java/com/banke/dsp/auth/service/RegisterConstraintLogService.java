package com.banke.dsp.auth.service;

import com.banke.dsp.auth.dao.RegisterConstraintLogDao;
import com.banke.dsp.auth.po.RegisterConstraintLog;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by ex-zhongbingguo on 2017/11/2.
 */
@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class RegisterConstraintLogService {

    @Autowired
    private RegisterConstraintLogDao registerConstraintLogDao;

    public RegisterConstraintLog save(RegisterConstraintLog rc){
        return registerConstraintLogDao.save(rc);
    }
}

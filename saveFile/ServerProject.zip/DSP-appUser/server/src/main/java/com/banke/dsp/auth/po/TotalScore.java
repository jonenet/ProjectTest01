package com.banke.dsp.auth.po;


import com.banke.bkc.framework.po.BasePO;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "total_score")
public class TotalScore extends BasePO{

    //用户ID
    private String userId;

    //用户手机号
    private String cellphone;

    //总积分
    private String numScore="0";
}

package com.banke.dsp.auth.api;

import com.banke.bkc.framework.exception.BusinessException;
import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dto.AppWechatUserDTO;
import com.banke.dsp.auth.dto.SendOtpCodeDto;
import com.banke.dsp.auth.service.AppLoginService;
import com.banke.dsp.auth.service.AppWeChatUserService;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * Created by ex-zhongbingguo on 2017/11/7.
 * app登入服务
 */
@RestController
@RequestMapping(value = "/api", method = {RequestMethod.GET, RequestMethod.POST})
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AppLoginApi {

    @NonNull
    private AppLoginService appLoginService;

    @NonNull
    private AppWeChatUserService appWechatUserService;


    /**
     *  登入: 密码登入（老版本）
     * @param request 账号/密码..
     * @return 登录成功/失败提示
     */
    @RequestMapping(value = "/login")
    public ResponseInfo<?> login(HttpServletRequest request) {
        return appLoginService.login(request);
    }

    /**
     * 登入: 验证码登录（新版本）
     * @param request   账号/验证码..
     * @return  登录成功/失败提示
     */
    @RequestMapping(value = "/loginNew")
    public ResponseInfo<?> loginNew(HttpServletRequest request) {
        return appLoginService.loginNew(request);
    }

    /**
     *  退出
     * @param request   手机号码
     * @return          退出提示
     */
    @RequestMapping(value = "/logout")
    public ResponseInfo<Map> logout(HttpServletRequest request) {
        return appLoginService.logout(request);
    }

    /**
     *  发送短信验证码
     * @param sendOtpCode 手机号码
     * @return             发送成功/失败提示
     */
    @RequestMapping("/sendPasscode")
    public ResponseInfo<Object> sendPasscode(@RequestBody SendOtpCodeDto sendOtpCode){
        return appLoginService.sendPasscode(sendOtpCode);
    }

    /**
     * 微信登入
     * @param request 微信用户code
     * @return 返回处理信息
     */
    @RequestMapping(value = "/weChatLogin")
    public ResponseInfo<?> weChatLogin(HttpServletRequest request) throws BusinessException {
        return ResponseInfo.success(appWechatUserService.weChatLogin(request));
    }

    /**
     * 绑定微信
     * @param dto 微信授权数据和微信用户信息
     * @return 返回处理信息
     */
    @RequestMapping(value = "/bindingWeChat")
    public ResponseInfo<?> bindingWeChat(@RequestBody AppWechatUserDTO dto) throws BusinessException {
        return ResponseInfo.success(appWechatUserService.bindingWeChat(dto));
    }

}

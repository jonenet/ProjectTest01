package com.banke.dsp.auth.service;

import com.alibaba.fastjson.JSONObject;
import com.banke.bkc.framework.exception.BusinessException;
import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.bkc.message.annotation.MessageListener;
import com.banke.bkc.service.util.ContextHolder;
import com.banke.dsp.auth.dao.*;
import com.banke.dsp.auth.dto.*;
import com.banke.dsp.auth.dto.ApplyInfo;
import com.banke.dsp.auth.po.*;
import com.banke.dsp.auth.sao.AdtJpushSao;
import com.banke.dsp.auth.sao.DspConfigSao;
import com.banke.dsp.auth.sao.PdtDefSao;
import com.banke.dsp.auth.sao.TeamSao;
import com.banke.dsp.auth.util.DateUtil;
import com.banke.dsp.auth.util.TextSensitivity;
import com.google.common.collect.Maps;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigInteger;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;


/**
 * Created by ex-liqiaoyong on 2017/7/24.
 */
@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class TeamService {
    private static String ALL = "ALL";
    private final String TEAM = "Team:";
    private final String BEST_ORDER = ":order";
    private final String BEST_AMOUNT = ":amount";
    private final String MY_COMMISSION = ":commission";
    private final static String LOAN_ANNOUNCEMENT = ":announcement";
    private final static int MEMBER_LIMIT_COUNT = 20;
    private final String TEAM_INTEGRAL = "integral:";
    private final String TEAM_RANKING = ":ranking";
    private final String TEAM_PM = "pm:";

    @NonNull
    private TeamInfoDao teamInfoDao;

    @NonNull
    private TeamOperationDao teamOperationDao;
    @NonNull
    private AppWeChatUserInfoDao appWeChatUserInfoDao;
    @NonNull
    private TeamMemberInfoDao teamMemberInfoDao;
    @NonNull
    private TeamMemberMgrDao teamMemberMgrDao;
    @NonNull
    private AppUserDao appUserDao;
    @NonNull
    private TeamIntegralRankingService teamIntegralRankingService;
    @NonNull
    private TeamSao teamSao;
    @NonNull
    private DspConfigSao dspConfigSao;
    @NonNull
    private AdtJpushSao adtJpushSao;
    @NonNull
    private TeamIntegralDao teamIntegralDao;
    @NonNull
    private PdtDefSao pdtDefSao;
    @NonNull
    private TeamGradeDao teamGradeDao;
    @NonNull
    private TeamChargeMessageDao teamChargeMessageDao;
    @NonNull
    private TeamGradeDownService teamGradeDownService;
    @NonNull
    private TeamInfoService teamInfoService;
    @NonNull
    private TeamIntegralService teamIntegralService;
    @Resource(name = "redisTemplate")
    private RedisTemplate<String, String> redisTemplate;
    @Resource(name = "redisTemplate")
    private RedisTemplate<String, List<Map<String, Object>>> redisTemplates;


    @Value("${redis.timeout.minute}")
    private Long redisTimeout;
    @Value("${by.teamgrade.maxNum}")
    private int byTeamgradeMaxNum;
    @Value("${by.teamgrade.announcement}")
    private int byTeamgradeAnnouncement;
    @Value("${by.teamgrade.charge}")
    private int byTeamgradeCharge;

    @Value("${cfh.template}")
    private String cfhTemplate;
    @Value("${cfh.template.title}")
    private String cfhTemplateTitle;

    @Value("${hj.invite.member}")
    private int hjInviteMember;
    @Value("${hj.team.integral}")
    private int hjTeamIntegral;
    @Value("${hj.team.loan}")
    private int hjTeamLoan;
    @Value("${hj.effective.third}")
    private int hjEffectiveThird;

    @Value("${zs.team.member}")
    private int zsTeamMember;
    @Value("${zs.team.third.loan}")
    private int zsTeamThirdLoan;
    @Value("${zs.team.loan}")
    private int zsTeamLoan;
    @Value("${zs.team.active.member}")
    private int zsTeamActiveMember;
    @Value("${zs.team.integral}")
    private int zsTeamIntegral;

    /**
     * 校验该用户是否可以创建团队
     *
     * @param agentNo
     * @return true 可以  false 不可以
     */
    public boolean checkCreateTeamOfUser(String agentNo) {
        //判断该用户是否有创建团队
        TeamInfo teamInfo = findByAgentNoAndStatusNot(agentNo, TeamStatusEnumDto.DELETE.toString());
        if (teamInfo != null) {
            return  false;
        }
        //是否半年内推单两笔或以上
        int applyCnt = getCountOrder(agentNo);
        if (applyCnt < 2) {
            return false;
        }
        return true;
    }

    /**
     * 等级最大人数
     *
     * @param teamInfo
     * @return
     */
    public int getTeamMaxNumber(TeamInfo teamInfo) {
        if (StringUtils.isEmpty(teamInfo.getCityCode())) {
            AppUserInfo appUserInfo = appUserDao.findByMongoId(teamInfo.getAgentNo());
            teamInfo.setCityCode(appUserInfo.getBusinessCityid());
        }
        /**
         * 判断城市是否有配置等级规则，有取城市规则，没有取全国配置规则
         */
        TeamGrade teamGrade = teamGradeDao.findByBusinessCityidAndGradeCode(teamInfo.getCityCode(), teamInfo.getGrade());
        if (null != teamGrade) {
            return teamGrade.getMaxMemNum();
        } else {
            teamGrade = teamGradeDao.findByBusinessCityidAndGradeCode(ALL, teamInfo.getGrade());
            return teamGrade.getMaxMemNum();
        }
    }

    /**
     * 根据agentNo 查询状态不是status的团队
     *
     * @param agentNo
     * @param status
     * @return
     */
    public TeamInfo findByAgentNoAndStatusNot(String agentNo, String status) {
        return teamInfoDao.findByAgentNoAndStatusNot(agentNo, status);
    }

    /**
     * 根据agentNo 查询状态是status的团队
     *
     * @param agentNo
     * @param status
     * @return
     */
    public TeamInfo findByAgentNoAndStatus(String agentNo, String status) {
        return teamInfoDao.findByAgentNoAndStatus(agentNo, status);
    }


    /**
     * 校验敏感词
     *
     * @param msg
     * @return
     */
    public String checkSensitiveWords(String msg) {
        return TextSensitivity.checkSensitive(msg) == true ? "SENSITIVE" : "";
    }

    /**
     * 创建团队
     *
     * @param agentNo
     * @return
     */
    @Transactional
    public TeamInfo createTeam(String agentNo, String name, String optUser) {
        //生成6位随机数
        int randomCode = 0;
        do {
            randomCode = RandomUtils.nextInt(100000, 999999);
        } while (findByTeamNo(randomCode + "") != null);
        String teamNo = randomCode + "";

        //获取用户手机号
        AppUserInfo appUser = appUserDao.findByMongoId(agentNo);

        TeamInfo teamInfo = new TeamInfo();
        if (null != appUser) {
            teamInfo.setTeamNo(teamNo);
            teamInfo.setAgentNo(agentNo);
            teamInfo.setTeamName(name);
            teamInfo.setStatus(TeamStatusEnumDto.NORMAL.toString());
            teamInfo.setEstablishDate(LocalDateTime.now());
            /**
             * 20171212 新增字段
             */
            teamInfo.setGrade(TeamGradeEnum.QT.getCode());
            teamInfo.setGradeSort("1");
            teamInfo.setCityCode(appUser.getBusinessCityid());
            teamInfo.setIsDowngrade(false);
            teamInfo.setSilverMember(false);
            teamInfo.setSilverAnnounce(false);
            teamInfo.setSilverCrash(false);
            teamInfo.setGoldMember(false);
            teamInfo.setGoldIntegral(false);
            teamInfo.setGoldLoan(false);
            teamInfo.setGoldLoanThird(false);
            teamInfo.setDiamondLoan(false);
            teamInfo.setDiamondIntegral(false);
            teamInfo.setDiamondMember(false);
            teamInfo.setDiamondActiveMember(false);
            teamInfo.setDiamondLoanThird(false);
            teamInfo = teamInfoDao.save(teamInfo);

            //写入操作日志
            createOperationLog(agentNo, teamNo, TeamStatusEnumDto.CREATE_TEAM.toString(),
                    optUser, agentNo);

            //加入成员自己
            joinTeam(appUser, teamNo, TeamStatusEnumDto.ROLE_OF_LEADER.toString(), optUser);


        }
        return teamInfo;
    }


    /**
     * 通过团队编号查询团队信息
     *
     * @param teamNo
     * @return
     */
    public TeamInfo findByTeamNo(String teamNo) {
        return teamInfoDao.findByTeamNo(teamNo);
    }


    public Map<String, Object> setFullTeamInfo(TeamInfo teamInfo) {
        String agentNo = ContextHolder.getAgentNo();
        log.info("TeamApi@setFullTeamInfo agentNo:{}", agentNo);

        //最佳放款成员
        String bestMemberOfAmount = getBestmemberOfAmount(teamInfo.getTeamNo());
        log.info("----bestMemberOfAmount:{}", bestMemberOfAmount);
        Map<String, Object> amountMap = new HashMap<String, Object>();
        if (StringUtils.isNotEmpty(bestMemberOfAmount)) {
            String[] str = bestMemberOfAmount.split(",");
            String nickName = bestMemberOfAmount.split(",")[0].toString();  //昵称
            String headImageId="";
            if(str.length ==2 ){
                  headImageId = bestMemberOfAmount.split(",")[1].toString(); //头像
            }

            amountMap.put("nickName", nickName);
            String showImage ="";
            if(StringUtils.isNotEmpty(headImageId)){
                //微信头像
                if(headImageId.startsWith("http")){
                    showImage = headImageId.replace("http","https");
                }else{
                    ResponseInfo<String> responseInfo = dspConfigSao.getImgUrl(headImageId,"phone");
                    if(responseInfo.isSuccess()){
                        showImage = responseInfo.getData();
                    }
                }
            }
            log.info("headImageId:{}",showImage);
            amountMap.put("headImageId", showImage);
        }
        //最佳推单成员
        String bestMemberOfOrder = getBestMemberOfOrder(teamInfo.getTeamNo());
        log.info("----bestMemberOfOrder:{}", bestMemberOfOrder);
        Map<String, Object> orderMap = new HashMap<String, Object>();
        if (StringUtils.isNotEmpty(bestMemberOfOrder)) {
            String[] str = bestMemberOfAmount.split(",");
            String nickName = bestMemberOfAmount.split(",")[0].toString();  //昵称
            String headImageId="";
            if(str.length ==2 ){
                headImageId = bestMemberOfAmount.split(",")[1].toString(); //头像
            }
            String showImage ="";
            orderMap.put("nickName", nickName);
            if(StringUtils.isNotEmpty(headImageId)){
                //微信头像
                if(headImageId.startsWith("http")){
                    showImage = headImageId.replace("http","https");
                }else{
                    ResponseInfo<String> responseInfo = dspConfigSao.getImgUrl(headImageId,"phone");
                    if(responseInfo.isSuccess()){
                        showImage = responseInfo.getData();
                    }
                }
            }
            log.info("headImageId:{}",showImage);
            orderMap.put("headImageId",showImage);
        }
        //业务公告
        List<String> businessNotice = getAnnouncementInformation(teamInfo.getTeamNo());
        //团员信息
        TeamMemberInfo teamMemberInfo = findByAgentNoAndTeamNoAndStatusNot(agentNo, teamInfo.getTeamNo(), TeamStatusEnumDto.DELETE.toString());
        //积分排名
        String ranking = getTeamIntegralRanking(teamInfo.getTeamNo());
        log.info("{}：团队本次排名:{}", teamInfo.getTeamNo(), ranking);
        //先从缓存取数据
        String redisKey = TEAM_PM + teamInfo.getTeamNo();
        Boolean hasKey = redisTemplate.hasKey(redisKey);
        int lastRanking = 0;
        if (hasKey) {
            String redisRank = redisTemplate.opsForValue().get(redisKey);
            log.info("{}：团队上一次排名:{}", teamInfo.getTeamNo(), redisRank);
            if (StringUtils.isNotEmpty(redisRank)) {
                lastRanking = Integer.parseInt(redisRank);
            }
        }
        String teamRankingType = "e";
        if (StringUtils.isNotEmpty(ranking)) {
            if(lastRanking==0){
                teamRankingType = "e";
            }else{
                //大于  排名上升
                if (Integer.parseInt(ranking) > lastRanking) {
                    teamRankingType = "d";
                    //小于  排名下降
                } else if (Integer.parseInt(ranking) < lastRanking) {
                    teamRankingType = "u";
                } else {
                    teamRankingType = "e";
                }
            }

        }

        //本季度总积分
        Integer integral = teamIntegralService.getTeamIntegralSumIndex(teamInfo.getTeamNo());
        if (null == integral) {
            integral = 0;
        }
        //判断是否团队满员
        String flag = teamInfo.getStatus();
        if (!flag.equals(TeamStatusEnumDto.READY_DELETE.toString())) {
            // 根据团队号获取当前团队的成员数量
            boolean teamMemberCount = getTeamMemberCount(teamInfo.getTeamNo());
            if (teamMemberCount) {
                flag = TeamStatusEnumDto.TEAM_FULL.toString();
            }
        }

        Map<String, Object> map = new HashMap<String, Object>();
        map.put("bestMemberOfAmount", amountMap == null ? "" : amountMap);
        map.put("bestMemberOfOrder", orderMap == null ? "" : orderMap);
        map.put("teamName", teamInfo.getTeamName());
        map.put("teamNo", teamInfo.getTeamNo());
        map.put("teamGrade", teamInfo.getGrade() == null ? "" : teamInfo.getGrade());//团队等级
        map.put("teamIntegral", integral);//团队积分
        map.put("teamIntegralRanking", ranking);//团队积分排名
        map.put("teamRankingType", teamRankingType);//团队排名变动
        map.put("notice", teamInfo.getNotice() == null ? "" : teamInfo.getNotice());
        map.put("businessNotice", businessNotice == null ? "" : businessNotice);
        map.put("status", flag);
        map.put("agentNo", agentNo);
        String status = teamMemberInfo == null ? TeamStatusEnumDto.DELETE.toString() : teamMemberInfo.getStatus();
        map.put("memberStatus", status);
        String operationType = teamMemberInfo == null ? "" : teamMemberInfo.getOperationType();
        if (TeamStatusEnumDto.OPT_BY_LEADER.toString().equals(operationType)) {
            operationType = TeamStatusEnumDto.OPT_BY_LEADER.toString();
        } else if (TeamStatusEnumDto.OPT_BY_MEMBER.toString().equals(operationType)) {
            operationType = TeamStatusEnumDto.OPT_BY_MEMBER.toString();
        }
        map.put("operation", operationType);

        return map;
    }

    /**
     * 操作日志
     *
     * @param agentNo       用户编号
     * @param teamNo        团队编号
     * @param status        操作状态
     * @param operationType 操作类型
     * @param operationBy   操作人
     */
    public void createOperationLog(String agentNo, String teamNo, String status,
                                   String operationType, String operationBy) {

        TeamOperationLog operationLog = new TeamOperationLog();
        operationLog.setAgentNo(agentNo);
        operationLog.setTeamNo(teamNo);
//        operationLog.setJoinType(joinType);
//        operationLog.setLeaveType(leaveType);
        operationLog.setStatus(status);
        operationLog.setOperationType(operationType);
        operationLog.setOperationDate(LocalDateTime.now());
        operationLog.setOperationBy(operationBy);

        try {
            teamOperationDao.save(operationLog);
        } catch (Exception e) {
            log.info("TeamService@createOperationLog 写入日志失败 agentNo:{}, teamNo:{}, status:{}, operationType:{}, operationBy:{}",
                    agentNo, teamNo, status, operationType, operationBy);
        }
    }

    /**
     * 根据团队编号和状态查询团队信息
     *
     * @param teamNo
     * @param status
     * @return
     */
    public TeamInfo findByTeamNoAndStatus(String teamNo, String status) {
        return teamInfoDao.findByTeamNoAndStatus(teamNo, status);
    }

    /**
     * 校验用户是否存在团队中
     *
     * @param agentNo
     * @param teamNo
     * @return true存在 false不存在
     */
    public boolean checkExistTeamOfMember(String agentNo, String teamNo) {
        TeamMemberInfo teamMemberInfo = findByAgentNoAndTeamNoAndStatusNot(agentNo, teamNo, TeamStatusEnumDto.DELETE.toString());
        return teamMemberInfo == null ? false : true;
    }

    public int findMemberCnt(String teamNo) {
        return teamMemberInfoDao.countByTeamNoAndStatusNot(teamNo, TeamStatusEnumDto.DELETE.toString());
    }

    /**
     * 根据用户编号和团队编号查询不在 status状态下的成员
     *
     * @param agentNo
     * @param teamNo
     * @param status
     * @return
     */
    public TeamMemberInfo findByAgentNoAndTeamNoAndStatusNot(String agentNo, String teamNo, String status) {
        return teamMemberInfoDao.findByAgentNoAndTeamNoAndStatusNot(agentNo, teamNo, status);
    }

    /**
     * 询积分排名
     *
     * @param teamNo
     * @return
     */
    public String getTeamIntegralRanking(String teamNo) {
        log.info("-----------" + teamNo);
        DecimalFormat format = new DecimalFormat("0");
        //先从缓存取数据
        String redisKey = TEAM_INTEGRAL + teamNo + TEAM_RANKING;
//        Boolean hasKey = redisTemplate.hasKey(redisKey);
//        if (hasKey) {
//            return redisTemplate.opsForValue().get(redisKey);
//        }

        //查询积分排名
        List<Object[]> listObj = teamIntegralRankingService.getTeamIntegralRankingOrderBy(teamNo);
        String banking = "0";
        if (null != listObj && listObj.size() > 0) {
            for (Object[] obj : listObj) {
                banking = format.format(obj[4]);
                log.info("banking:" + banking);
            }
        }

        //积分排序放入缓存
        redisTemplate.opsForValue().set(redisKey, banking, redisTimeout, TimeUnit.MINUTES);
        return banking;
    }

    /**
     * 根据用户编号和团队编号查询在 status状态下的成员
     *
     * @param agentNo
     * @param teamNo
     * @param status
     * @return
     */
    public TeamMemberInfo findByAgentNoAndTeamNoAndStatus(String agentNo, String teamNo, String status) {
        return teamMemberInfoDao.findByAgentNoAndTeamNoAndStatus(agentNo, teamNo, status);
    }

    /**
     * 团长不同意加入团队
     *
     * @param id
     */
    public void disagreeJoinTeam(String id) {
        TeamMemberInfo teamMemberInfo = teamMemberInfoDao.findById(id);
        if (null != teamMemberInfo) {
            teamMemberInfo.setStatus(TeamStatusEnumDto.DELETE.toString());
            teamMemberInfo.setJoinDate(LocalDateTime.now());
            teamMemberInfoDao.save(teamMemberInfo);
            List<String> userIdList = new ArrayList<String>();
            userIdList.add(teamMemberInfo.getAgentNo());
            String title = "驳回通知";
            String detail = "亲爱的团员你好，团长不同意你的入团申请！";
            pushNotificationLeader(userIdList, title, detail);
        }
    }

    /**
     * 加入团队
     *
     * @param appUser
     * @param teamNo
     * @return
     */
    public TeamMemberInfo joinTeam(AppUserInfo appUser, String teamNo, String teamRole, String optUser) {
        String agentNo = appUser.getMongoId();
        TeamMemberInfo teamMemberInfo = null;

        //加入团队
        if (null == teamMemberInfo) {
            teamMemberInfo = new TeamMemberInfo();
            teamMemberInfo.setAgentNo(agentNo);
            teamMemberInfo.setTeamNo(teamNo);
            teamMemberInfo.setTeamRole(teamRole);
            teamMemberInfo.setOperationType(optUser);
        }

        teamMemberInfo.setStatus(TeamStatusEnumDto.NORMAL.toString());
        teamMemberInfo.setJoinDate(LocalDateTime.now());
        if (appUser != null) {
            teamMemberInfo.setRegisterDate(appUser.getCreatedAt());
        }

        TeamMemberInfo memberInfo = teamMemberInfoDao.save(teamMemberInfo);

        //写入操作日志
        createOperationLog(agentNo, teamNo, TeamStatusEnumDto.JOIN_TEAM.toString(),
                optUser, agentNo);

        // 推送通知给团长
        TeamInfo teamInfo = findByTeamNoAndStatus(teamNo, TeamStatusEnumDto.NORMAL.toString());
        if (null != teamInfo && StringUtils.isNotBlank(teamInfo.getAgentNo()) && StringUtils.isNotBlank(teamInfo.getTeamName())) {
            List<String> userIdList = null;


            userIdList = new ArrayList<String>();
            userIdList.add(teamInfo.getAgentNo());
            //获取用户手机号
//            AppUserInfo appUser = appUserDao.findByMongoId(teamMemberInfo.getAgentNo());
            String title = "成员加入通知";
            String detail = "亲爱的团长你好，用户（" + appUser.getCellphone().replaceAll("(\\d{3})\\d{4}(\\d{4})", "$1****$2") + "）已加入（" + teamInfo.getTeamName() + "）团队";
            pushNotificationLeader(userIdList, title, detail);
        } else {
            log.info("TeamService@findByTeamNoAndStatus 无效的团队信息失败 teamNo:{} ", teamNo);
        }

        return memberInfo;
    }

    /**
     * 推送成员加入团的申请消息给团长
     *
     * @param agentNo
     * @return
     */

    public ResponseInfo<?> pushJoinTeamMessage(String agentNo, String teamNo) {
        AppUserInfo appUser = appUserDao.findByMongoId(agentNo);
        if (appUser == null) {
            return ResponseInfo.error("用户已失效，请重新登录！");
        }

        //写入操作日志
        createOperationLog(agentNo, teamNo, TeamStatusEnumDto.APPLICATION_TEAM.toString(),
                TeamStatusEnumDto.OPT_BY_MEMBER.toString(), agentNo);
        // 推送通知给团长
        TeamInfo teamInfo = findByTeamNoAndStatus(teamNo, TeamStatusEnumDto.NORMAL.toString());
        if (null == teamInfo) {
            log.info("无效的团队信息:" + teamInfo);
            return ResponseInfo.error("无效的团队信息！");
        }
        String title = "成员申请加入通知";
        String detail = "亲爱的团长你好，用户（" + appUser.getCellphone().replaceAll("(\\d{3})\\d{4}(\\d{4})", "$1****$2") + "）申请加入你的团队，请确认是否同意加入?";
        String sendTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        MessagePushRequestDTO messagePushRequestDTO = new MessagePushRequestDTO();
        messagePushRequestDTO.setApplySerialNO(agentNo);
        messagePushRequestDTO.setTitle(title);
        messagePushRequestDTO.setDetail(detail);
        messagePushRequestDTO.setType("060");  //普通业务消息推送
        messagePushRequestDTO.setUserId(teamInfo.getAgentNo());
        messagePushRequestDTO.setSendTime(sendTime);
        ResponseInfo<?> responseInfo = adtJpushSao.messagePushNew(messagePushRequestDTO);
        log.info("----------pushJoinTeamMessage----" + responseInfo);
        return ResponseInfo.success(true);
    }

    //团长同意团员加入团队
    public String argeeJoinTeam(AgreeJoinTeam agreeJoinTeam, String agentNo) throws BusinessException {

        //查询团队是否有效
        String detail = "你已成功加入";
        String noDetail = "很遗憾，你加入";
        TeamInfo teamInfo = teamInfoDao.findByAgentNoAndStatusNot(agentNo, TeamStatusEnumDto.DELETE.toString());
        if (null == teamInfo) {
            log.info("找不到团队{}", agentNo);
            throw new BusinessException("1000", agentNo + "找不到团队");

        }
        detail = detail + teamInfo.getTeamName() + "团队";
        noDetail = noDetail + teamInfo.getTeamName() + "的申请被拒绝";

        List<String> list = new ArrayList<String>();
        TeamMemberInfo teamMemberInfo = new TeamMemberInfo();
        //团长同意
        if (agreeJoinTeam.getAgree().equals("agree")) {
            AppUserInfo appUser = appUserDao.findByMongoId(agreeJoinTeam.getApplySerialNO());
            if (appUser == null) {
                throw new BusinessException("1001", "用户失效");
            }
            //加入团队
            teamMemberInfo.setAgentNo(agreeJoinTeam.getApplySerialNO());
            teamMemberInfo.setTeamNo(teamInfo.getTeamNo());
            teamMemberInfo.setTeamRole(TeamStatusEnumDto.ROLE_OF_MEMBER.toString());
            teamMemberInfo.setStatus(TeamStatusEnumDto.NORMAL.toString());
            teamMemberInfo.setJoinDate(LocalDateTime.now());
            teamMemberInfo.setRegisterDate(appUser.getCreatedAt());
            teamMemberInfo.setOperationType(TeamStatusEnumDto.OPT_BY_MEMBER.toString());
            teamMemberInfoDao.save(teamMemberInfo);

            //写入操作日志
            createOperationLog(agentNo, teamInfo.getTeamNo(), TeamStatusEnumDto.ARGEE_JOIN_TEAM.toString(),
                    TeamStatusEnumDto.ROLE_OF_LEADER.toString(), agentNo);
            list.add(agreeJoinTeam.getApplySerialNO());
            //发送成功加入消息给团员
            pushNotificationLeader(list, "成功加入团队", detail);

        } else {
            //写入操作日志
            createOperationLog(agentNo, teamInfo.getTeamNo(), TeamStatusEnumDto.NOTARGEE_JOIN_TEAM.toString(),
                    TeamStatusEnumDto.ROLE_OF_LEADER.toString(), agentNo);

            list.add(agreeJoinTeam.getApplySerialNO());
            //发送成功加入消息给团员
            pushNotificationLeader(list, "拒绝加入团队", noDetail);
        }

        //appMessage
        adtJpushSao.messageProcess(agreeJoinTeam.getId());

        return teamInfo.getTeamNo();
    }

    /**
     * 推送消息公共方法
     *
     * @param userIdList 用户mongoId
     * @param title      推送标题
     * @param detail     推送内容
     */
    public void pushNotificationLeader(List<String> userIdList, String title, String detail) {
        MessagePushRequestDTO messagePushRequestDTO = null;
        String sendTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        try {
            if(null != userIdList && userIdList.size() > 0){
                for (String userId : userIdList) {
                    messagePushRequestDTO = new MessagePushRequestDTO();
                    messagePushRequestDTO.setApplySerialNO("");
                    messagePushRequestDTO.setTitle(title);
                    messagePushRequestDTO.setDetail(detail);
                    messagePushRequestDTO.setType("050");
                    messagePushRequestDTO.setUserId(userId);
                    messagePushRequestDTO.setSendTime(sendTime);
                    adtJpushSao.messagePushNew(messagePushRequestDTO);
                }
            }
        } catch (Exception e) {
            log.info("TeamService@pushNotificationLeader 发送推送消息失败 userIdList:{}, title:{}, detail:{}", userIdList, title, detail);
        }
    }

    /**
     * 修改团队信息
     *
     * @param teamDto
     * @return
     */
    public TeamInfo updateTeam( TeamInfo teamInfo,TeamDto teamDto, String optUser) {
        if (teamInfo != null) {
            List<String> userIdList = teamMemberInfoDao.findByTeamNoAndStatusNotquery(teamDto.getTeamNo());
            //修改公告
            if (StringUtils.isNotBlank(teamDto.getNotice())) {
                teamInfo.setNotice(teamDto.getNotice());
                //团队公告通知
                if (null != userIdList && userIdList.size() > 0) {
                    String title = "团队公告通知";
                    String detail = "你所在的（" + teamInfo.getTeamName() + "）团队发布了新公告，内容为（公告内容" + teamDto.getNotice() + "）";
                    pushNotificationLeader(userIdList, title, detail);
                } else {
                    log.info("TeamService@findByTeamNoAndStatus 获取当前团队的所有成员ID失败 userIdList:{}", userIdList);
                }

                //调用升级接口
                teamInfoService.teamGradeProcess(teamInfo.getTeamNo());
            }

            //修改团队名
            if (StringUtils.isNotBlank(teamDto.getTeamName())) {
                //团队名称更换通知
                if (null != userIdList && userIdList.size() > 0) {
                    String title = "团队名称更换通知";
                    String detail = "你所在的（" + teamInfo.getTeamName() + "）团队已变更团队名称，新团队名为（" + teamDto.getTeamName() + "）";
                    pushNotificationLeader(userIdList, title, detail);
                } else {
                    log.info("TeamService@findByTeamNoAndStatus 获取当前团队的所有成员ID失败 userIdList:{}", userIdList);
                }
                teamInfo.setTeamName(teamDto.getTeamName());
            }

            teamInfo = teamInfoDao.save(teamInfo);


            //写入操作日志
            createOperationLog(teamInfo.getAgentNo(), teamInfo.getTeamNo(), TeamStatusEnumDto.UPDATE_TEAM.toString(),
                    optUser, teamInfo.getAgentNo());


        }

        return teamInfo;
    }

    /**
     * 删除团队
     *
     * @param teamNo
     * @return
     */
    public TeamInfo deleteTeam(String teamNo) {
        String status = TeamStatusEnumDto.READY_DELETE.toString();
        String leaveStatus = TeamStatusEnumDto.OPT_BY_DISBANDTEAM.toString();
        TeamInfo teamInfo = findByTeamNo(teamNo);
        if (teamInfo != null && TeamStatusEnumDto.NORMAL.toString().equals(teamInfo.getStatus())) {
            teamInfo.setStatus(status);
            teamInfo.setDisbandDate(LocalDateTime.now());
            teamInfo = teamInfoDao.save(teamInfo);
            //删除团队所有的成员
            disbandTeam(teamNo, teamInfo.getTeamName(), status, leaveStatus);
            //写入操作日志
            createOperationLog(teamInfo.getAgentNo(), teamInfo.getTeamNo(),
                    TeamStatusEnumDto.DISBAND_TEAM.toString(), leaveStatus, teamInfo.getAgentNo());
        }

        return teamInfo;
    }

    /**
     * 解散团队时移除团队所有成员
     *
     * @param teamNo
     * @param teamName
     * @param status
     * @param leaveStatus
     * @return
     */
    public void disbandTeam(String teamNo, String teamName, String status, String leaveStatus) {

        //查出所有在团成员，发送通知
        List<TeamMemberInfo> members = teamMemberMgrDao.findByTeamNoAndStatus(
                teamNo, TeamStatusEnumDto.NORMAL.toString());
        List<String> userIdList = new ArrayList<>();
        for (TeamMemberInfo member : members) {
            userIdList.add(member.getAgentNo());
            member.setStatus(status);
            member.setLeaveDate(LocalDateTime.now());
            member.setOperationType(leaveStatus);
            TeamMemberInfo teamMemberInfo = teamMemberInfoDao.save(member);
            //写入操作日志
            createOperationLog(teamMemberInfo.getAgentNo(), teamMemberInfo.getTeamNo(),
                    TeamStatusEnumDto.LEAVE_TEAM.toString(), leaveStatus, teamMemberInfo.getAgentNo());
        }
        String title = "团队解散通知";
        String detail = "亲爱的用户你好，很遗憾的告知你你所在的（" + teamName + "）团队已申请解散，该申请将在月底生效。生效前权益与福利将继续计算，生效后之前产生的团队收益请前往半刻钱包进行查看。";
        pushNotificationLeader(userIdList, title, detail);
/*
        //纪录操作
        createOperationLog(null, teamNo, null,
                TeamStatusEnumDto.DISBAND_TEAM.toString(), TeamStatusEnumDto.OPT_BY_OPERATE.toString());*/
    }

    /**
     * 删除成员
     *
     * @param agentNo
     * @param teamNo
     * @param delete
     * @return
     */
    public TeamMemberInfo deleteMember(String agentNo, String teamNo, String delete) {

        log.info("TeamService@deleteMember 团员id agentNo:{}", agentNo);
        String status = TeamStatusEnumDto.READY_DELETE.toString();
        //操作状态
        String leaveStatus = "";
        //成员删除delete 为空   团长删除delete为delete，运营删除delete为OPT
        if (StringUtils.isNotBlank(delete)) {
            if ("OPT".equals(delete)) {
                status = TeamStatusEnumDto.DELETE.toString();
                leaveStatus = TeamStatusEnumDto.OPT_BY_OPERATE.toString(); //运营操作
            }else{
                leaveStatus = TeamStatusEnumDto.OPT_BY_LEADER.toString(); //团长操作
            }
        }else{
            leaveStatus = TeamStatusEnumDto.OPT_BY_MEMBER.toString(); //成员操作
        }
        log.info("操作人：{}",leaveStatus);
        TeamMemberInfo teamMemberInfo = findByAgentNoAndTeamNoAndStatusNot(agentNo, teamNo, TeamStatusEnumDto.DELETE.toString());

        log.info("TeamService@deleteMember 团员角色 getTeamRole:{}", teamMemberInfo.getTeamRole());
        if (teamMemberInfo != null && !TeamStatusEnumDto.ROLE_OF_LEADER.toString().equals(teamMemberInfo.getTeamRole())) {
            teamMemberInfo.setStatus(status);
            teamMemberInfo.setOperationType(leaveStatus);
            teamMemberInfo.setLeaveDate(LocalDateTime.now());
            teamMemberInfo = teamMemberInfoDao.save(teamMemberInfo);
            //写入操作日志
            createOperationLog(teamMemberInfo.getAgentNo(), teamMemberInfo.getTeamNo(),
                    TeamStatusEnumDto.LEAVE_TEAM.toString(), leaveStatus, teamMemberInfo.getAgentNo());
            //团长操作
            TeamInfo teamInfo = findByTeamNoAndStatus(teamNo, TeamStatusEnumDto.NORMAL.toString());
            List<String> userIdList = new ArrayList<>();
            String title = "";
            String detail = "";
            if ("delete".equals(delete)) {
                //移除团队通知
                if (null != teamInfo && StringUtils.isNotBlank(teamInfo.getTeamName())) {
                    userIdList.add(agentNo);
                    title = "移除团队通知";
                    detail = "亲爱的用户你好，很遗憾的告知你你所在的（" + teamInfo.getTeamName() + "）团队已申请将你移除，该申请将在月底生效。生效前权益与福利将继续计算，生效后之前产生的团队收益请前往半刻钱包进行查看。";
                    pushNotificationLeader(userIdList, title, detail);
                } else {
                    log.info("TeamService@findByTeamNoAndStatus 无效的团队信息失败 teamNo:{} ", teamNo);
                }
            } else {
                if (null != teamInfo && StringUtils.isNotBlank(teamInfo.getAgentNo()) && StringUtils.isNotBlank(teamInfo.getTeamName())) {
                    userIdList.add(teamInfo.getAgentNo());
                    //获取用户手机号
                    AppUserInfo appUser = appUserDao.findByMongoId(teamMemberInfo.getAgentNo());
                    title = "成员退出通知";
                    detail = "亲爱的团长你好，用户（" + appUser.getCellphone().replaceAll("(\\d{3})\\d{4}(\\d{4})", "$1****$2") + "）已退出（" + teamInfo.getTeamName() + "）团队";
                    pushNotificationLeader(userIdList, title, detail);
                } else {
                    log.info("TeamService@findByTeamNoAndStatus 无效的团队信息失败 teamNo:{} ", teamNo);
                }

            }
        }

        return teamMemberInfo;
    }

    /**
     * 校验团队名称是否已存在
     *
     * @param name
     * @return true存在 false不存在
     */
    public boolean checkTeamNameExist(String name) {
        TeamInfo teamInfo = findByTeamNameAndStatusNot(name, TeamStatusEnumDto.DELETE.toString());
        return teamInfo == null ? false : true;
    }

    /**
     * 通过团队名称查询 不在 status状态下的团队
     *
     * @param name
     * @param status
     * @return
     */
    public TeamInfo findByTeamNameAndStatusNot(String name, String status) {
        return teamInfoDao.findByTeamNameAndStatusNot(name, status);
    }

    /**
     * 取最佳推单成员
     *
     * @param teamNo
     * @return
     */
    public String getBestMemberOfOrder(String teamNo) {
        //先从缓存取数据
        String redisKey = TEAM + teamNo + BEST_ORDER;
        Boolean hasKey = redisTemplate.hasKey(redisKey);
        if (hasKey) {
            return redisTemplate.opsForValue().get(redisKey);
        }

        //如果不存在则查询并存入缓存
        //String startDate = LocalDate.now().minusMonths(1).with(TemporalAdjusters.firstDayOfMonth()).toString();
        String startDate = LocalDate.now().with(TemporalAdjusters.firstDayOfMonth()).toString();
        //返回最佳推单成员的昵称和头像ID
        List<Object[]> listObj = teamMemberInfoDao.getBestMemberOfOrder(teamNo, startDate);
        StringBuffer sb = new StringBuffer();
        if (null != listObj && listObj.size() > 0) {
            for (Object[] obj : listObj) {
                String imageId ="";
                //判断是否为空
                if(null == obj[1]){
                    //微信图像
                    if(null != obj[2]){
                        String openId = String.valueOf(obj[2]);
                        AppWeChatUserInfo appWeChatUserInfo = appWeChatUserInfoDao.findByOpenid(openId);
                        if(null != appWeChatUserInfo){
                            imageId = appWeChatUserInfo.getHeadimgurl();
                        }
                    }
                }else {
                    imageId = String.valueOf(obj[1]);
                }
                //obj[0])昵称  //obj[1])头像ID  //obj[2])openId
                sb.append(obj[0]).append(",").append(imageId);
            }

        }
        //存入缓存
        if (StringUtils.isNotBlank(sb)) {
//            cellPhone = cellPhone.replaceAll("(\\d{3})\\d{4}(\\d{4})", "$1****$2");
            redisTemplate.opsForValue().set(redisKey, sb.toString(), redisTimeout, TimeUnit.MINUTES);
        }
        return sb.toString();
    }


    /**
     * 取最佳放款成员
     *
     * @param teamNo
     * @return
     */
    public String getBestmemberOfAmount(String teamNo) {
        //先从缓存取数据
        String redisKey = TEAM + teamNo + BEST_AMOUNT;
        Boolean hasKey = redisTemplate.hasKey(redisKey);
        if (hasKey) {
            return redisTemplate.opsForValue().get(redisKey);
        }

        //如果不存在则查询并存入缓存
        //String startDate = LocalDate.now().minusMonths(1).with(TemporalAdjusters.firstDayOfMonth()).toString();
        String startDate = LocalDate.now().with(TemporalAdjusters.firstDayOfMonth()).toString();
        //返回最佳放款成员的昵称和头像ID
        List<Object[]> listobj = teamMemberInfoDao.getBestMemberOfAmount(teamNo, startDate);
        StringBuffer sb = new StringBuffer();
        if (null != listobj && listobj.size() > 0) {
            for (Object[] obj : listobj) {
                String imageId ="";
                //判断是否为空
                if(null == obj[1]){
                    //微信图像
                    if(null != obj[2]){
                        String openId = String.valueOf(obj[2]);
                        AppWeChatUserInfo appWeChatUserInfo = appWeChatUserInfoDao.findByOpenid(openId);
                        if(null != appWeChatUserInfo){
                            imageId = appWeChatUserInfo.getHeadimgurl();
                        }
                    }
                }else {
                    imageId = String.valueOf(obj[1]);
                }
                //obj[0])昵称  //obj[1])头像ID  //obj[2])openId
                sb.append(obj[0]).append(",").append(imageId);
            }
        }

        //存入缓存
        if (StringUtils.isNotBlank(sb)) {
//            cellPhone = cellPhone.replaceAll("(\\d{3})\\d{4}(\\d{4})", "$1****$2");
            redisTemplate.opsForValue().set(redisKey, sb.toString(), redisTimeout, TimeUnit.MINUTES);
        }
        return sb.toString();
    }

    /**
     * @param agentNo
     * @return
     */
    public Map getTeamListForMember(String agentNo) {
        List<TeamIndexDto> list = new ArrayList<>();
        List<TeamDto> teamListForMember = teamMemberInfoDao.getTeamListForMember(agentNo);
        Map<String, Object> map = Maps.newHashMap();
        //是否能够创建team N 不能，Y 能
        String flag = "Y";
        int applyCnt = getCountOrder(agentNo);
        if (applyCnt < 2) {
            flag = "N";
        }
        int teamListForMemberSize = teamListForMember.size();
        if (null != teamListForMember && teamListForMemberSize > 0) {
            for (TeamDto teamDto : teamListForMember) {
                TeamIndexDto teamLeader;
                TeamIndexDto teamMember;
                if (teamDto.getTeamRole().equals(TeamStatusEnumDto.ROLE_OF_LEADER.toString())) {
                    flag = "Y";
                    teamLeader = getTeamIndexDto(teamDto);
                    list.add(teamLeader);
                    if (teamListForMemberSize < 2) {
                        teamMember = new TeamIndexDto(TeamStatusEnumDto.ROLE_OF_MEMBER.toString());
                        list.add(teamMember);
                    }
                }

                if (teamDto.getTeamRole().equals(TeamStatusEnumDto.ROLE_OF_MEMBER.toString())) {
                    teamMember = getTeamIndexDto(teamDto);
                    if (teamListForMemberSize < 2) {
                        teamLeader = new TeamIndexDto(TeamStatusEnumDto.ROLE_OF_LEADER.toString());
                        list.add(teamLeader);
                    }
                    list.add(teamMember);
                }
            }

        } else {
            TeamIndexDto teamLeader = new TeamIndexDto(TeamStatusEnumDto.ROLE_OF_LEADER.toString());
            TeamIndexDto teamMember = new TeamIndexDto(TeamStatusEnumDto.ROLE_OF_MEMBER.toString());
            list.add(teamLeader);
            list.add(teamMember);
        }
        map.put("createTeam", flag);
        map.put("list", list);
        return map;
    }

    /**
     * @param agentNo
     * @return
     */
    public int getCountOrder(String agentNo) {
        LocalDate localDate = LocalDate.now();
        LocalDate minusMonths = localDate.minusMonths(6);
        return teamMemberInfoDao.getCountOrder(agentNo, minusMonths);
    }


    private TeamIndexDto getTeamIndexDto(TeamDto teamDto) {
        TeamIndexDto teamIndexDto = new TeamIndexDto();
        teamIndexDto.setTeamNo(teamDto.getTeamNo());
        teamIndexDto.setTeamName(teamDto.getTeamName());
        teamIndexDto.setStatus(teamDto.getStatus());
        teamIndexDto.setNotice(null == teamDto.getNotice() ? "" : teamDto.getNotice());
        teamIndexDto.setTeamRole(teamDto.getTeamRole());
        return teamIndexDto;
    }


    public TeamMemberInfo getTeamInfo(String agentNo, LocalDateTime date) {
        TeamMemberInfo teamMemberInfo = teamMemberInfoDao.getTeamInfo(agentNo, date);
        return teamMemberInfo;
    }

    /**
     * 我的外快
     *
     * @param teamNo
     * @return
     */
    public String findMyCommission(String teamNo,String agentNo) {
        //先从缓存取数据
        String redisKey = TEAM + teamNo+agentNo + MY_COMMISSION;
        Boolean hasKey = redisTemplate.hasKey(redisKey);
        if (hasKey) {
            return redisTemplate.opsForValue().get(redisKey);
        }
        String commission = "";

        //如果不存在则查询并存入缓存
        ResponseInfo<?> amount = teamSao.findTeamCommissionAmount(teamNo,agentNo);
        if (amount.isSuccess() && amount.getData() != null) {
            commission = amount.getData() + "";
        }
        //存入缓存
        if (StringUtils.isNotBlank(commission)) {
            redisTemplate.opsForValue().set(redisKey, commission, redisTimeout, TimeUnit.MINUTES);
        }
        return commission;
    }

    /**
     * 通过团队编号获取成员列表
     *
     * @param teamNo
     * @return
     */
    public Map<String, Object> getMemberListByTeamNo(String teamNo) {

        List<Object[]> memberListByTeamNo = teamMemberInfoDao.getMemberListByTeamNo(teamNo);

        Map<String, Object> result = new HashMap<String, Object>();

        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        memberListByTeamNo.forEach(objects -> {
            Map<String, Object> map = new HashMap<String, Object>();
            //判断本周是否发起过冲锋号
            List<TeamChargeMessage> listTeamChargeMessage = teamChargeMessageDao.getTeamChargeMessageBy(objects[0].toString());
            if (null != listTeamChargeMessage && listTeamChargeMessage.size() > 0) {
                map.put("isCfh", "1");
            } else {
                map.put("isCfh", "0");
            }
            map.put("agentNo", objects[0]);
            map.put("status", objects[1]);
//            String phone = objects[2].toString().replaceAll("(\\d{3})\\d{4}(\\d{4})", "$1****$2");
//            map.put("cellphone", phone);
            //手机号换成昵称在APP端显示
            map.put("cellphone", objects[6]);

            String tips = "";
            if (TeamStatusEnumDto.READY_DELETE.toString().equals(objects[1])) {
                tips = TeamStatusEnumDto.OPT_BY_MEMBER.toString().equals(objects[3]) ? "已申请退出团队" : "已删除,月底生效";
            }
            map.put("tips", tips);
            //加入团队的月份差，均值取近三个月，结果集也只是查出3个月内的推单数
            int dateDiff = (int) objects[4];
            double monthDiff = dateDiff > 60 ? 3 : (dateDiff > 30 ? 2 : 1);
            //map.put("monthDiff", monthDiff);
            if (monthDiff > 1) {
                double act = ((BigInteger) objects[5]).intValue() / monthDiff;
                String count = String.format("%.1f", act).replaceAll("0+?$", "").replaceAll("[.]$", "");  //保留一位小数
                map.put("applyCount", count);
            } else {
                map.put("applyCount", objects[5]);
            }

            list.add(map);
        });

        result.put("memberCount", list.size());
        result.put("limitCount", (MEMBER_LIMIT_COUNT + 1));
        result.put("members", list);

        return result;
    }


    @Transactional
    @MessageListener(queue = "dsp.appuser.apply.notice.flow.wrk")
    public void listenTweetBusinessAnnouncementTask(String group, String type, WrokflowLog data) {
        if ("apply.C00.BEGIN".equals(type) && (data.getGroupNo().equals("01") || data.getGroupNo().equals("03"))) {
            ApplyInfo applyInfo = JSONObject.parseObject(data.getSendData(), ApplyInfo.class);
            if (null != applyInfo && StringUtils.isNotBlank(applyInfo.getAgentNo())) {
                log.info("TeamService@listenTweetBusinessAnnouncementTask 获取人员信息 AgentNo:{}, task_id:{}", applyInfo.getAgentNo(), data.getGroupNo());
                getTweetBusinessAnnouncement(applyInfo.getAgentNo());
            }
        }

        if ("apply.F00.BEGIN".equals(type) && data.getGroupNo().equals("05")) {
            ApplyInfo applyInfo = JSONObject.parseObject(data.getSendData(), ApplyInfo.class);
            if (null != applyInfo && StringUtils.isNotBlank(applyInfo.getAgentNo())) {
                log.info("TeamService@listenTweetBusinessAnnouncementTask 获取人员信息 AgentNo:{}, task_id:{}", applyInfo.getAgentNo(), data.getGroupNo());
                getTweetBusinessAnnouncement(applyInfo.getAgentNo());
            }
        }

        //流程二信息确认完成
        if ("apply.FFF.BEGIN".equals(type) && data.getGroupNo().equals("02")) {
            ApplyInfo applyInfo = JSONObject.parseObject(data.getSendData(), ApplyInfo.class);
            if (null != applyInfo && StringUtils.isNotBlank(applyInfo.getAgentNo())) {
                log.info("TeamService@listenTweetBusinessAnnouncementTask 获取人员信息 AgentNo:{}, task_id:{}", applyInfo.getAgentNo(), data.getGroupNo());
                getTweetBusinessAnnouncement(applyInfo.getAgentNo());
                TeamMemberInfo teamMemberInfo= teamMemberInfoDao.findByAgentNoAndStatusAndTeamRole(applyInfo.getAgentNo(),TeamStatusEnumDto.NORMAL.toString(),TeamStatusEnumDto.ROLE_OF_MEMBER.toString());
                if(null != teamMemberInfo){
                    //等级升级接口
                    teamInfoService.teamGradeProcess(teamMemberInfo.getTeamNo());
                    teamIntegralService.save(applyInfo.getAgentNo(),2);
                    log.info("{}:新增积分,来源于：{}", teamMemberInfo.getTeamNo(),applyInfo.getAgentNo());
                }

            }
        }

        //流程五信息确认完成
        if ("apply.FFF.BEGIN".equals(type) && data.getGroupNo().equals("05")) {
            ApplyInfo applyInfo = JSONObject.parseObject(data.getSendData(), ApplyInfo.class);
            if (null != applyInfo && StringUtils.isNotBlank(applyInfo.getAgentNo())) {
                log.info("TeamService@listenTweetBusinessAnnouncementTask 获取人员信息 AgentNo:{}, task_id:{}", applyInfo.getAgentNo(), data.getGroupNo());
                TeamMemberInfo teamMemberInfo= teamMemberInfoDao.findByAgentNoAndStatusAndTeamRole(applyInfo.getAgentNo(),TeamStatusEnumDto.NORMAL.toString(),TeamStatusEnumDto.ROLE_OF_MEMBER.toString());
                if(null != teamMemberInfo){
                    //等级升级接口
                    teamInfoService.teamGradeProcess(teamMemberInfo.getTeamNo());
                    teamIntegralService.save(applyInfo.getAgentNo(),2);
                    log.info("{}:新增积分,来源于：{}", teamMemberInfo.getTeamNo(),applyInfo.getAgentNo());
                }
            }
        }

        //流程七信息确认完成
        if ("apply.FFF.BEGIN".equals(type) && data.getGroupNo().equals("07")) {
            ApplyInfo applyInfo = JSONObject.parseObject(data.getSendData(), ApplyInfo.class);
            if (null != applyInfo && StringUtils.isNotBlank(applyInfo.getAgentNo())) {
                log.info("TeamService@listenTweetBusinessAnnouncementTask 获取人员信息 AgentNo:{}, task_id:{}", applyInfo.getAgentNo(), data.getGroupNo());
                TeamMemberInfo teamMemberInfo= teamMemberInfoDao.findByAgentNoAndStatusAndTeamRole(applyInfo.getAgentNo(),TeamStatusEnumDto.NORMAL.toString(),TeamStatusEnumDto.ROLE_OF_MEMBER.toString());
                if(null != teamMemberInfo){
                    //等级升级接口
                    teamInfoService.teamGradeProcess(teamMemberInfo.getTeamNo());
                    teamIntegralService.save(applyInfo.getAgentNo(),2);
                    log.info("{}:新增积分,来源于：{}", teamMemberInfo.getTeamNo(),applyInfo.getAgentNo());
                }
            }
        }

        //流程一影像核查通过
        if("apply.U01.END".equals(type) && data.getGroupNo().equals("01") && data.getWay().startsWith("PASS")){
            ApplyInfo applyInfo = JSONObject.parseObject(data.getSendData(), ApplyInfo.class);
            if(null != applyInfo){
                TeamMemberInfo teamMemberInfo= teamMemberInfoDao.findByAgentNoAndStatusAndTeamRole(applyInfo.getAgentNo(),TeamStatusEnumDto.NORMAL.toString(),TeamStatusEnumDto.ROLE_OF_MEMBER.toString());
                if(null != teamMemberInfo){
                    //等级升级接口
                    teamInfoService.teamGradeProcess(teamMemberInfo.getTeamNo());
                    teamIntegralService.save(applyInfo.getAgentNo(),2);
                    log.info("{}:新增积分,来源于：{}", teamMemberInfo.getTeamNo(),applyInfo.getAgentNo());
                }
            }
        }
        //流程三影像核查通过、
        if("apply.U01.END".equals(type) && data.getGroupNo().equals("03")  && data.getWay().startsWith("PASS")){
            ApplyInfo applyInfo = JSONObject.parseObject(data.getSendData(), ApplyInfo.class);
            if(null != applyInfo){
                TeamMemberInfo teamMemberInfo= teamMemberInfoDao.findByAgentNoAndStatusAndTeamRole(applyInfo.getAgentNo(),TeamStatusEnumDto.NORMAL.toString(),TeamStatusEnumDto.ROLE_OF_MEMBER.toString());
                if(null != teamMemberInfo){
                    //等级升级接口
                    teamInfoService.teamGradeProcess(teamMemberInfo.getTeamNo());
                    teamIntegralService.save(applyInfo.getAgentNo(),2);
                    log.info("{}:新增积分,来源于：{}", teamMemberInfo.getTeamNo(),applyInfo.getAgentNo());
                }
            }
        }


    }


    @Transactional
    @MessageListener(queue = "dsp.appuser.sync.ord.order.order")
    public void listenLoanAnnouncementTask(String group, String type, OrderInfo orderInfo) {

        if ("status.FFF".equals(type)) {
            log.info("TeamService@listenLoanAnnouncementTask 获取人员信息订单号放款金额 group:{},type:{},orderInfo:{}", group, type, orderInfo);
            if (null != orderInfo && StringUtils.isNotBlank(orderInfo.getAgentNo())
                    && StringUtils.isNotBlank(orderInfo.getApplyNo()) && null != orderInfo.getTransAmount()) {
                String agentNo = orderInfo.getAgentNo();
                String applyNo = orderInfo.getApplyNo();
                String transAmount = orderInfo.getTransAmount().toString();

                getLoanAnnouncement(agentNo, applyNo, transAmount);
            }
        }

    }

    /**
     * 推单业务公告
     *
     * @param agentNo
     * @return
     */
    public void getTweetBusinessAnnouncement(String agentNo) {

        //从消息取数据
        TeamMemberInfo teamMemberInfo = teamMemberInfoDao.findByAgentNoAndStatusAndTeamRole(agentNo, TeamStatusEnumDto.NORMAL.toString(), TeamStatusEnumDto.ROLE_OF_MEMBER.toString());
        if (null == teamMemberInfo) {
            log.info("TeamService@findByAgentNoAndStatus 用户不存在团队中  agentNo:{} ", agentNo);
        } else {
            List<Map<String, Object>> listMap = new ArrayList<>();
            Map mapResult = Maps.newHashMap();
            StringBuffer commission = new StringBuffer();

            String teamNo = teamMemberInfo.getTeamNo() == null ? "" : teamMemberInfo.getTeamNo();
            //从redis取数据
            String redisKey = TEAM + teamNo + LOAN_ANNOUNCEMENT;
            Boolean hasKey = redisTemplate.hasKey(redisKey);

            //获取用户手机号
            AppUserInfo appUser = appUserDao.findByMongoId(teamMemberInfo.getAgentNo());
            if (null != appUser) {
                commission.append(appUser.getCellphone().replaceAll("(\\d{3})\\d{4}(\\d{4})", "$1****$2") + " 成功推单。");
            }

            if (hasKey) {
                List<Map<String, Object>> redisDataMapsList = redisTemplates.opsForValue().get(redisKey);
                //缓存限制6条数据
                if (null != redisDataMapsList && redisDataMapsList.size() == 6) {
                    redisDataMapsList.remove(0);
                }
                mapResult.put("TBA_" + agentNo, commission.toString());
                redisDataMapsList.add(mapResult);
                //redisTemplates.opsForValue().set(redisKey, redisDataMapsList, redisTimeout, TimeUnit.MINUTES);
                redisTemplates.opsForValue().set(redisKey, redisDataMapsList);
            } else {
                //存入缓存
                if (StringUtils.isNotBlank(commission)) {
                    mapResult.put("TBA_" + agentNo, commission.toString());
                    listMap.add(mapResult);
                    //redisTemplates.opsForValue().set(redisKey, listMap, redisTimeout, TimeUnit.MINUTES);
                    redisTemplates.opsForValue().set(redisKey, listMap);
                }

            }
        }

    }

    /**
     * 放款公告业务
     *
     * @param agentNo
     * @return
     */
    public void getLoanAnnouncement(String agentNo, String applyNo, String loanAmount) {
        //从消息取数据
        TeamMemberInfo teamMemberInfo = teamMemberInfoDao.findByAgentNoAndStatusAndTeamRole(agentNo, TeamStatusEnumDto.NORMAL.toString(), TeamStatusEnumDto.ROLE_OF_MEMBER.toString());
        if (null == teamMemberInfo) {
            log.info("TeamService@findByAgentNoAndStatus 用户不存在团队中  agentNo:{} ", agentNo);
        } else {
            StringBuffer commission = new StringBuffer();
            List<Map<String, Object>> listMap = new ArrayList<>();
            Map mapResult = Maps.newHashMap();
            boolean flag = true;

            String teamNo = teamMemberInfo.getTeamNo() == null ? "" : teamMemberInfo.getTeamNo();
            //从redis取数据
            String redisKey = TEAM + teamNo + LOAN_ANNOUNCEMENT;
            Boolean hasKey = redisTemplate.hasKey(redisKey);

            //获取用户手机号
            AppUserInfo appUser = appUserDao.findByMongoId(teamMemberInfo.getAgentNo());
            if (null != appUser) {
                commission.append(appUser.getCellphone().replaceAll("(\\d{3})\\d{4}(\\d{4})", "$1****$2") + " 成功放款 " + loanAmount + "元。");
            }

            if (hasKey) {
                List<Map<String, Object>> redisDataMapsList = redisTemplates.opsForValue().get(redisKey);
                if (null != redisDataMapsList && redisDataMapsList.size() > 0) {
                    for (Map loanAnnouncementMap : redisDataMapsList) {
                        if (null != loanAnnouncementMap.get(applyNo)) {
                            log.info("TeamService@redisDataMapsList 从缓存中获取放款业务数据 LoanAnnouncement:{},", loanAnnouncementMap.get(applyNo));
                            loanAnnouncementMap.put(applyNo, commission.toString());
                            flag = false;
                            break;
                        }
                    }
                }
                if (flag) {
                    //缓存限制6条数据
                    if (null != redisDataMapsList && redisDataMapsList.size() == 6) {
                        redisDataMapsList.remove(0);
                    }
                    mapResult.put(applyNo, commission.toString());
                    redisDataMapsList.add(mapResult);
                }
                //redisTemplates.opsForValue().set(redisKey, redisDataMapsList, redisTimeout, TimeUnit.MINUTES);
                redisTemplates.opsForValue().set(redisKey, redisDataMapsList);
            } else {
                //存入缓存
                if (StringUtils.isNotBlank(commission)) {
                    mapResult.put(applyNo, commission.toString());
                    listMap.add(mapResult);
                    //redisTemplates.opsForValue().set(redisKey, listMap, redisTimeout, TimeUnit.MINUTES);\
                    redisTemplates.opsForValue().set(redisKey, listMap);
                }

            }
        }

    }

    /**
     * 获取业务公告信息从缓存中读取
     *
     * @return
     */
    public List<String> getAnnouncementInformation(String teamNo) {
        //从redis取数据
        String redisKey = TEAM + teamNo + LOAN_ANNOUNCEMENT;
        Boolean hasKey = redisTemplate.hasKey(redisKey);
        List<String> resultList = new ArrayList<>();
        if (hasKey) {
            List<Map<String, Object>> redisDataMapsList = redisTemplates.opsForValue().get(redisKey);
            if (null != redisDataMapsList && redisDataMapsList.size() > 0) {
                redisDataMapsList.forEach(mapData -> mapData.keySet().forEach(mapKey -> {
                    log.info("TeamService@getAnnouncementInformation 从缓存中获取业务公告数据 key:{} ,value:{},", mapKey, mapData.get(mapKey));
                    resultList.add(mapData.get(mapKey).toString());
                }));
            }
        }
        return resultList;
    }


    /**
     * 判断是否加入其它团队
     *
     * @param agentNo
     * @return
     */
    public boolean joinOrtherTeam(String agentNo) {
        int cnt = teamMemberInfoDao.countByAgentNoAndStatusNotAndTeamRole(agentNo,
                TeamStatusEnumDto.DELETE.toString(), TeamStatusEnumDto.ROLE_OF_MEMBER.toString());
        return cnt > 0 ? true : false;
    }


    public List<TeamMemberInfo> findMembersByStatus(String status) {
        return teamMemberInfoDao.findByStatus(status);
    }

    public List<TeamInfo> findTeamsByStatus(String status) {
        return teamInfoDao.findByStatus(status);
    }

    public void executeJobDeleteMember() {
        List<TeamMemberInfo> memberInfos = findMembersByStatus(TeamStatusEnumDto.READY_DELETE.toString());
        deleteTeamMemberByJob(memberInfos, "JOB");
    }

    public void executeJobDeleteTeam() {
        List<TeamInfo> teamInfos = findTeamsByStatus(TeamStatusEnumDto.READY_DELETE.toString());
        if (teamInfos != null && teamInfos.size() > 0) {
            teamInfos.forEach(teamInfo -> {
                //删除团队
                teamInfo.setStatus(TeamStatusEnumDto.DELETE.toString());
                teamInfoDao.save(teamInfo);
                //写入操作日志
                createOperationLog("", teamInfo.getTeamNo(), TeamStatusEnumDto.DISBAND_TEAM.toString(),
                        "JOB", "JOB");
                //删除该团队下的成员
                List<TeamMemberInfo> memberInfos = teamMemberInfoDao.findByTeamNoAndStatusNot(teamInfo.getTeamNo(), TeamStatusEnumDto.DELETE.toString());
                deleteTeamMemberByJob(memberInfos, TeamStatusEnumDto.OPT_BY_DISBANDTEAM.toString());
            });
        }
    }

    private void deleteTeamMemberByJob(List<TeamMemberInfo> memberInfos, String status) {

        if (memberInfos != null && memberInfos.size() > 0) {
            memberInfos.forEach(memberInfo -> {
                memberInfo.setStatus(TeamStatusEnumDto.DELETE.toString());
                memberInfo.setOperationType(status);
                teamMemberInfoDao.save(memberInfo);
                createOperationLog(memberInfo.getAgentNo(), memberInfo.getTeamNo(), TeamStatusEnumDto.LEAVE_TEAM.toString(),
                        status, "JOB");
            });
        }

    }

    /**
     * 外快成员列表
     *
     * @param teamNo
     * @return
     */
    public ResponseInfo<?> getAmountMemberList(String teamNo,String agentNo) {
        List<Map<String, Object>> listMap = new ArrayList<Map<String, Object>>();
        Map<String, Object> m = new HashMap<String, Object>();
        int totalCount =0;
        //调用佣金服务
        ResponseInfo<List<TeamCommissionDto>> teamCommission = teamSao.findTeamCommission(teamNo,agentNo);
        if (teamCommission.isSuccess() && teamCommission.getData() != null) {
            List<TeamCommissionDto> list = teamCommission.getData();
            if (list != null && list.size() > 0) {
                for (TeamCommissionDto teamCommissionDto:list) {
                    Map<String, Object> map = new HashMap<String, Object>();
                    AppUserInfo appUserInfo = appUserDao.findByMongoId(teamCommissionDto.getSourceAgentNo());
                    String nickName ="";
                    if(null != appUserInfo){
                        nickName = appUserInfo.getNickname();
                    }
                    map.put("cellphone",nickName);  //手机号变昵称
                    map.put("transAmount", formatNumber2(teamCommissionDto.getTransAmount()+ ""));
                    map.put("amount", formatNumber2(teamCommissionDto.getAmount() + ""));
                    if(null != teamCommissionDto.getGenerationTime()){
                        map.put("generationTime", DateUtil.localDateTimeToString(teamCommissionDto.getGenerationTime()));
                    }

                    listMap.add(map);
                }
                totalCount = list.size();
            }

            m.put("totalCount", totalCount);
            m.put("rebateTotal", formatNumber2(findMyCommission(teamNo,agentNo)));
            m.put("listMember", listMap);
        }

        return ResponseInfo.success(m);
    }

    public String formatNumber2(String number) {

        if (StringUtils.isBlank(number)) {
            return "0.00";
        }

        double num = 0;
        try {
            num = Double.valueOf(number);
        } catch (NumberFormatException e) {
            log.error("TeamService@formatNumber2 格式转换失败 number:{} \n", number, e);
        }

        String format = "0.00";
        try {
            format = new DecimalFormat("#.00").format(num);
        } catch (Exception e) {
            log.error("TeamService@formatNumber2 格式转换失败 number:{} \n", number, e);
        }
        return format;
    }


    public boolean getTeamMemberCount(String teamNo) {
        int teamNoMembercount = teamMemberInfoDao.countByTeamNoAndStatusNot(teamNo, TeamStatusEnumDto.DELETE.toString());
        if (MEMBER_LIMIT_COUNT < teamNoMembercount) {
            return true;
        }
        return false;
    }

    public void clearCache(String key) {
        redisTemplate.delete(key);
    }

    public Object getCache(String key) {
        return redisTemplate.opsForValue().get(key);
    }

    public AppUserInfo getTeamLeaderInfo(String teamNo) {
        AppUserInfo appUser = teamMemberInfoDao.getTeamLeaderInfo(teamNo);
        return appUser;
    }


    /**
     * 团队等级
     */
    public void executeTeamUpgradeJob() {
        for (int i = 0; i < 3; i++) {
            switch (i) {
                //白银
                case 0:
                    GradeTeamUpThread byGradeTeamUpThread = new GradeTeamUpThread(TeamGradeEnum.BY.getCode(), teamInfoDao, teamGradeDownService);
                    Thread byThread = new Thread(byGradeTeamUpThread);
                    byThread.start();
                    break;
                //黄金
                case 1:
                    GradeTeamUpThread hjGradeTeamUpThread = new GradeTeamUpThread(TeamGradeEnum.HJ.getCode(), teamInfoDao, teamGradeDownService);
                    Thread hjThread = new Thread(hjGradeTeamUpThread);
                    hjThread.start();
                    break;
                //钻石
                case 2:
                    GradeTeamUpThread zsGradeTeamUpThread = new GradeTeamUpThread(TeamGradeEnum.ZS.getCode(), teamInfoDao, teamGradeDownService);
                    Thread zsThread = new Thread(zsGradeTeamUpThread);
                    zsThread.start();
                    break;
            }
        }
    }

    /**
     * 等级
     *
     * @param teamNo
     * @return
     */
    public TeamGradeInfoDto findByTeamGradeInfoDto(String teamNo) throws BusinessException {
        log.info("------teamNo----------" + teamNo);
        TeamGradeInfoDto teamGradeInfoDto = new TeamGradeInfoDto();
        //查询团队等级相关信息
        TeamInfo teamInfo = teamInfoDao.findByTeamNoAndStatusNot(teamNo, TeamStatusEnumDto.DELETE.toString());
        if (null == teamInfo) {
            throw new BusinessException("1000", "无效的团队编号！");
        }

        String grade = teamInfo.getGrade()==null?TeamGradeEnum.BY.getCode():teamInfo.getGrade();  //查询不到等级，默认BY
        String cityCode = teamInfo.getCityCode(); //业务城市
        String notice = teamInfo.getNotice(); //公告

        if (StringUtils.isEmpty(cityCode)) {
            AppUserInfo appUserInfo = appUserDao.findByMongoId(teamInfo.getAgentNo());
            if (null != appUserInfo)
                cityCode = appUserInfo.getBusinessCityid();
        }

        //查询等级规则
        TeamGrade teamGrade = teamGradeDao.findByBusinessCityidAndGradeCode(cityCode, grade);
        if (null == teamGrade) {
            teamGrade = teamGradeDao.findByBusinessCityidAndGradeCode(ALL, grade);
        }
        if (null != teamGrade) {
            /**
             * 封装等级数据，返回H5
             */
            teamGradeInfoDto.setGradeCode(teamGrade.getGradeCode());
            teamGradeInfoDto.setGradeName(teamGrade.getGradeName());
            teamGradeInfoDto.setMaxMemNum(teamGrade.getMaxMemNum());
            teamGradeInfoDto.setTlRebateRatio(teamGrade.getTlRebateRatio());
            teamGradeInfoDto.setTnRebateRatio(teamGrade.getTnRebateRatio());
            teamGradeInfoDto.setMaxRebate(teamGrade.getMaxRebate());

            //成员数
            int countNum = teamMemberInfoDao.countByTeamNoAndTeamRoleNotAndStatusNot(teamInfo.getTeamNo(), TeamStatusEnumDto.ROLE_OF_LEADER.toString(), TeamStatusEnumDto.DELETE.toString());
            //团队积分
            Integer reamIntegral = teamIntegralDao.getTeamIntegralSumIndex(teamNo);
            if (null == reamIntegral) {
                reamIntegral = 0;
            }
            //青铜
            if (grade.equals(TeamGradeEnum.QT.getCode())) {
                int remainingGrade = 3;  //初始任务
                Map<String, Integer> mapNum = new HashMap<String, Integer>();
                mapNum.put("total", byTeamgradeMaxNum);
                mapNum.put("finish", countNum);
                teamGradeInfoDto.setByNumber(mapNum);
                //完成大于规定
                if (countNum >= byTeamgradeMaxNum) {
                    remainingGrade--;
                }

                //公告
                Map<String, Integer> mapAnnouncement = new HashMap<String, Integer>();
                mapAnnouncement.put("total", byTeamgradeAnnouncement);
                if (StringUtils.isEmpty(notice)) {
                    mapAnnouncement.put("finish", 0);
                } else {
                    mapAnnouncement.put("finish", 1);
                    remainingGrade--;
                }
                teamGradeInfoDto.setByAnnouncement(mapAnnouncement);

                //冲锋号
                Map<String, Integer> mapCharge = new HashMap<String, Integer>();
                List<TeamChargeMessage> list = teamChargeMessageDao.findByTeamNo(teamNo);
                mapCharge.put("total", byTeamgradeCharge);
                if (null != list && list.size() > 0) {
                    mapCharge.put("finish", list.size());
                    remainingGrade--;
                } else {
                    mapCharge.put("finish", 0);
                }
                teamGradeInfoDto.setByChargeNumber(mapCharge);
                teamGradeInfoDto.setRemainingGrade(remainingGrade);
                //白银
            } else if (grade.equals(TeamGradeEnum.BY.getCode())) {
                int remainingGrade = 4;        //升级任务
                //查询邀请人数
                Integer countYq = teamMemberInfoDao.getTeamMemberRegister(teamNo);
                Map<String, Integer> mapNum = new HashMap<String, Integer>();
                mapNum.put("total", hjInviteMember);
                mapNum.put("finish", countYq);
                teamGradeInfoDto.setHjNumber(mapNum);
                //完成任务一
                if (countYq >= hjInviteMember) {
                    remainingGrade--;
                }

                Map<String, Integer> mapIntegral = new HashMap<String, Integer>();
                mapIntegral.put("total", hjTeamIntegral);
                mapIntegral.put("finish", reamIntegral);
                teamGradeInfoDto.setHjTeamIntegral(mapIntegral);
                //完成任务二
                if (reamIntegral >= hjTeamIntegral) {
                    remainingGrade--;
                }
                //团队成功放款笔数
                int countSuccessLoad = teamMemberMgrDao.countSuccessLoanQuarter(teamNo);
                Map<String, Integer> mapLoan = new HashMap<String, Integer>();
                mapLoan.put("total", hjTeamLoan);
                mapLoan.put("finish", countSuccessLoad);
                teamGradeInfoDto.setHjFinishLoan(mapLoan);
                //完成任务三
                if (countSuccessLoad >= hjTeamLoan) {
                    remainingGrade--;
                }
                //有效推荐一笔及以上第	三方产品
                //查询大数产品
                ResponseInfo<?> responseInfo = pdtDefSao.findByCooperationId("104");
                StringBuffer sb = new StringBuffer();
                if (responseInfo.isSuccess()) {
                    List<ProductInfo> productInfoList = (List<ProductInfo>) responseInfo.getData();
                    if (null != productInfoList && productInfoList.size() > 0) {
                        for (ProductInfo p : productInfoList) {
                            sb.append(p.getProductNo()).append(",");
                        }
                    }
                }
                String[] array = sb.toString().split(",");
                int countThird = teamMemberMgrDao.getApplyCountByTeam(teamNo, array);
                Map<String, Integer> mapThird = new HashMap<String, Integer>();
                mapThird.put("total", hjEffectiveThird);
                mapThird.put("finish", countThird);
                teamGradeInfoDto.setHjFinishThird(mapThird);
                if (countThird >= hjEffectiveThird) {
                    remainingGrade--;
                }
                teamGradeInfoDto.setRemainingGrade(remainingGrade);
                //黄金和钻石
            } else {
                int remainingGrade = 5;  //任务
                //成员数达到15个人及以上
                Map<String, Integer> mapNum = new HashMap<String, Integer>();
                mapNum.put("total", zsTeamMember);
                mapNum.put("finish", countNum);
                teamGradeInfoDto.setZsNumber(mapNum);
                //完成任务一
                if (countNum >= zsTeamMember) {
                    remainingGrade--;
                }

                //团队积分达3000分
                Map<String, Integer> mapIntegral = new HashMap<String, Integer>();
                mapIntegral.put("total", zsTeamIntegral);
                mapIntegral.put("finish", reamIntegral);
                teamGradeInfoDto.setZsTeamIntegral(mapIntegral);
                //完成任务二
                if (reamIntegral >= zsTeamIntegral) {
                    remainingGrade--;
                }
                //团队总放款笔数10笔及以上 
                //团队成功放款笔数
                int countSuccessLoad = teamMemberMgrDao.countSuccessLoanQuarter(teamNo);
                Map<String, Integer> mapLoan = new HashMap<String, Integer>();
                mapLoan.put("total", zsTeamLoan);
                mapLoan.put("finish", countSuccessLoad);
                teamGradeInfoDto.setZsFinishLoan(mapLoan);
                //完成任务三
                if (countSuccessLoad >= zsTeamLoan) {
                    remainingGrade--;
                }

                //团队第三方产品成功放款3笔及以上
                ResponseInfo<?> responseInfo = pdtDefSao.findByCooperationId("104");
                StringBuffer sb = new StringBuffer();
                if (responseInfo.isSuccess()) {
                    List<ProductInfo> productInfoList = (List<ProductInfo>) responseInfo.getData();
                    if (null != productInfoList && productInfoList.size() > 0) {
                        for (ProductInfo p : productInfoList) {
                            sb.append(p.getProductNo()).append(",");
                        }
                    }
                }
                String[] array = sb.toString().split(",");
                int countThird = teamMemberMgrDao.countSuccessThirdLoan(teamNo, array);

                //团队第三方产品成功放款3笔及以上
                Map<String, Integer> mapThird = new HashMap<String, Integer>();
                mapThird.put("total", zsTeamThirdLoan);
                mapThird.put("finish", countThird);
                teamGradeInfoDto.setZsFinishThird(mapThird);
                //完成任务四
                if (countThird >= zsTeamThirdLoan) {
                    remainingGrade--;
                }
                //团队当月活跃用户人数10人及以上
                List<String> stringList = teamMemberMgrDao.getApplyCountByTeamActive(teamNo);
                int countActive=0;
                if(null != stringList){
                    countActive = stringList.size();
                }
                Map<String, Integer> mapActive = new HashMap<String, Integer>();
                mapActive.put("total", zsTeamActiveMember);
                mapActive.put("finish", countActive);
                teamGradeInfoDto.setZsActiveNumber(mapActive);
                //完成任务5
                if (countActive >= zsTeamActiveMember) {
                    remainingGrade--;
                }

                teamGradeInfoDto.setRemainingGrade(remainingGrade);
            }
        } else {
            log.info("根据业务城市{}和等级{}查询不到相关配置信息，请确认是否配置！", cityCode, grade);
        }

        return teamGradeInfoDto;
    }

    //冲锋号
    public void teamChargeNumber(String teamNo, String agentNo) {
        List<String> listAgentNo = new ArrayList<String>();
        listAgentNo.add(agentNo);

        log.info("冲锋号模板：" + cfhTemplate);
        //替换当前时间
        cfhTemplate = cfhTemplate.replace("Y", LocalDate.now().toString());
        //团队成功放款笔数   FFF  （本月）
        int countLoan = teamMemberMgrDao.countSuccessLoanM(teamNo);
        cfhTemplate = cfhTemplate.replace("N", countLoan + "");
        //查询团队本月推单数
        int applyCount = teamMemberMgrDao.getApplyCountByTeam(teamNo);
        cfhTemplate = cfhTemplate.replace("X", applyCount + "");
        //查询团队本月放款总额
        Double amount = teamMemberMgrDao.getOrderAmountByTeam(teamNo);
        if (amount == null) {
            amount = 0.0;
        }
        cfhTemplate = cfhTemplate.replace("T", amount + "");

        log.info("推送消息内容：" + cfhTemplate);
        pushNotificationLeader(listAgentNo, cfhTemplateTitle, cfhTemplate);

        //记录冲锋号
        TeamChargeMessage teamChargeMessage = new TeamChargeMessage();
        teamChargeMessage.setTeamNo(teamNo);
        teamChargeMessage.setTitle(cfhTemplateTitle);
        teamChargeMessage.setDetails(cfhTemplate);
        teamChargeMessage.setMsgStatus("UNREAD");  //未读
        teamChargeMessage.setMongoId(agentNo);
        teamChargeMessageDao.save(teamChargeMessage);
    }
}

package com.banke.dsp.auth.dto;

/**
 * 基本信息类型
 * Created by ex-zhongbingguo on 2017/8/31.
 */
public enum BaseInfoTypeEnum {
    BANKID(10, "bankId"),                   //银行
    BUSINESSCITY(20, "businessCity"),     //业务城市
    JOB(30, "job"),                         //职业
    ASCRIPTIONTYPE(40, "ascriptionType"), //归属
    CITIEID(50,"cityId"),                   //城市
    SOURCE(60, "source"),                   //用户注册渠道
    AREA(70,"area");                        //地区

    private Integer code;
    private String type;

    BaseInfoTypeEnum(Integer code, String type) {
        this.code = code;
        this.type = type;
    }

    public Integer getCode() {
        return code;
    }

    public String getType() {
        return type;
    }
}

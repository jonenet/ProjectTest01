package com.banke.dsp.auth.po;


import com.banke.bkc.framework.po.BasePO;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "register_constraint_log")
public class RegisterConstraintLog extends BasePO{

    //用户姓名
    private String username;

    //用户手机号码
    private String cellphone;

    //注册码
    private String registerCode;

    //操作系统版本
    private String osVersion;

    //app版本
    private String appVersion;

    private String registerDevice;

    //描述
    private String message;

}

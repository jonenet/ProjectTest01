package com.banke.dsp.auth.dto;

import com.banke.bkc.framework.po.BasePO;
import com.banke.bkc.framework.util.CodeEnum;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class OrderApplyInfoDto extends BasePO {

     // 申请编号
    private String applyNo;

    // 城市
    private String cityId;

    // 申请时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime applyDate;

    //申请金额
    private BigDecimal applyAmount;

    // 一级产品(产品大类)
    private String primaryProductNo;

    // 二级产品
    private String productNo;

    // 状态流转编号
    private String taskId;

     // 是否允许推荐其他产品
    private Boolean isAllowOtherProduct;

    // 查询征信机构(银行)
    private String bankId;

     //  业务机构(分公司)
    private String inputOrgId;

    // 渠道名称
    private String channel;

    // 业务员编码
    private String agentNo;

    // 业务员是否可信任（免见证）
    private Boolean isTrustAgent;

    // 客户编号
    private String clientNo;

    //  客户经理编号
    private String advisorNo;

    // 状态变更时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime statusDate;

    // 备注
    private String remark;


}

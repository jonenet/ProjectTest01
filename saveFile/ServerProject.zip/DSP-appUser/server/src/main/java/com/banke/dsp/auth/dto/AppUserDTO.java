package com.banke.dsp.auth.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * Created by ex-zhongbingguo on 2017/8/16.
 */
@Data
public class AppUserDTO extends AppUser {
    // 是否需要补业务城市
    private String repairBusinessCity;

    private String canPassCode;

    private List<AppRole> roles;

    @JsonProperty
    private boolean isSuperAgent;

    private String isBindBankCard;

    //银行名字： 例如招商银行/农业银行
    private String bankName;

    //银行背景图片
    private String backgroundUrl;

    //银行logo图片
    private String logoUrl;

    //银行卡类型：信用卡/储蓄卡
    private String cardType;

    //更改卡状态 1: 完成 2：正在更换中
    private String changeCardStatus;

    //壹钱包token
    private String yqbToken;

    //微信昵称
    private String nickname;

    //头像图片
    private String headImageUrl;

    //是否拥有客户经理
    private String hasCustomerManager;

    //用户归属
    private String ascription;

    //是否绑定微信
    private String hasWeChat;

    //是否有密码
    private String hasPassword;
}

package com.banke.dsp.auth.service;

import com.alibaba.fastjson.JSONObject;
import com.banke.bkc.framework.exception.BusinessException;
import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.bkc.service.util.ContextHolder;
import com.banke.dsp.auth.dto.*;
import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.sao.DspConfigSao;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by ex-zhongbingguo on 2017/8/15.
 */
@Service
@Slf4j
public class RecommendsService {

    @Autowired
    private DspConfigSao dspConfigSao;

    @Autowired
    private AppUserInfoUtilService appUserInfoUtilService;

    @Autowired
    private StaffInfoService staffInfoService;

    @Autowired
    private BranchInfoService branchInfoService;

    @Autowired
    private AppUserInfoService appUserInfoService;

    /**
     * 补业务城市编码
     * @param businessCityCode     业务城市code
     * @param inviteCode            邀请码
     * @return                       Map
     */
    public ResponseInfo<?> saveCity(String businessCityCode, String inviteCode) throws BusinessException{
        log.info("RecommendsService@saveCity,参数业务城市: {}, 参数邀请码:{}",businessCityCode,inviteCode);

        Map<Object, Object> map = new HashMap<>();
        if (StringUtils.isEmpty(inviteCode) && StringUtils.isEmpty(businessCityCode)){
            throw new BusinessException("0001","参数不能为空");
        }
        String mongoId = ContextHolder.getAgentNo();
        log.info("用户mongoId : {}", mongoId);
        AppUserInfo appUserInfo = appUserInfoService.findByMongoId(mongoId);

        String referrer = appUserInfo.getReferrer();
        String refererName = appUserInfo.getRefererName();
        if (StringUtils.isNotEmpty(referrer) && StringUtils.isNotEmpty(refererName) && !refererName.contains("虚拟")){
            throw new BusinessException("0003","已绑定客户经理，修改请联系客服");
        }
        String branchNo = "";
        if (StringUtils.isNotEmpty(inviteCode)){
            //邀请码校验
            ResponseInfo<RegisterConstraintInstenceDTO> response = dspConfigSao.findRCIByRegisterCode(inviteCode.trim());
            log.info("result to registerConstraintInstance: {}", JSONObject.toJSONString(response));

            if (!response.isSuccess() || response.getData() == null) {
                log.info("邀请码校验，无效的邀请码:{}",inviteCode);
                throw new BusinessException("0004","未找到客户经理，请确认邀请码是否正确");
            }
            RegisterConstraintInstenceDTO rci = response.getData();
            if (!rci.isEnabled()){
                log.info("邀请码校验，该邀请码已经被禁用:{}",inviteCode);
                throw new BusinessException("0005","抱歉，绑定失败，请稍后再试");
            }

            //根据用户id，获取客户经理（新增邀请码，没有判断用户角色，因此这需要角色过滤）
            StaffInfoDTO staffInfoDTO = staffInfoService.getCustomerManagerByUserId(rci.getClientManagerId());
            if (staffInfoDTO == null) {
                throw new BusinessException("0006","未找到客户经理，请确认邀请码是否正确");
            }
            appUserInfo.setRegisterId(rci.getId().toString());
            appUserInfo.setReferrer(rci.getClientManagerId());
            appUserInfo.setRefererName(rci.getClientManagerName());

            //查询业务城市
            BranchInfoDTO branchInfo = branchInfoService.getBranchByBranchNo(SysIdEnum.WRK.getValue(), staffInfoDTO.getBranchNo());
            if (branchInfo == null){
                log.info("无效的业务城市编码:{}", staffInfoDTO.getBranchNo());
                throw new BusinessException("0007","抱歉，绑定失败，请稍后再试");
            }
            appUserInfo.setBusinessCityid(branchInfo.getBranchNo());
            appUserInfo.setRefMobilePhone(staffInfoDTO.getPhoneNumber());
            branchNo = staffInfoDTO.getBranchNo();
        }else if(StringUtils.isNotEmpty(businessCityCode)){
            BranchInfoDTO branchInfo = branchInfoService.getBranchByBranchNo(SysIdEnum.WRK.getValue(), businessCityCode);
            if (branchInfo == null){
                log.info("无效的业务城市编码:{}", businessCityCode);
                throw new BusinessException("0008","抱歉，绑定失败，请稍后再试");
            }
            BusinessCity businessCity = new BusinessCity();
            businessCity.setId(branchInfo.getBranchNo());
            appUserInfo.setBusinessCityid(branchInfo.getBranchNo());
            //根据业务城市code查询 虚拟客户经理
            StaffInfoDTO staffInfoDTO = staffInfoService.getVirtualStaffInfoDTOByBranchNo(StaffInfoRoleEnum.B_GPS.getCode(), businessCityCode);
            if(staffInfoDTO==null){
                throw new BusinessException("0009","未查询到对应地推人员");
            }
            appUserInfo.setReferrer(staffInfoDTO.getUserId());
            appUserInfo.setRefererName(staffInfoDTO.getStaffName());
            branchNo = staffInfoDTO.getBranchNo();
        }

        //查询部门，补充用户归属
        BranchInfoDTO department = branchInfoService.getBranchByBranchNo(SysIdEnum.WRK.getValue(), branchNo);
        appUserInfo.setAscription(department.getAscription());           //归属
        appUserInfo.setAscriptionStatus(true);                          //归属状态

        appUserInfo.setModifiedAt(LocalDateTime.now());
        appUserInfo.setEnabled(true);
        appUserInfo.setCreditWay("bank");
        appUserInfo.setArchived(false);
        appUserInfo.setEnableEecommendation(true);
        appUserInfo.setExpired(false);
        appUserInfo.setLocked(false);
        appUserInfo.setIsNeedCredit(true);
        appUserInfoUtilService.updateAppUser(appUserInfo);
        return ResponseInfo.success(true);
    }

    /**
     *  BranchInfoDTO 转  BusinessCity
     * @param branchInfo    BranchInfoDTO
     * @return               BusinessCity
     */
    private BusinessCity businessCityConvert(BranchInfoDTO branchInfo){
        BusinessCity bc = new BusinessCity();
        if (branchInfo != null){
            bc.setId(branchInfo.getBranchNo());
            bc.setCode(branchInfo.getBranchNo());
            bc.setName(branchInfo.getName());
            bc.setSortNo(branchInfo.getSort().toString());
            bc.setStatus("00".equals(branchInfo.getBranchStatus()) ? "1" : "0");
        }
        return bc;
    }
}

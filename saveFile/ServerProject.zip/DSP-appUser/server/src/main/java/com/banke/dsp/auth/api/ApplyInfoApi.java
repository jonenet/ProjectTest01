package com.banke.dsp.auth.api;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.service.ApplyInfoService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Describe:
 * Created by zhangyong on 2017/8/28.
 */
@RestController
@RequestMapping(value = "/api", method = {RequestMethod.GET, RequestMethod.POST})
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ApplyInfoApi {

    @Autowired
    private ApplyInfoService applyInfoService;

    /**
     *  团队长查询团员下的 推单情况
     *  @param teamNo
     *  @param agentNo
     * @return
     */
    @RequestMapping("/findTeamNumberOrder")
    public ResponseInfo<?> findTokenByAppUserInfo(@RequestParam String teamNo,@RequestParam String agentNo) {
        return applyInfoService.findApplyInfoByAgentNo(teamNo,agentNo);
    }

}

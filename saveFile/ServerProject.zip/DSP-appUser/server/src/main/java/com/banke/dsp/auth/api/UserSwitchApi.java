package com.banke.dsp.auth.api;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.bkc.service.util.ContextHolder;
import com.banke.dsp.auth.dto.UserSwitchDTO;
import com.banke.dsp.auth.service.UserSwitchService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Slf4j
@RestController
@RequestMapping(value = "/api", method = {RequestMethod.GET, RequestMethod.POST})
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class UserSwitchApi {
    @Autowired
    private UserSwitchService userSwitchService;

    /**
     * 查询用户开关
     * @return
     */
    @RequestMapping("/findUserSwitch")
    public ResponseInfo<?> findUserSwitch(){
        String agentNo = ContextHolder.getAgentNo();
        log.info("UserSwitchApi@findUserSwitch agentNo={}",agentNo);
        Map<String, Object> userSwitch = userSwitchService.findUserSwitch(agentNo);
        return ResponseInfo.success(userSwitch);
    }

    /**
     * 设置用户开关
     * @param
     * @return
     */
    @RequestMapping("/setUserSwitch")
    public ResponseInfo<?> setUserSwitch(@RequestBody UserSwitchDTO userSwitchDTO){
        if(StringUtils.isEmpty(userSwitchDTO.getAgentNo()) || StringUtils.isEmpty(userSwitchDTO.getName()) ){
            return ResponseInfo.error("参数不能为空");
        }
        return userSwitchService.setUserSwitch(userSwitchDTO.getAgentNo(),userSwitchDTO.getName(),userSwitchDTO.getValue());
    }

    /**
     * 判断该用户是否是白名单
     * @param userSwitchDTO
     * @return
     */
    @RequestMapping("/isUserSwitch")
    public ResponseInfo<?> isUserSwitch(@RequestBody UserSwitchDTO userSwitchDTO){
        boolean flag = userSwitchService.findUserSwitchByAgentNoAndName(userSwitchDTO.getAgentNo(), userSwitchDTO.getName());
        return flag == false ? ResponseInfo.error("不是白名单") : ResponseInfo.success("成功");
    }

}

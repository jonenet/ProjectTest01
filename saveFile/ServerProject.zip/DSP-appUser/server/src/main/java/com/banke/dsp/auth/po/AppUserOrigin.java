package com.banke.dsp.auth.po;

import com.banke.bkc.framework.po.BasePO;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * Created by ex-zengfanxi on 2017/10/17.
 */
@Data
@NoArgsConstructor
@RequiredArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "appuser_origin")
public class AppUserOrigin  extends BasePO {

	//被推荐人mongoId
	@NonNull
	@Column(nullable = false)
	private String mongoId;

	//推荐人mongoId
	@NonNull
	@Column(nullable = false)
	private String invitationId;

	//推荐时间
	@Column
	@JsonSerialize(using = LocalDateTimeSerializer.class)
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime invitationDate;

	//来源
	@Column(nullable = false)
	private String source;
}

package com.banke.dsp.auth.service;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dao.*;
import com.banke.dsp.auth.dto.ProductInfo;
import com.banke.dsp.auth.dto.TeamGradeEnum;
import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.po.TeamGrade;
import com.banke.dsp.auth.po.TeamGradeHistory;
import com.banke.dsp.auth.po.TeamInfo;
import com.banke.dsp.auth.sao.PdtDefSao;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Created by ex-taozhangyi on 2018/3/5.
 */
@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class TeamGradeDownService {
    @NonNull
    private AppUserDao appUserDao;
    @NonNull
    private TeamGradeDao teamGradeDao;
    @NonNull
    private TeamMemberMgrDao teamMemberMgrDao;
    @NonNull
    private TeamInfoDao teamInfoDao;
    @NonNull
    private TeamGradeHistoryDao teamGradeHistoryDao;
    @NonNull
    private PdtDefSao pdtDefSao;
    //白银降级
    public void byGradeTeam(TeamInfo teamInfo){
        log.info("byGradeTeam_teamInfo"+teamInfo);
        try{
            if(null != teamInfo){
                TeamGradeHistory teamGradeHistory = new TeamGradeHistory();
                //判断团队业务城市是否为空
                if(StringUtils.isEmpty(teamInfo.getCityCode())){
                    AppUserInfo appUserInfo =  appUserDao.findByMongoId(teamInfo.getAgentNo());
                    teamInfo.setCityCode(appUserInfo.getBusinessCityid());
                }
                //根据业务城市和团队等级
                TeamGrade teamGrade = teamGradeDao.findByBusinessCityidAndGradeCode(teamInfo.getCityCode(),teamInfo.getGrade());
                if(null == teamGrade){
                    teamGrade = teamGradeDao.findByBusinessCityidAndGradeCode("ALL",teamInfo.getGrade());
                }
                //推单笔数
                int count = 6;
                int thirdCount = 2;
                int m = 3;
                if(null != teamGrade){
                    count = teamGrade.getKeepPushNum();
                    thirdCount = teamGrade.getKeepThirdPushNum();
                }

                //近三月  有效推单数
                int  tdNumber = teamMemberMgrDao.getApplyCountByTeamAndTime(teamInfo.getTeamNo());
                // 近三月 第三方产品有效推单数
                int tdNumberThird =teamMemberMgrDao.getApplyCountByTeam(teamInfo.getTeamNo(),getArray());
                log.info("团队编号为"+teamInfo.getTeamNo()+"近三个月有效推单数为："+tdNumber+";第三方产品有效推单数为："+tdNumberThird+";");
                //判断是否降级
                if((tdNumber < count) || (tdNumberThird < thirdCount)){
                    log.info("-------不符合等级考核----------");
                    teamInfo.setGrade(TeamGradeEnum.QT.getCode());
                    teamInfo.setIsDowngrade(true);   //是
                    teamInfo.setSilverAnnounce(false);
                    teamInfo.setSilverCrash(false);
                    teamInfo.setDowngradeDate(LocalDateTime.now());
                    teamInfoDao.save(teamInfo);
                    //团队升降级记录
                    teamGradeHistory.setTeamNo(teamInfo.getTeamNo());
                    teamGradeHistory.setGrade(teamInfo.getGrade());
                    teamGradeHistory.setOperationType("D");
                    teamGradeHistoryDao.save(teamGradeHistory);
                }
            }
        }catch (Exception e){
            log.info(e.toString());
        }

    }

    //黄金降级
    public void hjGradeTeam(TeamInfo teamInfo){
        log.info("hjGradeTeam_teamInfo"+teamInfo);
        try{
            if(null != teamInfo){
                TeamGradeHistory teamGradeHistory = new TeamGradeHistory();
                //判断团队业务城市是否为空
                if(StringUtils.isEmpty(teamInfo.getCityCode())){
                    AppUserInfo appUserInfo =  appUserDao.findByMongoId(teamInfo.getAgentNo());
                    teamInfo.setCityCode(appUserInfo.getBusinessCityid());
                }
                //根据业务城市和团队等级
                TeamGrade teamGrade = teamGradeDao.findByBusinessCityidAndGradeCode(teamInfo.getCityCode(),teamInfo.getGrade());
                if(null == teamGrade){
                    teamGrade = teamGradeDao.findByBusinessCityidAndGradeCode("ALL",teamInfo.getGrade());
                }
                //推单笔数
                int count = 9;
                int thirdCount = 4;
                int m = 3;
                if(null != teamGrade){
                    count = teamGrade.getKeepPushNum();
                    thirdCount = teamGrade.getKeepThirdPushNum();
                }
                // 近三月  有效推单数
                int  tdNumber = teamMemberMgrDao.getApplyCountByTeamAndTime(teamInfo.getTeamNo());
                // 近三月 第三方产品有效推单数
                int tdNumberThird =teamMemberMgrDao.getApplyCountByTeam(teamInfo.getTeamNo(),getArray());
                log.info("团队编号为"+teamInfo.getTeamNo()+"近三个月有效推单数为："+tdNumber+";第三方产品有效推单数为："+tdNumberThird+";");
                //判断是否降级
                if((tdNumber < count) ||(tdNumberThird < thirdCount)){
                    log.info("-------不符合等级考核---------");
                    teamInfo.setGrade(TeamGradeEnum.BY.getCode());
                    teamInfo.setIsDowngrade(true);   //是
                    teamInfo.setGoldIntegral(false);
                    teamInfo.setGoldLoan(false);
                    teamInfo.setGoldLoanThird(false);
                    teamInfo.setDowngradeDate(LocalDateTime.now());
                    teamInfoDao.save(teamInfo);

                    //团队升降级记录
                    teamGradeHistory.setTeamNo(teamInfo.getTeamNo());
                    teamGradeHistory.setGrade(teamInfo.getGrade());
                    teamGradeHistory.setOperationType("D");
                    teamGradeHistoryDao.save(teamGradeHistory);
                }
            }
        }catch (Exception e){
            log.info(e.toString());
        }

    }

    //钻石降级
    public void zsGradeTeam(TeamInfo teamInfo){
        log.info("zsGradeTeam_teamInfo"+teamInfo);
        try{
            if(null != teamInfo){
                TeamGradeHistory teamGradeHistory = new TeamGradeHistory();
                //判断团队业务城市是否为空
                if(StringUtils.isEmpty(teamInfo.getCityCode())){
                    AppUserInfo appUserInfo =  appUserDao.findByMongoId(teamInfo.getAgentNo());
                    teamInfo.setCityCode(appUserInfo.getBusinessCityid());
                }
                //根据业务城市和团队等级
                TeamGrade teamGrade = teamGradeDao.findByBusinessCityidAndGradeCode(teamInfo.getCityCode(),teamInfo.getGrade());
                log.info("--------teamGrade-----"+teamGrade);
                if(null == teamGrade){
                    teamGrade = teamGradeDao.findByBusinessCityidAndGradeCode("ALL",teamInfo.getGrade());
                }
                //推单笔数
                int count = 0;
                int thirdCount = 0;
                int m = 3;  //3个月
                if(null != teamGrade){
                    count = teamGrade.getKeepPushNum();
                    thirdCount = teamGrade.getKeepThirdPushNum();
                }

                // 近三月  有效推单数
                int  tdNumber = teamMemberMgrDao.getApplyCountByTeamAndTime(teamInfo.getTeamNo());
                // 近三月 第三方产品有效推单数
                int tdNumberThird =teamMemberMgrDao.getApplyCountByTeam(teamInfo.getTeamNo(),getArray());
                log.info("团队编号为"+teamInfo.getTeamNo()+"近三个月有效推单数为："+tdNumber+";第三方产品有效推单数为："+tdNumberThird+";");
                //判断是否降级
                if((tdNumber < count) || (tdNumberThird < thirdCount)){
                    log.info("----不符合等级考核------");
                    teamInfo.setGrade(TeamGradeEnum.HJ.getCode());
                    teamInfo.setIsDowngrade(true);   //是
                    teamInfo.setDiamondActiveMember(false);
                    teamInfo.setDiamondIntegral(false);
                    teamInfo.setDiamondLoan(false);
                    teamInfo.setDiamondLoanThird(false);
                    teamInfo.setDowngradeDate(LocalDateTime.now());
                    teamInfoDao.save(teamInfo);

                    //团队升降级记录
                    teamGradeHistory.setTeamNo(teamInfo.getTeamNo());
                    teamGradeHistory.setGrade(teamInfo.getGrade());
                    teamGradeHistory.setOperationType("D");
                    teamGradeHistoryDao.save(teamGradeHistory);
                }
            }
        }catch (Exception e){
            log.info(e.toString());
        }

    }


    /**
     * 查询104大数产品
     * @return
     */
    public String[] getArray(){
        //有效推荐一笔及以上第	三方产品
        //查询大数产品
        ResponseInfo<?> responseInfo =  pdtDefSao.findByCooperationId("104");
        StringBuffer sb = new StringBuffer();
        if(responseInfo.isSuccess()){
            List<ProductInfo> productInfoList = ( List<ProductInfo>)responseInfo.getData();
            if(null !=productInfoList && productInfoList.size() >0){
                for (ProductInfo p :productInfoList) {
                    sb.append(p.getProductNo()).append(",");
                }
            }
        }
        return sb.toString().split(",");
    }
}

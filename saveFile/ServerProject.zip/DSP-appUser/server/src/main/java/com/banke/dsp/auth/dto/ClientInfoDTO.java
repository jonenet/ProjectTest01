package com.banke.dsp.auth.dto;

import com.banke.bkc.framework.util.CodeEnum;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import java.time.LocalDate;
import java.util.List;

/**
 * Describe:
 * Created by zhangyong on 2017/8/29.
 */
@Data
@NoArgsConstructor
public class ClientInfoDTO {

    private Long id;

    //客户号
    private String clientNo;

    //客户姓名
    @NonNull
    private String clientName;

    //证件号码
    @NonNull
    private String idNo;

    //出生日期
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate birthDate;

    //国籍
    private String country;

    //民族
    private String nationality;

    //婚姻状况
    private String marriage;

    //工作是否在本地  1：有  0：否
    private Boolean localHouseFlag;

    //居住地是否在本地（客户评级需要）   1：有  0：否
    private Boolean nativePlaceFlag;

    //证件到期日
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate idnoValidDate;

    //身份证发证机关所在地
    private String nativeAddress;

    //城市（分公司）
    private String regionCode;

    //学历
    @Column
    private String education;

    //学位
    private String degree;

    //毕业学校代码
    private String schoolCode;

    //毕业时间
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate graduationTime;

    //雇佣类型(客户类型)
    private String employeeType;

    //定价类型
    private String pricingType;

    //公务员类型
    private String civilServantType;

    //优良职业类型
    private String occupationType;


}

package com.banke.dsp.auth.po;

import com.banke.bkc.framework.po.BasePO;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Created by ex-taozhangyi on 2018/2/27.
 */
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "team_charge_message")
public class TeamChargeMessage extends BasePO {
    //团队编号
    private String teamNo;
    //用户ID
    private String mongoId;
    //标题
    private String title;
   // 内容
    private String details;
    //是否读取
    private String msgStatus;
}

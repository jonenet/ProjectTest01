package com.banke.dsp.auth.sao;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dto.BaseInfoDto;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * 基础信息SAO
 * Created by ex-zhongbingguo on 2017/8/15.
 */
@FeignClient(name = "QRY-list")
public interface QryListSao {

    @RequestMapping("/api/base/getBaseInfoBySysIdAndTypeAndCode")
    ResponseInfo<BaseInfoDto> getBaseInfoBySysIdAndTypeAndCode(@RequestParam("sysId") String sysId, @RequestParam("type") String type, @RequestParam("code") String code);

    @RequestMapping("/api/base/getBaseInfoBySysIdAndType")
    ResponseInfo<List<BaseInfoDto>> getBaseInfoBySysIdAndType(@RequestParam(name = "sysId") String sysId, @RequestParam(name = "type") String type);

}

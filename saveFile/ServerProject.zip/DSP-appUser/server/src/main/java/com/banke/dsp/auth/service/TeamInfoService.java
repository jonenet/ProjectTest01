package com.banke.dsp.auth.service;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dao.*;
import com.banke.dsp.auth.dto.MessagePushRequestDTO;
import com.banke.dsp.auth.dto.ProductInfo;
import com.banke.dsp.auth.dto.TeamGradeEnum;
import com.banke.dsp.auth.dto.TeamStatusEnumDto;
import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.po.TeamChargeMessage;
import com.banke.dsp.auth.po.TeamGradeHistory;
import com.banke.dsp.auth.po.TeamInfo;
import com.banke.dsp.auth.sao.AdtJpushSao;
import com.banke.dsp.auth.sao.PdtDefSao;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Created by ex-taozhangyi on 2018/3/12.
 */
@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class TeamInfoService {
    @NonNull
    private TeamInfoDao teamInfoDao;
    @NonNull
    private AppUserDao appUserDao;
    @NonNull
    private TeamChargeMessageDao teamChargeMessageDao;
    @NonNull
    private TeamMemberInfoDao teamMemberInfoDao;
    @NonNull
    private TeamGradeHistoryDao teamGradeHistoryDao;
    @NonNull
    private TeamIntegralDao teamIntegralDao;
    @NonNull
    private TeamMemberMgrDao teamMemberMgrDao;
    @NonNull
    private PdtDefSao pdtDefSao;
    @NonNull
    private AdtJpushSao adtJpushSao;

    @Value("${by.teamgrade.maxNum}")
    private int byTeamgradeMaxNum;

    @Value("${hj.invite.member}")
    private int hjInviteMember;
    @Value("${hj.team.integral}")
    private int hjTeamIntegral;
    @Value("${hj.team.loan}")
    private int hjTeamLoan;
    @Value("${hj.effective.third}")
    private int hjEffectiveThird;


    @Value("${zs.team.member}")
    private int zsTeamMember;
    @Value("${zs.team.third.loan}")
    private int zsTeamThirdLoan;
    @Value("${zs.team.loan}")
    private int zsTeamLoan;
    @Value("${zs.team.active.member}")
    private int zsTeamActiveMember;
    @Value("${zs.team.integral}")
    private int zsTeamIntegral;

    //升级接口
    public void teamGradeProcess(String teamNo) {
        log.info("teamNo:{}", teamNo);
        TeamInfo teamInfo = teamInfoDao.findByTeamNoAndStatusNot(teamNo, TeamStatusEnumDto.DELETE.toString());
        if (null != teamInfo) {
            switch (teamInfo.getGrade()) {
                case "QT":
                    qtGradeTeamUp(teamInfo);
                    break;
                case "BY":
                    byGradeTeamUp(teamInfo);
                    break;
                case "HJ":
                    hjGradeTeamUp(teamInfo);
                    break;
            }
        }
    }

    public void qtGradeTeamUp(TeamInfo teamInfo) {
        boolean qt = true;
        //① 成员数达到3人（不含团长） ②成功发布一条公告 ③发布一条团队冲锋号
        log.info("GradeTeamUpThread_qtGradeTeamUp:{}" , teamInfo);
        if (null != teamInfo) {
            TeamGradeHistory teamGradeHistory = new TeamGradeHistory();
            if (StringUtils.isEmpty(teamInfo.getCityCode())) {
                AppUserInfo appUserInfo = appUserDao.findByMongoId(teamInfo.getAgentNo());
                teamInfo.setCityCode(appUserInfo.getBusinessCityid());
            }
            //判断是否降过级  任务1不做判断
            if (!teamInfo.getIsDowngrade()) {
                //判断条件一是否满足
                if (!teamInfo.getSilverMember()) {
                    //成员数达到3人（不含团长）
                    int countNum = teamMemberInfoDao.countByTeamNoAndTeamRoleNotAndStatusNot(teamInfo.getTeamNo(), TeamStatusEnumDto.ROLE_OF_LEADER.toString(), TeamStatusEnumDto.DELETE.toString());
                    log.info("by countNum:{}",countNum);
                    if (countNum < byTeamgradeMaxNum) {
                        qt = false;
                        return;
                    } else {
                        log.info("白银条件1满足");
                        //满足条件
                        teamInfo.setSilverMember(true);
                        teamInfoDao.save(teamInfo);
                    }
                }
            }

            //判断条件二是否满足
            if (!teamInfo.getSilverAnnounce()) {
                //②成功发布一条公告
                if (StringUtils.isEmpty(teamInfo.getNotice())) {
                    qt = false;
                    return;
                } else {
                    log.info("白银条件二是否满足");
                    teamInfo.setSilverAnnounce(true);
                    teamInfoDao.save(teamInfo);
                }
            }

            //条件三是否满足
            if (!teamInfo.getSilverCrash()) {
                //③发布一条团队冲锋号
                List<TeamChargeMessage> listTeamChargeMessage = teamChargeMessageDao.findByTeamNo(teamInfo.getTeamNo());
                if (null == listTeamChargeMessage || listTeamChargeMessage.size() == 0) {
                    qt = false;
                    return;
                } else {
                    log.info("白银条件三是否满足");
                    teamInfo.setSilverCrash(true);
                    teamInfoDao.save(teamInfo);
                }
            }

            //满足升级条件,升级白银
            if (qt) {
                teamInfo.setGrade(TeamGradeEnum.BY.getCode());
                if (teamInfo.getIsDowngrade()) {
                    if ("2".equals(teamInfo.getGradeSort())) {
                        teamInfo.setIsDowngrade(false);
                    }
                } else {
                    teamInfo.setGradeSort("2");
                }
                teamInfoDao.save(teamInfo);

                //历史记录
                teamGradeHistory.setTeamNo(teamInfo.getTeamNo());
                teamGradeHistory.setGrade(teamInfo.getGrade());
                teamGradeHistory.setOperationType("U");  //升级
                teamGradeHistoryDao.save(teamGradeHistory);

                //查询团员信息
               List<String>  listAgentNo = teamMemberInfoDao.findByTeamNoAndStatusNotquery(teamInfo.getTeamNo());
               if(null != listAgentNo && listAgentNo.size() >0){
                   String title ="团队等级升级";
                   String detail="恭喜您所在的团队("+teamInfo.getTeamName()+")等级升为白银。";
                   //推送消息
                    pushNotificationLeader(listAgentNo, title, detail);
                }
            }
        }
    }

    //白银升降级
    public void byGradeTeamUp(TeamInfo teamInfo) {
        boolean by = true;
        //① 累计邀请5位评估神新用户入团 ②团队积分达2500分 ③团队成功放款两笔及以上 ④有效推荐一笔及以上第	三方产品
        log.info("GradeTeamUpThread_byGradeTeamUp" + teamInfo);
        if (null != teamInfo) {
            TeamGradeHistory teamGradeHistory = new TeamGradeHistory();
            if (StringUtils.isEmpty(teamInfo.getCityCode())) {
                AppUserInfo appUserInfo = appUserDao.findByMongoId(teamInfo.getAgentNo());
                teamInfo.setCityCode(appUserInfo.getBusinessCityid());
            }
            //判断是否降过级  任务1不做判断
            if (!teamInfo.getIsDowngrade()) {
                if (!teamInfo.getGoldMember()) {
                    // ① 累计邀请5位评估神新用户入团
                    int registerNum = teamMemberInfoDao.getTeamMemberRegister(teamInfo.getTeamNo());
                    log.info("累计邀请评估神新用户入团人数：" + registerNum);
                    if (registerNum < hjInviteMember) {
                        by = false;
                        return;
                    } else {
                        log.info("黄金条件一满足");
                        teamInfo.setGoldMember(true);
                        teamInfoDao.save(teamInfo);
                    }
                }
            }
            if (!teamInfo.getGoldIntegral()) {
                // ②团队积分达2500分
                Integer strInteger = teamIntegralDao.getTeamIntegralSumIndex(teamInfo.getTeamNo());
                if(null == strInteger){
                    strInteger =0;
                }

                log.info("团队积分：" + strInteger);
                if (strInteger < hjTeamIntegral) {
                    by = false;
                    return;
                } else {
                    log.info("黄金条件二满足");
                    teamInfo.setGoldIntegral(true);
                    teamInfoDao.save(teamInfo);
                }
            }

            if (!teamInfo.getGoldLoan()) {
                //③团队成功放款两笔及以上
                int loanNum = teamMemberMgrDao.countSuccessLoanQuarter(teamInfo.getTeamNo());
                log.info("团队成功放款笔数：" + loanNum);
                if (loanNum < hjTeamLoan) {
                    by = false;
                    return;
                } else {
                    log.info("黄金条件三满足");
                    teamInfo.setGoldLoan(true);
                    teamInfoDao.save(teamInfo);
                }
            }

            if (!teamInfo.getGoldLoanThird()) {
                // ④有效推荐一笔及以上第	三方产品
                int thirdLoanNum = teamMemberMgrDao.getApplyCountByTeam(teamInfo.getTeamNo(), getArray());
                log.info("有效推荐一笔及以上笔数：" + thirdLoanNum);
                if (thirdLoanNum < hjEffectiveThird) {
                    by = false;
                } else {
                    log.info("黄金条件四满足");
                    teamInfo.setGoldLoanThird(true);
                    teamInfoDao.save(teamInfo);
                }
            }
            //满足升级条件,升级黄金
            if (by) {
                teamInfo.setGrade(TeamGradeEnum.HJ.getCode());
                if(teamInfo.getIsDowngrade()){
                    if("3".equals(teamInfo.getGradeSort())){
                        teamInfo.setIsDowngrade(false);
                    }
                }else{
                    teamInfo.setGradeSort("3");
                }
                teamInfoDao.save(teamInfo);

                teamGradeHistory.setTeamNo(teamInfo.getTeamNo());
                teamGradeHistory.setGrade(teamInfo.getGrade());
                teamGradeHistory.setOperationType("U");  //升级
                teamGradeHistoryDao.save(teamGradeHistory);

                List<String>  listAgentNo = teamMemberInfoDao.findByTeamNoAndStatusNotquery(teamInfo.getTeamNo());
                if(null != listAgentNo && listAgentNo.size() >0){
                    String title ="团队等级升级";
                    String detail="恭喜您所在的团队("+teamInfo.getTeamName()+")等级升为黄金。";
                    //推送消息
                    pushNotificationLeader(listAgentNo, title, detail);
                }
            }
        }
    }


    //黄金升级
    public void hjGradeTeamUp(TeamInfo teamInfo) {
        boolean hj = true;
        //①成员数达到15个人及以上  ②团队第三方产品成功放款3笔及以上  ③团队总放款笔数10笔及以上  ④团队当月活跃用户人数10人及以上 ⑤团队积分达3000分
        log.info("GradeTeamUpThread_hjGradeTeamUp" + teamInfo);
        if (null != teamInfo) {
            TeamGradeHistory teamGradeHistory = new TeamGradeHistory();
            if (StringUtils.isEmpty(teamInfo.getCityCode())) {
                AppUserInfo appUserInfo = appUserDao.findByMongoId(teamInfo.getAgentNo());
                teamInfo.setCityCode(appUserInfo.getBusinessCityid());
            }
            //判断是否降过级  任务1不做判断
            if (!teamInfo.getIsDowngrade()) {
                if (!teamInfo.getDiamondMember()) {
                    //①成员数达到15个人及以上
                    int countNum = teamMemberInfoDao.countByTeamNoAndTeamRoleNotAndStatusNot(teamInfo.getTeamNo(), TeamStatusEnumDto.ROLE_OF_LEADER.toString(), TeamStatusEnumDto.DELETE.toString());
                    log.info("团队成员数：" + countNum);
                    if (countNum < zsTeamMember) {
                        hj = false;
                        return;
                    } else {
                        log.info("钻石条件一满足");
                        teamInfo.setDiamondMember(true);
                        teamInfoDao.save(teamInfo);
                    }
                }
            }

            if (!teamInfo.getDiamondLoanThird()) {
                //②团队第三方产品成功放款3笔及以上
                int thirdLoanNum = teamMemberMgrDao.countSuccessThirdLoan(teamInfo.getTeamNo(), getArray());
                log.info("团队成功放款三方产品笔数：" + thirdLoanNum);
                if (thirdLoanNum < zsTeamThirdLoan) {
                    hj = false;
                    return;
                } else {
                    log.info("钻石条件二满足");
                    teamInfo.setDiamondLoanThird(true);
                    teamInfoDao.save(teamInfo);
                }
            }

            if (!teamInfo.getDiamondLoan()) {
                //③团队总放款笔数10笔及以上
                int loanNum = teamMemberMgrDao.countSuccessLoanQuarter(teamInfo.getTeamNo());
                log.info("团队成功放款笔数：" + loanNum);
                if (loanNum < zsTeamLoan) {
                    hj = false;
                    return;
                } else {
                    log.info("钻石条件三满足");
                    teamInfo.setDiamondLoan(true);
                    teamInfoDao.save(teamInfo);
                }
            }

            if (!teamInfo.getDiamondActiveMember()) {
                //④团队当月活跃用户人数10人及以上
                List<String> stringList = teamMemberMgrDao.getApplyCountByTeamActive(teamInfo.getTeamNo());
                int teamActive =0;
                if(null != stringList){
                     teamActive = stringList.size();
                }

                log.info("团队活跃人数：" + teamActive);
                if (teamActive < zsTeamActiveMember) {
                    hj = false;
                    return;
                } else {
                    log.info("钻石条件四满足");
                    teamInfo.setDiamondActiveMember(true);
                    teamInfoDao.save(teamInfo);
                }
            }

            if (!teamInfo.getDiamondIntegral()) {
                //⑤团队积分达3000分
                Integer strInteger = teamIntegralDao.getTeamIntegralSumIndex(teamInfo.getTeamNo());
                if(null == strInteger){
                    strInteger = 0;
                }
                log.info("团队积分：" + strInteger);
                if (strInteger < zsTeamIntegral) {
                    hj = false;
                    return;
                } else {
                    log.info("钻石条件五满足");
                    teamInfo.setDiamondIntegral(true);
                    teamInfoDao.save(teamInfo);
                }

            }

            //满足升级条件,升级黄金
            if (hj) {
                teamInfo.setGrade(TeamGradeEnum.ZS.getCode());
                teamInfo.setIsDowngrade(false);
                teamInfo.setGradeSort("4");
                teamInfoDao.save(teamInfo);

                teamGradeHistory.setTeamNo(teamInfo.getTeamNo());
                teamGradeHistory.setGrade(teamInfo.getGrade());
                teamGradeHistory.setOperationType("U");  //升级
                teamGradeHistoryDao.save(teamGradeHistory);

                List<String>  listAgentNo = teamMemberInfoDao.findByTeamNoAndStatusNotquery(teamInfo.getTeamNo());
                if(null != listAgentNo && listAgentNo.size() >0){
                    String title ="团队等级升级";
                    String detail="恭喜您所在的团队("+teamInfo.getTeamName()+")等级升为钻石。";
                    //推送消息
                    pushNotificationLeader(listAgentNo, title, detail);
                }
            }
        }
    }

    /**
     * 查询104大数产品
     *
     * @return
     */
    public String[] getArray() {
        //有效推荐一笔及以上第	三方产品
        //查询大数产品
        ResponseInfo<?> responseInfo = pdtDefSao.findByCooperationId("104");
        StringBuffer sb = new StringBuffer();
        if (responseInfo.isSuccess()) {
            List<ProductInfo> productInfoList = (List<ProductInfo>) responseInfo.getData();
            if (null != productInfoList && productInfoList.size() > 0) {
                for (ProductInfo p : productInfoList) {
                    sb.append(p.getProductNo()).append(",");
                }
            }
        }
        return sb.toString().split(",");
    }

    /**
     * 推送消息公共方法
     *
     * @param userIdList 用户mongoId
     * @param title      推送标题
     * @param detail     推送内容
     */
    public void pushNotificationLeader(List<String> userIdList, String title, String detail) {
        MessagePushRequestDTO messagePushRequestDTO = null;
        String sendTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        try {
            if(null != userIdList && userIdList.size() > 0){
                for (String userId : userIdList) {
                    messagePushRequestDTO = new MessagePushRequestDTO();
                    messagePushRequestDTO.setApplySerialNO("");
                    messagePushRequestDTO.setTitle(title);
                    messagePushRequestDTO.setDetail(detail);
                    messagePushRequestDTO.setType("050");
                    messagePushRequestDTO.setUserId(userId);
                    messagePushRequestDTO.setSendTime(sendTime);
                    adtJpushSao.messagePushNew(messagePushRequestDTO);
                }
            }
        } catch (Exception e) {
            log.info("TeamService@pushNotificationLeader 发送推送消息失败 userIdList:{}, title:{}, detail:{}", userIdList, title, detail);
        }
    }
}

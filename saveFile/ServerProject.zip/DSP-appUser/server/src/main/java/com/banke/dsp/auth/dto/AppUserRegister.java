package com.banke.dsp.auth.dto;

import lombok.Data;

/**
 *  app 注册/忘记密码参数对象
 * Created by ex-zhongbingguo on 2017/10/31.
 */
@Data
public class AppUserRegister {

    //版本号
    private String cv;

    //电话号码
    private String cellphone;

    //密码
    private String password;

    //验证码id
    private String requestId;

    //验证码
    private String passcode;

    //注册邀请码
    private String registerCode;

    //业务城市code
    private String businessCityCode;

    //推荐人手机号
    private String refMobilePhone;

    //app版本
    private String osVersion;

    ////操作系统版本
    private String appVersion;

    //注册设备
    private String registerDevice;

    // 来源
    private String source;

    private String deviceId;

    private String username;

    //注册城市code
    private String registerCityid;

}

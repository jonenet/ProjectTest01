package com.banke.dsp.auth.dto;

import com.banke.bkc.framework.util.CodeEnum;
import lombok.Data;

import java.util.List;

/**
 *  组织机构表/业务城市 model
 * Created by ex-zhongbingguo on 2017/9/18.
 */
@Data
public class BranchInfoDTO {

    private String branchNo;

    private String name;

    private Integer sort;

    public String branchStatus;

    List<BranchInfoDTO> parentData;

    private BranchType branchType;

    public enum BranchType {
        /**
         * 总部
         */
        ROOT("00"),
        /**
         * 归属城市
         */
        CITY("05"),
        /**
         * 分公司
         */
        BRANCH_COMPANY("10"),
        /**
         * 面签中心
         */
        SIGNING_CENTER("20"),
        /**
         * 部门
         */
        DEPARTMENT("30"),
        /**
         * 业务室
         */
        OFFICE("40"),
        /**
         * 团队
         */
        TEAM("50");

        BranchType(String val) {
            CodeEnum.init(this, val);
        }
    }

    //部门归属
    private String ascription;
}

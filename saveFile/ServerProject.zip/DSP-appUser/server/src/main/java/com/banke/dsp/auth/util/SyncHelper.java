package com.banke.dsp.auth.util;

import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.service.AppUserSyncService;

public class SyncHelper {
    private static AppUserSyncService syncService;

    public static void setSyncService(AppUserSyncService service) {
        syncService = service;
    }

    public static void sync(AppUserInfo target, String operation) {
        syncService.sendMessage(target, operation);
    }
}

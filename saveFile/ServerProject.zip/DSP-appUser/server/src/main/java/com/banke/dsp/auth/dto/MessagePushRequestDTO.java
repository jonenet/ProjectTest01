package com.banke.dsp.auth.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * Created by ex-taozhangyi on 2017/10/30.
 */
@Data
public class MessagePushRequestDTO {
    @JsonProperty("USERID")
    private String userId;

    @JsonProperty("APPLYSERIALNO")
    private String applySerialNO;

    @JsonProperty("TYPE")
    private String type;

    @JsonProperty("TITLE")
    private String title;

    @JsonProperty("DETAIL")
    private String detail;

    @JsonProperty("SENDTIME")
    private String sendTime;
}

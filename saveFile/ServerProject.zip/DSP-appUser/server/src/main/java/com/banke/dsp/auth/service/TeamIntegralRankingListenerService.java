package com.banke.dsp.auth.service;

/**
 * Created by ex-taozhangyi on 2018/2/28.
 */

import com.alibaba.fastjson.JSONObject;
import com.banke.bkc.message.annotation.MessageListener;
import com.banke.bkc.message.annotation.QueueConfig;
import com.banke.bkc.message.handler.MessageSender;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.net.InetAddress;
import java.time.LocalDateTime;

/**
 * 团队积分排序定时
 */

@Slf4j
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class TeamIntegralRankingListenerService {

    @NonNull
    private TeamIntegralService teamIntegralService;

    @QueueConfig(queue = "wrk.task")
    private MessageSender<JSONObject> messageSender;

    @MessageListener(queue = "dsp.appUser.teamIntegralRanking.task.wrk")
    public void executeTeamIntegralRankingJob(String group, String type, JSONObject data){
        log.info("TeamIntegralRankingListenerService@executeTeamIntegralRankingJob 定时任务开始执行, group:{}, type:{}, data:{}",group, type, data);
        String executeMachine=null;
        String exceptionFlag=null;
        try {
            executeMachine = InetAddress.getLocalHost().getHostName();//获得主机名
            if("teamIntegralRankingJob".equals(type)){
                //团队积分排名
                log.info("TeamDowngradeListenerService@executeTeamDowngradeJob  团队积分排名开始");
                teamIntegralService.executeTeamIntegralRankingJob();
                log.info("TeamDowngradeListenerService@executeTeamDowngradeJob 团队积分排名结束");

                exceptionFlag = "团队积分排名任务成功" + LocalDateTime.now();
            }
        } catch (Exception e) {
            log.info(e.toString());
        }
        data.put("ExceptionFlag", exceptionFlag);
        data.put("ExecuteMachine", executeMachine);
        messageSender.send("response", "JobResponse", data);
    }

    public MessageSender<JSONObject> getMessageSender() {
        return messageSender;
    }

    public void setMessageSender(MessageSender<JSONObject> messageSender) {
        this.messageSender = messageSender;
    }
}

package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.po.AppuserAscriptionLog;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by ex-zhongbingguo on 2018/1/9.
 */
public interface AppuserAscriptionLogDao extends CrudRepository<AppuserAscriptionLog, Long> {

}

package com.banke.dsp.auth.sao;

import com.banke.dsp.auth.dto.Response;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "disp",url="${disp.url}")
public interface QueryDispSao {

	/**
	 * 升级高级用户
	 * @param agentNo
	 * @return
	 */
	@RequestMapping("/userUpgrade")
	public Response userUpgrade(@RequestParam(value = "agentNo") String agentNo);
	
}

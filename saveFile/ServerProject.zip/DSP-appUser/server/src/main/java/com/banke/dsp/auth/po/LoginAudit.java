package com.banke.dsp.auth.po;


import com.banke.bkc.framework.po.BasePO;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.redis.core.index.Indexed;

import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "login_audit")
public class LoginAudit extends BasePO{

    @Indexed
    private String username;

    private String osVersion;

    private String appVersion;

    private String device;

    private String ipAddress;

    private String deviceId;

    private boolean authenticated;

}

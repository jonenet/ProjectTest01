package com.banke.dsp.auth.util.com.qcloud.Module;

public class Wenzhi extends Base {
	public Wenzhi(){
		serverHost = "wenzhi.api.qcloud.com";
	}
}

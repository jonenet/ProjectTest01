package com.banke.dsp.auth.service;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dao.AppUserDao;
import com.banke.dsp.auth.dao.SwitchDao;
import com.banke.dsp.auth.dao.UserSwitchDao;
import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.po.SwitchInfo;
import com.banke.dsp.auth.po.UserSwitchInfo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class UserSwitchService {

    @Autowired
    private UserSwitchDao userSwitchDao;

    @Autowired
    private SwitchDao switchDao;

    @Autowired
    private AppUserDao appUserDao;

    /**
     * 设置用户开关
     * @param agentNo
     * @param name
     * @return
     */
    public ResponseInfo<?> setUserSwitch(String agentNo, String name, String value) {
        log.info("UserSwitchService@setUserSwitch  param agentNo={}, name={}, value={}",agentNo, name, value);

        AppUserInfo userInfo = appUserDao.findByMongoId(agentNo);
        if(userInfo == null){
            return ResponseInfo.error("不存在此用户");
        }

        UserSwitchInfo userSwitchInfo = userSwitchDao.findByAgentNoAndName(agentNo, name);
        if(userSwitchInfo == null){
            userSwitchInfo = new UserSwitchInfo();
            SwitchInfo switchInfo = switchDao.findByName(name);
            log.info("UserSwitchService@setUserSwitch find switchInfo name={} switchInfo={}",name,switchInfo);
            if(switchInfo == null){
                return ResponseInfo.error("插入失败,找不到对应的开关");
            }
            userSwitchInfo.setAgentNo(agentNo);
            userSwitchInfo.setName(name);
            userSwitchInfo.setValue(switchInfo.getValue());
            userSwitchInfo.setType(switchInfo.getType());
        }else{
            userSwitchInfo.setValue(value);
        }

        userSwitchDao.save(userSwitchInfo);

        return ResponseInfo.success("插入成功");
    }

    /**
     * 根据agentNo查询该用户开关
     * @param agentNo
     */
    public Map<String, Object> findUserSwitch(String agentNo) {

        List<UserSwitchInfo> userSwitchInfos = userSwitchDao.findAllByAgentNo(agentNo);
        log.info("UserSwitchService@findUserSwitch find userSwitchInfos agentNo={}, userSwitchInfos={}",agentNo, userSwitchInfos.toString());
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("commission","N"); //强制设为否
        if(userSwitchInfos != null && userSwitchInfos.size() > 0){
            for (UserSwitchInfo userSwitchInfo : userSwitchInfos) {
                map.put(userSwitchInfo.getName(), userSwitchInfo.getValue());
            }
        }
        map.put("commission","Y"); //强制设为是

        AppUserInfo appUserInfo = appUserDao.findByMongoId(agentNo);
        //智能评估城市开放
        map.put("assessment","N"); //强制设为否
        if(appUserInfo.getBusinessCityid()!=null){
            List<UserSwitchInfo> userSwitchInfosList = userSwitchDao.findAllByAgentNo(appUserInfo.getBusinessCityid());
            if(userSwitchInfosList != null && userSwitchInfosList.size() > 0){
                for (UserSwitchInfo userSwitchInfo : userSwitchInfosList) {
                    map.put(userSwitchInfo.getName(), userSwitchInfo.getValue());
                }
            }
        }
        return map;
    }


    public boolean findUserSwitchByAgentNoAndName(String agentNo, String name) {
        boolean flag = false;
        UserSwitchInfo userSwitchInfo = userSwitchDao.findUserSwitchByAgentNoAndName(agentNo, name);
        if(userSwitchInfo != null && userSwitchInfo.getValue().equals("Y")){
            flag = true;
        }
        return flag;
    }
}

package com.banke.dsp.auth.sao;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dto.ForgetPasswordRequestDTO;
import com.banke.dsp.auth.dto.RegisterRequestDTO;
import com.banke.dsp.auth.dto.SmsOtpDTO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Created by luoyifei on 2017/5/23.
 */
@FeignClient(value = "MSG-sms")
public interface SendSMSRequestRepositorySao {

    @RequestMapping("/api/register/sendRegisterPasscode")
    public ResponseInfo<?> sendRegisterPasscode(@RequestParam("telphone") String telphone, @RequestParam("requestId") String requestId);

    @RequestMapping("/api/register/findRegisterRequestByRequestId")
    public ResponseInfo<RegisterRequestDTO> findRegisterRequestByRequestId(@RequestParam("requestId") String requestId);

    @RequestMapping("/api/password/sendForgetPasswordPasscode")
    public ResponseInfo<?> sendForgetPasswordPasscode(@RequestParam("telphone") String telphone, @RequestParam("requestId") String requestId);

    @RequestMapping("/api/password/findForgetPasswordRequestByRequestId")
    public ResponseInfo<ForgetPasswordRequestDTO> findForgetPasswordRequestByRequestId(@RequestParam("requestId") String requestId);

    @RequestMapping("/api/smsVerify/checkVerifyCode")
    public ResponseInfo<?> checkVerifyCode(@RequestParam("phone") String phone,
                                           @RequestParam("otpCode") String otpCode,
                                           @RequestParam("templetNo") String templetNo,
                                           @RequestParam("effectiveTime") String effectiveTime);

    @RequestMapping("api/sendSmsForPGS")
    public ResponseInfo<Object> sendSmsForPGS(@RequestBody SmsOtpDTO smsOtpDTO);

}

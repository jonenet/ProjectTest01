package com.banke.dsp.auth.sao;

import com.banke.bkc.framework.util.ResponseInfo;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Created by ex-zhongbingguo on 2018/2/6.
 */
@FeignClient(value = "DSP-apply")
public interface RecommendInfoSao {
    @RequestMapping("/api/recommends/getUserCity")
    public ResponseInfo<String> getUserCity(@RequestParam("agentNo")String agentNo);
}

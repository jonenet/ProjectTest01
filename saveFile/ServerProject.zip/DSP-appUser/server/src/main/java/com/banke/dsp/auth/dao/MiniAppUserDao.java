package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.po.MiniAppUserInfo;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

/**
 * Created by luoyifei on 2017/5/24.
 */
public interface MiniAppUserDao extends CrudRepository<MiniAppUserInfo, Long>, PagingAndSortingRepository<MiniAppUserInfo, Long> {

    //通过token查询用户信息
    MiniAppUserInfo findByToken(String token);

    // 根据userId查询用户信息
    MiniAppUserInfo findByUserId(Long userId);

    // 根据openid查询用户信息
    MiniAppUserInfo findByOpenid(String openid);

    List<MiniAppUserInfo> findAll();

	MiniAppUserInfo findByPublicopenid(String openid);

	MiniAppUserInfo findByUnionId(String unionid);

}

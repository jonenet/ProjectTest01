package com.banke.dsp.auth.service;

import com.banke.dsp.auth.dao.AppuserAscriptionLogDao;
import com.banke.dsp.auth.po.AppuserAscriptionLog;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by ex-zhongbingguo on 2018/1/9.
 */
@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AppuserAscriptionLogService {

    @Autowired
    private AppuserAscriptionLogDao appuserAscriptionLogDao;

    /**
     *  新增用户归属日志
     * @param agentNo          mongid
     * @param newAscription   新的归属
     * @param oldAscription   旧的归属
     * @param remark           备注
     */
    public void add(String agentNo, String newAscription, String oldAscription, String remark){
        // 如果新的归属和就得归属一致则不保存
        log.info("AppuserAscriptionLogService@add，参数agentNo:{},newAscription:{},oldAscription:{},remark:{}",
                agentNo, newAscription, oldAscription, remark);
        if (StringUtils.isNotEmpty(newAscription) && !newAscription.equals(oldAscription)){
            AppuserAscriptionLog aalog = new AppuserAscriptionLog();
            aalog.setAgentNo(agentNo);
            aalog.setNewAscription(newAscription);
            aalog.setOldAscription(oldAscription);
            aalog.setRemark(remark);
            appuserAscriptionLogDao.save(aalog);
        }
    }
}

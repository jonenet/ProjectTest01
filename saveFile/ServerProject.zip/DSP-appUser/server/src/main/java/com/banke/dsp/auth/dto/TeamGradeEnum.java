package com.banke.dsp.auth.dto;

import org.apache.commons.lang3.StringUtils;

/**
 * Created by ex-zhongbingguo on 2017/12/12.
 */
public enum TeamGradeEnum {

    QT("QT", "青铜"),
    BY("BY", "白银"),
    HJ("HJ", "黄金"),
    ZS("ZS", "钻石");

    private String code;

    private String desc;

    TeamGradeEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static String getDesc(String code){
        if (StringUtils.isNotEmpty(code)){
            for (TeamGradeEnum tgd : TeamGradeEnum.values()){
                if (code.equals(tgd.code)){
                    return tgd.desc;
                }
            }
        }
        return null;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
    
}

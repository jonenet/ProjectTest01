package com.banke.dsp.auth.service;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.sao.WrkStaffSao;
import com.google.common.collect.Lists;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 *  用户关联角色 Service
 * Created by ex-zhongbingguo on 2017/8/24.
 */
@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class UserRoleInfoService {

    @Autowired
    private WrkStaffSao wrkStaffSao;

    /**
     * 根据userId查询角色列表
     * @param userId         用户id
     * @return List<String>  角色列表
     */
    List<String> getValidRolesByUserId(String userId){
        ResponseInfo<List<String>> response = wrkStaffSao.getValidRolesByUserId(userId.toLowerCase());
        log.info("根据userId查询角色列表: {}", response);
        List<String> data = Lists.newArrayList();
        if (response.isSuccess()){
            data = response.getData();
        }
        return data;
    }
}

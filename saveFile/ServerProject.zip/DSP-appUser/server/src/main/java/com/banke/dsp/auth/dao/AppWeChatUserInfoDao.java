package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.po.AppWeChatUserInfo;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by ex-zengfanxi on 2018/02/27.
 */
public interface AppWeChatUserInfoDao extends CrudRepository<AppWeChatUserInfo, Long> {

	AppWeChatUserInfo findByOpenid(String openid);
}

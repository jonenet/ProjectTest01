package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.po.WalletInfo;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by ex-panhuayu on 2017/6/26.
 */
public interface AppWalletDao extends CrudRepository<WalletInfo, Long> {

    //通过mongoId查询平安付关联关系,仅查有效状态
    WalletInfo findByMidAndIsVaildIsTrue(String mongoId);


    WalletInfo findByMid(String mongoId);

}

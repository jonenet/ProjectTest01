package com.banke.dsp.auth.service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.bkc.framework.util.ThreadStore;
import com.banke.bkc.framework.util.UUIDUtil;
import com.banke.bkc.service.util.ContextHolder;
import com.banke.dsp.auth.dao.AppFansInfoDao;
import com.banke.dsp.auth.dao.AppUserDao;
import com.banke.dsp.auth.dao.MiniAppUserDao;
import com.banke.dsp.auth.dto.*;
import com.banke.dsp.auth.po.AppFansInfo;
import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.po.MiniAppUserInfo;
import com.banke.dsp.auth.sao.MicroproRequestRepositorySao;
import com.banke.dsp.auth.security.Base64;
import com.banke.dsp.auth.security.Encrypt;
import com.banke.dsp.auth.util.WxDecryptUtil;
import com.google.common.collect.Maps;
import com.sun.org.apache.bcel.internal.generic.IF_ACMPEQ;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.util.Base64Utils;
import org.springframework.web.bind.annotation.RequestParam;

import javax.transaction.Transactional;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AppUserService {

    @Value("${user.creditway}")
    private String userCreditway;
    @NonNull
    private final AppUserDao appUserDao;

    @NonNull
    private final MiniAppUserDao miniAppUserDao;

    @NonNull
    private final AppFansInfoDao appFansInfoDao;
    @NonNull
    private final MicroproRequestRepositorySao microproRequestRepositorySao;


    AppUserInfo findByToken(String token) {
        return appUserDao.findByToken(token);
    }


    /**
     * token查询用户信息
     *
     * @param token
     * @return
     */
    public ResponseInfo<?> findTokenByAppUserInfo(String token) {
        /*
         * appUserDao.findByToken 加上时间判断 tokenDate
		 */
        AppUserInfo appUser = findByToken(token);
        if (appUser != null && !"".equals(appUser.getId())) {
            return ResponseInfo.success(appUser);
        }
        return ResponseInfo.error(null);
    }

    /**
     * token查询用户信息
     *
     * @param mongoId
     * @return
     */
    public ResponseInfo<?> findByMongoId(String mongoId) {
        /*
         * appUserDao.findByToken 加上时间判断 tokenDate
		 */
        AppUserInfo appUser = appUserDao.findByMongoId(mongoId);
        if (appUser != null && !"".equals(appUser.getId())) {
            return ResponseInfo.success(appUser);
        } else {
            if (mongoId != null && mongoId.matches("[0-9]+")) {
                appUser = appUserDao.findById(Long.parseLong(mongoId));
                if (appUser != null && !"".equals(appUser.getId())) {
                    return ResponseInfo.success(appUser);
                }
            }
        }
        return ResponseInfo.error(null);
    }

    public AppUserInfo findByAgentNo(String mongoId) {
        return appUserDao.findByMongoId(mongoId);
    }

    /**
     * 用户验证
     * 登录验证用户密码是否正确，并验证token
     * token存在返回token,不存在则新建一个有效token
     * * @throws UnsupportedEncodingException
     *
     * @throws NoSuchAlgorithmException
     */
    public ResponseInfo<?> appUserAuth(String userName, String passWord)
            throws NoSuchAlgorithmException, UnsupportedEncodingException {
        Map<String, Object> data = Maps.newHashMap();
        AppUserInfo appUser = appUserDao.findByCellphone(userName);
        String token = "";
        if (appUser == null) {
            //登录失败
            data.put("MSG", "账户不存在，请重新登录！");
            data.put("token", token);
            return ResponseInfo.error(data);
        }
        /**
         * 加密算法
         */
        boolean validPass = validPassword(passWord, appUser.getPasswordSalt(), appUser.getPassword());
        if (validPass) {
            //登录成功
            //如果token失效或为生成则生成
            token = UUIDUtil.getUid("P@");
            appUser.setToken(token);
            appUser.setTokenDate(LocalDateTime.now());
            appUserDao.save(appUser);

            data.put("token", token);
            data.put("MSG", "登录成功！");
            return ResponseInfo.success(data);
        } else {
            //登录失败
            data.put("MSG", "账户或密码错误，请重新登录！");
            data.put("token", token);
            return ResponseInfo.error(data);
        }
    }

    /**
     * 同步用户信息
     * 通过disp消息同步用户信息
     * * @param appUser
     */
    public ResponseInfo<?> saveAppuser(AppUser appUser) {
        String mongoId = appUser.getId();
        AppUserInfo appuserInfo = appUserDao.findByMongoId(mongoId);
        if (appuserInfo == null || appuserInfo.getId() == null) {
            appuserInfo = new AppUserInfo();
            appuserInfo.setCreatedDate(LocalDateTime.now());
            appuserInfo.setUpdatedDate(LocalDateTime.now());
        }
        //mongoId
        appuserInfo.setMongoId(mongoId);
        //app角色
        List<AppRole> ar = appUser.getAppRoles();
        Set<AppRole> arset = new HashSet<AppRole>();
        if (ar != null) {
            for (AppRole appRole : ar) {
                arset.add(appRole);
            }
        }
        if (ar != null && arset != null) {
            appuserInfo.setAppRoles(arset.toString());
        }
        //app版本
        appuserInfo.setAppVersion(appUser.getAppVersion());
        //Archived
        appuserInfo.setArchived(appUser.isArchived());
        //银行编码
        Bank bank = appUser.getBank();
        if (bank != null) {
            appuserInfo.setBankId(bank.getId());
        }
        //银行账户名
        appuserInfo.setBankAccountName(appUser.getBankAccountName());
        //银行机构
        Bank bankBranch = appUser.getBankBranch();
        if (bankBranch != null) {
            appuserInfo.setBankBranchId(bankBranch.getId());
        }
        //银行卡号
        appuserInfo.setBankCardNumber(appUser.getBankCardNumber());
        //业务城市
        BusinessCity businessCity = appUser.getBusinessCity();
        if (businessCity != null) {
            appuserInfo.setBusinessCityid(businessCity.getId());
        }
        //手机号码
        appuserInfo.setCellphone(appUser.getCellphone());
        //注册日期
        Date createdAtDate = appUser.getCreatedAt();
        appuserInfo.setCreatedAt(dateToLocalDateTime(createdAtDate));
        //用户进件权限
        appuserInfo.setEnableEecommendation(appUser.getEnableRecommendation());
        //是否有效
        appuserInfo.setEnabled(appUser.isEnabled());
        //是否过期
        appuserInfo.setExpired(appUser.isExpired());
        //身份证号
        appuserInfo.setIdentityNumber(appUser.getIdentityNumber());
        //job
        appuserInfo.setJob(appUser.getJob());
        //locked
        appuserInfo.setLocked(appUser.isLocked());
        //操作时间
        Date modifiedAtDate = appUser.getModifiedAt();
        appuserInfo.setModifiedAt(dateToLocalDateTime(modifiedAtDate));
        //操作系统版本
        appuserInfo.setOsVersion(appUser.getOsVersion());
        //密文密码
        appuserInfo.setPassword(appUser.getPassword());
        //加码方式
        appuserInfo.setPasswordEncoder(appUser.getPasswordEncoder());
        //盐
        appuserInfo.setPasswordSalt(appUser.getPasswordSalt());
        //推荐人用户名
        appuserInfo.setRefererName(appUser.getRefererName());
        //referrer
        appuserInfo.setReferrer(appUser.getReferrer());
        //注册设备
        appuserInfo.setRegisterDevice(appUser.getRegisterDevice());
        //注册id
        appuserInfo.setRegisterId(appUser.getRegisterId());
        //用户星级
        appuserInfo.setStar(appUser.getStar());
        //用户名
        appuserInfo.setUserName(appUser.getUsername());
        //公司名称
        appuserInfo.setCompanyName(appUser.getCompanyName());
        //是否集团用户
        appuserInfo.setGroupFlag(appUser.getGroupFlag());
        //所属集团
        appuserInfo.setGroupName(appUser.getGroupName());
        //推广方式
        PopularizeType pt = appUser.getPopularizeType();
        if (pt != null) {
            appuserInfo.setPopularizeTypeId(pt.getDescription());
        }
        //真实名称
        appuserInfo.setRealName(appUser.getRealName());
        //地址
        appuserInfo.setAddress(appUser.getAddress());
        //邮箱
        appuserInfo.setEmail(appUser.getEmail());
        //推荐人手机号
        appuserInfo.setRefMobilePhone(appUser.getRefMobilePhone());
        //微信用户名
        appuserInfo.setWechatUsername(appUser.getWechatUsername());
        //achived
        appuserInfo.setAchived(appUser.getAchived());
        //渠道Id
        Channel channel = appUser.getChannel();
        if (channel != null) {
            appuserInfo.setChannelId(channel.getId());
        }
        //是否是授信标志
        appuserInfo.setIscredit(appUser.getIscredit());

        //是否推荐更多产品
        appuserInfo.setCommendMore(appUser.getCommendMore());

        //征信获取方式
        appuserInfo.setCreditWay(appUser.getCreditWay());

        //是否需要征信
        appuserInfo.setIsNeedCredit(appUser.isNeedCredit());

        //cv
        appuserInfo.setCv(appUser.getCv());

        //注册来源
        appuserInfo.setSource(appUser.getSource());

        appUserDao.save(appuserInfo);
        return ResponseInfo.success(null);
    }

    /**
     * 通过手机号查询客户信息
     *
     * @param cellPhone
     * @return
     */
    public AppUserInfo findByCellphone(String cellPhone) {
        return appUserDao.findByCellphone(cellPhone);
    }

    /**
     * 小程序根据token查询用户信息
     *
     * @param token
     * @return
     */
    public ResponseInfo<?> findMiniAppUserInfoByToken(String token) throws Exception {
        MiniAppUserInfo miniAppUser = miniAppUserDao.findByToken(token);
        return ResponseInfo.success(miniAppUser);
    }

    /**
     * 小程序根据openid查询用户信息
     *
     * @param openid
     * @return
     */
    public ResponseInfo<?> findByOpenid(String openid) throws Exception {
        MiniAppUserInfo miniAppUserInfo = miniAppUserDao.findByOpenid(openid);
        System.out.println("根据openid查询小程序用户信息: " + miniAppUserInfo);
        return ResponseInfo.success(miniAppUserInfo);
    }

    /**
     * 根据userId获取小程序用户信息
     *
     * @param userId
     * @return
     * @throws Exception
     */
    public ResponseInfo<?> findByUserId(Long userId) throws Exception {
        MiniAppUserInfo miniAppUserInfo = miniAppUserDao.findByUserId(userId);
        return ResponseInfo.success(miniAppUserInfo);
    }

    /**
     * 根据userId查询用户信息
     *
     * @param userId
     * @return
     * @throws Exception
     */
    public ResponseInfo<?> findAppUserInfoByUserId(Long userId) throws Exception {
        log.info("contextHolder::::{}", ContextHolder.getAgentNo());
        log.info("contextHolder::ALL::{}", ContextHolder.getAll());
        AppUserInfo appUserInfo = appUserDao.findById(userId);
        return ResponseInfo.success(appUserInfo);
    }

    /**
     * 完善用户资料
     *
     * @param identityNumber 身份证号
     * @param realName       姓名
     * @return
     */
    public ResponseInfo<?> perfectData(@RequestParam("identityNumber") String identityNumber, @RequestParam("realName") String realName) {
        String userId = ContextHolder.getAgentNo();
        log.info("contextholder中的userId: {}", userId);
        Long id = Long.parseLong(userId);
        log.info("用户id为： {}", id);
        AppUserInfo oldAppUser = appUserDao.findById(id);
        if (oldAppUser != null) {
            oldAppUser.setIdentityNumber(identityNumber);
            oldAppUser.setRealName(realName);
            appUserDao.save(oldAppUser);
        } else {
            // 根据userId查询不到用户信息
            return ResponseInfo.error(null);
        }

        return ResponseInfo.success(oldAppUser);

    }

    /**
     * 小程序登录验证
     *
     * @param userName
     * @param passWord
     * @param source
     * @param openid
     * @param avatarUrl
     * @param city
     * @param gender
     * @param nickName
     * @param province
     * @param latitude
     * @param longitude
     * @return
     * @throws Exception
     */
    public ResponseInfo<?> miniAppUserAuth(@RequestParam String userName, @RequestParam String passWord, @RequestParam String source, @RequestParam String openid, @RequestParam String avatarUrl, @RequestParam String city, @RequestParam String gender, @RequestParam String nickName, @RequestParam String province, @RequestParam String latitude, @RequestParam String longitude, @RequestParam String encryptedData, @RequestParam("session_key") String session_key, @RequestParam("iv") String iv) throws Exception {
        Map<String, Object> data = Maps.newHashMap();
        AppUserInfo appUser = appUserDao.findByCellphone(userName);
        String token = "";
        if (appUser == null) {
            //登录失败
            data.put("code", "0001");
            data.put("MSG", "手机号码不存在，请重新登录！");
            data.put("token", token);
            return ResponseInfo.success(data);
        }
        MiniAppUserInfo oldMiniAppUserInfo = miniAppUserDao.findByOpenid(openid);
        if (oldMiniAppUserInfo != null) {
            data.put("code", "0000");
            data.put("MSG", "您已登录， 请勿重新登录");
            data.put("token", oldMiniAppUserInfo.getToken());
            return ResponseInfo.success(data);
        }
        /**
         * 加密算法
         */
        boolean validPass = validBase64Password(passWord, appUser.getPassword());
        if (validPass) {
            //登录成功
            token = UUIDUtil.getUid("P@");
            // 新增小程序逻辑
            if ("".equals(openid) || null == openid) {
                // 获取不到openid
                //登录失败
                data.put("code", "0002");
                data.put("MSG", "获取openid出错，请重试");
                data.put("token", token);
                return ResponseInfo.success(data);
            }
            String json = WxDecryptUtil.wxDecrypt(encryptedData, session_key, iv);
            String unionId = null;
            JSONObject jsonObject = JSONObject.parseObject(json);
            if (jsonObject != null) {
                unionId = jsonObject.getString("unionId");
                oldMiniAppUserInfo = miniAppUserDao.findByUnionId(unionId);
                if (oldMiniAppUserInfo != null) {
                    oldMiniAppUserInfo.setOpenid(openid);
                    oldMiniAppUserInfo.setAvatarUrl(avatarUrl);
                    oldMiniAppUserInfo.setCity(city);
                    oldMiniAppUserInfo.setGender(gender);
                    oldMiniAppUserInfo.setNickName(nickName);
                    oldMiniAppUserInfo.setProvince(province);
                    miniAppUserDao.save(oldMiniAppUserInfo);
                    data.put("code", "0000");
                    data.put("MSG", "您已登录， 请勿重新登录");
                    data.put("token", oldMiniAppUserInfo.getToken());
                    return ResponseInfo.success(data);
                }
            }
            Long userId = appUser.getId();
            // 根据userId查询用户信息
            MiniAppUserInfo oldAppUser = miniAppUserDao.findByUserId(userId);
            if (null == oldAppUser || "".equals(oldAppUser)) {
                MiniAppUserInfo appUserInfoByOpenid = miniAppUserDao.findByOpenid(openid);
                if (appUserInfoByOpenid == null) {
                    // 之前没有存过用户信息
                    MiniAppUserInfo miniAppUser = new MiniAppUserInfo();
                    miniAppUser.setUserId(userId);
                    miniAppUser.setOpenid(openid);
                    miniAppUser.setToken(token);
                    miniAppUser.setTokenDate(LocalDateTime.now());
                    miniAppUser.setAvatarUrl(avatarUrl);
                    miniAppUser.setCity(city);
                    miniAppUser.setGender(gender);
                    miniAppUser.setNickName(nickName);
                    miniAppUser.setProvince(province);
                    miniAppUser.setLatitude(latitude);
                    miniAppUser.setLongitude(longitude);
                    miniAppUser.setUnionId(unionId);
                    miniAppUserDao.save(miniAppUser);
                }
            } else {
                // 如果存过信息则更新
                oldAppUser.setUserId(userId);
                oldAppUser.setOpenid(openid);
                oldAppUser.setProvince(province);
                oldAppUser.setNickName(nickName);
                oldAppUser.setGender(gender);
                oldAppUser.setCity(city);
                oldAppUser.setAvatarUrl(avatarUrl);
                oldAppUser.setToken(token);
                oldAppUser.setTokenDate(LocalDateTime.now());
                oldAppUser.setLatitude(latitude);
                oldAppUser.setLongitude(longitude);
                oldAppUser.setUnionId(unionId);
                oldAppUser.setPublicopenid("");
                miniAppUserDao.save(oldAppUser);
            }
            data.put("code", "0000");
            data.put("token", token);
            data.put("MSG", "登录成功！");

            return ResponseInfo.success(data);
        } else {
            //登录失败
            data.put("code", "0003");
            data.put("MSG", "手机号码或密码错误，请重新登录！");
            data.put("token", token);
            return ResponseInfo.success(data);
        }
    }

    /**
     * 根据header中的token获取用户所有信息
     *
     * @return
     */
    public ResponseInfo<?> getUserInfo() {
        Map<String, Object> returnMap = new HashedMap();
        String userId = ContextHolder.getAgentNo();
        Long id = Long.parseLong(userId);
        AppUserInfo appUserInfo = appUserDao.findById(id);
        MiniAppUserInfo miniAppUserInfo = miniAppUserDao.findByUserId(id);
        returnMap.put("appUserInfo", appUserInfo);
        returnMap.put("miniAppUserInfo", miniAppUserInfo);
        return ResponseInfo.success(returnMap);
    }

    /**
     * 根据app header中的token获取用户信息
     * @return
     */
    public ResponseInfo<?> getAppUserInfo() {
        String userId = ContextHolder.getAgentNo();
        log.info("根据app header中的token获取用户信息 : " + userId);
        AppUserInfo appUserInfo = appUserDao.findByMongoId(userId);
        return ResponseInfo.success(appUserInfo);
    }

    private boolean validSHAPassword(String password, String encPwd) throws Exception {
        if (Encrypt.SHA256(password).equals(encPwd)) {
            return true;
        } else {
            return false;
        }
    }

    private boolean validBase64Password(String password, String encPwd) throws Exception {
        if (password.equals(Base64.getFromBase64(encPwd))) {
            return true;
        } else {
            return false;
        }
    }

    private boolean validPassword(String password, String salt, String encPwd) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        if (StringUtils.isEmpty(salt)) {
            return StringUtils.equals(Base64Utils.encodeToString(password.getBytes()), encPwd);
        }
        return StringUtils.equals(md5(password, salt), encPwd);
    }

    private String md5(String str, String salt) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        return md5(str + "{" + salt + "}");
    }

    private String md5(String str) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        MessageDigest md5 = MessageDigest.getInstance("MD5");
        //加密后的字符串
        String newstr = bytesToHexString(md5.digest(str.getBytes()));
        newstr = newstr.toLowerCase();
        return newstr;
    }

    public static final String bytesToHexString(byte[] bArray) {
        StringBuilder sb = new StringBuilder(bArray.length);
        String sTemp;
        for (int i = 0; i < bArray.length; i++) {
            sTemp = Integer.toHexString(0xFF & bArray[i]);
            if (sTemp.length() < 2)
                sb.append(0);
            sb.append(sTemp.toUpperCase());
        }
        return sb.toString();
    }

    /**
     * date 转 localDateTime*
     *
     * @param date
     * @return
     */
    public LocalDateTime dateToLocalDateTime(Date date) {
        Instant instant = date.toInstant();
        ZoneId zone = ZoneId.systemDefault();
        LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, zone);
        return localDateTime;
    }

    public ResponseInfo<?> getMiniAppUserInfoList(String cellphone, int pageNumber, int pageSize) throws Exception {
        Long count = miniAppUserDao.count();
        Integer totalCount = count.intValue();
        log.info("数据总长度： " + totalCount);
        Integer pageCount = count.intValue() != 0 ? (int) Math.ceil(count.intValue() / (pageSize * 1d)) : 0;
        log.info("总页数： " + pageCount);
        if (StringUtils.isEmpty(cellphone) || cellphone == null || "".equals(cellphone)) {
            // List<MiniAppUserInfo> miniAppUserInfos = miniAppUserDao.findAll();
            PageRequest pageRequest = new PageRequest(pageNumber, pageSize, null);
            Page<MiniAppUserInfo> pageMiniAppUserInfos = miniAppUserDao.findAll(pageRequest);
            List<MiniAppUserInfo> miniAppUserInfosList = pageMiniAppUserInfos.getContent();
            List<AllMiniAppUserInfo> allMiniAppUserInfos = new ArrayList<AllMiniAppUserInfo>();
            for (MiniAppUserInfo miniAppUserInfo : miniAppUserInfosList) {
                Long id = miniAppUserInfo.getUserId();
                AllMiniAppUserInfo allMiniAppUserInfo = new AllMiniAppUserInfo();
                AppUserInfo appUserInfo = appUserDao.findById(id);
                if (miniAppUserInfo != null) {
                    allMiniAppUserInfo.setAvatarUrl(miniAppUserInfo.getAvatarUrl());
                    allMiniAppUserInfo.setCity(miniAppUserInfo.getCity());
                    allMiniAppUserInfo.setProvince(miniAppUserInfo.getProvince());
                    allMiniAppUserInfo.setNickName(miniAppUserInfo.getNickName());
                    allMiniAppUserInfo.setOpenid(miniAppUserInfo.getOpenid());
                    String gender = miniAppUserInfo.getGender();
                    if ("1".equals(gender)) {
                        allMiniAppUserInfo.setGender("男");
                    } else {
                        allMiniAppUserInfo.setGender("女");
                    }

                    if (appUserInfo != null) {
                        allMiniAppUserInfo.setCellphone(appUserInfo.getCellphone());
                        allMiniAppUserInfo.setCreatedAt(appUserInfo.getCreatedAt());
                        allMiniAppUserInfo.setIdentityNumber(appUserInfo.getIdentityNumber());
                        allMiniAppUserInfo.setRealName(appUserInfo.getRealName());
                    }
                    log.info("获取用户总信息: {}", allMiniAppUserInfo);
                    allMiniAppUserInfos.add(allMiniAppUserInfo);
                }

            }
            Map<String, Object> allResult = new HashMap<>();
            allResult.put("list", allMiniAppUserInfos);
            allResult.put("pageCount", pageCount);
            allResult.put("totalCount", totalCount);
            return ResponseInfo.success(allResult);
        } else {
            AllMiniAppUserInfo allMiniAppUserInfo = new AllMiniAppUserInfo();
            AppUserInfo appUserInfo = appUserDao.findByCellphone(cellphone);
            MiniAppUserInfo miniAppUserInfo = miniAppUserDao.findByUserId(appUserInfo.getId());
            if (appUserInfo != null) {
                allMiniAppUserInfo.setCellphone(cellphone);
                allMiniAppUserInfo.setCreatedAt(appUserInfo.getCreatedAt());
                allMiniAppUserInfo.setIdentityNumber(appUserInfo.getIdentityNumber());
                allMiniAppUserInfo.setRealName(appUserInfo.getRealName());
                if (miniAppUserInfo != null) {
                    allMiniAppUserInfo.setAvatarUrl(miniAppUserInfo.getAvatarUrl());
                    allMiniAppUserInfo.setCity(miniAppUserInfo.getCity());
                    allMiniAppUserInfo.setProvince(miniAppUserInfo.getProvince());
                    allMiniAppUserInfo.setNickName(miniAppUserInfo.getNickName());
                    allMiniAppUserInfo.setOpenid(miniAppUserInfo.getOpenid());
                    String gender = miniAppUserInfo.getGender();
                    if ("1".equals(gender)) {
                        allMiniAppUserInfo.setGender("男");
                    } else {
                        allMiniAppUserInfo.setGender("女");
                    }
                }
                log.info("根据手机号码获取用户总信息: {}", allMiniAppUserInfo);
                Map<String, Object> allResult = new HashMap<>();
                allResult.put("list", allMiniAppUserInfo);
                allResult.put("pageCount", pageCount);
                allResult.put("totalCount", totalCount);
                return ResponseInfo.success(allResult);
            } else {
                return ResponseInfo.success(null);
            }
        }

    }

    /**
     * 根据openid和access_token获取用户基本信息， 包括unionID
     *
     * @param openid
     * @return
     * @throws Exception
     */
    public void saveAllUserInfoWithUnionID(String openid) throws Exception {
        // 调用微信接口获取用户基本信息
        JSONObject jsonObject = microproRequestRepositorySao.getAllUserInfoWithUnionID(openid);
        // 保存到用户基本表中
        AppFansInfo appFansInfo = new AppFansInfo();
        AppFansInfo oldAppFansInfo = appFansInfoDao.findByOpenid(openid);
        log.info("根据openid查询原有用户基本信息: {}", oldAppFansInfo);
        if (oldAppFansInfo == null) {
            if (jsonObject != null) {
                // 国家
                String country = jsonObject.getString("country");
                // unionid
                String unionid = jsonObject.getString("unionid");
                // 关注状态
                String subscribe = jsonObject.getString("subscribe");
                // 城市
                String city = jsonObject.getString("city");
                // 性别（1为男， 2为女）
                int sex = jsonObject.getInteger("sex");
                // 分组
                int groupid = jsonObject.getInteger("groupid");
                // 语言
                String language = jsonObject.getString("language");
                // remark
                String remark = jsonObject.getString("remark");
                // 关注时间（时间戳）
                long subscribe_time = jsonObject.getInteger("subscribe_time");
                // 关注时间（转换过的）
                LocalDateTime subscribe_date = LocalDateTime.ofInstant(Instant.ofEpochMilli(subscribe_time), ZoneId.systemDefault());
                // 省份
                String province = jsonObject.getString("province");
                // 昵称
                String nickname = jsonObject.getString("nickname");
                // 头像
                String headimgurl = jsonObject.getString("headimgurl");

                appFansInfo.setOpenid(openid);
                appFansInfo.setCountry(country);
                appFansInfo.setUnionid(unionid);
                appFansInfo.setSubscribe(subscribe);
                appFansInfo.setCity(city);
                appFansInfo.setSex(sex);
                appFansInfo.setGroupid(groupid);
                appFansInfo.setLanguage(language);
                appFansInfo.setRemark(remark);
                appFansInfo.setSubscribe_time(subscribe_time);
                appFansInfo.setSubscribe_date(subscribe_date);
                appFansInfo.setProvince(province);
                appFansInfo.setNickname(nickname);
                appFansInfo.setHeadimgurl(headimgurl);
                appFansInfo.setFirst_subcribe_time(LocalDateTime.now());
                appFansInfoDao.save(appFansInfo);
            }
        } else {
            if (jsonObject != null) {
                // 国家
                String country = jsonObject.getString("country");
                // unionid
                String unionid = jsonObject.getString("unionid");
                // 关注状态
                String subscribe = jsonObject.getString("subscribe");
                // 城市
                String city = jsonObject.getString("city");
                // 性别（1为男， 2为女）
                int sex = jsonObject.getInteger("sex");
                // 分组
                int groupid = jsonObject.getInteger("groupid");
                // 语言
                String language = jsonObject.getString("language");
                // remark
                String remark = jsonObject.getString("remark");
                // 关注时间（时间戳）
                long subscribe_time = jsonObject.getInteger("subscribe_time");
                // 关注时间（转换过的）
                LocalDateTime subscribe_date = LocalDateTime.ofInstant(Instant.ofEpochMilli(subscribe_time), ZoneId.systemDefault());
                // 省份
                String province = jsonObject.getString("province");
                // 昵称
                String nickname = jsonObject.getString("nickname");
                // 头像
                String headimgurl = jsonObject.getString("headimgurl");

                oldAppFansInfo.setId(oldAppFansInfo.getId());
                oldAppFansInfo.setOpenid(openid);
                oldAppFansInfo.setCountry(country);
                oldAppFansInfo.setUnionid(unionid);
                oldAppFansInfo.setSubscribe(subscribe);
                oldAppFansInfo.setCity(city);
                oldAppFansInfo.setSex(sex);
                oldAppFansInfo.setGroupid(groupid);
                oldAppFansInfo.setLanguage(language);
                oldAppFansInfo.setRemark(remark);
                oldAppFansInfo.setSubscribe_time(subscribe_time);
                oldAppFansInfo.setSubscribe_date(subscribe_date);
                oldAppFansInfo.setProvince(province);
                oldAppFansInfo.setNickname(nickname);
                oldAppFansInfo.setHeadimgurl(headimgurl);
                appFansInfoDao.save(oldAppFansInfo);
            }
        }

    }

    /**
     * 保存新关注公众号用户信息
     *
     * @param appFansDto
     * @return
     * @throws Exception
     */
    public void saveWxFansUserInfo(AppFansDto appFansDto) throws Exception {
        AppFansInfo appFansInfo = new AppFansInfo();
        AppFansInfo oldAppFansInfo=appFansInfoDao.findByOpenid(appFansDto.getOpenid());
        log.info("根据openid查询原有用户基本信息: {}", oldAppFansInfo);
        if (oldAppFansInfo != null) {
            appFansInfo.setId(oldAppFansInfo.getId());
        }
        appFansInfo.setOpenid(appFansDto.getOpenid());
        appFansInfo.setCountry(appFansDto.getCountry());
        appFansInfo.setUnionid(appFansDto.getUnionid());
        appFansInfo.setSubscribe(appFansDto.getSubscribe());
        appFansInfo.setCity(appFansDto.getCity());
        appFansInfo.setSex(appFansDto.getSex());
        appFansInfo.setGroupid(appFansDto.getGroupid());
        appFansInfo.setLanguage(appFansDto.getLanguage());
        appFansInfo.setRemark(appFansDto.getRemark());
        appFansInfo.setSubscribe_time(appFansDto.getSubscribe_time());
        appFansInfo.setSubscribe_date(appFansDto.getSubscribe_date());
        appFansInfo.setProvince(appFansDto.getProvince());
        appFansInfo.setNickname(appFansDto.getNickname());
        appFansInfo.setHeadimgurl(appFansDto.getHeadimgurl());
        appFansInfo.setFirst_subcribe_time(appFansDto.getFirst_subcribe_time());
        appFansInfo.setSourceOne(appFansDto.getSourceOne());
        appFansInfo.setSourceTwo(appFansDto.getSourceTwo());
        appFansInfoDao.save(appFansInfo);
    }

    /**
     * 根据userId获取公众号openid
     *
     * @param userId
     * @return
     */
    public ResponseInfo<?> getWxOpenidByUserId(Long userId) throws Exception {
        MiniAppUserInfo miniAppUserInfo = miniAppUserDao.findByUserId(userId);
        String openid = null;
        if (miniAppUserInfo != null) {
            String unionid = miniAppUserInfo.getUnionId();
            AppFansInfo appFansInfo = appFansInfoDao.findByUnionid(unionid);
            if (appFansInfo != null) {
                openid = appFansInfo.getOpenid();
            }
            return ResponseInfo.success(openid);
        } else {
            return ResponseInfo.error(null);
        }
    }

    public void synchronizeUserInfo(String next_openid) {
        JSONObject fansList = microproRequestRepositorySao.getFansOpenid(next_openid);
        log.info("获取到的粉丝列表： {}", fansList);
        if (fansList == null || "".equals(fansList)) {
            log.info("获取粉丝openid列表出错");
            return;
        }
        if (fansList.containsKey("errcode")) {
            log.error("errcode: " + fansList.toString());
            if ("400014001442001".indexOf(fansList.getString("errcode")) != -1) {

            }
        } else {
            next_openid = fansList.getString("next_openid");
            log.info("next_openid为： {}", next_openid);
            if (fansList.containsKey("data")) {
                JSONObject data = fansList.getJSONObject("data");
                if (data != null && data.getJSONArray("openid") != null) {
                    JSONArray jsonArray = data.getJSONArray("openid");
                    for (int i = 0; i < jsonArray.size(); i++) {
                        String openid = jsonArray.get(i).toString();
                        JSONObject userInfoJo = microproRequestRepositorySao.getAllUserInfoWithUnionID(openid);
                        if (userInfoJo != null) {
                            String unionid = userInfoJo.getString("unionid");
                            AppFansInfo oldAppFansInfo = appFansInfoDao.findByOpenid(openid);
                            if (oldAppFansInfo != null) {
                                oldAppFansInfo.setUnionid(unionid);
                                appFansInfoDao.save(oldAppFansInfo);
                            }
                        }
                        if (next_openid != null && !"".equals(next_openid)) {
                            this.synchronizeUserInfo(next_openid);
                        }
                    }
                }
            }
        }
    }


    public ResponseInfo<?> publicAppUserAuth(String userName, String passWord, String source, String openid, String avatarUrl, String city, String gender, String nickName, String province, String unionid) throws Exception {
        Map<String, Object> data = Maps.newHashMap();
        AppUserInfo appUser = appUserDao.findByCellphone(userName);
        String token = "";
        if (appUser == null) {
            //登录失败
            data.put("code", "0001");
            data.put("MSG", "手机号码不存在，请重新登录！");
            return ResponseInfo.success(data);
        }
        /**
         * 加密算法
         */
        boolean validPass = validBase64Password(passWord, appUser.getPassword());
        if (validPass) {
            MiniAppUserInfo oldMiniAppUserInfo = miniAppUserDao.findByUnionId(unionid);
            if (oldMiniAppUserInfo != null) {
                //第一次登录微信公众号
                if (StringUtils.isEmpty(oldMiniAppUserInfo.getPublicopenid())) {
                    MiniAppUserInfo miniAppUser = new MiniAppUserInfo();
                    miniAppUser.setPublicopenid(openid);
                    miniAppUser.setAvatarUrl(avatarUrl);
                    miniAppUser.setCity(city);
                    miniAppUser.setGender(gender);
                    miniAppUser.setNickName(nickName);
                    miniAppUser.setProvince(province);
                    miniAppUser.setId(oldMiniAppUserInfo.getId());
                    miniAppUserDao.save(miniAppUser);
                    data.put("code", "0000");
                    data.put("MSG", "登录成功");
                    data.put("token", new String(Base64Utils.encode(oldMiniAppUserInfo.getToken().getBytes())));
                } else if (openid != null && openid.equals(oldMiniAppUserInfo.getPublicopenid())) {
                    data.put("code", "0000");
                    data.put("MSG", "登录成功");
                    data.put("token", new String(Base64Utils.encode(oldMiniAppUserInfo.getToken().getBytes())));
                } else {
                    data.put("code", "0002");
                    data.put("MSG", "非法操作");
                }
                return ResponseInfo.success(data);
            } else {
                //登录成功----首次登录微信
                token = UUIDUtil.getUid("P@");
                Long userId = appUser.getId();
                // 根据userId查询用户信息
                MiniAppUserInfo oldAppUser = miniAppUserDao.findByUserId(userId);
                if (null == oldAppUser || "".equals(oldAppUser)) {
                    // 之前没有存过用户信息
                    MiniAppUserInfo miniAppUser = new MiniAppUserInfo();
                    miniAppUser.setUserId(userId);
                    miniAppUser.setPublicopenid(openid);
                    miniAppUser.setToken(token);
                    miniAppUser.setTokenDate(LocalDateTime.now());
                    miniAppUser.setAvatarUrl(avatarUrl);
                    miniAppUser.setCity(city);
                    miniAppUser.setGender(gender);
                    miniAppUser.setNickName(nickName);
                    miniAppUser.setProvince(province);
                    miniAppUser.setUnionId(unionid);
                    miniAppUserDao.save(miniAppUser);
                } else {
                    // 如果存过信息则更新---踢人操作
                    oldAppUser.setId(oldAppUser.getId());
                    oldAppUser.setUserId(userId);
                    oldAppUser.setPublicopenid(openid);
                    oldAppUser.setOpenid("");
                    oldAppUser.setProvince(province);
                    oldAppUser.setNickName(nickName);
                    oldAppUser.setGender(gender);
                    oldAppUser.setCity(city);
                    oldAppUser.setAvatarUrl(avatarUrl);
                    oldAppUser.setToken(token);
                    oldAppUser.setTokenDate(LocalDateTime.now());
                    oldAppUser.setUnionId(unionid);
                    miniAppUserDao.save(oldAppUser);
                }
                data.put("code", "0000");
                data.put("token", new String(Base64Utils.encode(token.getBytes())));
                data.put("MSG", "登录成功！");
                return ResponseInfo.success(data);
            }
        } else {
            //登录失败
            data.put("code", "0003");
            data.put("MSG", "手机号码或密码错误，请重新登录！");
            data.put("token", token);
            return ResponseInfo.success(data);
        }
    }


    public String getMongoId(String cellphone) {
        if (cellphone == null) {
            return null;
        }
        return appUserDao.findByCellphone(cellphone) != null ? appUserDao.findByCellphone(cellphone).getMongoId() : null;
    }


    public List<AppUserInfo> findByAgentNoList(List<String> agentNoList) {
        return appUserDao.findByAgentNoList(agentNoList, "%ROLE_SUPER_AGENT%");
    }
    //构建PageRequest
    private PageRequest buildPageRequest(int pageNumber, int pagzSize) {
        return new PageRequest(pageNumber - 1, pagzSize, null);
    }
    public Page<AppFansInfo> findWxPublicUser(int pageNumber, int pageSize) {
        PageRequest request = this.buildPageRequest(pageNumber,pageSize);
        Page<AppFansInfo> sourceCodes= this.appFansInfoDao.findAll(request);
        return sourceCodes;
    }
    public AppFansInfo findWxPublicUserByOpenid(String openid) {
        return appFansInfoDao.findByOpenid(openid);
    }
    public Page<AppUserInfo> findAll(PageRequest pageReq ) {
        return appUserDao.findAll(pageReq);
    }

    public Page<AppUserInfo> getAppuserByList(Integer star,String role,String popularizeType,
                                              String businessCityId,String jobCode,PageRequest pageReq ){
        return appUserDao.getAppuserByList(star, role,popularizeType,  businessCityId, jobCode,pageReq);
    }

    /**
     * 查询客户经理 用户的权限信息
     *
     * @param referrer 客户经理（汉字或者拼音大写）
     * @return
     */
    public List<Map<String,String>> getReferrerUsers(String referrer,String manager) {
        List<Object[]> listArr = appUserDao.findByReferrerUsers(referrer,manager);
        List<Map<String,String>> result = new ArrayList<Map<String,String>>();
        for (Object[] obj : listArr){
            Map<String,String> map = new HashMap<String,String>(10);
            map.put("referrerName",String.valueOf(obj[0]));
            map.put("referrer",String.valueOf(obj[1]));
            map.put("type",String.valueOf(obj[2]));
            map.put("count",String.valueOf(obj[3]));
            result.add(map);
        }
        return result;
    }

    /**
     * 根据 客户经理和权限状态修改 权限
     *
     * @param newcreditWay 新的权限
     * @param referrer     要去修改的客户经理全拼
     * @return
     */
    @Transactional(rollbackOn=RuntimeException.class)
    public ResponseInfo<String> updateReferrerUsers(String newcreditWay,String oldcreditWay,String referrer) {
        // 数据验证
        if (StringUtils.isEmpty(referrer)){
            return ResponseInfo.error("客户经理不能为空！");
        }
        if (StringUtils.isEmpty(newcreditWay) || StringUtils.isEmpty(oldcreditWay)){
            return ResponseInfo.error("修改权限值不能为空！");
        }
        if (!userCreditway.contains(newcreditWay) || !userCreditway.contains(oldcreditWay)){
            return ResponseInfo.error("修改权限值无效！");
        }
        // 修改人
        String updatedBy = ThreadStore.getUserId();
        Integer count = 0;
        if(StringUtils.isBlank(oldcreditWay) || "null".equals(oldcreditWay)){
            count = appUserDao.updateReferrerUsersNull(newcreditWay, updatedBy, referrer);
        }else{
            count = appUserDao.updateReferrerUsers(newcreditWay, updatedBy, referrer,oldcreditWay);
        }
        return ResponseInfo.success("共修改数据： " + count + "条");
    }

}
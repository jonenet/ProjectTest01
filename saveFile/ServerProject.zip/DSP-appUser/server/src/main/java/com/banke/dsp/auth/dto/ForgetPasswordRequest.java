package com.banke.dsp.auth.dto;

import lombok.Data;

/**
 * Created by ex-zhongbingguo on 2017/10/31.
 */
@Data
public class ForgetPasswordRequest {
    private String username;

    private String cellphone;
}

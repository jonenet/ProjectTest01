package com.banke.dsp.auth.api;

import com.banke.bkc.framework.exception.BusinessException;
import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dto.AppUserRegister;
import com.banke.dsp.auth.dto.ChangePasswordRequestDTO;
import com.banke.dsp.auth.service.AppUserProfileService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * Created by ex-zhongbingguo on 2017/8/16.
 */
@RestController
@RequestMapping(value = "/api/v1", method = {RequestMethod.GET, RequestMethod.POST})
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AppUserProfileApi {

    @Autowired
    private AppUserProfileService appUserProfileService;

    /**
     * 获取个人资料
     * @return AppUserDTO
     */
    @RequestMapping("/profile")
    public ResponseInfo<?> getProfile(HttpServletRequest request) {
        String cv = request.getHeader("cv");
        return appUserProfileService.getProfile(cv);
    }

    /**
     *  旧版注册，新版不再维护
     * @param appUserRegister  入参
     */
    @RequestMapping(value = "/register/new")
    public ResponseInfo<?> registerNew(@RequestBody AppUserRegister appUserRegister) {
        return appUserProfileService.registerNew(appUserRegister);
//        return new ResponseInfo<>("9999","请升级到最新版本,进行注册登录", null);
    }

    /**
     *  推广页面 用户注册<旧版，新版不再维护>
     */
    @RequestMapping(value = "/register/quick")
    public ResponseInfo<?> registerQuick(@RequestBody AppUserRegister appUserRegister) {
        return appUserProfileService.registerQuick(appUserRegister);
//        return new ResponseInfo<>("9999","请升级到最新版本,进行注册登录", null);
    }

    /**
     *  用户注册
     * @param appUserRegister 手机号/验证码
     * @return  成功/失败提示
     */
    @RequestMapping(value = "/register")
    public ResponseInfo<?> register(@RequestBody AppUserRegister appUserRegister) {
        return appUserProfileService.register(appUserRegister);
    }

    /**
     *  修改密码
     * @return          boolean
     */
    @RequestMapping(value = "/changePassword")
    public ResponseInfo<Boolean> changePassword(@RequestBody ChangePasswordRequestDTO request) throws BusinessException {
       return appUserProfileService.changePassword(request);
    }

    /**
     *  忘记密码
     */
    @RequestMapping(value = "/forgetPassword")
    public ResponseInfo<?> forgetPassword(@RequestBody ChangePasswordRequestDTO request){
        return appUserProfileService.forgetPassword(request);
    }

    /**
     * 判断用户是否已经注册
     * @param request   cellphone
     * @return          Y/N
     */
    @RequestMapping(value = "/isRegister")
    public ResponseInfo<?> isRegister(HttpServletRequest request) {
        return appUserProfileService.isRegister(request.getParameter("cellphone"));
    }

    /**
     *  注册时发送短信验证码
     */
    @RequestMapping("/register/passcode")
    public ResponseInfo<?> sendRegisterPasscode(@RequestBody AppUserRegister appUserRegister){
        return appUserProfileService.sendRegisterPasscode(appUserRegister);
    }

    /**
     * 注册时语音验证码
     * (目前处理方式 还是发送短信验证码)
     */
    @RequestMapping(value = "/register/passcodeByVoice", method = RequestMethod.POST)
    public ResponseInfo<?> sendPasscodeByVoice(@RequestBody AppUserRegister appUserRegister) {
        // 目前不发送 语音验证码
        return appUserProfileService.sendRegisterPasscode(appUserRegister);
    }

    /**
     *  忘记密码时发送短信验证码
     */
    @RequestMapping("/forgetPassword/passcode")
    public ResponseInfo<?> sendForgetPasswordPasscode(@RequestBody ChangePasswordRequestDTO changePasswordRequestDTO){
        return appUserProfileService.sendForgetPasswordPasscode(changePasswordRequestDTO);
    }

    /**
     *  忘记密码时再次发送短信验证码
     */
    @RequestMapping("/reForgetPassword/passcode")
    public ResponseInfo<?> reSendForgetPasswordPasscode(@RequestBody ChangePasswordRequestDTO changePasswordRequestDTO) {
        return appUserProfileService.reSendForgetPasswordPasscode(changePasswordRequestDTO);
    }

    /**
     * 补充邀请码
     * @param request 邀请码
     * @return         true/失败原因
     */
    @RequestMapping(value = "/saveDevOpsUser")
    public ResponseInfo<String> savaDevOpsUser(HttpServletRequest request) throws BusinessException{
        String inviteCode = request.getParameter("inviteCode");
        return appUserProfileService.savaDevOpsUser(inviteCode);
    }

    /**
     *  个人积分《暂时》
     */
    @RequestMapping(value = "/getScore")
    public ResponseInfo<?> getScore(){
        return appUserProfileService.getScore();
    }

    /**
     * 保存虚拟客户经理（推单第一步调用）
     * @param cityId 城市id
     * @return  客户经理userId/失败提示
     */
    @RequestMapping(value = "/saveVirtualStaff")
    public ResponseInfo<String> saveVirtualStaff(@RequestParam("cityId") String cityId){
        return appUserProfileService.saveVirtualStaff(cityId);
    }

    /**
     *  设置密码
     * @param request   手机号，验证码，密码
     * @return          true/失败提示
     */
    @RequestMapping(value = "/savePassword")
    public ResponseInfo<?> savePassword(@RequestBody ChangePasswordRequestDTO request){
        return appUserProfileService.savePassword(request);
    }

    /**
     * 保存用户头像或者昵称
     * @param request  头像id/昵称
     * @return         成功/失败信息
     */
    @RequestMapping(value = "/saveHeadPortraitOrNickname")
    public ResponseInfo<Boolean> saveHeadPortraitOrNickname(HttpServletRequest request) throws BusinessException {
        String headImageId = request.getParameter("headImageId");
        String nickname = request.getParameter("nickname");
        return appUserProfileService.saveHeadPortraitOrNickname(headImageId, nickname);
    }

    /**
     *  校验验证码
     * @param cellphone 手机号码
     * @param passcode  验证码
     * @return           成功/失败提示
     */
    @RequestMapping("/checkVerifyCode")
    public ResponseInfo<?> checkVerifyCode(String cellphone, String passcode){
        return appUserProfileService.checkVerifyCode(cellphone, passcode);
    }

    /**
     *  获取用户业务城市
     * @return 业务城市
     */
    @RequestMapping("/getBusinessCity")
    public ResponseInfo<Map> getBusinessCity(){
        return ResponseInfo.success(appUserProfileService.getBusinessCity());
    }
}

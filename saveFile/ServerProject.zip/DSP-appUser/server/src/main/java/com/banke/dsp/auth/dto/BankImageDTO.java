package com.banke.dsp.auth.dto;

import lombok.Data;

/**
 * Created by ex-zhongbingguo on 2018/1/24.
 */
@Data
public class BankImageDTO {
    //银行code
    private String bankCode;
    //银行名字
    private String bankName;
    //logo图片id
    private String logoImageId;
    //背景图片id
    private String backgroundImageId;
}

package com.banke.dsp.auth.service.login;

import com.banke.dsp.auth.po.AppUserInfo;

import java.util.Date;

/**
 * Created by ex-zhongbingguo on 2017/11/7.
 */
public interface AppToken {
    public String getToken();

    public AppUserInfo getOwner();

    public Date getExpiredDate();

    public Date getLatestTime();

    public void updateExpiredDate(long timeout);
}

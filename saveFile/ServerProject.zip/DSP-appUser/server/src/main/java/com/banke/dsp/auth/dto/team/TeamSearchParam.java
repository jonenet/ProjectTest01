package com.banke.dsp.auth.dto.team;

import com.banke.dsp.auth.dto.PageDTO;
import lombok.Data;

/**
 * Created by linzhimou on 2017/7/31.
 */
@Data
public class TeamSearchParam extends PageDTO {

    private String teamNo;
    private String cellphone;
    private String inputOrgId;
}

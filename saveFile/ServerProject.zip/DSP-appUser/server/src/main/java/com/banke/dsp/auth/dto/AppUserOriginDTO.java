package com.banke.dsp.auth.dto;


import lombok.Data;

/**
 * Created by ex-zengfanxi on 2017/10/17.
 */
@Data
public class AppUserOriginDTO {

	//手机号码
	private String cellphone;

	//团队id
	private String teamNo;

	//来源
	private String source;

}

package com.banke.dsp.auth.service;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Base64Utils;
import org.springframework.web.bind.annotation.RequestParam;
import com.banke.bkc.service.util.ContextHolder;
import com.alibaba.fastjson.JSONObject;
import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.bkc.framework.util.UUIDUtil;
import com.banke.dsp.auth.dao.AppFansInfoDao;
import com.banke.dsp.auth.dao.AppUserDao;
import com.banke.dsp.auth.dao.MiniAppUserDao;
import com.banke.dsp.auth.dto.AppRole;
import com.banke.dsp.auth.dto.RegisterRequestDTO;
import com.banke.dsp.auth.po.AppFansInfo;
import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.po.MiniAppUserInfo;
import com.banke.dsp.auth.sao.MicroproRequestRepositorySao;
import com.banke.dsp.auth.sao.SendSMSRequestRepositorySao;
import com.banke.dsp.auth.security.Base64;
import com.banke.dsp.auth.util.WxDecryptUtil;

import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AppUserResgisterService {

	@NonNull
	private SendSMSRequestRepositorySao sendSMSRequestRepositorySao;

	@NonNull
	private MicroproRequestRepositorySao microproRequestRepositorySao;

	@NonNull
	private AppUserDao appUserDao;

	@NonNull
	private MiniAppUserDao miniAppUserDao;

	@NonNull
	private AppFansInfoDao appFansInfoDao;
	public ResponseInfo<?> sendRegisterPasscode(@RequestParam("telphone") String telphone,
			@RequestParam("requestId") String requestId) throws Exception {
		if (StringUtils.isEmpty(telphone)) {
			throw new RuntimeException("手机号码不能为空");
		}
		// 根据手机号码查询数据库
		AppUserInfo getUserInfo = appUserDao.findByCellphone(telphone);
		log.info("根据手机号码查询是否已注册: {}", getUserInfo);
		if (null != getUserInfo) {
			// 说明数据库中有这个手机号码， 不可以注册
			// throw new RuntimeException("手机号码已经被使用！");
			return ResponseInfo.success(null);
		}
		return sendSMSRequestRepositorySao.sendRegisterPasscode(telphone, requestId);
	}

	public ResponseInfo<?> register(@RequestParam("telphone") String telphone,
			@RequestParam("requestId") String requestId, @RequestParam("passCode") String passCode,
			@RequestParam("password") String password, @RequestParam("name") String name,
			@RequestParam("source") String source, @RequestParam("openid") String openid,
			@RequestParam("avatarUrl") String avatarUrl, @RequestParam("city") String city,
			@RequestParam("gender") String gender, @RequestParam("nickName") String nickName,
			@RequestParam("province") String province, @RequestParam("latitude") String latitude,
			@RequestParam("longitude") String longitude, @RequestParam("encryptedData") String encryptedData,
			@RequestParam("session_key") String session_key, @RequestParam("iv") String iv) {
		log.info("传过来的encryptedData： {}", encryptedData);
		Map<String, String> returnMap = new HashMap<>();
		if (StringUtils.isEmpty(passCode)) {
			throw new RuntimeException("验证码不能为空");
		}
		if (StringUtils.isEmpty(password)) {
			throw new RuntimeException("密码不能为空");
		}
		if (StringUtils.isEmpty(telphone)) {
			// throw new RuntimeException("手机号不能为空");
			returnMap.put("code", "0002");
			returnMap.put("msg", "手机号不能为空");
			return ResponseInfo.success(returnMap);
		}
		if (StringUtils.isEmpty(requestId)) {
			// throw new RuntimeException("验证码请求不能为空");
			returnMap.put("code", "0003");
			returnMap.put("msg", "验证码请求不能为空");
			return ResponseInfo.success(returnMap);
		}
		if (StringUtils.isEmpty(name)) {
			// throw new RuntimeException("验证码请求不能为空");
			returnMap.put("code", "0003");
			returnMap.put("msg", "用户真实姓名不能为空");
			return ResponseInfo.success(returnMap);
		}
		// 根据手机号码查询数据库
		AppUserInfo getUserInfo = appUserDao.findByCellphone(telphone);
		if (null != getUserInfo) {
			// 说明数据库中有这个手机号码， 不可以注册
			// throw new RuntimeException("手机号码已经被使用！");
			returnMap.put("code", "0004");
			returnMap.put("msg", "手机号码已经被使用！");
			return ResponseInfo.success(returnMap);
		}
		ResponseInfo<RegisterRequestDTO> returnData = sendSMSRequestRepositorySao
				.findRegisterRequestByRequestId(requestId);
		log.info("调用短信服务注册接口返回的数据： {}", returnData);
		if (returnData.isSuccess()) {
			RegisterRequestDTO registerRequestDTO = returnData.getData();
			log.info("调用短信服务注册接口获取到的请求dto: {}", registerRequestDTO);
			if (null == registerRequestDTO) {
				// throw new RuntimeException("验证码错误，请重新获取验证码！");
				returnMap.put("code", "0001");
				returnMap.put("msg", "验证码错误，请重新获取验证码！");
				return ResponseInfo.success(returnMap);
			}
			AppUserInfo appUser = new AppUserInfo();

			String expectedPasscode = passCode;
			log.info("用户输入的验证码: {}", expectedPasscode);
			log.info("数据库中对应的验证码: {}", registerRequestDTO.getPassCode());
			if (!registerRequestDTO.getPassCode().equals(expectedPasscode)) {
				// throw new RuntimeException("验证码错误，请重新获取验证码！");
				returnMap.put("code", "0001");
				returnMap.put("msg", "验证码错误，请重新获取验证码！");
				return ResponseInfo.success(returnMap);
			}
			Long exchangeExpiredAt = Date
					.from(registerRequestDTO.getExpiredAt().atZone(ZoneId.systemDefault()).toInstant()).getTime();
			if (System.currentTimeMillis() > exchangeExpiredAt) {
				// throw new RuntimeException("验证码已过期，请重新获取验证码！");
				returnMap.put("code", "0005");
				returnMap.put("msg", "验证码已过期，请重新获取验证码！");
				return ResponseInfo.success(returnMap);
			}
			List<AppRole> appRoles = new ArrayList<AppRole>();
			appRoles.add(AppRole.ROLE_USER);
			appRoles.add(AppRole.ROLE_AGENT);
			appUser.setCellphone(telphone);
			appUser.setPassword(Base64.getBase64(password));
			appUser.setPasswordEncoder("base64");
			appUser.setPasswordSalt("");
			appUser.setCreatedAt(LocalDateTime.now());
			appUser.setSource("miniPrograms");
			appUser.setMongoId(UUID.randomUUID().toString().trim().replace("-", ""));
			appUser.setAppRoles(StringUtils.join(appRoles.toArray(), ","));
			appUser.setRealName(name);
			appUserDao.save(appUser);
			log.info("用户角色： " + appUser.getAppRoles());

			// 新增新的逻辑， 注册成功之后直接登录
			String token = UUIDUtil.getUid("P@");
			String unionId = "";
			String json = WxDecryptUtil.wxDecrypt(encryptedData, session_key, iv);
			JSONObject jsonObject = JSONObject.parseObject(json);
			if (jsonObject != null) {
				unionId = jsonObject.getString("unionId");
			}
			log.info("获取到的unionid: {}", unionId);
			MiniAppUserInfo miniAppUserInfo = new MiniAppUserInfo();
			miniAppUserInfo.setUserId(appUser.getId());
			miniAppUserInfo.setOpenid(openid);
			miniAppUserInfo.setToken(token);
			miniAppUserInfo.setTokenDate(LocalDateTime.now());
			miniAppUserInfo.setAvatarUrl(avatarUrl);
			miniAppUserInfo.setCity(city);
			miniAppUserInfo.setGender(gender);
			miniAppUserInfo.setNickName(nickName);
			miniAppUserInfo.setProvince(province);
			miniAppUserInfo.setLatitude(latitude);
			miniAppUserInfo.setLongitude(longitude);
			miniAppUserInfo.setUnionId(unionId);
			MiniAppUserInfo oldMiniAppUserInfo = miniAppUserDao.findByOpenid(openid);
			if (oldMiniAppUserInfo == null) {
				miniAppUserDao.save(miniAppUserInfo);

				Long userId = miniAppUserInfo.getUserId();
				String wxOpenid = "";
				MiniAppUserInfo miniAppUserInfos = miniAppUserDao.findByUserId(userId);
				if (miniAppUserInfos != null) {
					String unionid = miniAppUserInfos.getUnionId();
					AppFansInfo appFansInfo = appFansInfoDao.findByUnionid(unionid);
					if (appFansInfo != null) {
						wxOpenid = appFansInfo.getOpenid();
						log.info("关注公众号的openid: {}", wxOpenid);
						if (wxOpenid != null && wxOpenid != "") {
							// 发送随机红包
							ContextHolder.setAgentNo(""+userId);
							ResponseInfo responseInfo = microproRequestRepositorySao.sendRedPacKage(wxOpenid, "ZC");
							Map<String, Object> requestMap = (Map<String, Object>) responseInfo.getData();
							log.info("发送随机红包返回结果： {}", requestMap);
							if (requestMap != null) {
								String requestCode = requestMap.get("return_code").toString();
								String requestMsg = requestMap.get("return_msg").toString();
								log.info("发送随机红包返回code: {}", requestCode);
								log.info("发送随机红包返回msg: {}", requestMsg);
								returnMap.put("requestCode", requestCode);
								returnMap.put("requestMsg", requestMsg);
							}
						}
					}
				} else {
				}
				returnMap.put("code", "0000");
				returnMap.put("msg", "注册成功");
				returnMap.put("token", token);

				return ResponseInfo.success(returnMap);
			} else {
				// 该openid表中已经有数据
				returnMap.put("code", "0000");
				returnMap.put("msg", "已注册，请直接登录");
				return ResponseInfo.success(returnMap);
			}

		} else {
			// throw new RuntimeException("获取验证码信息出错");
			returnMap.put("code", "0006");
			returnMap.put("msg", "获取验证码信息出错");
			return ResponseInfo.success(returnMap);
		}
	}
	@Transactional
	public ResponseInfo<?> publicregister(String telphone,String requestId, String passCode,String password,String name,String source,String openid,String avatarUrl,String city,String gender,String nickName,String province,String unionid) {
		Map<String, String> returnMap = new HashMap<>();
		if (StringUtils.isEmpty(passCode)) {
			throw new RuntimeException("验证码不能为空");
		}
		if (StringUtils.isEmpty(password)) {
			throw new RuntimeException("密码不能为空");
		}
		if (StringUtils.isEmpty(telphone)) {
			// throw new RuntimeException("手机号不能为空");
			returnMap.put("code", "0002");
			returnMap.put("msg", "手机号不能为空");
			return ResponseInfo.success(returnMap);
		}
		if (StringUtils.isEmpty(requestId)) {
			// throw new RuntimeException("验证码请求不能为空");
			returnMap.put("code", "0003");
			returnMap.put("msg", "验证码请求不能为空");
			return ResponseInfo.success(returnMap);
		}
		if (StringUtils.isEmpty(name)) {
			// throw new RuntimeException("验证码请求不能为空");
			returnMap.put("code", "0003");
			returnMap.put("msg", "用户真实姓名不能为空");
			return ResponseInfo.success(returnMap);
		}
		// 根据手机号码查询数据库
		AppUserInfo getUserInfo = appUserDao.findByCellphone(telphone);
		if (null != getUserInfo) {
			// 说明数据库中有这个手机号码， 不可以注册
			// throw new RuntimeException("手机号码已经被使用！");
			returnMap.put("code", "0004");
			returnMap.put("msg", "手机号码已经被使用！");
			return ResponseInfo.success(returnMap);
		}
		ResponseInfo<RegisterRequestDTO> returnData = sendSMSRequestRepositorySao
				.findRegisterRequestByRequestId(requestId);
		log.info("调用短信服务注册接口返回的数据： {}", returnData);
		if (returnData.isSuccess()) {
			RegisterRequestDTO registerRequestDTO = returnData.getData();
			log.info("调用短信服务注册接口获取到的请求dto: {}", registerRequestDTO);
			if (null == registerRequestDTO) {
				// throw new RuntimeException("验证码错误，请重新获取验证码！");
				returnMap.put("code", "0001");
				returnMap.put("msg", "验证码错误，请重新获取验证码！");
				return ResponseInfo.success(returnMap);
			}
			AppUserInfo appUser = new AppUserInfo();

			String expectedPasscode = passCode;
			log.info("用户输入的验证码: {}", expectedPasscode);
			log.info("数据库中对应的验证码: {}", registerRequestDTO.getPassCode());
			if (!registerRequestDTO.getPassCode().equals(expectedPasscode)) {
				// throw new RuntimeException("验证码错误，请重新获取验证码！");
				returnMap.put("code", "0001");
				returnMap.put("msg", "验证码错误，请重新获取验证码！");
				return ResponseInfo.success(returnMap);
			}
			Long exchangeExpiredAt = Date
					.from(registerRequestDTO.getExpiredAt().atZone(ZoneId.systemDefault()).toInstant()).getTime();
			if (System.currentTimeMillis() > exchangeExpiredAt) {
				// throw new RuntimeException("验证码已过期，请重新获取验证码！");
				returnMap.put("code", "0005");
				returnMap.put("msg", "验证码已过期，请重新获取验证码！");
				return ResponseInfo.success(returnMap);
			}
			List<AppRole> appRoles = new ArrayList<AppRole>();
			appRoles.add(AppRole.ROLE_USER);
			appRoles.add(AppRole.ROLE_AGENT);
			appUser.setCellphone(telphone);
			appUser.setPassword(Base64.getBase64(password));
			appUser.setPasswordEncoder("base64");
			appUser.setPasswordSalt("");
			appUser.setCreatedAt(LocalDateTime.now());
			appUser.setSource("wxpublic");
			appUser.setMongoId(UUID.randomUUID().toString().trim().replace("-", ""));
			appUser.setAppRoles(StringUtils.join(appRoles.toArray(), ","));
			appUser.setRealName(name);
			appUserDao.save(appUser);
			log.info("用户角色： " + appUser.getAppRoles());

			// 新增新的逻辑， 注册成功之后直接登录
			String token = UUIDUtil.getUid("P@");
			MiniAppUserInfo miniAppUserInfo = new MiniAppUserInfo();
			miniAppUserInfo.setUserId(appUser.getId());
			miniAppUserInfo.setPublicopenid(openid);
			miniAppUserInfo.setToken(token);
			miniAppUserInfo.setTokenDate(LocalDateTime.now());
			miniAppUserInfo.setAvatarUrl(avatarUrl);
			miniAppUserInfo.setCity(city);
			miniAppUserInfo.setGender(gender);
			miniAppUserInfo.setNickName(nickName);
			miniAppUserInfo.setProvince(province);
			miniAppUserInfo.setUnionId(unionid);
			MiniAppUserInfo oldMiniAppUserInfo = miniAppUserDao.findByOpenid(unionid);
			if (oldMiniAppUserInfo == null) {
				miniAppUserDao.save(miniAppUserInfo);
				Long userId = miniAppUserInfo.getUserId();
				if (openid != null && openid != "") {
					// 发送随机红包
					ContextHolder.setAgentNo(""+userId);
					ResponseInfo responseInfo = microproRequestRepositorySao.sendRedPacKage(openid, "ZC");
					Map<String, Object> requestMap = (Map<String, Object>) responseInfo.getData();
					log.info("发送随机红包返回结果： {}", requestMap);
					if (requestMap != null) {
						String requestCode = requestMap.get("return_code").toString();
						String requestMsg = requestMap.get("return_msg").toString();
						log.info("发送随机红包返回code: {}", requestCode);
						log.info("发送随机红包返回msg: {}", requestMsg);
						returnMap.put("requestCode", requestCode);
						returnMap.put("requestMsg", requestMsg);
					}
				}
				returnMap.put("code", "0000");
				returnMap.put("msg", "注册成功");
				returnMap.put("token", new String(Base64Utils.encode(token.getBytes())));
				return ResponseInfo.success(returnMap);
			} else {
				// 该openid表中已经有数据
				//如果以前注册过，update数据
				miniAppUserInfo.setId(oldMiniAppUserInfo.getId());
				miniAppUserDao.save(miniAppUserInfo);
				returnMap.put("code", "0000");
				returnMap.put("msg", "已注册，请直接登录");
				return ResponseInfo.success(returnMap);
			}

		} else {
			// throw new RuntimeException("获取验证码信息出错");
			returnMap.put("code", "0006");
			returnMap.put("msg", "获取验证码信息出错");
			return ResponseInfo.success(returnMap);
		}
	}


	public ResponseInfo<?> validpublicregister(String openid,String unionid) {
		Map<String, String> returnMap = new HashMap<>();
		if(StringUtils.isEmpty(openid)&&StringUtils.isEmpty(unionid)){
			returnMap.put("code", "0001");
			returnMap.put("msg", "入参不能为空");
			return ResponseInfo.success(returnMap);
		}
		MiniAppUserInfo miniAppUserInfo = miniAppUserDao.findByUnionId(unionid);
		if(miniAppUserInfo==null){
			//公众号没有注册过
			returnMap.put("code", "0002");
			returnMap.put("msg", "您还未注册，请先注册");
			return ResponseInfo.success(returnMap);
		} 
		if(StringUtils.isEmpty(miniAppUserInfo.getPublicopenid())){
			miniAppUserInfo.setPublicopenid(openid);
			miniAppUserDao.save(miniAppUserInfo);
		}
		returnMap.put("code", "0000");
		returnMap.put("token",new String(Base64Utils.encode(miniAppUserInfo.getToken().getBytes())));
		return ResponseInfo.success(returnMap);
	}
}

package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.po.TeamGradeHistory;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by ex-taozhangyi on 2018/2/9.
 */
public interface TeamGradeHistoryDao extends CrudRepository<TeamGradeHistory,Long> {
}

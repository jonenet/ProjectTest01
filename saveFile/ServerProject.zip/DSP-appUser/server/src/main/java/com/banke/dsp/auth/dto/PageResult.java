package com.banke.dsp.auth.dto;

import lombok.Data;

import java.util.List;

/**
 * Created by ex-zhongbingguo on 2017/10/26.
 */
@Data
public class PageResult<T> {

    /**
     *  结果集
     */
    private List<T> list;

    /**
     *  总记录数
     */
    private long rowCount;

    /**
     *  总页数
     */
    private long pageCount;

    /**
     *  当前页数
     */
    private long pageNow;
}

package com.banke.dsp.auth.service;

import com.alibaba.fastjson.JSONObject;
import com.banke.bkc.framework.exception.BusinessException;
import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.bkc.service.util.ContextHolder;
import com.banke.dsp.auth.dao.AppWeChatUserInfoDao;
import com.banke.dsp.auth.dto.*;
import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.po.InvitationBinding;
import com.banke.dsp.auth.po.ScoreDetails;
import com.banke.dsp.auth.po.TotalScore;
import com.banke.dsp.auth.sao.DspConfigSao;
import com.banke.dsp.auth.sao.RecommendInfoSao;
import com.banke.dsp.auth.sao.SendSMSRequestRepositorySao;
import com.banke.dsp.auth.security.Base64;
import com.banke.dsp.auth.util.DateUtil;
import com.banke.dsp.auth.util.RegexUtil;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by ex-zhongbingguo on 2017/8/16.
 */
@Slf4j
@Service
public class AppUserProfileService {

    @Value("${push.production}")
    private String production;

    @Value("${app.whiteList}")
    private String whiteList;

    @Value("${app.whiteListFlag}")
    private String whiteListFlag;

    @Value("${app.whiteCity}")
    private String whiteCity;

    @Value("${yqb.switch}")
    private String yqbSwitch;

    private static final String TEMP_GROUP_PREFIX = "test_";

    @Autowired
    private AppUserInfoUtilService appUserInfoUtilService;

    @Autowired
    private StaffInfoService staffInfoService;

    @Autowired
    private AppWalletService appWalletService;

    @Autowired
    private RegisterRequestService registerRequestInfoService;

    @Autowired
    private BranchInfoService branchInfoService;

    @Autowired
    private AppUserInfoService appUserInfoService;

    @Autowired
    private AppUserForgetPasswordService appUserForgetPasswordService;

    @Autowired
    private SendSMSRequestRepositorySao sendSMSRequestRepositorySao;

    @Autowired
    private AppuserAscriptionLogService appuserAscriptionLogService;

    @Autowired
    private RecommendInfoSao recommendInfoSao;

    @Autowired
    private SendSMSRequestRepositorySao sendSMSSao;

    @Autowired
    private DspConfigSao dspConfigSao;

    @Autowired
    private BaseInfoService baseInfoService;

    @Autowired
    private AppWeChatUserInfoDao appWeChatUserInfoDao;

    @Autowired
    private InvitationBindingService invitationBindingService;

    @Autowired
    private TotalScoreService totalScoreService;
    @Autowired
    private RegisterContraintsService registerContraintsService;

    @Autowired
    private RegisterConstraintLogService registerConstraintLogService;

    public ResponseInfo<?> getProfile(String cv){
        int cvInt  = 0;
        if(!StringUtils.isEmpty(cv)){
            try {
                cvInt = Integer.parseInt(cv);
            } catch (NumberFormatException e) {
                log.info("获取用户信息cv转化异常");
            }
        }

        String mongoId = ContextHolder.getAgentNo();
        log.info("当前用户mongoId : {}", mongoId);
        AppUserInfo appUserInfo = appUserInfoService.findByMongoId(mongoId);
        AppUserDTO result = appUserInfoUtilService.convert(appUserInfo);
        //老版本
        result.setCanPassCode("N");
        if(cvInt > 17){
            //校验用户注册时间和现在比较
            long time1 = result.getCreatedAt().getTime();
            long time2 = new Date().getTime();
            if((time2-time1) > (24* 3600000)){
                result.setCanPassCode("Y");
            }
        }

        String referrer = result.getReferrer();
        result.setCanUpgrade("N"); //是否能升级高级用户

        if(StringUtils.isNotEmpty(referrer)){
            //远程获取 地推人员
            StaffInfoDTO dto = staffInfoService.getStaffInfoByUserId(referrer);
            if (dto != null){
                result.setDevOpsUserMobile(dto.getPhoneNumber());
            }
        }

        boolean isSuperAgent = false;
        List<AppRole> appRoles = result.getAppRoles();
        if (CollectionUtils.isNotEmpty(appRoles)){
            isSuperAgent = appRoles.contains(AppRole.ROLE_SUPER_AGENT);
        }

        String businessCitieCode = "";
        BusinessCity businessCity = result.getBusinessCity();
        String repairBusinessCity;       //是否需要补城市编码
        if(businessCity!=null){
            businessCitieCode = businessCity.getCode();     // 客户城市代码
            repairBusinessCity="N";
        }else{
            repairBusinessCity="Y";
        }
        result.setRepairBusinessCity(repairBusinessCity);

        String isBindBankCard = "N";
        String bankCode;         //银行编号
        String bankName = "";         //银行名字
        String bankCardNumber = "";   //银行账号
        String backgroundUrl = "";    //银行背景图片
        String logoUrl = "";          //银行logo图片
        String cardType = "";         //银行卡类型
        String tokenYqb = "";          //壹钱包token
        String cityid = "";   //业务城市id
        String cityName = "";   //业务城市
        if(cvInt >= 17){
            Map yqbToken = appWalletService.getYqbToken(cv, mongoId);
            String token = (String)yqbToken.get("token");
            tokenYqb = token == null ? "" : token;
            isBindBankCard = (String)yqbToken.get("isBindBankCard");
            if(StringUtils.isEmpty(token)){
                result.setCanUpgrade("Y");
            }else{
                //如果有TOKEN 但不是高级用户 则升级为高级用户
                if(!isSuperAgent){
                    try {
                        appWalletService.userUpgrade(appUserInfo.getMongoId(),"");
                    } catch (Exception e) {
                        log.info("已绑定银行卡但不是高级用户升级失败 agentNo:{}",appUserInfo.getMongoId());
                    }
                }
                isSuperAgent = true;

                //新需求，显示银行的图片等信息
                if ("new".equals(yqbSwitch) && StringUtils.isNotEmpty((String)yqbToken.get("bankCode")) ){
                    bankCode = (String)yqbToken.get("bankCode");        // 银行code
                    bankName = (String)yqbToken.get("bankName");        // 银行名称
                    bankCardNumber = (String)yqbToken.get("cardNo");    //  银行卡号
                    cardType =  (String)yqbToken.get("cardType");      //  银行卡类型
                    log.info("平安付返回的银行code：{},名字:{},卡号：{},类型：{}", bankCode, bankName, bankCardNumber, cardType);
                    if ("D".equals(cardType)){
                        cardType = "储蓄卡";
                    }else if ("C".equals(cardType)){
                        cardType = "信用卡";
                    }else if ("P".equals(cardType)){
                        cardType = "存折";
                    } else {
                        cardType = "";
                    }
                    try {
                        // 仅仅匹配信用社
                        if (bankName.contains("信用社")){
                            bankCode = "RCC";
                        }
                        //根据银行code查询其对应的背景/logo图片id
                        ResponseInfo<BankImageDTO> responseInfo = dspConfigSao.view(bankCode);
                        log.info("根据bankcode查询背景/log图片id,结果：{}",responseInfo);
                        BankImageDTO biDto = responseInfo.getData();
                        backgroundUrl = getImageUrl(biDto.getBackgroundImageId());
                        logoUrl = getImageUrl(biDto.getLogoImageId());
                    }catch (Exception e) {
                        log.error("获取图片路径异常");
                    }
                }
            }
        }

        List<String> tags = new ArrayList<>();
        String cellphone = result.getCellphone();

        // 使用白名单的情況下
        if("Y".equals(whiteListFlag)){
            if(whiteCity.contains(businessCitieCode)){
                result.setCanUserApp("Y");
            }else if(whiteList.contains(cellphone)){
                result.setCanUserApp("Y");
            }else{
                result.setCanUserApp("N");
                result.setCantUseReason("您非内测用户，不能使用新版评估神！");
            }
        }else{
            result.setCanUserApp("Y");
        }

        // 不是生产环境，要加test_头
        String tagPrefix = null;
        if("false".equals(production)){
            tagPrefix = TEMP_GROUP_PREFIX;
        }

        // 是高级用户
        if(isSuperAgent){
            tags.add(tagPrefix + "ROLE_SUPER_AGENT");
            tags.add(tagPrefix + "star" + result.getStar());
        }else{
            tags.add(tagPrefix + "ROLE_AGENT");
        }

        String userJob = result.getJob();

        if(StringUtils.isNotEmpty(userJob)){
            tags.add(tagPrefix + "JOB_" + userJob);
        }

        if(businessCity != null && !StringUtils.isNotEmpty(businessCity.getId())){
            tags.add(tagPrefix + "BUSINESSCITY_" + businessCity.getId());
        }

        PopularizeType popularizeType = result.getPopularizeType();

        if(popularizeType != null && StringUtils.isNotEmpty(popularizeType.name())){
            tags.add(tagPrefix + popularizeType.name());
        }

        result.setIsBindBankCard(isBindBankCard); //是否绑定银行卡
        result.setSuperAgent(isSuperAgent);
        result.setTags(tags);
        result.setPassword(null);
        result.setPasswordEncoder(null);
        result.setPasswordSalt(null);
        //新需求
        result.setBackgroundUrl(backgroundUrl); //银行背景图片
        result.setLogoUrl(logoUrl);             //银行logo图片
        result.setBankName(bankName);           //银行名字
        result.setCellphone(cellphone);         //手机号码
        result.setBankCardNumber(bankCardNumber);   //银行账号后四位
        result.setCardType(cardType);           //银行类型
        result.setYqbToken(tokenYqb);

        //头像图片
        String headImageUrl = "";
        if (StringUtils.isNotEmpty(appUserInfo.getHeadImageId())){
            headImageUrl = this.getImageUrl(appUserInfo.getHeadImageId());
        }else if (StringUtils.isNotEmpty(appUserInfo.getOpenid())){
            headImageUrl = appWeChatUserInfoDao.findByOpenid(appUserInfo.getOpenid()).getHeadimgurl();
        }
        result.setHeadImageUrl(headImageUrl);

        //判断是否绑定客户经理（不包括虚拟客户经理）
        String hasCustomerManager = "N";
        if(StringUtils.isNotEmpty(appUserInfo.getReferrer()) && StringUtils.isNotEmpty(appUserInfo.getRefererName())
                && !appUserInfo.getRefererName().contains("虚拟")){
            hasCustomerManager = "Y";
        }
        result.setHasCustomerManager(hasCustomerManager);
        result.setAscription(appUserInfo.getAscription());
        result.setHasWeChat(StringUtils.isEmpty(appUserInfo.getOpenid()) ? "N" : "Y");
        result.setHasPassword(StringUtils.isEmpty(appUserInfo.getPassword()) ? "N" : "Y");
        return ResponseInfo.success(result);
    }

    private String getImageUrl(String imageId) {
        log.info("查询图片信息，imageId:{}", imageId);
        ResponseInfo<String> logoRes = dspConfigSao.getImgUrl(imageId, "phone");
        String logoUrl = "";
        if (logoRes != null && logoRes.isSuccess()){
            logoUrl = logoRes.getData();
        }
        return logoUrl;
    }

    public ResponseInfo<Boolean> changePassword(ChangePasswordRequestDTO request) throws BusinessException{
        if (StringUtils.isEmpty(request.getOldPassword())) {
            throw new BusinessException("0001","旧密码不能为空");
        }
        if (StringUtils.isEmpty(request.getNewPassword())) {
            throw new BusinessException("0002","新密码不能为空");
        }
        if (request.getNewPassword().length() < 8){
            throw new BusinessException("0003","用户密码长度至少为8位");
        }

        String mongoId = ContextHolder.getAgentNo();
        log.info("当前用户mongoId : {}", mongoId);
        AppUserInfo appUserInfo = appUserInfoService.findByMongoId(mongoId);
        //判断旧密码是否正确base64和MD5
        String base64 = Base64.getBase64(request.getOldPassword());
        if (!appUserInfo.getPassword().equals(base64)){
            throw new BusinessException("0005","用户旧密码错误");
        }

        String newPassword = Base64.getBase64(request.getNewPassword());
        appUserInfo.setPassword(newPassword);
        appUserInfo.setPasswordEncoder("base64");
        appUserInfoUtilService.updateAppUser(appUserInfo);
        return ResponseInfo.success(true);
    }

    public ResponseInfo<?> isRegister(String cellphone) {
        Map<String,String> data = new HashMap<>();
        if(StringUtils.isEmpty(cellphone)){
            return new ResponseInfo<>("9999", "手机号不能为空", null);
        }
        String mobileFormat = "^1[34578]\\d{9}$";
        Pattern pattern = Pattern.compile(mobileFormat);
        Matcher isMobile = pattern.matcher(cellphone);
        if(!isMobile.matches()) {
            return new ResponseInfo<>("9999", "手机号码不正确", null);
        }
        String isRegister = "N";
        AppUserInfo appuser = appUserInfoService.findByCellphone(cellphone);
        if (appuser != null && StringUtils.isNotEmpty(appuser.getCellphone())) {
            isRegister="Y";
        }
        data.put("isRegister", isRegister);
        return ResponseInfo.success(data);
    }

    public ResponseInfo<?> sendRegisterPasscode(AppUserRegister appUserRegister) {
        if (StringUtils.isEmpty(appUserRegister.getCellphone())) {
            return new ResponseInfo<>("9999", "手机号码不能为空", null);
        }
        if (StringUtils.isEmpty(appUserRegister.getRequestId())){
            appUserRegister.setRequestId("");
        }
        return sendSMSRequestRepositorySao.sendRegisterPasscode(appUserRegister.getCellphone(), appUserRegister.getRequestId());
    }

    public ResponseInfo<?> sendForgetPasswordPasscode(ChangePasswordRequestDTO changePasswordRequestDTO) {
        if (StringUtils.isEmpty(changePasswordRequestDTO.getCellphone())) {
            return new ResponseInfo<>("9999", "手机号码不能为空", null);
        }
        if (StringUtils.isEmpty(changePasswordRequestDTO.getRequestId())){
            changePasswordRequestDTO.setRequestId("");
        }
        return  appUserForgetPasswordService.sendForgetPasswordPasscode(changePasswordRequestDTO.getCellphone(), changePasswordRequestDTO.getRequestId());
    }

    public ResponseInfo<?> reSendForgetPasswordPasscode(ChangePasswordRequestDTO changePasswordRequestDTO) {
        ResponseInfo<ForgetPasswordRequestDTO> returnData = sendSMSRequestRepositorySao.findForgetPasswordRequestByRequestId(changePasswordRequestDTO.getRequestId());
        if(returnData.isSuccess()){
            if (StringUtils.isEmpty(changePasswordRequestDTO.getRequestId())){
                changePasswordRequestDTO.setRequestId("");
            }
            return  appUserForgetPasswordService.sendForgetPasswordPasscode(returnData.getData().getTelphone(), changePasswordRequestDTO.getRequestId());
        }else{
            return new ResponseInfo<>("9999", "获取短信验证码失败", null);
        }
    }

    /**
     * 补充邀请码
     * @param inviteCode 邀请码
     * @return           成功/失败提示
     */
    public ResponseInfo<String> savaDevOpsUser(String inviteCode) throws BusinessException{
        if(StringUtils.isEmpty(inviteCode)){
            throw new BusinessException("0001","邀请码不能为空");
        }
        String mongoId = ContextHolder.getAgentNo();
        log.info("当前用户mongoId : {}", mongoId);
        AppUserInfo appUserInfo = appUserInfoService.findByMongoId(mongoId);

        String oldAscription = appUserInfo.getAscription();  //旧的用户归属
        String referrer = appUserInfo.getReferrer();         //客户经理userId
        String refererName = appUserInfo.getRefererName();   //客户经理name

        //判断是绑定客户经理
        if(StringUtils.isNotEmpty(referrer) && StringUtils.isNotEmpty(refererName) && !refererName.contains("虚拟")){
            throw new BusinessException("0003","已绑定客户经理，修改请联系客服");
        }

        //校验邀请码
        Map map = this.validateInviteCode(inviteCode, appUserInfo);
        if (StringUtils.isNotEmpty((String)map.get("error"))){
            throw new BusinessException("0004",(String)map.get("error"));
        }
        appUserInfo = (AppUserInfo)map.get("data");

        //保存用户
        appUserInfoUtilService.updateAppUser(appUserInfo);

        //新增用户归属日志
        appuserAscriptionLogService.add(appUserInfo.getMongoId(), appUserInfo.getAscription(), oldAscription, null);
        return ResponseInfo.success("已绑定客户经理" + appUserInfo.getRefererName());
    }

    /**
     * 校验邀请码
     * @param inviteCode    邀请码
     * @param appUserInfo   用户信息
     * @return               用户信息
     */
    private Map validateInviteCode(String inviteCode, AppUserInfo appUserInfo){
        Map<String, Object> map = Maps.newHashMap();
        //校验邀请码
        ResponseInfo<RegisterConstraintInstenceDTO> response = dspConfigSao.findRCIByRegisterCode(inviteCode.trim());
        log.info("检验邀请码:{}", JSONObject.toJSONString(response));

        if (!response.isSuccess() || response.getData() == null) {
            log.info("邀请码校验，无效的邀请码:{}",inviteCode);
            map.put("error", "未找到客户经理，请确认邀请码是否正确");
            return map;
        }
        RegisterConstraintInstenceDTO rci = response.getData();
        if (!rci.isEnabled()){
            log.info("邀请码校验，该邀请码已经被禁用:{}",inviteCode);
            map.put("error", "抱歉，绑定失败，请稍后再试");
            return map;
        }

        //根据用户id，获取客户经理（新增邀请码，没有判断用户角色，因此这需要角色过滤）
        StaffInfoDTO staffInfo = staffInfoService.getCustomerManagerByUserId(rci.getClientManagerId());
        if (staffInfo == null) {
            map.put("error", "未找到客户经理，请确认邀请码是否正确");
            return map;
        }

        appUserInfo.setRegisterId(rci.getRegisterId());
        appUserInfo.setReferrer(rci.getClientManagerId().toUpperCase());
        appUserInfo.setRefererName(rci.getClientManagerName());

        //邀请码使用次数
        dspConfigSao.upUsedCount(rci.getId());

        String businessCityCode = staffInfo.getBranchNo();
        if(StringUtils.isNotEmpty(businessCityCode)){
            BranchInfoDTO businessCity = branchInfoService.getBranchByBranchNo(SysIdEnum.WRK.getValue(), businessCityCode);
            if (businessCity == null) {
                log.info("无效的业务城市编码,{}",businessCityCode);
                map.put("error", "抱歉，绑定失败，请稍后再试");
                return map;
            }
            //取部门的归属
            appUserInfo.setAscription(businessCity.getAscription());
            appUserInfo.setAscriptionStatus(true);
            //根据组织机构获取 分公司
            BranchInfoDTO dto = branchInfoService.getBusinessCity(businessCity, BranchInfoDTO.BranchType.BRANCH_COMPANY.name());
            appUserInfo.setBusinessCityid(dto.getBranchNo());
        }
        map.put("data", appUserInfo);
        return map;
    }

    public ResponseInfo<?> forgetPassword(ChangePasswordRequestDTO request){
        if (StringUtils.isEmpty(request.getRequestId())) {
            return new ResponseInfo<>("9999", "验证码错误，请重新获取验证码!",null);
        }
        if (StringUtils.isEmpty(request.getPasscode())) {
            return new ResponseInfo<>("9999", "验证码不能为空",null);
        }
        if (StringUtils.isEmpty(request.getNewPassword())) {
            return new ResponseInfo<>("9999", "新密码不能为空",null);
        }
        if (request.getNewPassword().length() < 8){
            return new ResponseInfo<>("9999", "用户密码长度至少为8位!",null);
        }

        String cellphone;
        ResponseInfo<ForgetPasswordRequestDTO> returnData = sendSMSRequestRepositorySao.findForgetPasswordRequestByRequestId(request.getRequestId());
        if (returnData.isSuccess()) {
            ForgetPasswordRequestDTO data = returnData.getData();
            if (data == null ) {
                return new ResponseInfo<>("9999", "验证码错误，请重新获取验证码",null);
            }
            if (!data.getPassCode().equals(request.getPasscode())) {
                return new ResponseInfo<>("9999", "验证码错误，请重新获取验证码!",null);
            }
            if (System.currentTimeMillis() > DateUtil.localDateTimeToDate(data.getExpiredAt()).getTime()) {
                return new ResponseInfo<>("9999", "验证码已过期，请重新获取验证码",null);
            }
            cellphone = data.getTelphone();
        }else{
            return new ResponseInfo<>("9999", "获取短信验证码失败",null);
        }
        AppUserInfo appUserInfo = appUserInfoService.findByCellphone(cellphone);
        if(appUserInfo == null) {
            return new ResponseInfo<>("9999", "该手机号未注册",null);
        }
        String newPassword = Base64.getBase64(request.getNewPassword());
        appUserInfo.setPassword(newPassword);
        appUserInfo.setPasswordEncoder("base64");
        appUserInfoUtilService.updateAppUser(appUserInfo);
        return ResponseInfo.success(true);
    }

    public ResponseInfo<?> getScore() {
        Map<String,String> data = new HashMap<>();
        data.put("score", "0");
        return ResponseInfo.success(data);
    }

    /**
     *  保存虚拟客户经理
     * @param cityId  城市id
     * @return        客户经理userId/失败信息
     */
    public ResponseInfo<String> saveVirtualStaff(String cityId) {
        String mongoId = ContextHolder.getAgentNo();
        log.info("当前用户mongoId : {}", mongoId);
        AppUserInfo appUserInfo = appUserInfoService.findByMongoId(mongoId);

        //绑定直接返回
        if (StringUtils.isNotEmpty(appUserInfo.getReferrer())){
            return ResponseInfo.success(appUserInfo.getReferrer());
        }

        //查询城市分公司配置
        ResponseInfo<String> response = dspConfigSao.findCompanyCode(cityId);

        StaffInfoDTO virtualStaff = staffInfoService.getVirtualStaffInfoDTOByBranchNo(StaffInfoRoleEnum.B_GPS.getCode(), response.getData());
        if (virtualStaff == null) {
            log.info("未找到对应的虚拟客户经理,城市code:{}", response.getData());
            return new ResponseInfo<>("9999", "新增虚拟客户经理失败",null);
        }

        //查询部门
        BranchInfoDTO department = branchInfoService.getBranchByBranchNo(SysIdEnum.WRK.getValue(), virtualStaff.getBranchNo());

        //根据部门查询分公司
        BranchInfoDTO branchOffice = branchInfoService.getBusinessCity(department, BranchInfoDTO.BranchType.BRANCH_COMPANY.name());
        appUserInfo.setBusinessCityid(branchOffice.getBranchNo());       //分公司
        appUserInfo.setAscription(department.getAscription());           //归属
        appUserInfo.setAscriptionStatus(true);                          //归属状态
        appUserInfo.setReferrer(virtualStaff.getUserId());              //虚拟客户经理
        appUserInfo.setRefererName(virtualStaff.getStaffName());        //虚拟客户经理名字
        appUserInfoUtilService.updateAppUser(appUserInfo);

        //新增归属日志
        appuserAscriptionLogService.add(appUserInfo.getMongoId(), department.getAscription(), null, null);
        return ResponseInfo.success(virtualStaff.getUserId());
    }

    /**
     *  保存密码
     * @param request 密码/验证码/手机号
     * @return        成功/失败信息
     */
    public ResponseInfo<?> savePassword(ChangePasswordRequestDTO request) {
        if (StringUtils.isEmpty(request.getNewPassword())) {
            return new ResponseInfo<>("0001", "密码不能为空", null);
        }
        //校验验证码
        ResponseInfo<?> responseInfo = sendSMSSao.checkVerifyCode(request.getCellphone(), request.getPasscode(), "t002", "10");
        if (!responseInfo.isSuccess()){
            return responseInfo;
        }

        //保存密码
        String mongoId = ContextHolder.getAgentNo();
        log.info("当前用户mongoId : {}", mongoId);
        AppUserInfo appUserInfo = appUserInfoService.findByMongoId(mongoId);

        String newPassword = Base64.getBase64(request.getNewPassword());
        appUserInfo.setPassword(newPassword);
        appUserInfo.setPasswordEncoder("base64");
        appUserInfoUtilService.updateAppUser(appUserInfo);
        return ResponseInfo.success(true);
    }

    /**
     * 保存用户头像或者昵称
     * @param headImageId 头像url或者昵称
     * @return              true/失败提示
     */
    public ResponseInfo<Boolean> saveHeadPortraitOrNickname(String headImageId, String nickname) throws BusinessException {
        if (StringUtils.isEmpty(headImageId) && StringUtils.isEmpty(nickname)) {
            throw new BusinessException("0001","参数不能为空");
        }
        String mongoId = ContextHolder.getAgentNo();
        log.info("当前用户mongoId : {}", mongoId);
        AppUserInfo appUserInfo = appUserInfoService.findByMongoId(mongoId);

        if (StringUtils.isNotEmpty(headImageId)){
            appUserInfo.setHeadImageId(headImageId);
        }
        if (StringUtils.isNotEmpty(nickname)) {
            appUserInfo.setNickname(nickname);
        }
        appUserInfoUtilService.updateAppUser(appUserInfo);
        return ResponseInfo.success(true);
    }

    /**
     *  用户注册
     * @param appUserRegister 注册对象
     * @return 成功/失败信息
     */
    public ResponseInfo<?> register(AppUserRegister appUserRegister) {
        String cellphone = appUserRegister.getCellphone();
        String passcode = appUserRegister.getPasscode();
        if (StringUtils.isEmpty(cellphone) || StringUtils.isEmpty(passcode)) {
            return new ResponseInfo<>("0001", "手机号或验证码不能为空", null);
        }

        //校验手机号码规范性
        if (!RegexUtil.checkCellPhone(cellphone)) {
            return new ResponseInfo<>("0002", "请输入正确的手机号码", null);
        }

        //校验验证码
        ResponseInfo<?> responseInfo = sendSMSSao.checkVerifyCode(cellphone, passcode, "t002", "10");
        if (!responseInfo.isSuccess()){
            return responseInfo;
        }

        //判断用户是否存在
        AppUserInfo appUserInfo = appUserInfoService.findByCellphone(cellphone);
        if (appUserInfo != null) {
            return new ResponseInfo<>("0003", "用户存在，注册失败", null);
        }

        //新用户注册
        this.register(cellphone, null,null,null,null, null, appUserRegister.getSource());
        return ResponseInfo.success(true);
    }

    /**
     *  用户注册
     * @param userName  手机号
     * @param city       城市名
     * @param province  省份名
     * @param cityId    城市id
     * @param openid    微信openid
     * @param nickname  微信昵称
     * @param source    渠道来源
     * @return           用户对象
     */
    AppUserInfo register(String userName, String city, String province, String cityId, String openid, String nickname, String source) {
        AppUserInfo appUser = new AppUserInfo();
        //获取注册城市
        if (StringUtils.isEmpty(cityId)) {
            cityId = this.getRegisterCityid(userName, province, city);
        }

        if (StringUtils.isEmpty(nickname)){
            nickname = "评估神用户" + userName.substring(7,11);
        }
        appUser.setMongoId(UUID.randomUUID().toString().replace("-", ""));
        appUser.setUserName(userName);
        appUser.setCellphone(userName);
        appUser.setRegisterCityid(cityId);
        appUser.setSource(source);
        appUser.setPasswordSalt("");
        appUser.setEnabled(true);
        appUser.setCreditWay("all");
        appUser.setArchived(false);
        appUser.setEnableEecommendation(true);
        appUser.setExpired(false);
        appUser.setLocked(false);
        appUser.setIsNeedCredit(true);
        appUser.setCreatedAt(LocalDateTime.now());
        appUser.setModifiedAt(LocalDateTime.now());
        appUser.setAppRoles("["+ AppRole.ROLE_USER + "," + AppRole.ROLE_AGENT +"]");
        appUser.setNickname(nickname);
        appUser.setOpenid(openid);
        appUser.setAscription("0001");
        appUser.setAscriptionStatus(true);
        AppUserInfo appUserInfo = appUserInfoUtilService.updateAppUser(appUser);
        //新增归属日志
        appuserAscriptionLogService.add(appUserInfo.getMongoId(), "0001", null, null);
        return appUserInfo;
    }

    /**
     *  获取手机号查询城市code
     * @param userName 手机号码
     * @param province 省份
     * @param city     城市
     * @return         城市code
     */
    private String getRegisterCityid(String userName, String province, String city) {
        //如果省份和城市都为空，手机归属城市作为注册城市
        if (StringUtils.isEmpty(province) && StringUtils.isEmpty(city)){
            String mobile = userName.substring(0, 7);
            ResponseInfo<JSONObject> mobileAscription = dspConfigSao.findByMobile(mobile);
            log.info("手机号码：{}，手机归属对象：{}",userName, mobileAscription);
            if (mobileAscription.isSuccess()){
                province = mobileAscription.getData().getString("province");
                city = mobileAscription.getData().getString("city");
            }
        }

        ResponseInfo<String> responseInfo = dspConfigSao.getCityCode(province, city);
        log.info("根据省份名和城市名获取城市code:{}", responseInfo);
        return responseInfo.getData();
    }

    /**
     *  校验验证码
     * @param cellphone 手机号码
     * @param passCode  验证码
     * @return           成功/失败提示
     */
    public ResponseInfo<?> checkVerifyCode(String cellphone, String passCode) {
        log.info("校验验证码参数:cellphone:{},passCode:{}", cellphone, passCode);
        return sendSMSSao.checkVerifyCode(cellphone, passCode, "t002", "10");
    }

    /**
     *  获取用户业务城市
     * @return 业务城市
     */
    public Map getBusinessCity() {
        String mongoId = ContextHolder.getAgentNo();
        log.info("当前用户mongoId : {}", mongoId);
        AppUserInfo appUserInfo = appUserInfoService.findByMongoId(mongoId);
        //查询分公司
        BranchInfoDTO branchInfo = branchInfoService.getBranchByBranchNo(SysIdEnum.WRK.getValue(), appUserInfo.getBusinessCityid());
        Map<String, String> map = Maps.newHashMap();
        if (branchInfo != null) {
            map.put("code", branchInfo.getBranchNo());
            map.put("name", branchInfo.getName());
        }
        return map;
    }

    //老代码：
    /**
     *  用户注册
     * @param appUserRegister 注册参数
     * @return   ResponseInfo<?>
     */
    public ResponseInfo<?> registerNew(AppUserRegister appUserRegister) {
        log.info("AppUserProfileService@registerNew,参数appUserRegister:{}", appUserRegister);
        String message = null;
        try{
            AppUserInfo appUser = new AppUserInfo();
            //1.参数非空校验
            this.parameterNotNullCheck(appUserRegister);
            //2.参数逻辑校验
            this.parameterLogicCheck(appUserRegister);
            //3.业务城市验证：如果业务城市不为空，则为业务城市对应的虚拟客户经理
            appUser = this.registerCodeCheck(appUserRegister, appUser);
            //4.推荐人手机号处理
            String refMobile = appUserRegister.getRefMobilePhone();
            refMobile = this.checkRefMobile(refMobile);
            //5.积分处理
            refMobile = this.updateScore(appUserRegister, refMobile);
            //6.注册邀请码验证：如果注册邀请码不为空，则为邀请码对应的客户经理
            appUser = this.isRegisterCodeRequired(appUserRegister, appUser);
            //7.新增用户
            appUser = this.appUserConvert(appUserRegister, appUser, refMobile);
            //8.新增用户归属日志
            appuserAscriptionLogService.add(appUser.getMongoId(), appUser.getAscription(), null, null);
            return ResponseInfo.success(appUser.getMongoId());
        } catch (Exception e){
//            log.info("用户注册异常", e);
            message = e.getMessage();
        }
        return new ResponseInfo<>("9999",message, null);
    }

    private void parameterNotNullCheck(AppUserRegister appUserRegister) throws Exception{
        String cv =appUserRegister.getCv();
        log.info("新增cv控制,cv:{}", cv);
        if(org.springframework.util.StringUtils.isEmpty(cv)){
            throw new RuntimeException("您的版本太低，为了向您提供更好的服务，请下载评估神2.0");
        }
        if (org.springframework.util.StringUtils.isEmpty(appUserRegister.getCellphone())) {
            throw new RuntimeException("手机号不能为空");
        }
        if (org.springframework.util.StringUtils.isEmpty(appUserRegister.getRequestId())) {
            throw new RuntimeException("验证码请求不能为空");
        }
        if (org.springframework.util.StringUtils.isEmpty(appUserRegister.getPasscode())) {
            throw new RuntimeException("验证码不能为空");
        }
        if (org.springframework.util.StringUtils.isEmpty(appUserRegister.getPassword())) {
            throw new RuntimeException("密码不能为空");
        }
    }

    private void parameterLogicCheck(AppUserRegister appUserRegister) throws Exception {
        //检查手机验证码
        this.registerCheck(appUserRegister.getRequestId(),appUserRegister.getPasscode());

        if(appUserInfoService.findByCellphone(appUserRegister.getCellphone()) != null) {
            throw new RuntimeException("手机号码已经被使用");
        }
    }

    //老代码: 待删除
    private String registerCheck(String requestId, String passcode)  throws Exception {
        //校验验证码
        RegisterRequestDTO rrDTO = registerRequestInfoService.findRegisterRequestByRequestId(requestId);
        if (rrDTO == null ) {
            throw new RuntimeException("验证码错误,请重新输入验证码");
        }
        if (!rrDTO.getPassCode().equals(passcode)) {
            throw new RuntimeException("验证码错误,请重新输入验证码");
        }
        if (System.currentTimeMillis() > DateUtil.localDateTimeToDate(rrDTO.getExpiredAt()).getTime()) {
            throw new RuntimeException("验证码已过期,请重新获取验证码");
        }
        return rrDTO.getTelphone();
    }

    private AppUserInfo registerCodeCheck(AppUserRegister appUserRegister, AppUserInfo appUser) throws Exception {
        String businessCityCode = appUserRegister.getBusinessCityCode();
        // 如果注册邀请码为空
        if(StringUtils.isEmpty(appUserRegister.getRegisterCode())){
            if(StringUtils.isEmpty(businessCityCode)){
                throw new RuntimeException("城市编码不能为空");
            }else{
                //根据系统id和机构编号 查询 组织机构
                BranchInfoDTO businessCity = branchInfoService.getBranchByBranchNo(SysIdEnum.WRK.getValue(), businessCityCode);
                if (businessCity == null) {
                    throw new RuntimeException("无效的业务城市编码");
                }else{
                    //根据角色id和组织机构编号 获取虚拟客户经理
                    StaffInfoDTO virtualStaffInfo = staffInfoService.getVirtualStaffInfoDTOByBranchNo(StaffInfoRoleEnum.B_GPS.getCode(), businessCityCode);
                    if(virtualStaffInfo==null){
                        log.info("未查询到虚拟客户经理，业务城市:{}", virtualStaffInfo.getBranchNo());
                        throw new RuntimeException("未找到客户经理，请确认邀请码是否正确");
                    }

                    appUser.setBusinessCityid(businessCityCode);
                    appUser.setReferrer(virtualStaffInfo.getUserId().toUpperCase());
                    appUser.setRefererName(virtualStaffInfo.getStaffName());
                    //分公司的虚拟客户经理名下的用户归属半刻
                    appUser.setAscription("0001");
                    appUser.setAscriptionStatus(true);
                }
            }
        }
        return appUser;
    }

    private String checkRefMobile(String refMobile) {
        if (StringUtils.isNotEmpty(refMobile)) {
            //推荐人
            AppUserInfo existedAppUser = appUserInfoService.findByCellphone(refMobile);
            if (null == existedAppUser) {
                throw new RuntimeException("手机号对应的推荐人不存在，请核对");
            }
            refMobile = existedAppUser.getUserName();
        }
        return refMobile;
    }

    private String updateScore(AppUserRegister appUserRegister, String refMobile) {
        InvitationBinding ib = invitationBindingService.findBybeInvitedPeople(appUserRegister.getCellphone());
        String mobile = ib == null ? "" : ib.getInvitePeople();
        if (StringUtils.isNotEmpty(mobile)){
            AppUserInfo existedAppUser = appUserInfoService.findByCellphone(mobile);
            if (existedAppUser != null){
                String asinitScore = null;
                String userId = existedAppUser.getId().toString();
                String initScore = StringUtils.isNotEmpty(asinitScore) ? asinitScore : "10";
                TotalScore ts = new TotalScore();
                ts.setUserId(userId);
                ts.setCellphone(mobile);
                ts.setNumScore(initScore);
                ScoreDetails sd = new ScoreDetails();
                sd.setUserId(userId);
                sd.setCellphone(mobile);
                sd.setDescription("分享有礼推荐客户"+appUserRegister.getCellphone()+"送积分"+initScore);
                sd.setScore(initScore);
                //老版本：待删除
                totalScoreService.saveTotalScore(ts, sd);
                refMobile = existedAppUser.getUserName();
            }
        }
        return refMobile;
    }

    private AppUserInfo isRegisterCodeRequired(AppUserRegister appUserRegister, AppUserInfo appUser) throws Exception{
        boolean isRegisterCodeRequired = registerContraintsService.isRegisterCodeRequired();
        StaffInfoDTO staffInfo = null;  //地推人员
        String branchNo = null;           //机构编号
        if (isRegisterCodeRequired) {
            String registerCode = appUserRegister.getRegisterCode();
            //如果 注册邀请码不为空
            if (StringUtils.isNotEmpty(registerCode)) {
//                try{
                //根据邀请码查询 有效/启用的 邀请码实例
//                    RegisterConstraintInstenceDTO rci = dspConfigSao.validateRegisterCode(registerCode);
                ResponseInfo<RegisterConstraintInstenceDTO> response = dspConfigSao.findRCIByRegisterCode(registerCode.trim());
                log.info("检验邀请码:{}", JSONObject.toJSONString(response));

                if (!response.isSuccess() || response.getData() == null) {
                    log.info("邀请码校验，无效的邀请码");
                    throw new RuntimeException("抱歉，绑定失败，请稍后再试");
                }
                RegisterConstraintInstenceDTO rci = response.getData();
                if (!rci.isEnabled()){
                    log.info("邀请码校验，该邀请码已经被禁用");
                    throw new RuntimeException("抱歉，绑定失败，请稍后再试");
                }
                appUser.setRegisterId(rci.getRegisterId());
                appUser.setReferrer(rci.getClientManagerId());
                appUser.setRefererName(rci.getClientManagerName());
                //根据用户id，获取客户经理（新增邀请码，没有判断用户角色，因此这需要角色过滤）
                staffInfo = staffInfoService.getCustomerManagerByUserId(rci.getClientManagerId());
                if (staffInfo == null) {
                    throw new RuntimeException("未找到客户经理，请确认邀请码是否正确");
                }
                dspConfigSao.upUsedCount(rci.getId());
//                }catch (Exception e){
//                    try {
//                        RegisterConstraintLog registerConstraintLog = new RegisterConstraintLog();
//                        registerConstraintLog.setUsername(appUserRegister.getUsername());
//                        registerConstraintLog.setCellphone(appUserRegister.getCellphone());
//                        registerConstraintLog.setRegisterCode("\"" + appUserRegister.getRegisterCode() + "\"");
//                        registerConstraintLog.setOsVersion(appUserRegister.getOsVersion());
//                        registerConstraintLog.setAppVersion(appUserRegister.getAppVersion());
//                        registerConstraintLog.setRegisterDevice(appUserRegister.getRegisterDevice());
//                        String message = e.getMessage();
//                        registerConstraintLog.setMessage(message);
//                        registerConstraintLogService.save(registerConstraintLog);
//                    } catch (Exception ie) {
//                        log.info("AppUserProfileService.isRegisterCodeRequired,保存注册日志异常");
//                    }
//                }
            }
        }
        if(staffInfo != null){
            branchNo = staffInfo.getBranchNo();
            if(StringUtils.isNotEmpty(branchNo)){
                //根据系统id 和机构编号 查询 组织机构
                BranchInfoDTO businessCity = branchInfoService.getBranchByBranchNo(SysIdEnum.WRK.getValue(), branchNo);
                if (businessCity == null) {
                    throw new RuntimeException("无效的业务城市编码");
                }
                //用户归属设置
                appUser.setAscription(businessCity.getAscription());
                appUser.setAscriptionStatus(true);
                //根据组织机构获取 分公司
                BranchInfoDTO dto = branchInfoService.getBusinessCity(businessCity, BranchInfoDTO.BranchType.BRANCH_COMPANY.name());
                appUser.setBusinessCityid(dto.getBranchNo());
            }
        }
        return appUser;
    }

    private AppUserInfo appUserConvert(AppUserRegister appUserRegister, AppUserInfo appUser, String refMobile) {
        appUser.setMongoId(UUID.randomUUID().toString().replace("-", ""));
        appUser.setUserName(appUserRegister.getCellphone());
        appUser.setCellphone(appUserRegister.getCellphone());
        appUser.setOsVersion(appUserRegister.getOsVersion());
        appUser.setAppVersion(appUserRegister.getAppVersion());
        appUser.setRegisterDevice(appUserRegister.getRegisterDevice());
        String source = appUserRegister.getSource();
        appUser.setSource(StringUtils.isNotEmpty(source) ? source : "app");
        if (StringUtils.isNotEmpty(refMobile)) {
            appUser.setPopularizeTypeId(PopularizeType.USER_REFERRAL.getDescription());
        }
        appUser.setPassword(Base64.getBase64(appUserRegister.getPassword()));
        appUser.setPasswordEncoder("base64");
        appUser.setPasswordSalt("");
        appUser.setEnabled(true);
        appUser.setCreditWay("all");
        appUser.setArchived(false);
        appUser.setEnableEecommendation(true);
        appUser.setExpired(false);
        appUser.setLocked(false);
        appUser.setIsNeedCredit(true);
        appUser.setCreatedAt(DateUtil.dateToLocalDateTime(new Date()));
        appUser.setModifiedAt(DateUtil.dateToLocalDateTime(new Date()));
        StringBuilder sb = new StringBuilder();
        sb.append("[").append( AppRole.ROLE_USER).append(",").append(AppRole.ROLE_AGENT).append("]");
        appUser.setAppRoles(sb.toString());
        appUser.setNickname("评估神用户" + appUserRegister.getCellphone().substring(7,11));
        return appUserInfoUtilService.updateAppUser(appUser);
    }

    /**
     *  app 推广页面 用户注册
     * @param appUserRegister 参数对象
     * @return  用户id
     */
    public ResponseInfo<?> registerQuick(AppUserRegister appUserRegister) {
        log.info("AppUserProfileService@registerQuick,参数appUserRegister:{}", appUserRegister);
        String message = null;
        try{
            AppUserInfo appUser = new AppUserInfo();
            //1.参数非空校验
            this.paramNotNullCheckSimpleRegister(appUserRegister);
            //2.参数逻辑校验  （手机号 和 验证码）
            this.parameterLogicCheck(appUserRegister);
            //3.新增用户
            appUser = this.appUserRegisterQuick(appUserRegister, appUser);
            return ResponseInfo.success(appUser.getMongoId());
        } catch (Exception e){
            message = e.getMessage();
        }
        return new ResponseInfo<>("9999",message, null);
    }

    // 推广页面注册  验证
    private void paramNotNullCheckSimpleRegister(AppUserRegister appUserRegister) throws Exception{
        if (StringUtils.isEmpty(appUserRegister.getCellphone())) {
            throw new RuntimeException("手机号不能为空");
        }
        if (StringUtils.isEmpty(appUserRegister.getRequestId())) {
            throw new RuntimeException("验证码请求不能为空");
        }
        if (StringUtils.isEmpty(appUserRegister.getPasscode())) {
            throw new RuntimeException("验证码不能为空");
        }
        if (StringUtils.isEmpty(appUserRegister.getPassword())) {
            throw new RuntimeException("密码不能为空");
        }
    }

    //  快速注册时  用户信息  保存
    private AppUserInfo appUserRegisterQuick(AppUserRegister appUserRegister, AppUserInfo appUser) {
        appUser.setMongoId(UUID.randomUUID().toString().replace("-", ""));
        appUser.setCellphone(appUserRegister.getCellphone());
        appUser.setUserName(appUserRegister.getCellphone());// 设置用户名为 手机号
        String source = appUserRegister.getSource();
        appUser.setSource(StringUtils.isNotEmpty(source) ? source : "Extension");
        appUser.setPassword(Base64.getBase64(appUserRegister.getPassword()));
        appUser.setPasswordEncoder("base64");
        appUser.setPasswordSalt("");
        appUser.setEnabled(true);
        appUser.setCv(appUserRegister.getCv());
        StringBuilder sb = new StringBuilder();
        sb.append("[").append( AppRole.ROLE_USER).append(",").append(AppRole.ROLE_AGENT).append("]");
        appUser.setAppRoles(sb.toString());
        appUser.setCreatedAt(DateUtil.dateToLocalDateTime(new Date()));
        appUser.setModifiedAt(DateUtil.dateToLocalDateTime(new Date()));
        return appUserInfoUtilService.updateAppUser(appUser);
    }
}

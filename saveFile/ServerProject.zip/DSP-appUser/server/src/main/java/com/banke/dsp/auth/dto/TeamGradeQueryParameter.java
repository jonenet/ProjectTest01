package com.banke.dsp.auth.dto;

import lombok.Data;

/**
 * Created by ex-zhongbingguo on 2017/12/8.
 */
@Data
public class TeamGradeQueryParameter extends PageDTO {

    private String gradeName;

    private String gradeCode;

    private String businessCityid;
}

package com.banke.dsp.auth.dto;

/**
 * 地推人员 角色
 * Created by ex-zhongbingguo on 2017/8/24.
 */
public enum StaffInfoRoleEnum {

    B_GPS("B_GPS","地推人员"),
    B_BTL("B_BTL","团队长"),
    H_OQ("H_OQ", "总部运营岗");

    private String code;

    private String name;

    StaffInfoRoleEnum(String code, String name){
        this.code = code;
        this.name = name;
    }

    public String getCode(){
        return this.code;
    }

    public String getName(){
        return name;
    }

}

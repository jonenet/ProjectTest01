package com.banke.dsp.auth.po;

import com.banke.bkc.framework.po.BasePO;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Created by ex-zengfanxi on 2018/02/27.
 */
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "app_wechat_user_info")
public class AppWeChatUserInfo extends BasePO {

	//普通用户的标识，对当前开发者帐号唯一
	private String openid;

	//普通用户昵称
	private String nickname;

	//普通用户性别，1为男性，2为女性
	private String sex;

	//普通用户个人资料填写的省份
	private String province;

	//普通用户个人资料填写的城市
	private String city;

	//国家，如中国为CN
	private String country;

	//用户头像（有0、46、64、96、132）
	private String headimgurl;

	//用户特权信息，json数组
	private String privilege;

	//用户统一标识
	private String unionid;

}

package com.banke.dsp.auth.po;

import com.banke.bkc.framework.po.BasePO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * Created by ex-liqiaoyong on 2017/7/24.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "team_operation_log")
public class TeamOperationLog extends BasePO{
    //用户编号
    private String agentNo;

    //团队编号
    private String teamNo;

    //加入类型
    private String joinType;

    //离开类型
    private String leaveType;

    //操作状态
    private String status;

    //操作类型
    private String operationType;

    //操作时间
    private LocalDateTime operationDate;

    //操作人
    private String operationBy;

}

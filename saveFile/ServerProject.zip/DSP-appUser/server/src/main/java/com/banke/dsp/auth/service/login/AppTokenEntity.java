package com.banke.dsp.auth.service.login;

import com.banke.dsp.auth.po.AppUserInfo;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;
import java.util.Date;
import java.util.UUID;

/**
 * Created by ex-zhongbingguo on 2017/11/7.
 */
public class AppTokenEntity implements AppToken, Authentication {

    private static final long serialVersionUID = 37917547119376571L;

    public static AppTokenEntity create(AppUserInfo owner, long timeout) {
        AppTokenEntity result = new AppTokenEntity();
        String value = UUID.randomUUID().toString().replace("-", "");
        result.setToken(value);
        result.setOwner(owner);
        Date date = new Date(System.currentTimeMillis() + timeout);
        result.setExpiredDate(date);
        result.setLatestTime(new Date());
        return result;
    }

    private String token;

    private AppUserInfo owner;

    private Date expiredDate;

    private Date latestTime;

    @Override
    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    @Override
    public AppUserInfo getOwner() {
        return owner;
    }

    public void setOwner(AppUserInfo owner) {
        this.owner = owner;
    }

    @Override
    public Date getExpiredDate() {
        return expiredDate;
    }

    public void setExpiredDate(Date expiredDate) {
        this.expiredDate = expiredDate;
    }

    @Override
    public Date getLatestTime() {
        return latestTime;
    }

    public void setLatestTime(Date latestTime) {
        this.latestTime = latestTime;
    }

    @Override
    public void updateExpiredDate(long timeout) {
        Date date = new Date(System.currentTimeMillis() + timeout);
        this.setExpiredDate(date);
        this.setLatestTime(new Date());
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return null;
    }

    @Override
    public Object getCredentials() {
        return null;
    }

    @Override
    public Object getDetails() {
        return null;
    }

    @Override
    public Object getPrincipal() {
        return null;
    }

    @Override
    public boolean isAuthenticated() {
        return true;
    }

    @Override
    public void setAuthenticated(boolean isAuthenticated) throws IllegalArgumentException {

    }
}

package com.banke.dsp.auth.sao;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dto.MessagePushRequestDTO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Created by ex-liqiaoyong on 2017/8/15.
 */
@FeignClient(name = "ADT-jpush")
public interface AdtJpushSao {

    @RequestMapping(value = "/api/messagePush/new")
    public ResponseInfo<?> messagePushNew(@RequestBody MessagePushRequestDTO messagePushRequest) ;

    /**
     *
     * @return  app消息处理
     */
    @RequestMapping(value = "/api/message/process")
    public ResponseInfo<?> messageProcess(@RequestParam(name="id")  String id);
}

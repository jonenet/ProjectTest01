package com.banke.dsp.auth.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import java.util.Iterator;

/**
 * Created by ex-zhongbingguo on 2017/11/20.
 */
public class HttpMultipartUtils {
    private static final Log logger = LogFactory.getLog(HttpMultipartUtils.class);

    public static MultipartFile getMultipartFile(HttpServletRequest request) {
        if (!(request instanceof MultipartHttpServletRequest)) {
            return null;
        }

        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        Iterator<String> it = multipartRequest.getFileNames();
        if (it == null || !it.hasNext()) {
            return null;
        }

        return multipartRequest.getFile(it.next());
    }
}

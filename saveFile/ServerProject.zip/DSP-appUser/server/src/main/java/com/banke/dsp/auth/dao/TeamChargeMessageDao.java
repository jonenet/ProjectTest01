package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.po.TeamChargeMessage;
import com.banke.dsp.auth.po.TeamMemberInfo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Created by ex-taozhangyi on 2018/2/27.
 */
public interface TeamChargeMessageDao extends CrudRepository<TeamChargeMessage,Long> {
    /**
     * 返回最新一条冲锋号读取
     * @param teamNo
     * @param mongoId
     * @param msgStatus
     * @return
     */
    @Query(value = "select * from team_charge_message t where t.team_no = ?1 and t.mongo_id = ?2 and "+
            " t.msg_status = ?3 order by t.created_date desc limit 1", nativeQuery = true)
    TeamChargeMessage findByTeamNoAndMongoIdAndMsgStatus(String teamNo,String mongoId,String msgStatus);

    /**
     * 查询本周有没有冲锋号
     * @param agentNo
     * @return
     */
    @Query(value = "select * from team_charge_message t where t.mongo_id = ?1 and "+
            " YEARWEEK(date_format(t.created_date,'%Y-%m-%d')) = YEARWEEK(now())", nativeQuery = true)
    List<TeamChargeMessage> getTeamChargeMessageBy(String agentNo);

    /**
     * 查询团队是否发起过冲锋号(当前季度)
     * @param teamNo
     * @return
     */
    @Query(value = "select * from team_charge_message t where t.team_no = ?1 and "+
            "  QUARTER(t.created_date)=QUARTER(now()) and  YEAR(t.created_date)=YEAR(NOW())", nativeQuery = true)
    List<TeamChargeMessage> findByTeamNo(String teamNo);

}

package com.banke.dsp.auth.dto;

import com.banke.bkc.framework.util.CodeEnum;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

/**
 * Created by ex-zhongbingguo on 2017/8/24.
 */
@Data
public class StaffInfoDTO {

    //所属系统
    private String sysId;

    //业务员编号
    private String staffNo;

    //系统用户名
    private String userId;

    //所属机构
    private String branchNo;

    //姓名
    private String staffName;

    //性别
    private String sex;

    //出生日期
    private LocalDate birthDate;

    //身份份证类型
    private String idType;

    //证件号码
    private String idNo;

    //手机号码
    private String phoneNumber;

    //邮箱
    private String email;

    //住址
    private String address;

    //入职时间
    private LocalDate entryDate;

    //离职时间
    private LocalDate resignDate;

    //备注
    private String remark;

    private List<UserRoleInfoDTO> userRoleInfos;

    /**
     * 状态
     */
    private StaffStatus staffStatus;

    public enum StaffStatus {
        /**
         * 01-正常、02-离职、03-禁用
         */
        NORMAL("01"), QUIT("02"), DISABLE("03");

        StaffStatus(String val) {
            CodeEnum.init(this, val);
        }
    }

    private String roleIds;

    /**
     * 状态
     *  /**
     * 01-正常、02-离职、03-禁用
     */
    private String status;

    private String ascription;
}

package com.banke.dsp.auth.sao;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dto.ApplyInfo;
import com.banke.dsp.auth.dto.OrderApplyInfoDto;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Describe:
 * Created by zhangyong on 2017/8/28.
 */
@FeignClient(name = "ORD-order")
public interface OrdOrderSao {

    @RequestMapping("/api/apply/findByApplyNo")
    public ResponseInfo<OrderApplyInfoDto> findByApplyNo(@RequestParam("applyNo") String applyNo);


    /**
     *
     * @return 返回数量
     */
    @RequestMapping("/api/apply/getAgentNoCnt")
    public ResponseInfo<Integer> getAgentNoCnt(@RequestParam("agentNo") String agentNo);
}

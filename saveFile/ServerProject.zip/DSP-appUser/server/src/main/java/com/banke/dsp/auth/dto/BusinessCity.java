package com.banke.dsp.auth.dto;

import java.util.Date;
import java.util.List;

import lombok.Data;

/**
 * 城市信息表
 * @author ex-panhuayu
 *
 */
@Data
public class BusinessCity {
    
    private String id;
    
    private String code;
    
    private String name;
    
    private String sortNo;
    
    private String status;
    
}

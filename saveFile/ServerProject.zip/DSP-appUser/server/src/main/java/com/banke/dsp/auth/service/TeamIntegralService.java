package com.banke.dsp.auth.service;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dao.*;
import com.banke.dsp.auth.dto.TeamStatusEnumDto;
import com.banke.dsp.auth.po.*;
import com.banke.dsp.auth.sao.OrdOrderSao;
import com.banke.dsp.auth.util.DeployUtil;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.transaction.Transactional;
import java.text.DecimalFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class TeamIntegralService {
    @NonNull
    private final TeamIntegralDao teamIntegralDao;
    @NonNull
    private final TeamMemberInfoDao teamMemberInfoDao;
    @NonNull
    private final TeamInfoDao teamInfoDao;
    @NonNull
    private TeamIntegralRankingDao teamIntegralRankingDao;
    @NonNull
    private AppUserDao appUserDao;
    @NonNull
    private TeamInfoService teamInfoService;
    @NonNull
    private AppUserService appUserService;
    @NonNull
    private OrdOrderSao ordOrderSao;
    private static final String TEAM_PM = "pm:";

    @Resource(name = "redisTemplate")
    private RedisTemplate<String, String> redisTemplate;

    /**
     * @return 新增积分
     */
    @Transactional
    public void save(String agentNo, int type) {
        log.info("agentNo:{}", agentNo);
        log.info("type:{}", type);

        if (type == 2) {
            AppUserInfo appUserInfo = appUserService.findByAgentNo(agentNo);
            if (null != appUserInfo) {
                //获取当前用户注册时间
                LocalDateTime localDateTime = appUserInfo.getCreatedAt();
                //两个时间差的天
                Duration duration = Duration.between(localDateTime, LocalDateTime.now());
                long day = duration.toDays();
                log.info("{}:用户注册到第一次推单时间为：{}", agentNo, day);
                //          2  邀请新用户：100
                //          4  新用户首次推单：200
                if (day <= 7) {
                    ResponseInfo<Integer> responseInfo = ordOrderSao.getAgentNoCnt(agentNo);
                    log.info("responseInfo:{}",responseInfo);
                    if(responseInfo.isSuccess()){
                        if(responseInfo.getData()==1){
                            type = 4;
                        }
                    }
                }
            }
        }
        // 判断团员归属于那个团队

        List<TeamMemberInfo> listTeamMemberInfo = teamMemberInfoDao.findByAgentNoAndStatusNot(agentNo, TeamStatusEnumDto.DELETE.toString());
        if (null != listTeamMemberInfo && listTeamMemberInfo.size() > 0) {
            for (TeamMemberInfo teamMemberInfo : listTeamMemberInfo) {
                TeamIntegral teamIntegral = new TeamIntegral();
                teamIntegral.setTeamNo(teamMemberInfo.getTeamNo());
                teamIntegral.setAgentNo(agentNo);
                //判断积分来源，不同来源积分增加不同
//          1  邀请新用户：100
//          2  推单：100
//          3  放款：500
//          4  新用户首次推单：200
                switch (type) {
                    case 1:
                        teamIntegral.setNewIntegral(DeployUtil.INVITE_MEMBERS_JF);
                        teamIntegral.setIntegralSource(DeployUtil.INVITE_MEMBERS_SOURCE);
                        break;
                    case 2:
                        teamIntegral.setNewIntegral(DeployUtil.SUCCESSFUL_SINGLE_DELIVERY_JF);
                        teamIntegral.setIntegralSource(DeployUtil.SUCCESSFUL_SINGLE_DELIVERY_SOURCE);
                        break;
                    case 3:
                        teamIntegral.setNewIntegral(DeployUtil.SUCCESSFUL_LOAN_JF);
                        teamIntegral.setIntegralSource(DeployUtil.SUCCESSFUL_LOAN_SOURCE);
                        break;
                    case 4:
                        teamIntegral.setNewIntegral(DeployUtil.INVITE_MEMBERS_NEW_JF);
                        teamIntegral.setIntegralSource(DeployUtil.INVITE_MEMBERS_NEW_SOURCE);
                        break;
                }
                teamIntegralDao.save(teamIntegral);
                //等级升级接口
                teamInfoService.teamGradeProcess(teamMemberInfo.getTeamNo());

            }
        }
    }

    /**
     * @param teamNo 团队编号
     * @return 获取团队积分(一个季度) 首页
     */
    public Integer getTeamIntegralSumIndex(String teamNo) {
        return teamIntegralDao.getTeamIntegralSumIndex(teamNo);
    }

    /**
     * 定时统计积分排名
     */
    @Transactional
    public void executeTeamIntegralRankingJob() {
        DecimalFormat format = new DecimalFormat("0");
        //查询积分排序进行缓存
        List<Object[]> listObjectAll = teamIntegralRankingDao.getTeamIntegralRanking();
        for (Object[] objAll : listObjectAll) {
            String pm = "0";
            String redisKey = TEAM_PM + objAll[1];
            log.info("redisKey:{}", redisKey);
            if (null != objAll[4]) {
                pm = format.format(objAll[4]);
            }
            redisTemplate.opsForValue().set(redisKey, pm, 24, TimeUnit.HOURS);   //缓存有效期24小时

        }

        //根据团队分组统计总积分
        List<Object[]> listObj = teamIntegralDao.getTeamIntegralSumOrderBy();

        if (null != listObj && listObj.size() > 0) {
            teamIntegralRankingDao.deleteAll();
            for (Object[] obj : listObj) {

                //判断是新增还是修改
                TeamIntegralRanking teamIntegralRanking = new TeamIntegralRanking();
                //总积分
                if (obj[0] != null) {
                    teamIntegralRanking.setTotalIntegral(Integer.parseInt(obj[0].toString()));
                }
                teamIntegralRanking.setTeamNo(obj[1].toString());
                TeamInfo teamInfo = teamInfoDao.findByTeamNoAndStatusNot(obj[1].toString(), TeamStatusEnumDto.DELETE.toString());
                if (null != teamInfo) {
                    teamIntegralRanking.setTeamName(teamInfo.getTeamName());
                }

                teamIntegralRankingDao.save(teamIntegralRanking);
            }
        }
    }

    //          1  邀请新用户：100
    //          2  推单：100
    //          3  放款：500
    //          4  新用户首次推单：200
    public ResponseInfo<?> teamIntegralInfo(String teamNo) {
        log.info("-------" + teamNo);
        List<Map<String, String>> listMap = new ArrayList<>();
        //查询积分详情
        List<TeamIntegral> listTeamIntegral = teamIntegralDao.getTeamIntegralInfoByTeamNo(teamNo);
        if (null != listTeamIntegral && listTeamIntegral.size() > 0) {
            for (TeamIntegral teamIntegral : listTeamIntegral) {
                String integralSorceName = "";
                String nickname = "";
                Map<String, String> map = new HashMap<>();
                String agentNo = teamIntegral.getAgentNo();
                AppUserInfo userInfo = appUserDao.findByMongoId(agentNo);
                if (null != userInfo) {
                    nickname = userInfo.getNickname();
                }
                map.put("nickName", nickname);  //昵称
                map.put("newIntegral", teamIntegral.getNewIntegral() + "");//积分
                //时间格式转换
                DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy.MM.dd");
                map.put("dateTime", df.format(teamIntegral.getCreatedDate()));//时间
                switch (teamIntegral.getIntegralSource()) {
                    case "1":
                        integralSorceName = DeployUtil.INVITE_MEMBERS;
                        break;
                    case "2":
                        integralSorceName = DeployUtil.SUCCESSFUL_SINGLE_DELIVERY;
                        break;
                    case "3":
                        integralSorceName = DeployUtil.SUCCESSFUL_LOAN;
                        break;
                    case "4":
                        integralSorceName = DeployUtil.INVITE_MEMBERS_NEW;
                        break;
                }
                map.put("integralSorceName", integralSorceName);//来源
                listMap.add(map);
            }
        }
        return ResponseInfo.success(listMap);
    }
}

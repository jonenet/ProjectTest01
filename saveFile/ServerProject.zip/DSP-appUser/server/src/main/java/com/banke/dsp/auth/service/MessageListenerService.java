package com.banke.dsp.auth.service;

import com.alibaba.fastjson.JSONObject;
import com.banke.bkc.message.annotation.MessageListener;
import com.banke.bkc.message.annotation.QueueConfig;
import com.banke.bkc.message.handler.MessageSender;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.net.InetAddress;
import java.time.LocalDateTime;

@Slf4j
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MessageListenerService {

    @NonNull
    private TeamService teamService;

    @QueueConfig(queue = "wrk.task")
    private MessageSender<JSONObject> messageSender;

    @MessageListener(queue = "dsp.appUser.task.wrk")
    public void executeJobForDelete(String group, String type, JSONObject data){
        log.info("MessageListenerService@executeJobForDelete 定时任务开始执行, group:{}, type:{}, data:{}",group, type, data);
        String executeMachine=null;
        String exceptionFlag=null;


        try {
            executeMachine = InetAddress.getLocalHost().getHostName();//获得主机名
            if("teamJobForDelete".equals(type)){
                //删除成员
                log.info("MessageListenerService@executeJobForDelete 删除成员开始");
                teamService.executeJobDeleteMember();
                log.info("MessageListenerService@executeJobForDelete 删除成员结束");

                //删除团队
                log.info("MessageListenerService@executeJobForDelete 删除团队开始");
                teamService.executeJobDeleteTeam();
                log.info("MessageListenerService@executeJobForDelete 删除团队结束");

                exceptionFlag = "执行删除任务成功" + LocalDateTime.now();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        data.put("ExceptionFlag", exceptionFlag);
        data.put("ExecuteMachine", executeMachine);
        messageSender.send("response", "JobResponse", data);
    }



    public MessageSender<JSONObject> getMessageSender() {
        return messageSender;
    }

    public void setMessageSender(MessageSender<JSONObject> messageSender) {
        this.messageSender = messageSender;
    }

}

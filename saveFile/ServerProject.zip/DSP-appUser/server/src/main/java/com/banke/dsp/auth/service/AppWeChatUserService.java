package com.banke.dsp.auth.service;

import com.alibaba.fastjson.JSONObject;
import com.banke.bkc.framework.exception.BusinessException;
import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.bkc.service.util.ContextHolder;
import com.banke.dsp.auth.dao.AppUserDao;
import com.banke.dsp.auth.dao.AppWeChatUserInfoDao;
import com.banke.dsp.auth.dao.AppWeChatUserDao;
import com.banke.dsp.auth.dto.AppWechatUserDTO;
import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.po.AppWeChatUser;
import com.banke.dsp.auth.po.AppWeChatUserInfo;
import com.banke.dsp.auth.sao.AdtWxSao;
import com.banke.dsp.auth.util.EmojiUtil;
import com.google.common.collect.Maps;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.Map;

/**
 * Created by ex-zengfanxi on 2018/02/27.
 * 微信登入服务
 */
@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AppWeChatUserService {

	@NonNull
	private final AppWeChatUserDao appWeChatUserDao;

	@Autowired
	private final AppLoginService appLoginService;

	@NonNull
	private final AppWeChatUserInfoDao appWeChatUserInfoDao;

	@NonNull
	private final AppUserDao appUserDao;

	@NonNull
	private final AdtWxSao adtWxSao;


	/**
	 *  微信登入
	 * @param request 微信用户coede 设备信息
	 * @return 是否登入绑定成功 loginSuccess Y 成功
	 * @throws BusinessException 错误信息
	 */
	@Transactional(rollbackOn = Exception.class)
	public Map<String, Object> weChatLogin(HttpServletRequest request) throws BusinessException {
		log.info("request{}",request.getParameterMap().keySet());
		String code = request.getParameter("code");
		if(StringUtils.isBlank(code)){
			throw new BusinessException("0001","code不能为空");
		}
		Map<String,Object> returnMap = Maps.newHashMap();
		//sao请求微信服务接口拿到微信用户数据
		ResponseInfo<JSONObject> returnJsonData =  adtWxSao.getAppUserInfo(code);
		if(returnJsonData.isSuccess()){
			JSONObject userInfo = returnJsonData.getData();
			String openid = userInfo.getString("openid");
			if(StringUtils.isBlank(openid)){
				throw new BusinessException("0002","openid不能为空");
			}
			AppWeChatUser appWeChatUser = appWeChatUserDao.findByOpenid(openid);
			AppWeChatUserInfo appWeChatUserInfo = appWeChatUserInfoDao.findByOpenid(openid);
			if(appWeChatUser == null){
				appWeChatUser = new AppWeChatUser();
				appWeChatUser.setSignDate(LocalDateTime.now());
			}
			appWeChatUser.setOpenid(openid);
			appWeChatUserDao.save(appWeChatUser);
			if(appWeChatUserInfo == null){
				appWeChatUserInfo = new AppWeChatUserInfo();
			}
			AppWeChatUserInfo appWeChatUserInfoNew = userInfo.toJavaObject(AppWeChatUserInfo.class);
			BeanUtils.copyProperties(appWeChatUserInfoNew, appWeChatUserInfo);
			//去除用户名中的表情 以及特殊字符
			String nickname = EmojiUtil.filterEmoji(appWeChatUserInfo.getNickname());
			log.info("微信名称nickname>{}",nickname);
			appWeChatUserInfo.setNickname(nickname);
			appWeChatUserInfoDao.save(appWeChatUserInfo);
			AppUserInfo appUserInfo =  appUserDao.findByOpenid(openid);
			returnMap.put("nickname",appWeChatUserInfo.getNickname());
			returnMap.put("headimgurl",appWeChatUserInfo.getHeadimgurl());
			returnMap.put("openid",openid);
			if(null != appUserInfo){
				//调用openid登入接口
				Map<String,Object> loginRetutnMap = appLoginService.loginByWeChat(request,openid,nickname);
				returnMap.put("loginSuccess","Y");
				returnMap.put("cellphone",appUserInfo.getCellphone());
				returnMap.putAll(loginRetutnMap);
			}else{
				returnMap.put("loginSuccess","N");
				returnMap.put("token","");
				//跳转短信注册页面 进行微信绑定
			}
		}else{
			throw new BusinessException("0001","获取微信数据失败");
		}
		return returnMap;
	}

	/**
	 * 绑定微信
	 * @param dto 微信code 用户手机号码
	 * @return 是否绑定失败bindingSuccess  Y 成功
	 * @throws BusinessException 错误信息
	 */
	@Transactional(rollbackOn = Exception.class)
	public Map<String,Object> bindingWeChat(AppWechatUserDTO dto) throws BusinessException {
		String code = dto.getCode();
		String userId = dto.getUserId();
		if(StringUtils.isEmpty(userId)){
			userId = ContextHolder.getAgentNo();
		}
		if(StringUtils.isBlank(code)){
			throw new BusinessException("0001","code不能为空");
		}
		if(StringUtils.isBlank(userId)){
			throw new BusinessException("0001","userId不能为空");
		}
		Map<String,Object> returnMap = Maps.newHashMap();
		//sao请求接口拿到数据
		//sao请求微信服务接口拿到微信用户数据

		ResponseInfo<JSONObject> returnJsonData =  adtWxSao.getAppUserInfo(code);
		if(returnJsonData.isSuccess()){
			JSONObject userInfo = returnJsonData.getData();
			String openid = userInfo.getString("openid");
			if(StringUtils.isBlank(openid)){
				throw new BusinessException("0002","openid不能为空");
			}
			AppUserInfo appUserInfo = appUserDao.findByOpenid(openid);
			if(appUserInfo!=null){
				throw new BusinessException("0003","该微信账号已被绑定请更换微信号后重试");
			}
			AppWeChatUser appWeChatUser = appWeChatUserDao.findByOpenid(openid);
			AppWeChatUserInfo appWeChatUserInfo = appWeChatUserInfoDao.findByOpenid(openid);
			if(appWeChatUser == null){
				appWeChatUser = new AppWeChatUser();
				appWeChatUser.setSignDate(LocalDateTime.now());
			}
			appWeChatUser.setOpenid(openid);
			appWeChatUserDao.save(appWeChatUser);
			if(appWeChatUserInfo == null){
				appWeChatUserInfo = new AppWeChatUserInfo();
			}
			AppWeChatUserInfo appWeChatUserInfoNew = userInfo.toJavaObject(AppWeChatUserInfo.class);
			BeanUtils.copyProperties(appWeChatUserInfoNew, appWeChatUserInfo);
			String nickname = EmojiUtil.filterEmoji(appWeChatUserInfo.getNickname());
			log.info("微信名称nickname>{}",nickname);
			appWeChatUserInfo.setNickname(nickname);
			appWeChatUserInfo.setOpenid(openid);
			appWeChatUserInfoDao.save(appWeChatUserInfo);
			appUserInfo =  appUserDao.findByMongoId(userId);
			appUserInfo.setOpenid(openid);
			appUserInfo.setNickname(appWeChatUserInfo.getNickname());
			appUserDao.save(appUserInfo);
			//调用openid登入接口
			returnMap.put("bindingSuccess","Y");
			returnMap.put("nickname",appWeChatUserInfo.getNickname());
			returnMap.put("headimgurl",appWeChatUserInfo.getHeadimgurl());
			returnMap.put("openid",openid);
			returnMap.put("cellphone",appUserInfo.getCellphone());
		}else{
			throw new BusinessException("0001","获取微信数据失败");
		}
		log.info("成功后返回的数据----------------------------------{}",JSONObject.toJSONString(returnMap));
		return returnMap;
	}


}

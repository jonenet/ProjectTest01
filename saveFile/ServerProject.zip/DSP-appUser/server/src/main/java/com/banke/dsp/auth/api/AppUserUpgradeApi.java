package com.banke.dsp.auth.api;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dto.SendOtpCodeDto;
import com.banke.dsp.auth.dto.UpgradeUserRequest;
import com.banke.dsp.auth.service.AppUserUpgradeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by ex-zhongbingguo on 2017/9/5.
 */
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/upgrade", method = {RequestMethod.GET, RequestMethod.POST})
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AppUserUpgradeApi {

    @Autowired
    private AppUserUpgradeService appUserUpgradeService;

    /**
     * 新版补全高级用户资料
     */
    @RequestMapping("/new2")
    public ResponseInfo<?> uploadSuperAgentNew(@RequestBody UpgradeUserRequest request) {
        return appUserUpgradeService.uploadSuperAgentNew(request);
    }

    /**
     * 升级高级用户
     */
    @RequestMapping(value = "/userUpgrade")
    public ResponseInfo<?> userUpgrade(HttpServletRequest request){
        return appUserUpgradeService.userUpgrade();
    }

    /**
     * 新版升级高级用户（微服务调用）
     */
    @RequestMapping(value = "/userUpgradeToMicroService")
    public ResponseInfo<?> userUpgradeToMicroService(@RequestParam String agentNo, String status) throws Exception{
        return appUserUpgradeService.userUpgradeToMicroService(agentNo, status);
    }

    /**
     * 升级高级用户OTP验证码
     */
    @RequestMapping("/sendOtpCode")
    public ResponseInfo<?> sendOtpCode(@RequestBody SendOtpCodeDto sendOtpCode){
        String cellphone = sendOtpCode.getCellphone();
        log.info("sendOtpCode cellphone is : {}", cellphone);
        if(StringUtils.isEmpty(cellphone)){
            return ResponseInfo.error("手机号不能为空");
        }
        appUserUpgradeService.sendOtpCode(cellphone);
        return ResponseInfo.success("1");
    }

    @RequestMapping("/checkVerifyCode")
    public ResponseInfo<?> checkVerifyCode(String cellphone, String passCode){
        return appUserUpgradeService.checkVerifyCode(cellphone, passCode);
    }

}

package com.banke.dsp.auth.service;

import com.banke.bkc.message.annotation.MessageListener;
import com.banke.dsp.auth.dto.OrderInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

/**
 * Created by ex-taozhangyi on 2018/3/1.
 * 推单成功奖励积分500
 */
@Service
@Slf4j
public class LoanListenerService {
    @Autowired
    private TeamIntegralService teamIntegralService;

    @Transactional
    @MessageListener(queue = "dsp.appuser.sync.ord.order.status.fff")
    public void process(String group, String type, OrderInfo data) {
        log.info("dsp.appuser.sync.ord.order.status.fff接收放款成功任务:{},{},{}", group, type, data);
        if(null != data){
            log.info("订单状态："+data.getOrderStatus().toString());
            if(OrderInfo.Status.FINISH.equals(data.getOrderStatus())){
                teamIntegralService.save(data.getAgentNo(),3);
                log.info("放款成功，新增积分500");
            }
        }
    }
}

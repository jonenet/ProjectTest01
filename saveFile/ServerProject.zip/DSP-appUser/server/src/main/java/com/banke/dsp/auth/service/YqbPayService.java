package com.banke.dsp.auth.service;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dao.AppWalletDao;
import com.banke.dsp.auth.po.WalletInfo;
import com.banke.dsp.auth.sao.AdtYqbSao;
import com.banke.dsp.auth.sao.FtsPaySao;
import feign.FeignException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

/*
 * Created by ex-lingsuzhi on 2018/3/23.
 *
 */
@Slf4j
@Service
public class YqbPayService {
    @Autowired
    private AdtYqbSao adtYqbSao;//壹钱宝
    @Autowired
    private FtsPaySao ftsPaySao;
    @Autowired
    private AppWalletDao appWalletDao;

    /**
     * 获取可提现金额
     *
     * @param agentNo
     * @return
     */
    public String getBalance(String agentNo) {
        log.info("查询可体现余额");

        //获取壹钱宝token
        WalletInfo walletInfo = appWalletDao.findByMid(agentNo);
        if (walletInfo == null) {
            log.info("获取壹钱宝token 失败，agentNo：{}", agentNo);
            return null;
        }
        String token = walletInfo.getToken();

        //获取可提现余额
        try {
            ResponseInfo<Long> info = adtYqbSao.getBalance(token);
            if (info.isSuccess() && info.getData() != null) {
                Long aLong = info.getData();
                //返回单位为分，转换为元
                BigDecimal bigDecimal = new BigDecimal(aLong);
                bigDecimal = bigDecimal.divide(new BigDecimal(100));
                return bigDecimal.setScale(2,BigDecimal.ROUND_HALF_UP).toString();
            }
        } catch (FeignException e) {
            log.error("查询可提现余额 失败FeignException 参数token：{}", token);
        }
        return null;
    }

    /**
     * 查询佣金计算中的金额
     */
    public String findPaySumAmount(String agentNo) {
        log.info("查询佣金计算中的金额");
        try {
            ResponseInfo<BigDecimal> info = ftsPaySao.findPaySumAmount(agentNo);
            if (info.isSuccess() && info.getData() != null) {
                BigDecimal bigDecimal = info.getData();
                if (bigDecimal != null) {
                    return bigDecimal.setScale(2,BigDecimal.ROUND_HALF_UP).toString();
                }
            }
        } catch (FeignException e) {
            log.error("查询佣金失败参数 agentNo： {} ", agentNo);
        }
        return null;
    }
}

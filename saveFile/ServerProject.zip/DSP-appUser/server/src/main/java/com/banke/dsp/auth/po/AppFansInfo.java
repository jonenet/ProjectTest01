package com.banke.dsp.auth.po;

import com.banke.bkc.framework.po.BasePO;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * Created by luoyifei on 2017/7/4.
 */

@Data
@NoArgsConstructor
@RequiredArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "app_fans_info")
public class AppFansInfo extends BasePO {

    @NonNull
	@Column
    private Long id;

    @NonNull
	@Column(nullable = true, length = 2)
    private String subscribe;

    @NonNull
	@Column(nullable = true, length = 36)
    private String openid;

    @NonNull
	@Column(nullable = true, length = 50)
    private String nickname;

    @NonNull
	@Column
    private Integer sex;

    @NonNull
	@Column(nullable = true, length = 30)
    private String city;

    @NonNull
	@Column(nullable = true, length = 50)
    private String country;

    @NonNull
	@Column(nullable = true, length = 50)
    private String province;

    @NonNull
	@Column(nullable = true, length = 30)
    private String language;

    @NonNull
	@Column(nullable = true, length = 500)
    private String headimgurl;

    @NonNull
	@Column
    private Long subscribe_time;

    @NonNull
	@Column
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime subscribe_date;

    @NonNull
	@Column(nullable = true, length = 50)
    private String unionid;

    @NonNull
    @Column(nullable = true, length = 500)
	private String remark;

    @NonNull
    @Column
	private Integer groupid;

    @NonNull
    @Column(nullable = true, length = 1)
	private String state;

    @NonNull
    @Column
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime first_subcribe_time;

    @Column(nullable = true, length = 50)
    private String sourceOne;

    @Column(nullable = true, length = 50)
    private String sourceTwo;
}

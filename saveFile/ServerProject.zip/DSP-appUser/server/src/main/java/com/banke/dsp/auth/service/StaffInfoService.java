package com.banke.dsp.auth.service;

import com.alibaba.fastjson.JSONObject;
import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dto.StaffInfoDTO;
import com.banke.dsp.auth.dto.StaffInfoRoleEnum;
import com.banke.dsp.auth.dto.UserRoleInfoDTO;
import com.banke.dsp.auth.sao.WrkStaffSao;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 人员信息SAO service
 * Created by ex-zhongbingguo on 2017/8/22.
 */
@Service
@Slf4j
class StaffInfoService {

    @Autowired
    private WrkStaffSao wrkStaffSao;

    /**
     *  根据用户id，获取客户经理
     */
    StaffInfoDTO getCustomerManagerByUserId(String userId){
        ResponseInfo<StaffInfoDTO> response = wrkStaffSao.getStaffInfoByUserId(userId.toLowerCase());
        log.info("result to DevOpsUser: {}", JSONObject.toJSONString(response));
        StaffInfoDTO dto = null;
        if (response != null && response.isSuccess() && response.getData() != null){
            List<UserRoleInfoDTO> userRoleInfos = response.getData().getUserRoleInfos();
            if (CollectionUtils.isNotEmpty(userRoleInfos)){
                for (UserRoleInfoDTO role : userRoleInfos){
                    if (StaffInfoRoleEnum.B_GPS.getCode().equals(role.getRoleId())){
                        dto = response.getData();
                    }
                }
            }
        }
        return dto;
    }

    /**
     *  根据用户id，获取人员信息
     * @param userId    用户id
     * @return          人员信息
     */
    StaffInfoDTO getStaffInfoByUserId(String userId){
        ResponseInfo<StaffInfoDTO> response = wrkStaffSao.getStaffInfoByUserId(userId.toLowerCase());
        log.info("result to DevOpsUser: {}", JSONObject.toJSONString(response));
        if (response.isSuccess()){
           return response.getData();
        }
        return null;
    }


    /**
     *  根据角色id 和 组织机构编号 获取人员列表
     * @param roleId    角色id
     * @param branchNo  组织机构编号
     * @return          人员列表
     */
    List<StaffInfoDTO> getStaffInfoByBranchNo(String roleId, String branchNo){
        ResponseInfo<List<StaffInfoDTO>> response = wrkStaffSao.queryStaffInfo(roleId, branchNo, null,null);
        List<StaffInfoDTO> list = Lists.newArrayList();
        if (response !=null && response.isSuccess() && response.getData() != null){
            for (StaffInfoDTO dto : response.getData()){
                list.add(dto);
            }
        }
        return list;
    }

    /**
     *  根据角色id 和 组织机构编号 获取虚拟客户经理
     * @param roleId    角色id
     * @param branchNo  组织机构编号
     * @return          虚拟客户经理
     */
    StaffInfoDTO getVirtualStaffInfoDTOByBranchNo(String roleId, String branchNo){
        ResponseInfo<List<StaffInfoDTO>> response = wrkStaffSao.queryStaffInfo(roleId, branchNo, "","");
        if (response !=null && response.isSuccess() && response.getData() != null){
            for (StaffInfoDTO dto : response.getData()){
                if (dto.getStaffName().contains("虚拟客户经理")){
                    return dto;
                }
            }
        }
        return null;
    }

    /**
     *  根据组织机构编号，查询其下的所有地推人员userId
     */
    List<String> getUserIds(String branchNo){
        ResponseInfo<List<StaffInfoDTO>> response = wrkStaffSao.getStaffInfoByBranchNo(branchNo);
        List<String> list = Lists.newArrayList();
        if (response !=null && response.isSuccess() && response.getData() != null){
            for (StaffInfoDTO dto : response.getData()){
                List<UserRoleInfoDTO> userRoleInfos = dto.getUserRoleInfos();
                if (CollectionUtils.isNotEmpty(userRoleInfos)){
                    for (UserRoleInfoDTO role : userRoleInfos){
                        if ( StaffInfoRoleEnum.B_GPS.getCode().equals(role.getRoleId())){
                            // appUser 中 referrer 可能是大小写 混合的
                            list.add(dto.getUserId().toUpperCase());
                            list.add(dto.getUserId().toLowerCase());
                        }
                    }
                }
            }
        }
        return list;
    }

}

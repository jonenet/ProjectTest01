package com.banke.dsp.auth.sao;

import com.alibaba.fastjson.JSONObject;
import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dto.BankImageDTO;
import com.banke.dsp.auth.dto.RegisterConstraintInstenceDTO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Created by ex-zhongbingguo on 2018/2/24.
 */
@FeignClient(value = "DSP-config")
public interface DspConfigSao {

    /**
     *  查询手机归属
     * @param mobile 手机号
     * @return        归属对象
     */
    @RequestMapping("/api/mobile/ascription/findByMobile")
    ResponseInfo<JSONObject> findByMobile(@RequestParam("mobile")String mobile);

    /**
     *  根据省份和城市名称查询 cityId
     * @param province 省份
     * @param city      城市
     * @return          cityId
     */
    @RequestMapping("/api/branchInfo/getCityCode")
    ResponseInfo<String> getCityCode(@RequestParam("province") String province, @RequestParam("city") String city);

    /**
     *  获取图片完整路径
     * @param imgId 图片UUID
     * @param type  类型： phone 手机端  web WEB 端 (针对Mysql中的图片)
     * @return
     */
    @RequestMapping("/api/getImgUrl")
    ResponseInfo<String> getImgUrl(@RequestParam("imgId")String imgId, @RequestParam("type")String type);

    /**
     * 根据银行code查询银行图片对象
     * @param bankCode 银行code
     * @return      银行图片对象
     */
    @RequestMapping("/api/bankImage/view")
    ResponseInfo<BankImageDTO> view(@RequestParam(name="bankCode") String bankCode);

    /**
     *  根据邀请码查询邀请码实例
     * @param registerCode
     * @return
     */
    @RequestMapping("/api/register/findRCIByRegisterCode")
    ResponseInfo<RegisterConstraintInstenceDTO> findRCIByRegisterCode(@RequestParam(name = "registerCode") String registerCode);

    /**
     *  邀请码+1
     * @param id  邀请码实例
     * @return    邀请码实例
     */
    @RequestMapping("/api/register/upUsedCount")
    ResponseInfo<?> upUsedCount(@RequestParam(name = "id") Long id);

    /**
     *  根据城市code查询城市业务城市规则
     * @param cityCode 城市code
     * @return          虚拟创新营销部编号
     */
    @RequestMapping("/api/CityCompany/findCompanyCode")
    ResponseInfo<String> findCompanyCode(@RequestParam(name = "cityCode") String cityCode);
}

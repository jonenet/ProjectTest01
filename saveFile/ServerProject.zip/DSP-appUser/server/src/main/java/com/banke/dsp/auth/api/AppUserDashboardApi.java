package com.banke.dsp.auth.api;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dto.AppUserDetailRequest;
import com.banke.dsp.auth.dto.AppUserManageRequest;
import com.banke.dsp.auth.dto.AppUserQueryParameter;
import com.banke.dsp.auth.service.AppUserDashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by ex-zhongbingguo on 2017/8/21.
 */
@RestController
@RequestMapping(value = "/api/dashboard/appusers", method = {RequestMethod.GET, RequestMethod.POST})
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AppUserDashboardApi {

    @Autowired
    private AppUserDashboardService dashboardService;

    /**
     * 查询用户列表
     * @param request   请求对象
     * @return Object   响应对象
     */
    @RequestMapping("/list")
    public ResponseInfo<?> list(AppUserQueryParameter request) {
        return ResponseInfo.success(dashboardService.listData(request));
    }

    /**
     *  用户管理
     * @param request   请求对象
     * @return  object   响应对象
     */
    @RequestMapping("/manage")
    public ResponseInfo<?> saveManage(AppUserManageRequest request){
        return dashboardService.saveManage(request);
    }

    /**
     * 信息变更
     * @param request  请求对象
     * @return Object   响应对象
     */
    @RequestMapping("/detail")
    public ResponseInfo<?> saveDetail(AppUserDetailRequest request) {
        return dashboardService.saveDetail(request);
    }

    /**
     *  禁止/激活进件
     * @param id           主键id
     * @return             ResponseInfo<AppUserInfo>
     */
    @RequestMapping("/enableRecommendation")
    public ResponseInfo<?> enableRecommendation(@RequestParam Long id, @RequestParam Boolean enableEecommendation) {
        return dashboardService.enableRecommendation(id, enableEecommendation);
    }

    /**
     *  初始化业务城市/工作 信息
     * @return 业务城市/工作列表
     */
    @RequestMapping("/initBusinessCity")
    public ResponseInfo<?> initBusinessCity(@RequestParam String sysId, @RequestParam String type){
        return ResponseInfo.success(dashboardService.initBusinessCity(sysId, type));
    }

    /**
     * 根据所属机构获取所有地推人员，排除团队长
     * @param branchNo  机构编号
     * @return           地推人员/团队长列表
     */
    @RequestMapping("/getStaffInfoByBranchNo")
    public ResponseInfo<?> getStaffInfoByBranchNo(@RequestParam String branchNo){
        return ResponseInfo.success(dashboardService.getStaffInfoByBranchNo(branchNo));
    }

    /**
     *  根据 branchNo 获取 分公司 业务编码
     * @param branchNo    branchNo
     * @return            分公司业务编码
     */
    @RequestMapping("/getBusinessCity")
    public ResponseInfo<?> getBusinessCity(@RequestParam String branchNo){
        return dashboardService.getBusinessCity(branchNo);
    }

    /**
     *  excel导出 <隐藏该功能>
     * @param request   请求对象
     * @return Object   ResponseInfo<?>
     */
    @RequestMapping("/listDown")
    public ResponseInfo<?> listDowsn(AppUserQueryParameter request) {
        request.setPageNum(-1);
        return ResponseInfo.success(dashboardService.listData(request));
    }

    /**
     * 批量导入修改客户经理
     * @param flag      1：修改客户经理 2：修改信用用户标志
     * @param reqeust   HttpServletRequest
     * @return          true/false
     */
    @RequestMapping("/batchUpdateReferer")
    public ResponseInfo<?> batchUpdateReferer(String flag, HttpServletRequest reqeust) {
        return dashboardService.batchUpdateReferer(flag, reqeust);
    }


    /**
     * 批量修改客户信用标志
     * @param flag         1：修改客户经理 2：修改信用用户标志
     * @param reqeust      HttpServletRequest
     * @return              ture/false
     */
    @RequestMapping("/batchUpdateIscredit")
    public ResponseInfo<?> batchUpdateIscredit(String flag, HttpServletRequest reqeust) {
        return dashboardService.batchUpdateIscredit(flag, reqeust);
    }

    /**
     * 根据条件查询用户分页结果集(其他服务调用)
     * @param request  enabled/pageNum/pageSize/userType/ascription/ascriptionStatus/businessCityid
     * @return      PageResult
     */
    @RequestMapping("/listToPush")
    public ResponseInfo<?> listToPush(@RequestBody AppUserQueryParameter request) {
        return dashboardService.listToPush(request);
    }
}

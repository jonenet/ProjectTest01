package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.po.ScoreDetails;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by ex-zhongbingguo on 2017/11/2.
 */
public interface ScoreDetailsDao extends CrudRepository<ScoreDetails, Long> {
}

package com.banke.dsp.auth.dto;

import lombok.Data;

/**
 * Created by ex-zhongbingguo on 2018/2/28.
 */
@Data
public class SmsOtpDTO {

    private String mobileNo; //手机号码

    private String templetNo; // 模板编号

    private String effectiveTime; // 有效时间 （分钟）

    private String messageType; // 消息类型 1-短信 2-语音

    public SmsOtpDTO() {
    }

    public SmsOtpDTO(String mobileNo, String templetNo, String effectiveTime, String messageType) {
        this.mobileNo = mobileNo;
        this.templetNo = templetNo;
        this.effectiveTime = effectiveTime;
        this.messageType = messageType;
    }
}

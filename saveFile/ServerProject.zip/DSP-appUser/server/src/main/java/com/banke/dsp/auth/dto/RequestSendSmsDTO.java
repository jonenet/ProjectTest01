package com.banke.dsp.auth.dto;

import lombok.Data;
import org.hibernate.validator.constraints.NotBlank;

@Data
public class RequestSendSmsDTO {
	@NotBlank
	private String mobileNO;
	
	@NotBlank
	private String message;

	//短信签名
	private String subCode;

	//1 文字短信
	//2 语音短信
	@NotBlank
	private String messageType;
}

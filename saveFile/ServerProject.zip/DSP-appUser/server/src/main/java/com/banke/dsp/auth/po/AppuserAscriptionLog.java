package com.banke.dsp.auth.po;

import com.banke.bkc.framework.po.BasePO;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Created by ex-zhongbingguo on 2018/1/9.
 */
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "appuser_ascription_log")
public class AppuserAscriptionLog extends BasePO {

    private String agentNo;

    private String oldAscription;

    private String newAscription;

    private String remark;
}

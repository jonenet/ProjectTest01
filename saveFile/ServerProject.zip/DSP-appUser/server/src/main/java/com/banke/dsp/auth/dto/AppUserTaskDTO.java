package com.banke.dsp.auth.dto;

import lombok.Data;

/**
 *  用户任务详情
 * Created by ex-zhongbingguo on 2018/3/16.
 */
@Data
public class AppUserTaskDTO {

    /**mongId*/
    private String mongoId;

    /**注册地*/
    private String registerCity;

    /**注册地id*/
    private String registerCityid;

    /**注册时间*/
    private String createdAt;

    /**分公司id*/
    private String businessCityid;

    /**客户经理*/
    private String referrer;

    /**客户经理姓名*/
    private String	refererName;

    /**是否绑定微信*/
    private Boolean hasWeChat;

    /**渠道类型*/
    private String source;

    /**姓名*/
    private String realName;

    //手机号码
    private String cellphone;

    /**身份证号*/
    private String identityNumber;

    /**性别*/
    private String sex;

    /**婚姻状况*/
    private String marriage;

    //收入水平
    private String incomeLevel;

    //用户行业
    private String userIndustry;

    //居住地址
    private String liveProvince;
    private String liveCity;
    private String liveArea;
    private String liveAddress;

    //工作地址
    private String workProvince;
    private String workCity;
    private String workArea;
    private String workAddress;

}

package com.banke.dsp.auth.sao;

import com.banke.bkc.framework.util.ResponseInfo;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by ex-lingsuzhi on 2018/03/23.
 */
@FeignClient(name = "FTS-pay")
public interface FtsPaySao {

	@RequestMapping("/api/pay/findPaySumAmount")//丁家辉
	public ResponseInfo<BigDecimal>findPaySumAmount(@RequestParam(value = "agentNo") String agentNo);

	}

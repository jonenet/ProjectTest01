package com.banke.dsp.auth.dto;

import lombok.Data;

@Data
public class AppUserQueryResult {

	private Long id;

	//用户名
	private String userName;

	//地推人员
	private String 	refererName;

	//referrer
	private String referrer;

	//用户真实名
	private String realName;

	//推荐人手机号
	private String refMobilePhone;

	//手机号
	private String cellphone;

	//身份证号
	private String identityNumber;

	//用户星级
	private Integer star;

	//是否集团用户
	private String groupFlag;

	//所属集团
	private String groupName;

	//公司名称
	private String companyName;

	//推广方式
	private String popularizeTypeId;

	//注册时间
	private String createdDataAt;

	// 状态
	private String enabledDes;

	//是否有效
	private Boolean enabled;

	// 业务城市
	private String businessCityName;

	//  业务城市code
	private String businessCityid;

	//注册城市
	private String registerCityName;

	//类别
	private String userType;

	private String ascription;

	private Boolean ascriptionStatus;

	private String ascriptionStatusDesc;
	/****信息变更页 ****/

	//银行账户名
	private String bankAccountName;

	//银行卡号
	private String bankCardNumber;

	//银行编码
	private String bankId;

	//银行机构 分行
	private String bankBranchId;

//	//地址
//	private String address;

	//是否是授信标志
	private String iscredit;

	//是否是授信标志描述
	private String iscreditDes;

	//用户进件权限
	private Boolean enableEecommendation;

	//用户角色
	private String role;

	//注册城市
	private String registerCityid;

	//归属城市
	private String ascriptionCityid;

	//是否绑定微信
	private Boolean hasWeChat;

	// 用户来源
	private String source;

	//是否高级用户
	private Boolean superAgent;


	//居住地址
	private String liveProvince;
	private String liveCity;
	private String liveArea;
	private String liveAddress;

	//工作地址
	private String workProvince;
	private String workCity;
	private String workArea;
	private String workAddress;

	//性别,M:男；F:女
	private String sex;

	//婚姻状况,S:未婚;M:已婚
	private String marriage;

	//收入水平01-05
	private String incomeLevel;

	//用户行业
	private String userIndustry;

}

package com.banke.dsp.auth.api;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dto.AppFansDto;
import com.banke.dsp.auth.dto.AppUser;
import com.banke.dsp.auth.po.AppFansInfo;
import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.service.AppUserForgetPasswordService;
import com.banke.dsp.auth.service.AppUserResgisterService;
import com.banke.dsp.auth.service.AppUserService;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.*;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping(value = "/api/", method = {RequestMethod.GET, RequestMethod.POST})
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AppUserApi {

    @NonNull
    private final AppUserService appUserService;

    @NonNull
    private final AppUserResgisterService appUserResgisterService;

    @NonNull
    private final AppUserForgetPasswordService appUserForgetPasswordService;

    /**
     * disp token查询用户信息
     * * @param token
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("/findToken")
    public ResponseInfo<?> findTokenByAppUserInfo(@RequestParam String token) {
        return appUserService.findTokenByAppUserInfo(token);
    }

    /**
     * 登录效验用户信息
     * * @param userName
     *
     * @param passWord
     * @return
     * @throws UnsupportedEncodingException
     * @throws NoSuchAlgorithmException
     * @throws Exception
     */
    @RequestMapping("/AppUserAuth")
    public ResponseInfo<?> AppUserAuth(@RequestParam String userName, @RequestParam String passWord) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        return appUserService.appUserAuth(userName, passWord);
    }

    /**
     * mongId查询用户信息
     * * @param mongoId
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("/findByMongoId")
    public ResponseInfo<?> findByMongoId(@RequestParam String mongoId) {
        log.info("findByMongoId-->mongoId:{}",mongoId);
        return appUserService.findByMongoId(mongoId);
    }

    /**
     * 同步保存用户信息
     *
     * @param appUser
     * @return
     * @throws Exception
     */
    @RequestMapping("/saveAppuser")
    public ResponseInfo<?> saveAppuser(@RequestBody AppUser appUser) {
        return appUserService.saveAppuser(appUser);
    }


    /**
     * 通过手机号查询客户信息
     *
     * @param cellPhone
     * @return
     */
    @RequestMapping("findByCellphone")
    public ResponseInfo<?> findByCellphone(@RequestParam(name = "cellPhone") String cellPhone) {
        return ResponseInfo.success(appUserService.findByCellphone(cellPhone));
    }

    /**
     * 小程序根据openid查询用户信息
     *
     * @param openid
     * @return
     */
    @RequestMapping("/findByOpenid")
    public ResponseInfo<?> findByOpenid(@RequestParam String openid) throws Exception {
        return appUserService.findByOpenid(openid);
    }

    /**
     * 根据userId查询小程序用户信息
     *
     * @param userId
     * @return
     * @throws Exception
     */
    @RequestMapping("/findByUserId")
    public ResponseInfo<?> findByUserId(@RequestParam Long userId) throws Exception {
        return appUserService.findByUserId(userId);
    }

    /**
     * 根据userId查询用户信息
     *
     * @param userId
     * @return
     * @throws Exception
     */
    @RequestMapping("/findAppUserInfoByUserId")
    public ResponseInfo<?> findAppUserInfoByUserId(@RequestParam Long userId) throws Exception {
        return appUserService.findAppUserInfoByUserId(userId);
    }

    /**
     * 根据token查询小程序用户信息
     *
     * @param token
     * @return
     * @throws Exception
     */
    @RequestMapping("/findMiniAppUserInfoByToken")
    public ResponseInfo<?> findMiniAppUserInfoByToken(@RequestParam String token) throws Exception {
        return appUserService.findMiniAppUserInfoByToken(token);
    }

    /**
     * 小程序注册时发送短信验证码
     *
     * @param telphone
     * @param requestId
     * @return
     */
    @RequestMapping("/sendRegisterPasscode")
    public ResponseInfo<?> sendRegisterPasscode(@RequestParam("telphone") String telphone, @RequestParam("requestId") String requestId) throws Exception {
        return appUserResgisterService.sendRegisterPasscode(telphone, requestId);
    }

    /**
     * 小程序注册接口
     *
     * @param telphone
     * @param requestId
     * @param passCode
     * @param password
     * @return
     */
    @RequestMapping("/register")
    public ResponseInfo<?> register(@RequestParam("telphone") String telphone, @RequestParam("requestId") String requestId, @RequestParam("passCode") String passCode, @RequestParam("password") String password, @RequestParam("name") String name, @RequestParam String source, @RequestParam String openid, @RequestParam String avatarUrl, @RequestParam String city, @RequestParam String gender, @RequestParam String nickName, @RequestParam String province, @RequestParam String latitude, @RequestParam String longitude, @RequestParam String encryptedData, @RequestParam("session_key") String session_key, @RequestParam("iv") String iv) throws Exception {
        return appUserResgisterService.register(telphone, requestId, passCode, password, name, source, openid, avatarUrl, city, gender, nickName, province, latitude, longitude, encryptedData, session_key, iv);
    }

    /**
     * 小程序忘记密码时发送短信验证码
     *
     * @param telphone
     * @param requestId
     * @return
     */
    @RequestMapping("/sendForgetPasswordPasscode")
    public ResponseInfo<?> sendForgetPasswordPasscode(@RequestParam("telphone") String telphone, @RequestParam("requestId") String requestId) throws Exception {
        return appUserForgetPasswordService.sendForgetPasswordPasscode(telphone, requestId);
    }

    /**
     * 小程序重置密码
     *
     * @param telphone
     * @param requestId
     * @param passCode
     * @param password
     * @return
     */
    @RequestMapping("resetPassword")
    public ResponseInfo<?> resetPassword(@RequestParam("telphone") String telphone, @RequestParam("requestId") String requestId, @RequestParam("passCode") String passCode, @RequestParam("password") String password) throws Exception {
        return appUserForgetPasswordService.resetPassword(telphone, requestId, passCode, password);
    }

    /**
     * 完善个人资料
     *
     * @param identityNumber
     * @param realName
     * @return
     */
    @RequestMapping("perfectData")
    public ResponseInfo<?> perfectData(@RequestParam("identityNumber") String identityNumber, @RequestParam("realName") String realName) throws Exception {
        return appUserService.perfectData(identityNumber, realName);
    }

    /**
     * 根据小程序header中的token获取用户所有信息
     *
     * @return
     */
    @RequestMapping("getUserInfo")
    public ResponseInfo<?> getUserInfo() throws Exception {
        return appUserService.getUserInfo();
    }

    /**
     * 根据app header中的token获取用户信息
     * @return
     * @throws Exception
     */
    @RequestMapping("getAppUserInfo")
    public ResponseInfo<?> getAppUserInfo() throws Exception {
        return appUserService.getAppUserInfo();
    }

    /**
     * 小程序校验登录用户信息
     *
     * @param userName
     * @param passWord
     * @param source
     * @param openid
     * @param avatarUrl
     * @param city
     * @param gender
     * @param nickName
     * @param province
     * @return
     * @throws Exception
     */
    @RequestMapping("/miniAppUserAuth")
    public ResponseInfo<?> miniAppUserAuth(@RequestParam String userName, @RequestParam String passWord, @RequestParam String source, @RequestParam String openid, @RequestParam String avatarUrl, @RequestParam String city, @RequestParam String gender, @RequestParam String nickName, @RequestParam String province, @RequestParam String latitude, @RequestParam String longitude, @RequestParam String encryptedData, @RequestParam("session_key") String session_key, @RequestParam("iv") String iv) throws Exception {
        return appUserService.miniAppUserAuth(userName, passWord, source, openid, avatarUrl, city, gender, nickName, province, latitude, longitude, encryptedData, session_key, iv);
    }

    @RequestMapping("/getMiniAppUserInfoList")
    public ResponseInfo<?> getMiniAppUserInfoList(@RequestParam(value = "cellphone", required = false) String cellphone, @RequestParam(name = "pageNumber") int pageNumber,@RequestParam(name = "pageSize") int pageSize) throws Exception {
        return appUserService.getMiniAppUserInfoList(cellphone, pageNumber, pageSize);
    }

    @RequestMapping("/saveAllUserInfoWithUnionID")
    public void saveAllUserInfoWithUnionID(@RequestParam("openid") String openid) throws Exception {
        appUserService.saveAllUserInfoWithUnionID(openid);
    }

    @RequestMapping("/saveWxFansUserInfo")
    public ResponseInfo<?> saveWxFansUserInfo(@RequestBody AppFansDto appFansDto) throws Exception {
        appUserService.saveWxFansUserInfo(appFansDto);
        return ResponseInfo.success(null);
    }

    /**
     * @param userId
     * @return
     * @throws Exception 根据userId获取公众号openid
     */
    @RequestMapping("/getWxOpenidByUserId")
    public ResponseInfo<?> getWxOpenidByUserId(@RequestParam("userId") Long userId) throws Exception {
        return appUserService.getWxOpenidByUserId(userId);
    }

    @RequestMapping("/synchronizeUserInfo")
    public void synchronizeUserInfo() {
        String next_openid = "";
        appUserService.synchronizeUserInfo(next_openid);
    }

    /**
     * 公众号用户注册
     *
     * @param telphone
     * @param requestId
     * @param passCode
     * @param password
     * @param name
     * @param source
     * @param openid
     * @param avatarUrl
     * @param city
     * @param gender
     * @param nickName
     * @param province
     * @param unionid
     * @return
     * @throws Exception
     */
    @RequestMapping("/publicRegister")
    public ResponseInfo<?> publicregister(@RequestParam("telphone") String telphone, @RequestParam("requestId") String requestId, @RequestParam("passCode") String passCode, @RequestParam("password") String password, @RequestParam("name") String name, @RequestParam String source, @RequestParam String openid, @RequestParam String avatarUrl, @RequestParam String city, @RequestParam String gender, @RequestParam String nickName, @RequestParam String province, @RequestParam String unionid) throws Exception {
        return appUserResgisterService.publicregister(telphone, requestId, passCode, password, name, source, openid, avatarUrl, city, gender, nickName, province, unionid);
    }

    /**
     * 根据openid判断是不是注册用户
     *
     * @param openid
     * @param unionid
     * @return
     * @throws Exception
     */
    @RequestMapping("/validPublicRegister")
    public ResponseInfo<?> validpublicregister(@RequestParam("openid") String openid, @RequestParam("unionid") String unionid) throws Exception {
        return appUserResgisterService.validpublicregister(openid, unionid);
    }

    /**
     * 公众号登录接口
     *
     * @param userName
     * @param passWord
     * @param source
     * @param openid
     * @return
     * @throws Exception
     */
    @RequestMapping("/publicAppUserAuth")
    public ResponseInfo<?> publicAppUserAuth(@RequestParam String userName, @RequestParam String passWord, @RequestParam String source, @RequestParam String openid, @RequestParam String avatarUrl, @RequestParam String city, @RequestParam String gender, @RequestParam String nickName, @RequestParam String province, @RequestParam String unionid) throws Exception {
        return appUserService.publicAppUserAuth(userName, passWord, source, openid, avatarUrl, city, gender, nickName, province, unionid);
    }


    /**
     * 根据业务员手机号码获取mongoId
     *
     * @param cellphone
     * @return
     */
    @RequestMapping("/getMongoId")
    public ResponseInfo<?> getMongoId(@RequestParam("cellphone") String cellphone) {
        return ResponseInfo.success(appUserService.getMongoId(cellphone));
    }


    /**
     * 根据业务员编号查询业务员手机号码和权限码
     *
     * @param agentNoList
     * @return
     * @throws Exception
     */
    @RequestMapping("/findByAgentNoList")
    ResponseInfo<?> findByAgentNoList(@RequestParam(name = "agentNoList") List<String> agentNoList) {
        return ResponseInfo.success(appUserService.findByAgentNoList(agentNoList));
    }

    /**
     * 分页获取微信公众号的所有用户
     * @param pageNumber
     * @param pageSize
     * @return
     */
    @RequestMapping("/findWxPublicUser")
    ResponseInfo<?> findWxPublicUser(@RequestParam(name = "pageNumber") int pageNumber,@RequestParam(name = "pageSize") int pageSize) {
        return ResponseInfo.success(appUserService.findWxPublicUser(pageNumber,pageSize));
    }
    /**
     * 通过openid获取公众号用户
     * @param openid
     * @return
     */
    @RequestMapping("/findWxPublicUserByOpenid")
    ResponseInfo<?> findWxPublicUserByOpenid(@RequestParam(name="openid") String openid) {
        return ResponseInfo.success(appUserService.findWxPublicUserByOpenid(openid));
    }

    @RequestMapping("/findAll")
    ResponseInfo<List<AppUserInfo>> findAll(@RequestParam(name = "pageNumber") int pageNumber, @RequestParam(name = "pageSize") int pageSize) {
        PageRequest pageReq = new PageRequest(pageNumber,pageSize,null);
        List<AppUserInfo> appUserInfoList =  appUserService.findAll(pageReq).getContent();
        return ResponseInfo.success(appUserInfoList);
    }

    /**
     * 根据业务城市 角色 星级等查询
     * @param star
     * @param role
     * @param popularizeType
     * @param businessCityId
     * @param jobCode
     * @param pageNumber
     * @param pageSize
     * @return
     */
	@RequestMapping("/getAppuserByList")
	ResponseInfo<List<AppUserInfo>> getAppuserByList( @RequestParam(name = "star") Integer star,
	                                                 @RequestParam(name = "role") String role,
	                                                 @RequestParam(name = "popularizeType") String popularizeType,
	                                                 @RequestParam(name = "businessCityId") String businessCityId,
	                                                 @RequestParam(name = "jobCode") String jobCode,
	                                                 @RequestParam(name = "pageNumber") int pageNumber,
	                                                 @RequestParam(name = "pageSize") int pageSize){
		PageRequest pageReq = new PageRequest(pageNumber,pageSize,null);
		List<AppUserInfo> appUserInfoList =  appUserService.getAppuserByList(star, role,popularizeType,
				businessCityId, jobCode,pageReq).getContent();
		return ResponseInfo.success(appUserInfoList);
	}


    /**
     * 查询客户经理 用户的权限信息
     * all:流程一、二、三   upload: 流程三  bank：流程一   notall：流程二
     * @param referrer  客户经理
     * @param manager  客拼音
     * @return
     */
    @RequestMapping("/getReferrerUsers")
    ResponseInfo<List<Map<String,String>>> getReferrerUsers( @RequestParam(name = "referrer") String referrer,@RequestParam(name = "manager") String manager){
        List<Map<String,String>> result = appUserService.getReferrerUsers(referrer,manager);
        return ResponseInfo.success(result);
    }

    /**
     * 根据 客户经理和权限状态修改 权限
     *
     * @param newcreditWay 新的权限
     * @param referrer     要去修改的客户经理全拼
     * @return
     */
    @RequestMapping("/updateReferrerUsers")
    ResponseInfo<String> updateReferrerUsers(@RequestParam(name = "newcreditWay")String newcreditWay,
                                             @RequestParam(name = "oldcreditWay")String oldcreditWay,
                                             @RequestParam(name = "referrer")String referrer ) {
        return appUserService.updateReferrerUsers(newcreditWay,oldcreditWay, referrer);
    }

}

package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.po.InvitationBinding;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by ex-zhongbingguo on 2017/11/2.
 */
public interface InvitationBindingDao extends CrudRepository<InvitationBinding, Long>{

    InvitationBinding findBybeInvitedPeople(String beInvitedPeople);
}

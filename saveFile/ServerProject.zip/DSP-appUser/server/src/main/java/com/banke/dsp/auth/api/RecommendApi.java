package com.banke.dsp.auth.api;

import com.banke.bkc.framework.exception.BusinessException;
import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.service.RecommendsService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by ex-zhongbingguo on 2017/8/16.
 */
@RestController
@RequestMapping(value = "/api/v1/recommends", method = {RequestMethod.GET, RequestMethod.POST})
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class RecommendApi {

    @Autowired
    private RecommendsService recommendsService;

    /**
     * 补业务城市编码
     */
    @PostMapping("/saveCity")
    public ResponseInfo<?> saveCity(HttpServletRequest request) throws BusinessException {
        String businessCityCode = request.getParameter("businessCityCode");
        String inviteCode = request.getParameter("inviteCode");
        return  recommendsService.saveCity(businessCityCode, inviteCode);
    }
}

package com.banke.dsp.auth.dto;

import lombok.Data;

import java.util.List;

/**
 *  用户请求对象
 * Created by ex-zhongbingguo on 2017/8/21.
 */
@Data
public class AppUserQueryParameter extends PageDTO{

    private String mongoId;

    //地推人员referrerName
    private String	refererName;

    //用户名
    private String userName;

    //用户姓名
    private String realName;

    //手机号cellphone
    private String cellphone;

    //用户身份证号identityNumber
    private String identityNumber;

    //开始注册时间createdAtBegin
    private String createdAtBegin;

    //结束注册时间createdAtEnd
    private String createdAtEnd;

    //用户状态
    private Boolean enabled;

    //用户类别userType
    private String userType;

    //用户星级start
//    private Integer star;

    private List<String> lists;

    //业务城市id
    private String businessCityid;

    //业务城市id集合
    private List<String> businessCityids;

    private String referrer;

    // 用户来源
    private String source;

    //用户归属
    private String ascription;

    //用户归属集合
    private List<String> ascriptions;

    //是否激活
    private Boolean ascriptionStatus;

}

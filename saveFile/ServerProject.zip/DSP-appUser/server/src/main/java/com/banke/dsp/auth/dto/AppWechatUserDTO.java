package com.banke.dsp.auth.dto;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * Created by ex-zengfanxi on 2018/02/27.
 */
@Data
public class AppWechatUserDTO {
	//普通用户的标识，对当前开发者帐号唯一
	private String openid;

	private String userId;

	private String code;
}

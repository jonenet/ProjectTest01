package com.banke.dsp.auth.service;

import com.banke.dsp.auth.dao.LoginAuditDao;
import com.banke.dsp.auth.po.LoginAudit;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by ex-zhongbingguo on 2017/11/7.
 */
@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class LoginAuditService {

    @Autowired
    private LoginAuditDao loginAuditDao;

    public void save(LoginAudit loginAudit){
        loginAuditDao.save(loginAudit);
    }
}


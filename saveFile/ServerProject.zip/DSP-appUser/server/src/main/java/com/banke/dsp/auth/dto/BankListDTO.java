package com.banke.dsp.auth.dto;

import lombok.Data;

@Data
public class BankListDTO {
    /*银行代码*/
    private String bankCode;
    /*银行名称*/
    private String bankName;
    /*银行卡号*/
    private String cardNo;
    /*卡类型*/
    private String cardType;
}

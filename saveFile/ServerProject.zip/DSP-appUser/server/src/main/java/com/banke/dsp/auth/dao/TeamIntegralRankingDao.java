package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.po.TeamIntegralRanking;
import com.banke.dsp.auth.po.TeamMemberInfo;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by ex-taozhangyi on 2018/2/28.
 */
public interface TeamIntegralRankingDao extends CrudRepository<TeamIntegralRanking, Long>, JpaSpecificationExecutor {
    /**
     * 积分排名(根据积分排名，首字母排序)
     * @return
     */
    @Query(value = "select * from (select t.id,t.team_no,t.team_name,t.total_integral,(@rowno\\:=@rowno+1) as rowno from team_integral_ranking t ,"+
            "(Select @rowno \\:=0 ) b order by t.total_integral desc,convert(t.team_name using gbk)) a where a.team_no = ?1", nativeQuery = true)
    List<Object[]> getTeamIntegralRankingOrderBy(String teamNo);

    /**
     * 积分排名(根据积分排名，首字母排序)
     * @return
     */
    @Query(value = "select t.id,t.team_no,t.team_name,t.total_integral,(@rowno\\:=@rowno+1) as rowno from team_integral_ranking t ,"+
            "(Select @rowno \\:=0 ) b order by t.total_integral desc,convert(t.team_name using gbk) ", nativeQuery = true)
    List<Object[]> getTeamIntegralRanking();

    /**
     * 积分排名(根据积分排名，首字母排序)
     * @return
     */
    @Query(value = "select * from (select t.id,t.team_no,t.team_name,t.total_integral,(@rowno\\:=@rowno+1) as rowno from team_integral_ranking t ,"+
            "(Select @rowno \\:=0 ) b order by t.total_integral desc,convert(t.team_name using gbk)) a where a.rowno in (?1)", nativeQuery = true)
    List<Object[]> getTeamIntegralRankingByRownoIn(int[] rwono);

    TeamIntegralRanking findByTeamNo(String teamNo);

    int countBy();


}

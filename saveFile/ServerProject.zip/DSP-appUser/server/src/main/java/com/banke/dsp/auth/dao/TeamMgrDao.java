package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.dto.team.TeamList;
import com.banke.dsp.auth.po.TeamInfo;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import javax.transaction.Transactional;

/**
 * 团队管理-运营后台使用
 * Created by linzhimou on 2017/7/25.
 */
public interface TeamMgrDao extends CrudRepository<TeamInfo, Long>, JpaSpecificationExecutor {

    @Query("select NEW com.banke.dsp.auth.dto.team.TeamList(t.teamNo, t.teamName, t.status, u.cellphone," +
            "u.businessCityid, t.establishDate, t.disbandDate)" +
            " from TeamInfo as t, AppUserInfo as u where t.agentNo=u.mongoId" +
            " and (:#{#teamNo.isEmpty()} = true or t.teamNo=:teamNo)" +
            " and(:#{#cellphone.isEmpty()} = true or u.cellphone=:cellphone)" +
            " and(:#{#inputOrgId.isEmpty()} = true or u.businessCityid=:inputOrgId) order by establish_date desc")
    Page<TeamList> queryTeamList(@Param("teamNo") String teamNo,
                                 @Param("cellphone") String cellphone,
                                 @Param("inputOrgId") String inputOrgId,
                                 Pageable pageReq);

    TeamInfo findByTeamNo(String teamNo);

    /**
     * 变更团长
     * @param agentNo
     * @param teamNo
     * @return
     */
    @Modifying
    @Query("update TeamInfo set agent_no=?1 where team_no=?2")
    int updateTeamLeader(String agentNo, String teamNo);

}

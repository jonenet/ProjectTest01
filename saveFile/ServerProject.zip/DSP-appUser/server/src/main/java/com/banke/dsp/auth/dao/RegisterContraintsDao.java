package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.po.RegisterContraints;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by ex-zhongbingguo on 2017/11/2.
 */
public interface RegisterContraintsDao extends CrudRepository<RegisterContraints, Long> {

    RegisterContraints findByRcId(String rcId);
}

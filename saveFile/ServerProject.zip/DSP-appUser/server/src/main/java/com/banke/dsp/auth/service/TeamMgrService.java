package com.banke.dsp.auth.service;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dao.TeamMemberMgrDao;
import com.banke.dsp.auth.dao.TeamMgrDao;
import com.banke.dsp.auth.dto.TeamStatusEnumDto;
import com.banke.dsp.auth.dto.team.MemberShowInfo;
import com.banke.dsp.auth.dto.team.TeamList;
import com.banke.dsp.auth.dto.team.TeamSearchParam;
import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.po.TeamInfo;
import com.banke.dsp.auth.po.TeamMemberInfo;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import javax.persistence.criteria.*;
import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.*;

/**
 * Created by linzhimou on 2017/7/25.
 */
@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class TeamMgrService {

    @NonNull
    private final TeamMgrDao teamMgrDao;

    @NonNull
    private final TeamMemberMgrDao teamMemberMgrDao;

    @Autowired
    private TeamService teamService;

    /**
     * 获取团队列表
     *
     * @return
     */
    public ResponseInfo<?> getTeamList(TeamSearchParam teamSearch, PageRequest pageReq) {
        //Specification sf = queryTeamParam(teamSearch);
        //Page<TeamInfo> result = teamMgrDao.findAll(sf,pageReq);

        Page<TeamList> result = teamMgrDao.queryTeamList(teamSearch.getTeamNo(),
                teamSearch.getCellphone(), teamSearch.getInputOrgId(), pageReq);

        List<TeamList> teamList = result.getContent();
        teamList.forEach(team -> {
            String teamNo = team.getTeamNo();
            team.setMemberCount(teamMemberMgrDao.countByTeamNoAndStatusNot(teamNo,TeamStatusEnumDto.DELETE.toString()));
            //添加团队推单笔数和金额直接在数据列表展示
            // 查询团队本月放款总额
            Double orderAmount = teamMemberMgrDao.getOrderAmountByTeam(teamNo);
            team.setOrderAmount(orderAmount == null?0D:orderAmount);
            //查询团队本月推单数
            int applyCount = teamMemberMgrDao.getApplyCountByTeam(teamNo);
            team.setApplyCount(applyCount);
        });

        return ResponseInfo.success(result);
    }

    //组装查询参数
    private Specification queryTeamParam(TeamSearchParam teamSearch) {
        Specification cification = new Specification() {
            @Override
            public Predicate toPredicate(Root root, CriteriaQuery query, CriteriaBuilder cb) {
                List<Predicate> predicates = new ArrayList<Predicate>();

                if (StringUtils.isNotBlank(teamSearch.getTeamNo())) {
                    predicates.add(cb.equal(root.get("teamNo"), teamSearch.getTeamNo()));
                }

                boolean cell = StringUtils.isNotBlank(teamSearch.getCellphone());
                boolean org = StringUtils.isNotBlank(teamSearch.getInputOrgId());
                if (cell || org) {
                    Join<TeamInfo, AppUserInfo> userJoin = root.join(
                            root.getModel().getSingularAttribute("appUser", AppUserInfo.class), JoinType.LEFT);
                    if (cell)
                        predicates.add(cb.equal(userJoin.get("cellphone"), teamSearch.getCellphone()));
                    if (org)
                        predicates.add(cb.equal(userJoin.get("businessCityid"), teamSearch.getInputOrgId()));
                }

                Predicate[] pre = new Predicate[predicates.size()];
                query.where(predicates.toArray(pre));

                List<Order> orderList = new ArrayList();
                orderList.add(cb.asc(root.get("leaveDate")));
                orderList.add(cb.asc(root.get("status")));

                query.orderBy(orderList);
                return query.getRestriction();
            }
        };
        return cification;
    }

    /**
     * 获取团队成员列表
     * @param teamSearch
     * @return
     */
    public ResponseInfo<?> getTeamMembers(TeamSearchParam teamSearch) {
        Specification sf = queryTeamParam(teamSearch);
        List<TeamMemberInfo> members = teamMemberMgrDao.findAll(sf);
        members.sort(Comparator.comparing(TeamMemberInfo::getTeamRole));
        return ResponseInfo.success(members);
    }

    /**
     * 解散团队
     * @param teamNo
     * @return
     */
    @Transactional
    public void disbandTeam(String teamNo) {
        //更新团队状态
        TeamInfo team = teamMgrDao.findByTeamNo(teamNo);
        if(team == null) return;

        team.setStatus(TeamStatusEnumDto.DELETE.toString());
        team.setDisbandDate(LocalDateTime.now());
        teamMgrDao.save(team);

        //查出所有在团成员，发送通知
        List<TeamMemberInfo> members = teamMemberMgrDao.findByTeamNoAndStatus(
                teamNo, TeamStatusEnumDto.NORMAL.toString());
        List<String> userIdList = new ArrayList<>();
        for (TeamMemberInfo member : members) {
            userIdList.add(member.getAgentNo());
        }
        String title = "团队解散通知";
        String detail = "亲爱的用户你好，你所在的团队(" + team.getTeamName() + ")已由管理员解散。";
        teamService.pushNotificationLeader(userIdList, title, detail);

        //更新团队成员状态，将所有团员更新为离团
        teamMemberMgrDao.removeAllTeamMember(teamNo);

        //纪录操作
        teamService.createOperationLog(null, teamNo, null,
                TeamStatusEnumDto.DISBAND_TEAM.toString(), TeamStatusEnumDto.OPT_BY_OPERATE.toString());
    }

    /**
     * 移除团队成员
     * @param agentNo
     * @return
     */
    public int removeTeamMember(String teamNo, String agentNo) {

        int record = teamMemberMgrDao.removeTeamMember(teamNo, agentNo);

        TeamInfo team = teamMgrDao.findByTeamNo(teamNo);

        List<String> userIdList = new ArrayList<>();
        userIdList.add(agentNo);
        String title = "移除团员通知";
        String detail = "亲爱的用户你好，你已被管理员移除出团队(" + team.getTeamName() + ")";
        teamService.pushNotificationLeader(userIdList, title, detail);

        //纪录操作
        teamService.createOperationLog(agentNo, teamNo, null,
                TeamStatusEnumDto.LEAVE_TEAM.toString(), TeamStatusEnumDto.OPT_BY_OPERATE.toString());

        return record;
    }

    /**
     * 更换团长
     * @param teamNo
     * @param agentNo
     * @return
     */
    @Transactional
    public ResponseInfo<?> changeTeamLeader(String teamNo, String agentNo) {
        String roleLeader = TeamStatusEnumDto.ROLE_OF_LEADER.toString();
        String roleMember = TeamStatusEnumDto.ROLE_OF_MEMBER.toString();
        //查询出该团队的团长(状态正常的纪录)
        TeamMemberInfo leader = teamMemberMgrDao.findByTeamNoAndTeamRoleAndStatus(
                teamNo, roleLeader, TeamStatusEnumDto.NORMAL.toString());

        //查询该团长是否为其它团队的团员
        TeamMemberInfo leaderOtherRole = teamMemberMgrDao.findByAgentNoAndTeamRoleAndStatus(
                leader.getAgentNo(), roleMember, TeamStatusEnumDto.NORMAL.toString());
        if (leaderOtherRole != null) {
            return ResponseInfo.error("此团队团长同时为其它团队的成员，设置失败");
        }

        //只存在一个团长身份，再判断指定的成员是否为其它团队的团长
        TeamMemberInfo member = teamMemberMgrDao.findByAgentNoAndTeamRoleAndStatus(
                agentNo, roleLeader, TeamStatusEnumDto.NORMAL.toString());
        if (member != null) {
            return ResponseInfo.error("此团员同时为其它团队的团长，设置失败");
        }

        //条件都通过，身份无冲突，将当前团队的团长设置为团员，将指定团员设置为团长
        teamMemberMgrDao.updateTeamRole(roleMember, teamNo, leader.getAgentNo());
        teamMemberMgrDao.updateTeamRole(roleLeader, teamNo, agentNo);
        teamMgrDao.updateTeamLeader(agentNo, teamNo);

        //纪录操作
        teamService.createOperationLog(agentNo, teamNo, null,
                TeamStatusEnumDto.CHANGE_LEADER.toString(), TeamStatusEnumDto.OPT_BY_OPERATE.toString());

        return ResponseInfo.success("");
    }

    /**
     * 查询团队当月总的推单数和放款金额
     * @param teamNo
     * @return
     */
    public ResponseInfo<?> getApplyAndOrderInfo(String teamNo) {
        Map<String, Object> result = new HashMap<String, Object>();
        int applyCount = teamMemberMgrDao.getApplyCountByTeam(teamNo);
        Double orderAmount = teamMemberMgrDao.getOrderAmountByTeam(teamNo);
        result.put("applyCount", applyCount);
        result.put("orderAmount", orderAmount);
        return ResponseInfo.success(result);
    }

    /**
     * 根据手机号查询团队成员信息
     * @param cellphone
     * @return
     */
    public ResponseInfo<?> searchMemberInfo(String cellphone) {
        List<MemberShowInfo> members = teamMemberMgrDao.searchMemberInfo(cellphone);
        members.forEach(member ->{
            if(StringUtils.isNotEmpty(member.getTeamNo())){
                member.setTeamRole(TeamStatusEnumDto.valueOf(member.getTeamRole()).getDescription());
                member.setTeamName(teamMgrDao.findByTeamNo(member.getTeamNo()).getTeamName());
                member.setApplyCount(teamMemberMgrDao.getApplyCountByAgent(member.getAgentNo()));
                member.setOrderTransAmount(teamMemberMgrDao.getOrderAmountByAgent(member.getAgentNo()));
            }
        });
        return ResponseInfo.success(members);
    }

    /**
     * 变更团队，只有团队成员可进行此操作
     * @param memberId
     * @param newTeamNo
     * @return
     */
    @Transactional
    public ResponseInfo<?> changeTeam(Long memberId, String newTeamNo, String newTeamRole) {

        //查询新团队编号是否存在
        TeamInfo teamInfo = teamMgrDao.findByTeamNo(newTeamNo);
        if(teamInfo == null || !teamInfo.getStatus().equals(TeamStatusEnumDto.NORMAL.toString())){
            return ResponseInfo.error("不存在的团队编号或该团队已解散");
        }

        TeamMemberInfo leader = teamMemberMgrDao.findByTeamNoAndTeamRoleAndStatus(
                teamInfo.getTeamNo(), TeamStatusEnumDto.ROLE_OF_LEADER.toString(),
                TeamStatusEnumDto.NORMAL.toString());

        //查询该成员信息
        TeamMemberInfo member = teamMemberMgrDao.findOne(memberId);
        if(member == null){
            return ResponseInfo.error("没有找到团员");
        }

        if(leader.getAgentNo().equals(member.getAgentNo())){
            return ResponseInfo.error("此团员已是该团队的团长，设置失败");
        }

        //更新原团队状态为退出
        member.setStatus(TeamStatusEnumDto.DELETE.toString());
        teamMemberMgrDao.save(member);

        //新增一条到新团队的纪录,这里只是更换为团员，如果变换为团长，需要对新团队的团长进行降级
        TeamMemberInfo newMember = new TeamMemberInfo();
        newMember.setAgentNo(member.getAgentNo());
        newMember.setTeamNo(newTeamNo);
        newMember.setStatus(TeamStatusEnumDto.NORMAL.toString());
        newMember.setTeamRole(TeamStatusEnumDto.ROLE_OF_MEMBER.toString());
        newMember.setJoinDate(LocalDateTime.now());
        teamMemberMgrDao.save(newMember);

        //通知团员信息变更
        List<String> userIdList = new ArrayList<>();
        userIdList.add(member.getAgentNo());
        String title = "团队更换通知";
        String detail = "亲爱的用户你好，你已被管理员更换到新团队(" + teamInfo.getTeamName() + ")";
        teamService.pushNotificationLeader(userIdList, title, detail);

        //纪录操作
        teamService.createOperationLog(member.getAgentNo(), newTeamNo, null,
                TeamStatusEnumDto.CHANGE_TEAM.toString(), TeamStatusEnumDto.OPT_BY_OPERATE.toString());

        return ResponseInfo.success("");
    }

}

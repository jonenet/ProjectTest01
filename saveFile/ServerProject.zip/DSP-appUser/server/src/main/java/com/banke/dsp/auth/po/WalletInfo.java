package com.banke.dsp.auth.po;

import com.banke.bkc.framework.po.BasePO;
import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Created by ex-panhuayu on 2017/6/26.
 * 平安付绑定关联关系表
 */
@Data
@NoArgsConstructor
@RequiredArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "wallet_info")
public class WalletInfo extends BasePO {


    @NonNull//平安付会员号
    @Column(nullable = false)
    private String uid;

    //mongoId
    @Column(nullable = false)
    private String mid;

    //token
    @Column(nullable = false)
    private String token;

    /**
     * 商户号
     */
    @Column(name = "merchant_id")
    private String merchantId;
    /**
     * 绑定类型 绑定1/解绑0
     * 1:有效；0：无效
     */
    @Column(name = "is_vaild")
    private Boolean isVaild;

    /**
     * 签名信息
     */
    @Column(name = "signature")
    private String signature;

    /**
     * 平安付会员号
     */
    @Column(name = "customer_id")
    private String customerId;

}

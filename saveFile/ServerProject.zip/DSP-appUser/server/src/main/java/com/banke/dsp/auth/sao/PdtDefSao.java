package com.banke.dsp.auth.sao;

import com.alibaba.fastjson.JSONObject;
import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dto.ProductInfo;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Map;

/**
 * Created by ex-liqiaoyong on 2017/8/23.
 */
@FeignClient(name = "PDT-def")
public interface PdtDefSao {

    @RequestMapping("/api/material/getMaterialBankTreeByBranchNo")
    ResponseInfo<JSONObject> getMaterialBankTree(@RequestParam("branchNo") String branchNo);

    /**
     *根据产品编号查询产品详情
     * @param productNo
     * @return
     */
    @RequestMapping("/api/productInfo/findByProductNo")
    public ResponseInfo<JSONObject> findByProductNo(@RequestParam("productNo") String productNo) ;
    /**
     *根据大类产品编号查询产品详情
     * @param parentNo
     * @return
     */
    @RequestMapping("/api/parentProduct/getParentProduct")
    public ResponseInfo<JSONObject> getParentProduct(@RequestParam("parentNo") String parentNo);

    @RequestMapping("/api/parentProduct/checkDashuProduct")
    public ResponseInfo<Boolean> checkDashuProduct(@RequestParam(value="parentNo",required=false) String parentNo,
                                                   @RequestParam(value="productNo",required=false) String productNo);

    /**
     * 根据银行id查询产品材料
     * @param bankNo 银行id
     * @return 产品信息
     */
    @RequestMapping("/api/material/queryProductMaterial")
    public ResponseInfo<List<Map<String, Object>>> queryProductMaterial(@RequestParam("bankNo") String bankNo);

    /**
     * 根据合作方Id查询产品信息
     * @param cooperationId
     * @return
     */
    @RequestMapping("/api/productInfo/findByCooperationId")
    public ResponseInfo<List<ProductInfo>> findByCooperationId(@RequestParam("cooperationId") String cooperationId);

}

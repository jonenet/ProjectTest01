package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.po.AppFansInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * Created by luoyifei on 2017/7/4.
 */
public interface AppFansInfoDao extends CrudRepository<AppFansInfo, Long>,PagingAndSortingRepository<AppFansInfo, Long>,JpaSpecificationExecutor<AppFansInfo> {

    AppFansInfo findByOpenid(String openid);

    AppFansInfo findByUnionid(String unionid);
}

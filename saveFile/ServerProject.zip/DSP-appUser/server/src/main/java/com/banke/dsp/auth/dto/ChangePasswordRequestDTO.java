package com.banke.dsp.auth.dto;

import lombok.Data;

/**
 *  修改密码 参数对象
 * Created by ex-zhongbingguo on 2017/10/31.
 */
@Data
public class ChangePasswordRequestDTO {

    private String requestId;

    private String passcode;

    private String oldPassword;

    private String newPassword;

    //注册码：手机号码
    private String cellphone;
}

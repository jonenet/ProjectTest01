package com.banke.dsp.auth.dao;

import com.banke.dsp.auth.po.AppuserUpgrade;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by ex-zhongbingguo on 2017/11/6.
 */
public interface AppuserUpgradeDao extends CrudRepository<AppuserUpgrade, Long> {
    AppuserUpgrade findByAgentNo(String agentNo);
}

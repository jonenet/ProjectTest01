package com.banke.dsp.auth.service;

import com.banke.dsp.auth.dto.*;
import com.banke.dsp.auth.po.AppUserInfo;
import com.banke.dsp.auth.util.DateUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * appUserInfo 的一些公共方法
 * Created by ex-zhongbingguo on 2017/8/16.
 */

@Slf4j
@Service
public class AppUserInfoUtilService {

    @Value("${appuserSave.businessCitys}")
    private String appuserBusinessCitys;

    @Autowired
    private AppUserInfoService appUserInfoService;

    @Autowired
    private AppUserService appUserService;

    @Autowired
    private BaseInfoService baseInfoService;

    @Autowired
    private StaffInfoService staffInfoService;

    @Autowired
    private BranchInfoService branchInfoService;

    /**
     * AppUserInfo 转换 AppUserDTO
     * @param appuserInfo  入参
     * @return AppUserDTO
     */
    public AppUserDTO convert(AppUserInfo appuserInfo) {
        AppUserDTO appUser = new AppUserDTO();
        //mongoId
        appUser.setId(appuserInfo.getMongoId());
        //app角色
        List<AppRole> ar = this.getAppRoles(appuserInfo.getAppRoles());
        log.info("after appRoles: {}", ar);
        //用户角色
        appUser.setAppRoles(ar);
        //app版本
        appUser.setAppVersion(appuserInfo.getAppVersion());
        //Archived
        appUser.setArchived(appuserInfo.getArchived() == null ? false : appuserInfo.getArchived());
        //银行账户名
        appUser.setBankAccountName(appuserInfo.getBankAccountName());
        //银行卡号
        appUser.setBankCardNumber(appuserInfo.getBankCardNumber());
        //业务城市
        if (appuserInfo.getBusinessCityid() != null){
            BranchInfoDTO branchInfo = branchInfoService.getBranchByBranchNo(SysIdEnum.WRK.getValue(), appuserInfo.getBusinessCityid());
            appUser.setBusinessCity(this.businessCityConvert(branchInfoService.getBusinessCity(branchInfo, BranchInfoDTO.BranchType.BRANCH_COMPANY.name())));
        }
        //手机号码
        appUser.setCellphone(appuserInfo.getCellphone());
        //注册日期
        appUser.setCreatedAt(DateUtil.localDateTimeToDate(appuserInfo.getCreatedAt()));
        //用户进件权限
        appUser.setEnableRecommendation(appuserInfo.getEnableEecommendation() == null ? false : appuserInfo.getEnableEecommendation());
        //是否有效
        appUser.setEnabled(appuserInfo.getLocked() == null ? false : appuserInfo.getEnabled());
        //是否过期
        appUser.setExpired(appuserInfo.getExpired() == null ? false : appuserInfo.getExpired());
        //身份证号
        appUser.setIdentityNumber(appuserInfo.getIdentityNumber());
        //job
        appUser.setJob(appuserInfo.getJob());
        //locked
        appUser.setLocked(appuserInfo.getLocked() == null ? false : appuserInfo.getLocked());
        //操作时间
        appUser.setModifiedAt(appuserInfo.getModifiedAt() == null ? null : DateUtil.localDateTimeToDate(appuserInfo.getModifiedAt()));
        //操作系统版本
        appUser.setOsVersion(appuserInfo.getOsVersion());
        //密文密码
        appUser.setPassword(appuserInfo.getPassword());
        //加码方式
        appUser.setPasswordEncoder(appuserInfo.getPasswordEncoder());
        //盐
        appUser.setPasswordSalt(appuserInfo.getPasswordSalt());
        //推荐人用户名
        if (appuserInfo.getReferrer() != null){
            StaffInfoDTO staffInfo = staffInfoService.getStaffInfoByUserId(appuserInfo.getReferrer());
            appUser.setRefererName(staffInfo != null ? staffInfo.getStaffName() : appuserInfo.getRefererName());
        }
        //referrer
        appUser.setReferrer(appuserInfo.getReferrer());
        //注册设备
        appUser.setRegisterDevice(appuserInfo.getRegisterDevice());
        //注册id
        appUser.setRegisterId(appuserInfo.getRegisterId());
        //用户星级
        appUser.setStar(appuserInfo.getStar());
        //用户名
        appUser.setUsername(appuserInfo.getUserName());
        //公司名称
        appUser.setCompanyName(appuserInfo.getCompanyName());
        //是否集团用户
        appUser.setGroupFlag(appuserInfo.getGroupFlag());
        //所属集团
        appUser.setGroupName(appuserInfo.getGroupName());
        //推广方式
        appUser.setPopularizeType(PopularizeType.getPopularizeTypeByCode(appuserInfo.getPopularizeTypeId()));
        //真实名称
        appUser.setRealName(appuserInfo.getRealName());
        //地址
        appUser.setAddress(appuserInfo.getAddress());
        //邮箱
        appUser.setEmail(appuserInfo.getEmail());
        //推荐人手机号
        appUser.setRefMobilePhone(appuserInfo.getRefMobilePhone());
        //微信用户名
        appUser.setWechatUsername(appuserInfo.getWechatUsername());
        //achived
        appUser.setAchived(appuserInfo.getAchived());
        //是否是授信标志
        appUser.setIscredit(appuserInfo.getIscredit());
        //是否推荐更多产品
        appUser.setCommendMore(appuserInfo.getCommendMore());
        //征信获取方式
        appUser.setCreditWay(appuserInfo.getCreditWay());
        //是否需要征信
        appUser.setNeedCredit(appuserInfo.getIsNeedCredit() == null ? false : appuserInfo.getIsNeedCredit());
        //cv
        appUser.setCv(appuserInfo.getCv());
        //注册来源
        appUser.setSource(appuserInfo.getSource());

        //昵称
        appUser.setNickname(appuserInfo.getNickname());
        return appUser;
    }

    public List<AppRole> getAppRoles(String appRoles) {
        appRoles = StringUtils.replace(appRoles, "[", "");
        appRoles = StringUtils.replace(appRoles, "]", "");
        log.info("before appRoles: {}", appRoles);
        List<AppRole> ar = new ArrayList<>();
        String[] split = StringUtils.split(appRoles, ",");
        if (split != null){
            for (String str : split){
                AppRole appRole = AppRole.getAppRoleByCode(StringUtils.trim(str));
                ar.add(appRole);
            }
        }
        return ar;
    }


    /**
     *  BranchInfoDTO 转  BusinessCity
     * @param branchInfo    BranchInfoDTO
     * @return               BusinessCity
     */
    private BusinessCity businessCityConvert(BranchInfoDTO branchInfo){
        BusinessCity bc = new BusinessCity();
        if (branchInfo != null){
            bc.setId(branchInfo.getBranchNo());
            bc.setCode(branchInfo.getBranchNo());
            bc.setName(branchInfo.getName());
            bc.setSortNo(branchInfo.getSort().toString());
            bc.setStatus("00".equals(branchInfo.getBranchStatus()) ? "1" : "0");
        }
        return bc;
    }

    //修改用户
    @Transactional(rollbackFor=RuntimeException.class)
    public AppUserInfo updateAppUser(AppUserInfo appUserInfo){
        String code = appUserInfo.getBusinessCityid();
        if (StringUtils.isNotEmpty(code) && appuserBusinessCitys.contains(code)){
            appUserInfo.setCreditWay("all");
        }

        return appUserInfoService.save(appUserInfo);
    }

}

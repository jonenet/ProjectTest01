package com.banke.dsp.auth.api;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.auth.dto.TeamGradeQueryParameter;
import com.banke.dsp.auth.po.TeamGrade;
import com.banke.dsp.auth.service.TeamGradeService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * Created by ex-zhongbingguo on 2017/12/8.
 */

@RestController
@RequestMapping(value = "/api/team/grade", method = {RequestMethod.GET, RequestMethod.POST})
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class TeamGradeApi {

    @Autowired
    private TeamGradeService teamGradeService;

    @RequestMapping("/save")
    public ResponseInfo<?> save(TeamGrade teamGrade){
        return teamGradeService.save(teamGrade);
    }

    @RequestMapping("/delete")
    public ResponseInfo<?> delete(Long id){
        return teamGradeService.delete(id);
    }

    @RequestMapping("/update")
    public ResponseInfo<?> update(TeamGrade teamGrade){
        return teamGradeService.update(teamGrade);
    }

    @RequestMapping("/page")
    public ResponseInfo<?> page(TeamGradeQueryParameter request){
        return null;
    }

    @RequestMapping("/list")
    public ResponseInfo<?> list(@RequestParam("businessCityid") String businessCityid, String gradeCode){
        return ResponseInfo.success(teamGradeService.list(businessCityid, gradeCode));
    }
}

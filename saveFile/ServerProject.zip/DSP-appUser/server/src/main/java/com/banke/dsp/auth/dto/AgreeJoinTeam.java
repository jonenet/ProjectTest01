package com.banke.dsp.auth.dto;

import lombok.Data;

/**
 * Created by ex-taozhangyi on 2018/3/8.
 */
@Data
public class AgreeJoinTeam {
    private String id;
    private String  applySerialNO;   //团员ID
    private String agree;
}

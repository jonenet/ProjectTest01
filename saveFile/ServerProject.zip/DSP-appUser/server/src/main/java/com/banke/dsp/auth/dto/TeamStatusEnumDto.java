package com.banke.dsp.auth.dto;

/**
 * Created by ex-liqiaoyong on 2017/7/25.
 */
public enum TeamStatusEnumDto {
    NORMAL("正常"),              //团队和团员
    READY_DELETE("即将删除"),  //团队和团员
    DELETE("删除"),             //团队和团员

    TEAM_FULL("团队满员"),
    CREATE_TEAM("创建团队"),
    UPDATE_TEAM("修改团队"),
    DISBAND_TEAM("解散团队"),
    JOIN_TEAM("加入团队"),
    LEAVE_TEAM("离开团队"),
    CHANGE_LEADER("更换团长"),
    CHANGE_TEAM("更换团队"),
    OPT_BY_LEADER("团长操作"),
    OPT_BY_MEMBER("成员操作"),
    OPT_BY_OPERATE("运营操作"),
    OPT_BY_DISBANDTEAM("解散团队操作"),
    APPLICATION_TEAM("申请入团"),
    ROLE_OF_LEADER("团长"),
    ARGEE_JOIN_TEAM("同意加入"),
    NOTARGEE_JOIN_TEAM("不同意加入"),
    ROLE_OF_MEMBER("成员");

    private final String description;
    private TeamStatusEnumDto(String value) {
        description = value;
    }

    public String getDescription() {
        return description;
    }
}

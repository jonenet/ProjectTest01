package com.banke.dsp.auth.sao;

import com.alibaba.fastjson.JSONObject;
import com.banke.bkc.framework.util.ResponseInfo;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Created by ex-zengfanxi on 2018/03/09.
 * 微信服务
 */
@FeignClient(name = "ADT-wx")
public interface AdtWxSao {
	@RequestMapping("/api/authorizationrequest/getAppUserInfo")
	ResponseInfo<JSONObject> getAppUserInfo(@RequestParam(value = "code") String code);
}

package com.banke.dsp.auth.util;

/**
 * Created by ex-taozhangyi on 2018/3/9.
 */
public class DeployUtil {
    public static final String INVITE_MEMBERS="邀请成员";
    public static final String SUCCESSFUL_SINGLE_DELIVERY="推单成功";
    public static final String SUCCESSFUL_LOAN="放款成功";
    public static final String INVITE_MEMBERS_NEW="新用户首次推单";

    public static final String INVITE_MEMBERS_SOURCE="1";
    public static final String SUCCESSFUL_SINGLE_DELIVERY_SOURCE="2";
    public static final String SUCCESSFUL_LOAN_SOURCE="3";
    public static final String INVITE_MEMBERS_NEW_SOURCE="4";


    public static final Integer INVITE_MEMBERS_JF=100;
    public static final Integer SUCCESSFUL_SINGLE_DELIVERY_JF=100;
    public static final Integer SUCCESSFUL_LOAN_JF=300;
    public static final Integer INVITE_MEMBERS_NEW_JF=200;

}

package com.banke.dsp.auth.po;


import com.banke.bkc.framework.po.BasePO;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "score_details")
public class ScoreDetails extends BasePO{

    //用户ID
    private String userId;

    //用户手机号
    private String cellphone;

    //获得积分
    private String score;

    //描述
    private String description;
}

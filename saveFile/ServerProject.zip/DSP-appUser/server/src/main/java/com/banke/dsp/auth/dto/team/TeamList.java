package com.banke.dsp.auth.dto.team;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * Created by linzhimou on 2017/8/1.
 */
@Data
public class TeamList {

    public TeamList(String teamNo, String teamName, String status, String cellphone,
                    String businessCityId, LocalDateTime establishDate, LocalDateTime disbandDate) {
        this.teamNo = teamNo;
        this.teamName = teamName;
        this.status = status;
        this.cellphone = cellphone;
        this.businessCityId = businessCityId;
        this.establishDate = establishDate;
        this.disbandDate = disbandDate;
    }

    private String teamNo;
    private String teamName;
    private String status;
    private String cellphone;
    private String businessCityId;
    private Long memberCount;
    private double orderAmount;
    private int applyCount;

    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime establishDate;

    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime disbandDate;

}

package com.banke.dsp.auth.dto;

import lombok.Data;

/**
 * Created by ex-liqiaoyong on 2017/11/7.
 */
@Data
public class SendOtpCodeDto {
    private String cellphone;

    private String requestId;

    private String otpCode;

    private String cv;
}

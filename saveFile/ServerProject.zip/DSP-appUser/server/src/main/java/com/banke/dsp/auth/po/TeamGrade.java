package com.banke.dsp.auth.po;

import com.banke.bkc.framework.po.BasePO;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.math.BigDecimal;

/**
 * Created by ex-zhongbingguo on 2017/12/8.
 */
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "team_grade")
public class TeamGrade extends BasePO {

    //等级编号
    private String gradeCode;

    //团队等级
    private String gradeName;

    //业务城市
    private String businessCityid;

    //最大成员数
    private Integer maxMemNum;

    //团长返佣比例
    private BigDecimal tlRebateRatio;

    //团员返佣比例
    private BigDecimal tnRebateRatio;

    //最大返佣基数
    private BigDecimal maxRebate;

    //等级维持规则,有效推单数最小笔数
    private Integer keepPushNum;

    //等级维持规则,第三方产品有效推最小单数
    private Integer keepThirdPushNum;
}

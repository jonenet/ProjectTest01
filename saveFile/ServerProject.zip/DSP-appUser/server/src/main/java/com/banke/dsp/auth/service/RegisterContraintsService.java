package com.banke.dsp.auth.service;

import com.banke.dsp.auth.dao.RegisterContraintsDao;
import com.banke.dsp.auth.dto.RegisterContraintEnum;
import com.banke.dsp.auth.po.RegisterContraints;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by ex-zhongbingguo on 2017/11/2.
 */
@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class RegisterContraintsService {

    @Autowired
    private RegisterContraintsDao registerContraintsDao;

    public boolean isRegisterCodeRequired(){
        RegisterContraints rc = registerContraintsDao.findByRcId(RegisterContraintEnum.PUBLISHED_ID.getValue());
        return rc == null ? false : rc.isCodeRequired();
    }

}

CREATE TABLE `public_user_relevance` (
	`id` BIGINT(15) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT,
	`userid` VARCHAR(40) NOT NULL COMMENT '评估神用户ID' COLLATE 'utf8mb4_bin',
	`unionid` VARCHAR(40) NOT NULL COMMENT '微信unionid' COLLATE 'utf8mb4_bin',
	`oneopenid` VARCHAR(40) NOT NULL COMMENT '评估神公众号openid' COLLATE 'utf8mb4_bin',
	`token` VARCHAR(40) NOT NULL COMMENT '公众号用Token' COLLATE 'utf8mb4_bin',
	`created_date` DATETIME NOT NULL COMMENT '创建时间',
	`created_by` VARCHAR(100) NOT NULL COMMENT '创建用户' COLLATE 'utf8mb4_bin',
	`updated_date` DATETIME NOT NULL COMMENT '修改时间',
	`updated_by` VARCHAR(100) NOT NULL COMMENT '修改用户' COLLATE 'utf8mb4_bin',
	PRIMARY KEY (`id`),
	INDEX `index_unionid` (`unionid`),
	INDEX `index_user_id` (`user_id`)
)
COMMENT='微信用户和评估神用户绑定表'
COLLATE='utf8mb4_bin'
ENGINE=InnoDB
AUTO_INCREMENT=100000000000114;

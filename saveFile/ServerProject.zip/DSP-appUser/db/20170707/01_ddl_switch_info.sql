

-- 导出  表 appuser.switch_info 结构
CREATE TABLE IF NOT EXISTS `switch_info` (
  `id` bigint(15) unsigned zerofill NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(30) COLLATE utf8mb4_bin NOT NULL COMMENT '开关名称',
  `value` varchar(20) COLLATE utf8mb4_bin NOT NULL COMMENT '开关值',
  `type` varchar(10) COLLATE utf8mb4_bin NOT NULL COMMENT '开关类型',
  `created_by` varchar(30) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '创建人',
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_by` varchar(30) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '修改人',
  `updated_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='开关表';


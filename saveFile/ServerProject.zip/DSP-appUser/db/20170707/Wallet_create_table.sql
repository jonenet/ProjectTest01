CREATE TABLE `wallet_info` (
	`id` BIGINT(15) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT,
	`uid` VARCHAR(40) NOT NULL COMMENT '平安付会员号' COLLATE 'utf8mb4_bin',
	`mid` VARCHAR(40) NOT NULL COMMENT 'mongoId' COLLATE 'utf8mb4_bin',
	`token` VARCHAR(64) NOT NULL COMMENT 'token' COLLATE 'utf8mb4_bin',
	`created_date` DATETIME NOT NULL COMMENT '创建时间',
	`created_by` VARCHAR(100) NOT NULL COMMENT '创建用户' COLLATE 'utf8mb4_bin',
	`updated_date` DATETIME NOT NULL COMMENT '修改时间',
	`updated_by` VARCHAR(100) NOT NULL COMMENT '修改用户' COLLATE 'utf8mb4_bin',
	`merchant_id` VARCHAR(64) NOT NULL COMMENT '商户号' COLLATE 'utf8mb4_bin',
	`is_vaild` BIT(1) NOT NULL DEFAULT b'1' COMMENT '绑定类型 绑定T/解绑U',
	`signature` VARCHAR(64) NOT NULL COMMENT '签名信息' COLLATE 'utf8mb4_bin',
	PRIMARY KEY (`id`),
	INDEX `index_mid` (`mid`)
)
COMMENT='用户和易钱包的关联关系表'
COLLATE='utf8mb4_bin'
ENGINE=InnoDB
AUTO_INCREMENT=100000000000114;

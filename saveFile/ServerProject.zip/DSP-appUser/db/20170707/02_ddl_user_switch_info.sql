

-- 导出  表 appuser.user_switch_info 结构
CREATE TABLE IF NOT EXISTS `user_switch_info` (
  `id` bigint(15) unsigned zerofill NOT NULL AUTO_INCREMENT COMMENT 'id',
  `agent_no` varchar(40) COLLATE utf8mb4_bin NOT NULL COMMENT 'appUserMongoID',
  `name` varchar(30) COLLATE utf8mb4_bin NOT NULL COMMENT '开关名称',
  `value` varchar(20) COLLATE utf8mb4_bin NOT NULL COMMENT '开关值',
  `type` varchar(10) COLLATE utf8mb4_bin NOT NULL COMMENT '开关类型',
  `created_by` varchar(30) COLLATE utf8mb4_bin NOT NULL COMMENT '创建人',
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_by` varchar(30) COLLATE utf8mb4_bin NOT NULL COMMENT '修改人',
  `updated_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `agentNo_name` (`agent_no`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='用户开关表';


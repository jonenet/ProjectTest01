

-- 导出  表 appuser.apply_info 结构
CREATE TABLE IF NOT EXISTS `apply_info` (
  `apply_no` varchar(20) COLLATE utf8mb4_bin NOT NULL COMMENT '申请编号',
  `apply_amount` decimal(19,2) DEFAULT NULL COMMENT '申请金额',
  `advisor_no` varchar(11) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '客户经理编号',
  `agent_no` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '业务员编码',
  `apply_date` datetime NOT NULL COMMENT '申请时间',
  `apply_status` varchar(10) COLLATE utf8mb4_bin NOT NULL COMMENT '状态',
  `city_id` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '城市',
  `input_org_id` varchar(6) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '业务机构(分公司)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=COMPACT COMMENT='申请信息表';



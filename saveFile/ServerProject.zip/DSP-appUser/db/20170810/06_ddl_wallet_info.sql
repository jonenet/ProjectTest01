ALTER TABLE `wallet_info`
	ADD COLUMN `customer_id` VARCHAR(16) NOT NULL COMMENT '平安付会员号' AFTER `signature`;

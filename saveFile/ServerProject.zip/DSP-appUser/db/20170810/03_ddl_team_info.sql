
-- 导出  表 appuser.team_info 结构
CREATE TABLE IF NOT EXISTS `team_info` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `team_no` varchar(6) COLLATE utf8mb4_bin NOT NULL COMMENT '团队编号',
  `agent_no` varchar(32) COLLATE utf8mb4_bin NOT NULL COMMENT '团长ID',
  `team_name` varchar(30) COLLATE utf8mb4_bin NOT NULL COMMENT '团队名称',
  `status` varchar(20) COLLATE utf8mb4_bin NOT NULL COMMENT '团队状态 NORMAL正常,READY_DELETE即将解散,DELETE解散',
  `notice` varchar(200) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '团队公告',
  `establish_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '成立时间',
  `disband_date` datetime DEFAULT NULL COMMENT '解散时间',
  `created_by` varchar(30) COLLATE utf8mb4_bin DEFAULT NULL,
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(30) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `team_no` (`team_no`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='团队表';



-- 导出  表 appuser.team_member_info 结构
CREATE TABLE IF NOT EXISTS `team_member_info` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `agent_no` varchar(32) COLLATE utf8mb4_bin NOT NULL COMMENT '团员id',
  `team_no` varchar(6) COLLATE utf8mb4_bin NOT NULL COMMENT '团队编号',
  `team_role` varchar(15) COLLATE utf8mb4_bin NOT NULL COMMENT '团员角色 TEAM_LEADER团长 TEAM_MEMBER团员',
  `status` varchar(20) COLLATE utf8mb4_bin NOT NULL COMMENT '团队状态 NORMAL正常,READY_DELETE即将退出,DELETE退出',
  `operation_type` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '操作类型 OPT_BY_LEADER团长操作 OPT_BY_MEMBER成员操作 OPT_BY_OPERATE运营操作',
  `join_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '加入时间',
  `leave_date` datetime DEFAULT NULL COMMENT '离开时间',
  `created_by` varchar(30) COLLATE utf8mb4_bin DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `agent_no` (`agent_no`)
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='团队成员表';



-- 导出  表 appuser.team_operation_log 结构
CREATE TABLE IF NOT EXISTS `team_operation_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `agent_no` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '用户编号',
  `team_no` varchar(6) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '团队编号',
  `join_type` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '加入类型 JOIN_TEAM加入团队',
  `leave_type` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '离开类型 LEAVE_TEAM离开团队',
  `status` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'CREATE_TEAM创建团队，UPDATE_TEAM修改团队，DISBAND_TEAM解散团队，JOIN_TEAM加入团队，LEAVE_TEAM离开团队',
  `operation_type` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '操作类型 OPT_BY_LEADER团长操作 OPT_BY_MEMBER成员操作 OPT_BY_OPERATE运营操作',
  `operation_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
  `operation_by` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '操作人',
  `created_by` varchar(30) COLLATE utf8mb4_bin DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(30) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=338 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='团队操作记录表';


-- 导出  表 appuser.order_info 结构
CREATE TABLE IF NOT EXISTS `order_info` (
  `order_no` varchar(40) COLLATE utf8mb4_bin NOT NULL COMMENT '订单号',
  `apply_no` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '申请书编号',
  `apply_date` datetime NOT NULL COMMENT '申请时间',
  `agent_no` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '业务员编码',
  `input_org_id` varchar(6) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '业务机构(分公司)',
  `order_status` varchar(10) COLLATE utf8mb4_bin NOT NULL COMMENT '状态',
  `trans_date` datetime DEFAULT NULL COMMENT '放款时间',
  `trans_amount` decimal(19,2) DEFAULT NULL COMMENT '放款金额'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=COMPACT COMMENT='订单信息表';

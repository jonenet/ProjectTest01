﻿-- 邀请绑定表
CREATE TABLE `invitation_binding` (
  `id` bigint(15) NOT NULL AUTO_INCREMENT primary key,
  `invite_people` varchar(11) DEFAULT NULL COMMENT '邀请人手机号码',
  `be_invited_people` varchar(11) DEFAULT NULL COMMENT '被邀请人手机号码',
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `created_by` varchar(30) DEFAULT NULL COMMENT '创建用户',
  `updated_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `updated_by` varchar(30) DEFAULT NULL COMMENT '修改用户'
) COMMENT='邀请绑定表' AUTO_INCREMENT=10000 ;


-- 总积分表
CREATE TABLE `total_score` (
  `id` bigint(15) NOT NULL AUTO_INCREMENT primary key,
  `user_id` varchar(30) DEFAULT NULL COMMENT '用户id',
  `cellphone` varchar(11) DEFAULT NULL COMMENT '用户手机号码',
  `num_score` varchar(100) DEFAULT NULL COMMENT '总积分',
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `created_by` varchar(30) DEFAULT NULL COMMENT '创建用户',
  `updated_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `updated_by` varchar(30) DEFAULT NULL COMMENT '修改用户'
) COMMENT='总积分表' AUTO_INCREMENT=10000 ;

-- 新增索引
create index ix_total_score_cellphone on total_score(cellphone);


-- 积分明细表
CREATE TABLE `score_details` (
  `id` bigint(15) NOT NULL AUTO_INCREMENT primary key,
  `user_id` varchar(100) DEFAULT NULL COMMENT '用户id',
  `cellphone` varchar(11) DEFAULT NULL COMMENT '用户手机号码',
  `score` varchar(100) DEFAULT NULL COMMENT '积分',
  `description` varchar(200) DEFAULT NULL COMMENT '描述',
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `created_by` varchar(30) DEFAULT NULL COMMENT '创建用户',
  `updated_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `updated_by` varchar(30) DEFAULT NULL COMMENT '修改用户'
) COMMENT='积分明细表' AUTO_INCREMENT=10000 ;

-- 新增索引
create index ix_score_details_cellphone on score_details(cellphone);

-- 
CREATE TABLE `register_contraints` (
  `id` bigint(15) NOT NULL AUTO_INCREMENT primary key,
  `rc_id` varchar(2) DEFAULT NULL,
  `code_required` tinyint(1) DEFAULT NULL,
  `register_id` varchar(200) DEFAULT NULL,
  `register_code` varchar(200) DEFAULT NULL,
  `register_limited_to` int(10) DEFAULT NULL,
  `code_expired_at` datetime DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `created_by` varchar(30) DEFAULT NULL COMMENT '创建用户',
  `updated_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `updated_by` varchar(30) DEFAULT NULL COMMENT '修改用户'
) COMMENT='积分明细表' AUTO_INCREMENT=10000 ;


-- 注册日志表
CREATE TABLE `register_constraint_log` (
  `id` bigint(15) NOT NULL AUTO_INCREMENT primary key,
  `username` varchar(30) DEFAULT NULL COMMENT '用户姓名',
  `cellphone` varchar(11) DEFAULT NULL COMMENT '用户手机号码',
  `register_code` varchar(100) DEFAULT NULL COMMENT '注册码',
  `os_version` varchar(20) DEFAULT NULL COMMENT '操作系统版本',
  `app_version` varchar(20) DEFAULT NULL COMMENT 'app版本',
  `register_device` varchar(20) DEFAULT NULL,
  `message` varchar(200) DEFAULT NULL COMMENT '描述',
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `created_by` varchar(30) DEFAULT NULL COMMENT '创建用户',
  `updated_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `updated_by` varchar(30) DEFAULT NULL COMMENT '修改用户'
) COMMENT='注册日志表' AUTO_INCREMENT=10000 ;

-- 新增索引
create index ix_rclog_cellphone on register_constraint_log(cellphone);

insert into register_contraints(rc_id,code_required,register_id,register_code,register_limited_to) VALUES('1', 1, '5b177d6223154f86a0fbadc6e4dc249f','0qXBWC','250');

-- 用户升级表
CREATE TABLE `appuser_upgrade` (
  `id` bigint(15) NOT NULL AUTO_INCREMENT primary key,
  `agent_no` varchar(40) DEFAULT NULL,
  `real_name` varchar(30) DEFAULT NULL COMMENT '真实名称',
  `identity_number` varchar(18) DEFAULT NULL COMMENT '身份证号',
  `bank_card_number` varchar(20) DEFAULT NULL COMMENT '银行卡号',
  `cellphone` varchar(11) DEFAULT NULL COMMENT '银行预留手机号码',
  `identity_zm_image_id` varchar(32) DEFAULT NULL COMMENT '身份证正面图片Id',
  `identity_fm_image_id` varchar(32) DEFAULT NULL COMMENT '身份证反面图片Id',
  `identity_tx_image_id` varchar(32) DEFAULT NULL COMMENT '身份证头像图片Id',
  `other_info` text DEFAULT NULL COMMENT '身份证其他信息',
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `created_by` varchar(30) DEFAULT NULL COMMENT '创建用户',
  `updated_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `updated_by` varchar(30) DEFAULT NULL COMMENT '修改用户'
) COMMENT='用户升级表' AUTO_INCREMENT=10000;

-- 新增索引
create index ix_aupgrade_mongo_id on appuser_upgrade(agent_no);


CREATE TABLE `login_audit` (
  `id` bigint(15) NOT NULL AUTO_INCREMENT primary key,
  `username` varchar(30) DEFAULT NULL COMMENT '用户名',
  `os_version` varchar(30) DEFAULT NULL COMMENT '手机版本',
  `app_version` varchar(30) DEFAULT NULL COMMENT 'app版本',
  `ip_address` varchar(50) DEFAULT NULL COMMENT 'ip地址',
  `device` varchar(50) DEFAULT NULL,
  `device_id` varchar(50) DEFAULT NULL,
  `authenticated` TINYINT(1) DEFAULT NULL COMMENT '是否认证',
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `created_by` varchar(30) DEFAULT NULL COMMENT '创建用户',
  `updated_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `updated_by` varchar(30) DEFAULT NULL COMMENT '修改用户'
)  AUTO_INCREMENT=10000 ;


create index ix_laudits_username on login_audit(username);
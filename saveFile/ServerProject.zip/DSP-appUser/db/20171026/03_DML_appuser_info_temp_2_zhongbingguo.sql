-- 分批更新 appuser_info
UPDATE appuser_info t1,appuser_info_temp_2 t2 
SET t1.source=t2.source, t1.is_need_credit=t2.is_need_credit,t1.credit_way=t2.credit_way
WHERE t1.mongo_id=t2.mongo_id AND t1.credit_way != t2.credit_way AND t1.mongo_id LIKE '0%';

UPDATE appuser_info t1,appuser_info_temp_2 t2 
SET t1.source=t2.source, t1.is_need_credit=t2.is_need_credit,t1.credit_way=t2.credit_way
WHERE t1.mongo_id=t2.mongo_id AND t1.credit_way != t2.credit_way AND t1.mongo_id LIKE '1%';

UPDATE appuser_info t1,appuser_info_temp_2 t2 
SET t1.source=t2.source, t1.is_need_credit=t2.is_need_credit,t1.credit_way=t2.credit_way
WHERE t1.mongo_id=t2.mongo_id AND t1.credit_way != t2.credit_way AND t1.mongo_id LIKE '2%';

UPDATE appuser_info t1,appuser_info_temp_2 t2 
SET t1.source=t2.source, t1.is_need_credit=t2.is_need_credit,t1.credit_way=t2.credit_way
WHERE t1.mongo_id=t2.mongo_id AND t1.credit_way != t2.credit_way AND t1.mongo_id LIKE '3%';

UPDATE appuser_info t1,appuser_info_temp_2 t2 
SET t1.source=t2.source, t1.is_need_credit=t2.is_need_credit,t1.credit_way=t2.credit_way
WHERE t1.mongo_id=t2.mongo_id AND t1.credit_way != t2.credit_way AND t1.mongo_id LIKE '4%';

UPDATE appuser_info t1,appuser_info_temp_2 t2 
SET t1.source=t2.source, t1.is_need_credit=t2.is_need_credit,t1.credit_way=t2.credit_way
WHERE t1.mongo_id=t2.mongo_id AND t1.credit_way != t2.credit_way AND t1.mongo_id LIKE '5%';

UPDATE appuser_info t1,appuser_info_temp_2 t2 
SET t1.source=t2.source, t1.is_need_credit=t2.is_need_credit,t1.credit_way=t2.credit_way
WHERE t1.mongo_id=t2.mongo_id AND t1.credit_way != t2.credit_way AND t1.mongo_id LIKE '6%';

UPDATE appuser_info t1,appuser_info_temp_2 t2 
SET t1.source=t2.source, t1.is_need_credit=t2.is_need_credit,t1.credit_way=t2.credit_way
WHERE t1.mongo_id=t2.mongo_id AND t1.credit_way != t2.credit_way AND t1.mongo_id LIKE '7%';

UPDATE appuser_info t1,appuser_info_temp_2 t2 
SET t1.source=t2.source, t1.is_need_credit=t2.is_need_credit,t1.credit_way=t2.credit_way
WHERE t1.mongo_id=t2.mongo_id AND t1.credit_way != t2.credit_way AND t1.mongo_id LIKE '8%';

UPDATE appuser_info t1,appuser_info_temp_2 t2 
SET t1.source=t2.source, t1.is_need_credit=t2.is_need_credit,t1.credit_way=t2.credit_way
WHERE t1.mongo_id=t2.mongo_id AND t1.credit_way != t2.credit_way AND t1.mongo_id LIKE '9%';

UPDATE appuser_info t1,appuser_info_temp_2 t2 
SET t1.source=t2.source, t1.is_need_credit=t2.is_need_credit,t1.credit_way=t2.credit_way
WHERE t1.mongo_id=t2.mongo_id AND t1.credit_way != t2.credit_way AND t1.mongo_id LIKE 'a%';

UPDATE appuser_info t1,appuser_info_temp_2 t2 
SET t1.source=t2.source, t1.is_need_credit=t2.is_need_credit,t1.credit_way=t2.credit_way
WHERE t1.mongo_id=t2.mongo_id AND t1.credit_way != t2.credit_way AND t1.mongo_id LIKE 'b%';

UPDATE appuser_info t1,appuser_info_temp_2 t2 
SET t1.source=t2.source, t1.is_need_credit=t2.is_need_credit,t1.credit_way=t2.credit_way
WHERE t1.mongo_id=t2.mongo_id AND t1.credit_way != t2.credit_way AND t1.mongo_id LIKE 'c%';

UPDATE appuser_info t1,appuser_info_temp_2 t2 
SET t1.source=t2.source, t1.is_need_credit=t2.is_need_credit,t1.credit_way=t2.credit_way
WHERE t1.mongo_id=t2.mongo_id AND t1.credit_way != t2.credit_way AND t1.mongo_id LIKE 'd%';

UPDATE appuser_info t1,appuser_info_temp_2 t2 
SET t1.source=t2.source, t1.is_need_credit=t2.is_need_credit,t1.credit_way=t2.credit_way
WHERE t1.mongo_id=t2.mongo_id AND t1.credit_way != t2.credit_way AND t1.mongo_id LIKE 'e%';

UPDATE appuser_info t1,appuser_info_temp_2 t2 
SET t1.source=t2.source, t1.is_need_credit=t2.is_need_credit,t1.credit_way=t2.credit_way
WHERE t1.mongo_id=t2.mongo_id AND t1.credit_way != t2.credit_way AND t1.mongo_id LIKE 'f%';


-- 导出  表 appuser.appuser_origin 结构
CREATE TABLE IF NOT EXISTS `appuser_origin` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `mongo_id` varchar(32) COLLATE utf8mb4_bin NOT NULL COMMENT '被邀请人',
  `invitation_id` varchar(32) COLLATE utf8mb4_bin NOT NULL COMMENT '邀请人',
  `invitation_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '邀请时间',
  `source` VARCHAR(20)  COLLATE 'utf8mb4_bin' NULL DEFAULT NULL COMMENT '用户来源',
  `created_by` varchar(30) COLLATE utf8mb4_bin DEFAULT NULL,
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(30) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='邀请人员来源关系表';
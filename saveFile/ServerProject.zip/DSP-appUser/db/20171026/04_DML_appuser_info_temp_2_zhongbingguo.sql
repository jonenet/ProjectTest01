-- 分批更新临时表
UPDATE appuser_info_temp_2 SET iscredit = 'N' WHERE iscredit !='Y' AND iscredit !='N' AND mongo_id LIKE '0%';
UPDATE appuser_info_temp_2 SET iscredit = 'N' WHERE iscredit !='Y' AND iscredit !='N'AND mongo_id LIKE '1%';
UPDATE appuser_info_temp_2 SET iscredit = 'N' WHERE iscredit !='Y' AND iscredit !='N'AND mongo_id LIKE '2%';
UPDATE appuser_info_temp_2 SET iscredit = 'N' WHERE iscredit !='Y' AND iscredit !='N'AND mongo_id LIKE '3%';
UPDATE appuser_info_temp_2 SET iscredit = 'N' WHERE iscredit !='Y' AND iscredit !='N'AND mongo_id LIKE '4%';
UPDATE appuser_info_temp_2 SET iscredit = 'N' WHERE iscredit !='Y' AND iscredit !='N'AND mongo_id LIKE '5%';
UPDATE appuser_info_temp_2 SET iscredit = 'N' WHERE iscredit !='Y' AND iscredit !='N'AND mongo_id LIKE '6%';
UPDATE appuser_info_temp_2 SET iscredit = 'N' WHERE iscredit !='Y' AND iscredit !='N'AND mongo_id LIKE '7%';
UPDATE appuser_info_temp_2 SET iscredit = 'N' WHERE iscredit !='Y' AND iscredit !='N'AND mongo_id LIKE '8%';
UPDATE appuser_info_temp_2 SET iscredit = 'N' WHERE iscredit !='Y' AND iscredit !='N'AND mongo_id LIKE '9%';

UPDATE appuser_info_temp_2 SET iscredit = 'N' WHERE iscredit !='Y' AND iscredit !='N'AND mongo_id LIKE 'a%';
UPDATE appuser_info_temp_2 SET iscredit = 'N' WHERE iscredit !='Y' AND iscredit !='N'AND mongo_id LIKE 'b%';
UPDATE appuser_info_temp_2 SET iscredit = 'N' WHERE iscredit !='Y' AND iscredit !='N'AND mongo_id LIKE 'c%';
UPDATE appuser_info_temp_2 SET iscredit = 'N' WHERE iscredit !='Y' AND iscredit !='N'AND mongo_id LIKE 'd%';
UPDATE appuser_info_temp_2 SET iscredit = 'N' WHERE iscredit !='Y' AND iscredit !='N'AND mongo_id LIKE 'e%';
UPDATE appuser_info_temp_2 SET iscredit = 'N' WHERE iscredit !='Y' AND iscredit !='N'AND mongo_id LIKE 'f%';
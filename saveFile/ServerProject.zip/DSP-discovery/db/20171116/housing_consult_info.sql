CREATE TABLE `housing_consult_info` (
	`id` BIGINT(20) NOT NULL AUTO_INCREMENT,
	`created_by` VARCHAR(30) NULL DEFAULT NULL COLLATE 'utf8mb4_bin',
	`created_date` DATETIME NULL DEFAULT NULL,
	`updated_by` VARCHAR(30) NULL DEFAULT NULL COLLATE 'utf8mb4_bin',
	`updated_date` DATETIME NULL DEFAULT NULL,
	`property_type` VARCHAR(10) NULL DEFAULT NULL COMMENT '��Ȩ������' COLLATE 'utf8mb4_unicode_ci',
	`cousulting_way` VARCHAR(20) NULL DEFAULT NULL COMMENT '��ѯ��ʽ' COLLATE 'utf8mb4_unicode_ci',
	`certificate_number` VARCHAR(40) NULL DEFAULT NULL COMMENT '����֤' COLLATE 'utf8mb4_unicode_ci',
	`name` VARCHAR(20) NULL DEFAULT NULL COMMENT '����' COLLATE 'utf8mb4_unicode_ci',
	`id_number` VARCHAR(30) NULL DEFAULT NULL COMMENT '����֤��' COLLATE 'utf8mb4_unicode_ci',
	`word_number` VARCHAR(40) NULL DEFAULT NULL COMMENT '�ֺ�' COLLATE 'utf8mb4_unicode_ci',
	`estate_number` VARCHAR(40) NULL DEFAULT NULL COMMENT '�ֺ�' COLLATE 'utf8mb4_unicode_ci',
	`status` VARCHAR(10) NULL DEFAULT NULL COMMENT '״̬' COLLATE 'utf8mb4_unicode_ci',
	`user_id` VARCHAR(40) NULL DEFAULT NULL COMMENT '��ѯ�û���mongoId' COLLATE 'utf8mb4_unicode_ci',
	`property_status` VARCHAR(10) NULL DEFAULT NULL COMMENT '��Ȩ״̬' COLLATE 'utf8mb4_unicode_ci',
	`mortgagee` VARCHAR(50) NULL DEFAULT NULL COMMENT '��ѺȨ��' COLLATE 'utf8mb4_unicode_ci',
	`mortgage_date` VARCHAR(40) NULL DEFAULT NULL COMMENT '��Ѻ����' COLLATE 'utf8mb4_unicode_ci',
	`housing_type` VARCHAR(10) NULL DEFAULT NULL COMMENT '�������' COLLATE 'utf8mb4_unicode_ci',
	`building_area` VARCHAR(10) NULL DEFAULT NULL COMMENT '�������' COLLATE 'utf8mb4_unicode_ci',
	`registration_price` VARCHAR(10) NULL DEFAULT NULL COMMENT '�ǼǼ�' COLLATE 'utf8mb4_unicode_ci',
	`completion_date` VARCHAR(40) NULL DEFAULT NULL COMMENT '����ʱ��' COLLATE 'utf8mb4_unicode_ci',
	`img_id` VARCHAR(200) NULL DEFAULT NULL COMMENT '��ͼ' COLLATE 'utf8mb4_unicode_ci',
	`random_id` VARCHAR(200) NULL DEFAULT NULL COMMENT '��ͼ' COLLATE 'utf8mb4_unicode_ci',
	PRIMARY KEY (`id`)
)
COLLATE='utf8mb4_bin'
ENGINE=InnoDB
AUTO_INCREMENT=1
;

CREATE TABLE `article_info` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `created_by` VARCHAR(30) NULL DEFAULT NULL COLLATE 'utf8mb4_bin',
  `created_date` DATETIME NULL DEFAULT NULL,
  `updated_by` VARCHAR(30) NULL DEFAULT NULL COLLATE 'utf8mb4_bin',
  `updated_date` DATETIME NULL DEFAULT NULL,
  `title` VARCHAR(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标题',
  `summary` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '摘要',
  `author` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '作者',
  `content` mediumtext COLLATE utf8mb4_unicode_ci COMMENT '资讯内容',
  `status` varchar(10) NULL DEFAULT NULL COLLATE utf8mb4_unicode_ci COMMENT '发布状态',
  `cover_img_url` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '封面图片地址',
  `original_link` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '原文链接',
  `show_cover` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `browse_count` int(11) DEFAULT '0' COMMENT '浏览量',
  `relay_count` int(11) DEFAULT '0' COMMENT '转发次数',
  `like_count` int(11) DEFAULT '0' COMMENT '点赞次数',
  `effect_date` datetime DEFAULT NULL COMMENT '生效时间',
  `cancel_date` datetime DEFAULT NULL COMMENT '失效时间',
  PRIMARY KEY (`id`)
)
COLLATE='utf8mb4_bin'
ENGINE=InnoDB
AUTO_INCREMENT=1
;
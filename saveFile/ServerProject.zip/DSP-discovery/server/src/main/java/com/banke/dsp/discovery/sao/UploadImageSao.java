package com.banke.dsp.discovery.sao;

import com.banke.bkc.framework.util.ResponseInfo;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

/**
 * Created by luoyifei on 2017/5/11.
 */
@FeignClient(value = "RES-image")
public interface UploadImageSao {

    @RequestMapping(value = "/api/upload", method = RequestMethod.POST, headers = {"Content-Type=multipart/form-data"})
    ResponseInfo<String> upload(@RequestPart("file") MultipartFile file,
                                @RequestParam("bizId") String bizId, @RequestParam(value = "fileName", required = false) String fileName);

    /**
     * 下载文件
     * @param imgId
     * @return
     */
    @RequestMapping(value="/api/down",headers="content-type=application/octet-stream")
    ResponseEntity<byte[]> down(@RequestParam("imgId") String imgId);
}

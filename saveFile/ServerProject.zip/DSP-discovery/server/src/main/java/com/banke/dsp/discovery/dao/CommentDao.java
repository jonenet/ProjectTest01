package com.banke.dsp.discovery.dao;

import com.banke.dsp.discovery.dto.CommentDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.SelectProvider;

import java.util.List;

/**
 * Created by luoyifei on 2017/12/25.
 */
@Mapper
public interface CommentDao extends BaseDao<CommentDto> {

    /**
     * 根据id删除评论
     * @param id
     */
    @SelectProvider(type = CommentDao.CommentSql.class, method = "deleteCommentById")
    void deleteCommentById(@Param("id") Long id);

    /**
     * 根据评论id获取评论信息
     * @param id
     * @return
     */
    @SelectProvider(type = CommentDao.CommentSql.class, method = "getCommentById")
    CommentDto getCommentById(@Param("id") Long id);


    /**
     * 根据文章id和文章类型获取评论列表（分WRK和disp）
     * @param articleId
     * @return
     */
    @SelectProvider(type = CommentDao.CommentSql.class, method = "getCommentListByArticleIdAndArticleType")
    List<CommentDto> getCommentListByArticleIdAndArticleType(@Param("articleId") Long articleId, @Param("articleType") String articleType, @Param("source") String source);



    class CommentSql {
        public String deleteCommentById(@Param("id") Long id) {
            StringBuilder sql = new StringBuilder();
            sql.append("DELETE FROM article_comment");
            sql.append(" WHERE id=" + id);
            return sql.toString();
        }

        public String getCommentById(@Param("id") Long id) {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT created_date,");
            sql.append(" article_id,");
            sql.append(" article_type,");
            sql.append(" comment_user_id,");
            sql.append(" comment_content,");
            sql.append(" reply_id,");
            sql.append(" status,");
            sql.append(" source,");
            sql.append(" is_top");
            sql.append(" FROM article_comment");
            sql.append(" WHERE id=" + id);
            return sql.toString();
        }

        public String getCommentListByArticleIdAndArticleType(@Param("articleId") Long articleId, @Param("articleType") String articleType, @Param("source") String source) {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT id,");
            sql.append(" created_date,");
            sql.append(" article_id,");
            sql.append(" article_type,");
            sql.append(" comment_user_id,");
            sql.append(" comment_content,");
            sql.append(" reply_id,");
            sql.append(" status,");
            sql.append(" source,");
            sql.append(" is_top,");
            sql.append(" like_count");
            sql.append(" FROM article_comment");
            sql.append(" WHERE article_id=" + articleId);
            sql.append(" AND article_type=" + articleType);
            if (! "WRK".equals(source)) {
                // 如果不是WRK请求，不显示隐藏的评论
                sql.append(" AND status='1'");
                sql.append(" ORDER BY is_top DESC,");
                sql.append(" created_date DESC");
            } else {
                sql.append(" ORDER BY created_date DESC");
            }

            return sql.toString();
        }
    }

}

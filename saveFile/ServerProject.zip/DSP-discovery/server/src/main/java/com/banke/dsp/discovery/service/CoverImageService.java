package com.banke.dsp.discovery.service;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.discovery.dao.CoverImageDao;
import com.banke.dsp.discovery.dto.CoverImageDto;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by luoyifei on 2017/5/11.
 */
@Slf4j
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CoverImageService {

    @NonNull
    private CoverImageDao coverImageDao;

    public ResponseInfo<?> insertCoverImage(String coverImgUrl, String jumpImgUrl) {
        CoverImageDto coverImageDto = new CoverImageDto();
        coverImageDto.setCoverImgUrl(coverImgUrl);
        coverImageDto.setJumpImgUrl(jumpImgUrl);
        coverImageDao.insert(coverImageDto);
        return ResponseInfo.success(null);
    }

    public ResponseInfo<?> findCoverImageUrl() {
        Map<String, Object> map = new HashMap();
        CoverImageDto dto = coverImageDao.findCoverImageUrl();
        if(null != dto) {
            String coverImgUrl = dto.getCoverImgUrl();
            String jumpImgUrl = dto.getJumpImgUrl();
            map.put("coverImgUrl", coverImgUrl);
            map.put("jumpImgUrl", jumpImgUrl);
            return ResponseInfo.success(map);
        } else {
            return ResponseInfo.error(null);
        }

    }
}

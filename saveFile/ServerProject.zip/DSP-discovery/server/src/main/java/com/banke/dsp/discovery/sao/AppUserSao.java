package com.banke.dsp.discovery.sao;

import com.alibaba.fastjson.JSONObject;
import com.banke.bkc.framework.util.ResponseInfo;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Created by luoyifei on 2017/12/25.
 */
@FeignClient(value = "DSP-appUser")
public interface AppUserSao {

    /**
     * 根据mongoId获取用户信息
     * @param mongoId
     * @return
     */
    @RequestMapping("/api/findByMongoId")
    ResponseInfo<JSONObject> findByMongoId(@RequestParam(name = "mongoId") String mongoId);

    /**
     * 根据token获取用户信息
     * @param token
     * @return
     */
    @RequestMapping("/api/findToken")
    ResponseInfo<?> findToken(@RequestParam(name = "token") String token);

}

package com.banke.dsp.discovery.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.springframework.web.multipart.MultipartFile;

import com.google.common.io.Files;

import lombok.Data;

@Data
public class MultipartFileImpl implements MultipartFile{
	private File file;
	private String name;
	private String originalFilename;
	private String contentType;
	private InputStream is;
	private byte[] fileByte;
	
	public MultipartFileImpl(InputStream is,byte[] bytes){
		this.is = is;
		this.fileByte = bytes;
	}
	
	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public long getSize() {
		// TODO Auto-generated method stub
		return file.length();
	}

	@Override
	public byte[] getBytes() throws IOException {
		return fileByte;
	}

	@Override
	public InputStream getInputStream() throws IOException {
		// TODO Auto-generated method stub
		return is;
	}

	@Override
	public void transferTo(File dest) throws IOException, IllegalStateException {
		// TODO Auto-generated method stub
		
	}
}

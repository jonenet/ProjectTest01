package com.banke.dsp.discovery.util;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

public class DateFormatUtil {
	private LocalDateTime date;

	//用于格式化html5中datetime-local类型iput控件的时间问题
	public LocalDateTime dateFormatFromDateLocal(String dateLocal){
		String date = null;
		if(null == dateLocal || "".equals(dateLocal)){
			date = "9999-12-31 00:00:00";
		}else{
			dateLocal = dateLocal.concat(":00");
			date = dateLocal.replace('T', ' ');
		}

		Timestamp t = Timestamp.valueOf(date);
		
		return t.toLocalDateTime();
	}

	public LocalDateTime getDate() {
		return date;
	}

	public void setDate(LocalDateTime date) {
		this.date = date;
	}
	
	public String dateFormatFromString(String dateLocal){
		SimpleDateFormat sdf  = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		if(dateLocal ==null || "".equals(dateLocal)){
			return 	dateLocal;
		}
		try {
			Date date = sdf.parse(dateLocal);
			dateLocal = sdf.format(date);
		} catch (ParseException e) {
			return "";
		}
		return 	dateLocal;
		
	}
	
	
}

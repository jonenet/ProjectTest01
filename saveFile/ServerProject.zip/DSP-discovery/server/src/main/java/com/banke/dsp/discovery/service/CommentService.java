package com.banke.dsp.discovery.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.bkc.service.util.ContextHolder;
import com.banke.dsp.discovery.dao.CommentDao;
import com.banke.dsp.discovery.dto.AppUserInfo;
import com.banke.dsp.discovery.dto.CommentDto;
import com.banke.dsp.discovery.sao.AppUserSao;
import com.banke.dsp.discovery.util.MapUtil;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;

/**
 * Created by luoyifei on 2017/12/25.
 * <p>
 * 发现频道评论功能
 */
@Slf4j
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CommentService {

    @NonNull
    private CommentDao commentDao;

    @NonNull
    private AppUserSao appUserSao;

    /**
     * 评论点赞
     */
    @Resource(name = "redisTemplate")
    private HashOperations<String, String, Set<String>> commentLike;

    /**
     * 发布评论
     *
     * @param commentDto
     * @param source
     * @return
     */
    public ResponseInfo<?> insertComment(CommentDto commentDto, String source) {
        try {
            if ("WRK".equals(source)) {
                // 如果是从WRK发起的，把userId设为mongoId
                commentDto.setCommentUserId("official");
                // 初始状态为隐藏
                commentDto.setStatus("0");
            } else {
                // 从app发起的，获取mongoId
                String mongoId = ContextHolder.getAgentNo();
                commentDto.setCommentUserId(mongoId);
            }
            commentDao.insert(commentDto);
            return ResponseInfo.success(null);
        } catch (Exception e) {
            return ResponseInfo.error(null);
        }
    }

    /**
     * 根据id删除评论
     *
     * @param id
     * @return
     */
    public ResponseInfo<?> deleteComment(Long id, String source) {
        try {
            if (!"WRK".equals(source)) {
                // 如果从app端发起的删除评论请求
                CommentDto dto = commentDao.getCommentById(id);
                // 从contextHolder取mongoId
                String mongoId = ContextHolder.getAgentNo();
                if (!mongoId.equals(dto.getCommentUserId())) {
                    // 如果不是删除自己的评论，则返回错误
                    return new ResponseInfo<>("0001", "非法操作", null);
                }
            }
            commentDao.deleteCommentById(id);
            return ResponseInfo.success(null);
        } catch (Exception e) {
            return ResponseInfo.error(null);
        }
    }

    /**
     * 根据id翻转评论状态或者是否置顶状态
     * WRK调用
     *
     * @param id
     * @return
     */
    public ResponseInfo<?> updateStatusOrIstopCommentById(Long id, String status, String isTop) {
        try {
            CommentDto commentDto = commentDao.getCommentById(id);
            if (!StringUtils.isEmpty(status)) {
                // 如果传入状态不为空
                String originalStatus = commentDto.getStatus();
                if ("0".equals(originalStatus)) {
                    // 如果原先的状态是隐藏，则翻转为显示
                    commentDto.setStatus("1");
                } else if ("1".equals(originalStatus)) {
                    // 如果原先的状态是显示，则翻转为隐藏
                    commentDto.setStatus("0");
                }
            }
            if (!StringUtils.isEmpty(isTop)) {
                // 如果传入是否置顶不为空
                String originalIsTop = commentDto.getIsTop();
                if ("0".equals(originalIsTop)) {
                    // 如果原先的状态是隐藏，则翻转为显示
                    commentDto.setIsTop("1");
                } else if ("1".equals(originalIsTop)) {
                    // 如果原先的状态是显示，则翻转为隐藏
                    commentDto.setIsTop("0");
                }
            }
            commentDao.updateById(commentDto);
            return ResponseInfo.success(null);
        } catch (Exception e) {
            return ResponseInfo.error(null);
        }
    }

    /**
     * 根据id更新评论内容
     * WRK调用
     *
     * @param id
     * @return
     */
    public ResponseInfo<?> updateCommentById(Long id) {
        return ResponseInfo.success(null);
    }

    /**
     * 根据文章id和文章类型获取评论列表（分WRK和disp）
     *
     * @param articleId
     * @param articleType
     * @param source
     * @return
     */
    public ResponseInfo<?> getCommentListByArticleIdAndArticleType(Long articleId, String articleType, String source) {
        try {
            Map<String, Object> returnMap = new HashMap<>();
            Map<String, Object> map = new HashMap<>();
            List<Map<String, Object>> returnData = new ArrayList<>();
            List<CommentDto> commentList = commentDao.getCommentListByArticleIdAndArticleType(articleId, articleType, source);
            for (CommentDto commentDto : commentList) {
                if (null != commentDto) {

                    // 评论id
                    Long commentId = commentDto.getId();
                    // 从redis中取点赞数
                    if (commentLike.hasKey("article_" + articleId + "_" + articleType, commentId.toString())) {
                        int likeCount = commentLike.get("article_" + articleId + "_" + articleType, commentId.toString()).size();
                        commentDto.setLikeCount(likeCount);
                    } else {
                        commentDto.setLikeCount(0);
                    }
                    returnMap = MapUtil.transBean2Map(commentDto);
                    // 评论者mongoId
                    String userId = commentDto.getCommentUserId();
                    if ("official".equals(userId)) {
                        // 如果是后台评论的，则不予处理
                        map.put("officialComment", commentDto);
                    } else {
                        returnData.add(returnMap);
                        // 如果是disp评论的，则获取用户信息
                        ResponseInfo<JSONObject> appUser = appUserSao.findByMongoId(userId);
                        if (appUser.isSuccess()) {
                            JSONObject appUserInfoDto = appUser.getData();
                            AppUserInfo userMap = JSON.parseObject(appUserInfoDto.toJSONString(), AppUserInfo.class);
                            returnMap.putAll(MapUtil.transBean2Map(userMap));
                        } else {
                            return new ResponseInfo<>("1001", "获取用户信息错误", null);
                        }
                    }
                }
            }
            // 排序
            Collections.sort(returnData,new Comparator<Map<String, Object>>(){
                public int compare(Map<String, Object> arg0, Map<String, Object> arg1) {
                    // 优先按置顶排序
                    int isTop = arg1.get("isTop").toString().compareTo(arg0.get("isTop").toString());
                    if (isTop == 0) {
                        // 如果置顶相同，则按点赞数排序
                        int likeCount = arg1.get("likeCount").toString().compareTo(arg0.get("likeCount").toString());
                        if (likeCount == 0) {
                            // 如果点赞数相同，则按发布时间倒序排序
                            return arg1.get("createdDate").toString().compareTo(arg0.get("createdDate").toString());
                        }
                        return likeCount;
                    }
                    return isTop;
                }
            });
            map.put("commentList", returnData);
            return ResponseInfo.success(map);
        } catch (Exception e) {
            return ResponseInfo.error(null);
        }
    }

    /**
     * 评论点赞功能
     * @param commentDto
     * @return
     */
    public ResponseInfo<?> insertCommentList(CommentDto commentDto) {
        try {
            // 点赞者的mongoId
            String mongoId = ContextHolder.getAgentNo();
            // 文章类型
            String articleType = commentDto.getArticleType();
            // 文章id
            Long articleId = commentDto.getArticleId();
            // 评论id
            Long commentId = commentDto.getId();
            // 以hash的方式存入，用Set保存mongoId， 去重
            if (commentLike.hasKey("article_" + articleId + "_" + articleType, commentId.toString())) {
                Set<String> likeCommentList = commentLike.get("article_" + articleId + "_" + articleType, commentId.toString());
                likeCommentList.add(mongoId);
                commentLike.put("article_" + articleId + "_" + articleType, commentId.toString(), likeCommentList);
            } else {
                Set<String> likeCommentNewList = new HashSet<String>();
                likeCommentNewList.add(mongoId);
                commentLike.put("article_" + articleId + "_" + articleType, commentId.toString(), likeCommentNewList);
            }
            return ResponseInfo.success(null);
        }catch (Exception e) {
            return ResponseInfo.error(e);
        }
    }
}

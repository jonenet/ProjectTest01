package com.banke.dsp.discovery.dao;

import com.banke.dsp.discovery.util.SQLUtil;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.UpdateProvider;

public interface BaseDao<T> {
    @InsertProvider(type = SQLUtil.class, method = "insert")
    int insert(T obj);

    @UpdateProvider(type = SQLUtil.class, method = "updateById")
    int updateById(T obj);

    @UpdateProvider(type = SQLUtil.class, method = "updateByUK")
    int updateByUK(T obj);
}

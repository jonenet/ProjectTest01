package com.banke.dsp.discovery.service;

import com.banke.bkc.framework.util.MultipartFileWrap;
import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.bkc.framework.util.UUIDUtil;
import com.banke.dsp.discovery.dao.InfoDao;
import com.banke.dsp.discovery.dto.InfoDto;
import com.banke.dsp.discovery.dto.InfoQueryRequest;
import com.banke.dsp.discovery.sao.UploadImageSao;
import com.banke.dsp.discovery.util.DateFormatUtil;
import com.banke.dsp.discovery.util.DateUtil;
import com.banke.dsp.discovery.util.ImageBase64;
import com.banke.dsp.discovery.util.MultipartFileImpl;
import com.google.common.collect.Maps;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by luoyifei on 2017/5/11.
 */
@Slf4j
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class InfoService {

    @NonNull
    private UploadImageSao uploadImageSao;

    @NonNull
    private InfoDao infoDao;

    /**
     * 文章发布平台上传图片
     * WRK调用
     * @param file
     * @return
     */
    public Map<String, Object> fileUpload(MultipartFile file) {
        Map<String, Object> returnMap = new HashMap<String, Object>();
        try {
            if (null == file) {
                log.info("请先上传文件");
                returnMap.put("error", 1);
                returnMap.put("url", "");
                return returnMap;
            }

            String imgUrl = this.uploadImage(file);
            returnMap.put("error", 0);
            returnMap.put("url", imgUrl);
            return returnMap;
        } catch (Exception e) {
            returnMap.put("error", 9999);
            returnMap.put("url", "");
            return returnMap;
        }
    }

    /**
     * 查询图片
     * @return
     */
    public ResponseEntity<?> down(String imageId){
        ResponseEntity<byte[]> file = uploadImageSao.down(imageId);
        List<String> disposition = file.getHeaders().get("X-Filename");
        byte[] fileData = file.getBody();
        return ResponseEntity.ok(fileData);
    }

    /**
     * 根据id查询热门资讯详情
     * @param id
     * @return
     */
    public ResponseInfo<?> findInfoById(Long id, String source) {
        InfoDto dto = infoDao.findInfoById(id);
        if(null == dto) {
            return new ResponseInfo<>("9999", "找不到该资讯", null);
        }
        if(! "WRK".equals(source)) {
            // 说明不是wrk操作
            // 判断文章状态是不是隐藏状态
            if ("0".equals(dto.getStatus())) {
                return new ResponseInfo<>("1111", "文章飘走了", null);
            }
        }
        return ResponseInfo.success(dto);
    }

    /**
     * 上传富文本编辑器图片
     * @param file
     * @return
     */
    public String uploadImage(MultipartFile file) {
        String bizId = "A00000000";
        Map<String, Object> map = Maps.newHashMap();
        if (file.isEmpty()) {
            map.put("succeed", Boolean.FALSE);
            map.put("message", "图片不能为空");
            map.put("data", "");
            log.info("上传图片时图片不能为空");
            return null;
        }
        MultipartFile newImage = new MultipartFileWrap(file) {
            @Override
            public String getName() {
                return "file";
            }
            @Override
            public String getOriginalFilename() {
                String imageName = UUIDUtil.getUid("RES");
                return imageName+".jpg";
            }
        };
        log.info("image flieName is {}",newImage.getOriginalFilename());
        ResponseInfo<String> response = uploadImageSao.upload(newImage, bizId, null);
        if(response.isSuccess()) {
            String imageId = response.getData();
            String imageUrl = "/api/info/down?imgId=" + imageId + "&bkcSysId=WRK";
            return imageUrl;
        } else {
            map.put("succeed", Boolean.FALSE);
            map.put("message", "图片上传失败");
            map.put("data", "");
            log.info("图片上传失败");
            return null;
        }

    }

    /**
     * 发布热门资讯入口
     * @param infoDto
     * @return
     */
    public ResponseInfo<?> createInfo(InfoDto infoDto) {
        try {
            if (StringUtils.isEmpty(infoDto.getTitle())) {
                return new ResponseInfo<>("1001", "标题不能为空", null);
            }
            if (StringUtils.isEmpty(infoDto.getSummary())) {
                return new ResponseInfo<>("1002", "摘要不能为空", null);
            }
            if (StringUtils.isEmpty(infoDto.getAuthor())) {
                return new ResponseInfo<>("1003", "作者不能为空", null);
            }
            if (StringUtils.isEmpty(infoDto.getCoverImgUrl())) {
                return new ResponseInfo<>("1004", "封面不能为空", null);
            }
            if (StringUtils.isEmpty(infoDto.getContent())) {
                return new ResponseInfo<>("1005", "文章内容不能为空", null);
            }
            // 如果没有输入生效时间，则默认立即生效
            if (null == infoDto.getEffectDate()) {
                infoDto.setEffectDate(LocalDateTime.now());
            }
            // 如果没有输入失效时间，则默认永久生效
            if (null == infoDto.getCancelDate()) {
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                infoDto.setCancelDate(LocalDateTime.parse("9999-12-31 23:59:59", dtf));
            }
            infoDao.insert(infoDto);
            return ResponseInfo.success(null);
        } catch (Exception e) {
            return ResponseInfo.error(e);
        }
    }

    /**
     * 根据id更新热门资讯
     * @param infoDto
     * @return
     */
    public ResponseInfo<?> updateInfoById(InfoDto infoDto) {
        try {
            if (StringUtils.isEmpty(infoDto.getTitle())) {
                return new ResponseInfo<>("1001", "标题不能为空", null);
            }
            if (StringUtils.isEmpty(infoDto.getSummary())) {
                return new ResponseInfo<>("1002", "摘要不能为空", null);
            }
            if (StringUtils.isEmpty(infoDto.getAuthor())) {
                return new ResponseInfo<>("1003", "作者不能为空", null);
            }
            if (StringUtils.isEmpty(infoDto.getCoverImgUrl())) {
                return new ResponseInfo<>("1004", "封面不能为空", null);
            }
            if (StringUtils.isEmpty(infoDto.getContent())) {
                return new ResponseInfo<>("1005", "文章内容不能为空", null);
            }
            // 如果没有输入生效时间，则默认立即生效
            if (null == infoDto.getEffectDate()) {
                infoDto.setEffectDate(LocalDateTime.now());
            }
            // 如果没有输入失效时间，则默认永久生效
            if (null == infoDto.getCancelDate()) {
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                infoDto.setCancelDate(LocalDateTime.parse("9999-12-31 23:59:59", dtf));
            }
            infoDao.updateById(infoDto);
            return ResponseInfo.success(null);
        } catch (Exception e) {
            return ResponseInfo.error(null);
        }
    }

    /**
     * 根据id翻转热门资讯的发布状态或者置顶状态
     * @param id
     * @return
     */
    public ResponseInfo<?> updateInfoStatusOrIsTopById(Long id, String status, String isTop) {
        try {
            InfoDto infoDto = infoDao.findInfoById(id);
            if (null != infoDto) {
                if (! StringUtils.isEmpty(status)) {
                    // 表中的状态
                    String origialStatus = infoDto.getStatus();
                    if ("0".equals(origialStatus)) {
                        // 如果原先的状态为隐藏，则翻转为发布
                        infoDto.setStatus("1");
                    } else if("1".equals(origialStatus)) {
                        // 如果原先的状态为发布，则反转为隐藏
                        infoDto.setStatus("0");
                    }
                }
                if (! StringUtils.isEmpty(isTop)) {
                    // 如果传入是否置顶不为空
                    String originalIsTop = infoDto.getIsTop();
                    if("0".equals(originalIsTop)) {
                        // 如果原先的状态是隐藏，则翻转为显示
                        infoDto.setIsTop("1");
                    } else if("1".equals(originalIsTop)) {
                        // 如果原先的状态是显示，则翻转为隐藏
                        infoDto.setIsTop("0");
                    }
                }
                infoDao.updateById(infoDto);
            }
            return ResponseInfo.success(null);
        } catch (Exception e) {
            return ResponseInfo.error(null);
        }
    }

    /**
     * 根据id删除热门资讯
     * @param id
     * @throws Exception
     */
    public void deleteInfoById(Long id) throws Exception {
        infoDao.deleteInfoById(id);
    }

    /**
     * 资讯长度
     * @return
     */
    public Integer findCount() {
        return infoDao.findCount();
    }


    /**
     * 上传封面图片
     * @param imageData 参数为base64
     * @return
     */
    public ResponseInfo<?> uploadCoverImg(String imageData) {
        String bizId = "A00000000";
        Map<String, Object> map = Maps.newHashMap();
        if (StringUtils.isEmpty(imageData)) {
            map.put("succeed", Boolean.FALSE);
            map.put("message", "图片不能为空");
            map.put("data", "");
            return ResponseInfo.success(map);
        }
        byte[] imgData = new ImageBase64().getImgData(imageData);
        InputStream is = new ByteArrayInputStream(imgData);
        MultipartFileImpl mf = new MultipartFileImpl(is, imgData);
        MultipartFile newImage = new MultipartFileWrap(mf) {
            @Override
            public String getName() {
                return "file";
            }
            @Override
            public String getOriginalFilename() {
                String imageName = UUIDUtil.getUid("RES");
                return imageName+".jpg";
            }
        };
        log.info("image flieName is {}",newImage.getOriginalFilename());
        ResponseInfo<String> response = uploadImageSao.upload(newImage, bizId, null);
        if(response.isSuccess()) {
            String imageId = response.getData();
//            String imageUrl = "/attachments/" + imageId;
            String imageUrl = "/api/info/down?imgId=" + imageId;
            map.put("succeed", Boolean.TRUE);
            map.put("message", "图片上传成功");
            map.put("data", imageUrl);
        } else {
            map.put("succeed", Boolean.FALSE);
            map.put("message", "图片上传失败");
            map.put("data", "");
        }
        return ResponseInfo.success(map);
    }

    /**
     * 分页获取热门资讯列表
     * @param pageNum
     * @param pageSize
     * @param source
     * @return
     */
    public ResponseInfo<?> findList(Integer pageNum, Integer pageSize, String source) {
        Map<String, Object> map = new HashMap();
        pageNum = (pageNum - 1) * pageSize;
        Integer count = infoDao.findCount();
        List<InfoDto> list = infoDao.findList(pageNum, pageSize, source);
        map.put("list", list);
        map.put("count", count);
        return ResponseInfo.success(map);
    }

    /**
     * 根据条件获取热点资讯列表
     * WRK调用
     * @param infoQueryRequest
     * @return
     */
    public ResponseInfo<?> queryInfoList(InfoQueryRequest infoQueryRequest) {
        try {
            List<InfoDto> infoList = infoDao.queryInfoList(infoQueryRequest);
            return ResponseInfo.success(infoList);
        } catch (Exception e) {
            return ResponseInfo.error(e);
        }
    }

}

package com.banke.dsp.discovery.api;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.discovery.dto.InfoDto;
import com.banke.dsp.discovery.dto.InfoQueryRequest;
import com.banke.dsp.discovery.service.HotActivityService;
import com.banke.dsp.discovery.service.InfoService;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

/**
 * Created by luoyifei on 2018/1/4.
 */
@Slf4j
@RestController
@RequestMapping(value = "/api/activity/", method = {RequestMethod.GET, RequestMethod.POST})
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class HotActivityApi {

    @NonNull
    private HotActivityService hotActivityService;

    /**
     * 根据id删除热门活动
     * WRK调用
     * @param id
     * @throws Exception
     */
    @RequestMapping("/deleteActivityById")
    public void deleteActivityById(@RequestParam("id") Long id) throws Exception {
        hotActivityService.deleteActivityById(id);
    }
}

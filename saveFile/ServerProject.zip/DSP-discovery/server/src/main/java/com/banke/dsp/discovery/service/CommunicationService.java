package com.banke.dsp.discovery.service;

import com.banke.bkc.framework.util.MultipartFileWrap;
import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.bkc.framework.util.UUIDUtil;
import com.banke.bkc.service.util.ContextHolder;
import com.banke.dsp.discovery.dao.CommunicationDao;
import com.banke.dsp.discovery.dto.InfoDto;
import com.banke.dsp.discovery.dto.InfoQueryRequest;
import com.banke.dsp.discovery.dto.CommunicationDto;
import com.banke.dsp.discovery.util.ImageBase64;
import com.banke.dsp.discovery.util.MultipartFileImpl;
import com.google.common.collect.Maps;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by luoyifei on 2017/5/11.
 */
@Slf4j
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CommunicationService {

    @NonNull
    private CommunicationDao communicationDao;

    /**
     * 产品交流发布问题
     * @param communicationDto
     * @return
     */
    public ResponseInfo<?> publishCommunication(CommunicationDto communicationDto) {
        try {
            if (StringUtils.isEmpty(communicationDto.getTitle())) {
                return new ResponseInfo<>("1001", "提问标题不能为空", null);
            }
            if (StringUtils.isEmpty(communicationDto.getContent())) {
                return new ResponseInfo<>("1002", "提问内容不能为空", null);
            }
            // 提问者mongoId
            String userId = ContextHolder.getAgentNo();
            communicationDto.setUserId(userId);
            // 状态立马生效
            communicationDto.setStatus("1");
            // 默认不是精华
            communicationDto.setIsEssence("0");
            // 默认不是指定
            communicationDto.setIsTop("1");

            communicationDao.insert(communicationDto);
        } catch (Exception e) {

        }
        return ResponseInfo.success(null);
    }

    /**
     * 根据id删除问题
     * WRK调用
     * @param id
     * @return
     */
    public ResponseInfo<?> deleteCommunicationById(Long id) {
        try {
            communicationDao.deleteCommunicationById(id);
            return ResponseInfo.success(null);
        } catch (Exception e) {
            return ResponseInfo.error(e);
        }
    }
}

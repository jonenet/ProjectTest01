package com.banke.dsp.discovery.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

/**
 * Created by luoyifei on 2017/12/28.
 */
@Slf4j
public class DateUtil {

    /**
     *  string 转 localDateTime
     * @param str
     * @return
     * @throws Exception
     */
    public static LocalDateTime stringToLocalDateTime(String str){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date = sdf.parse(str);
            return dateToLocalDateTime(date);
        }catch (Exception e){
            log.info("string 转 localDateTime 异常，{}",e);
        }
        return null;
    }

    /**
     * date 转 localDateTime
     *
     * @param date
     * @return
     */
    public static LocalDateTime dateToLocalDateTime(Date date) {
        if (date == null) return null;
        Instant instant = date.toInstant();
        ZoneId zone = ZoneId.systemDefault();
        LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, zone);
        return localDateTime;
    }

    /**
     * localDateTime 转 String，去掉T ：例如：2017-03-27 11:57:32
     * @param time
     * @return
     */
    public static String localDateTimeToString(LocalDateTime time){
        return StringUtils.replace(time.toString(), "T", " ");
    }




}

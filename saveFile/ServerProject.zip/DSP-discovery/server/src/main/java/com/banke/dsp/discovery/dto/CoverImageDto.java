package com.banke.dsp.discovery.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * Created by luoyifei on 2017/5/11.
 *
 * 热门资讯
 */
@Data
@EqualsAndHashCode
@NoArgsConstructor
@Table(name = "cover_image_info")
public class CoverImageDto {

    @Column
    private  Long id;

    @Column
    private String coverImgUrl; // 封面图片地址

    @Column
    private String jumpImgUrl; // 跳转链接
}

package com.banke.dsp.discovery.util;

/**
 * Created by luoyifei on 2017/5/12.
 */
public class UploadImgFactory {
}

package com.banke.dsp.discovery.dao;

import com.banke.dsp.discovery.dto.HousingConsultInfoDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.UpdateProvider;

/**
 * Created by luoyifei on 2017/11/3.
 */
@Mapper
public interface HousingConsultDao extends BaseDao<HousingConsultInfoDto> {

    @SelectProvider(type =  HousingConsultSql.class, method = "findHousingConsultInfoById")
    HousingConsultInfoDto findHousingConsultInfoById(@Param("id") Long id);

    @SelectProvider(type = HousingConsultSql.class, method = "getTask")
    HousingConsultInfoDto getTask();
    
    @SelectProvider(type = HousingConsultSql.class, method = "getByUUID")
    HousingConsultInfoDto getByUUID(@Param("randomId") String randomId);

    class HousingConsultSql {
        public String findHousingConsultInfoById(@Param("id") Long id) {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT  * ");
            sql.append(" FROM housing_consult_info ");
            sql.append(" WHERE id = " + id);
            return sql.toString();
        }

        public String getTask() {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT id, property_type, cousulting_way, certificate_number, name, id_number, word_number, estate_number, status");
            sql.append(" FROM housing_consult_info ");
            sql.append(" WHERE status = '0'");
            sql.append(" order by created_date desc");
            sql.append(" limit 1");
            return sql.toString();
        }
        
        public String getByUUID(@Param("randomId") String randomId) {
        	StringBuilder sql = new StringBuilder();
            sql.append("SELECT *");
            sql.append(" FROM housing_consult_info ");
            sql.append(" WHERE random_id='" + randomId + "'");
            return sql.toString();
        }
    }
}

package com.banke.dsp.discovery.api;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.discovery.dto.HousingConsultInfoDto;
import com.banke.dsp.discovery.service.HousingConsultService;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

/**
 * Created by luoyifei on 2017/11/4.
 */
@Slf4j
@RestController
@Component
@RequestMapping(value = "/api/house/", method = {RequestMethod.GET, RequestMethod.POST})
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class HousingConsultApi {

    @NonNull
    private HousingConsultService housingConsultService;

    @RequestMapping(value = "/createImg")
    public ResponseInfo<?> createImg(@RequestParam(name = "imageData") String imageData) throws Exception {
        return housingConsultService.createImg(imageData);
    }
    /**
     * 用户请求时插入状态（前端调用接口）
     * @param housingConsultInfoDto
     * @return
     */
    @RequestMapping(value = "/insertHousingConsultQueue")
    public ResponseInfo<?> insertHousingConsultQueue(@RequestBody HousingConsultInfoDto housingConsultInfoDto) throws Exception {
        return housingConsultService.insertHousingConsultQueue(housingConsultInfoDto);
    }

    @RequestMapping("/getResultInfoById")
    public ResponseInfo<?> getResultInfoById(@RequestParam(name = "id") Long id) throws Exception {
        return housingConsultService.getResultInfoById(id);
    }

    /**
     * C# 调用更新查询状态
     * @param id
     * @param propertyStatus
     * @param mortgagee
     * @param mortgageDate
     * @param housingType
     * @param buildingArea
     * @param registrationPrice
     * @param completionDate
     * @return
     */
    @RequestMapping("/updateHousingConsultInfoById")
    public ResponseInfo<?> updateHousingConsultInfoById(@RequestParam(name = "id") Long id, @RequestParam(name = "status") String status, @RequestParam(name = "propertyStatus", required = false) String propertyStatus, @RequestParam(name = "mortgagee", required = false) String mortgagee, @RequestParam(name = "mortgageDate", required = false) String mortgageDate, @RequestParam(name = "housingType", required = false) String housingType, @RequestParam(name = "buildingArea", required = false) String buildingArea, @RequestParam(name = "registrationPrice", required = false) String registrationPrice, @RequestParam(name = "completionDate", required = false) String completionDate, @RequestParam(name = "imgId", required = false) String imgId) throws Exception {
    	return housingConsultService.updateHousingConsultInfoById(id, status, propertyStatus, mortgagee, mortgageDate, housingType, buildingArea, registrationPrice, completionDate, imgId);
    }

    /**
     * C# 调用获取任务
     * @return
     * @throws Exception
     */
    @RequestMapping("/getTask")
    public ResponseInfo<?> getTask() throws Exception {
        return housingConsultService.getTask();
    }
}

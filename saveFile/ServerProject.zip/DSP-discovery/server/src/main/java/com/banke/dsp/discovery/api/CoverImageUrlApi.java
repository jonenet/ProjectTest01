package com.banke.dsp.discovery.api;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.discovery.service.CoverImageService;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 * Created by luoyifei on 2017/5/11.
 */
@RestController
@RequestMapping(value = "/api/cover/", method = {RequestMethod.GET, RequestMethod.POST})
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CoverImageUrlApi {

    @NonNull
    private CoverImageService coverImageService;

    @RequestMapping("/insertCoverImage")
    public ResponseInfo<?> insertCoverImage(String coverImgUrl, String jumpImgUrl)  throws Exception {
         return  coverImageService.insertCoverImage(coverImgUrl, jumpImgUrl);
    }

    @RequestMapping("/findCoverImageUrl")
    public ResponseInfo<?> findCoverImageUrl() throws Exception {
        return coverImageService.findCoverImageUrl();
    }

}

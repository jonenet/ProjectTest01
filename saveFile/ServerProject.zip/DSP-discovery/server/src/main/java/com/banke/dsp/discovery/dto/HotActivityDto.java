package com.banke.dsp.discovery.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * Created by luoyifei on 2018/1/4.
 *
 * 发现频道热门活动
 */
@Data
@EqualsAndHashCode
@NoArgsConstructor
@Table(name = "hot_activity")
public class HotActivityDto {

    @Column
    private  Long id;

    @Column
    private String type;  // 文章类型

    @Column
    private String title; // 活动标题

    @Column
    private String activityUrl; // 活动链接

    @Column
    private String coverImgUrl; // 活动图片地址

    @Column
    private int browseCount; // 浏览量

    @Column
    private int relayCount; // 转发量

    @Column
    private int likeCount; // 点赞数

    @Column
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime effectDate; // 生效时间

    @Column
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime cancelDate; // 失效时间

    @Column
    private String status; // 发布状态(0：隐藏，1：发布)

    @Column
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdDate; // 发布时间

    @Column
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updatedDate; // 更新时间

    @Column
    private String isTop; // 是否置顶（0：不置顶，1：置顶）

}

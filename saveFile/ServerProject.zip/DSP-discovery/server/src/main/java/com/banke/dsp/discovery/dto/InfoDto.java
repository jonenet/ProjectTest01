package com.banke.dsp.discovery.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * Created by luoyifei on 2017/5/11.
 *
 * 发现频道热点资讯文章
 */
@Data
@EqualsAndHashCode
@NoArgsConstructor
@Table(name = "article_info")
public class InfoDto {

    @Column
    private  Long id;

    @Column
    private String type;  // 文章类型

    @Column
    private String title; // 标题

    @Column
    private String summary; //摘要

    @Column
    private String author; // 作者

    @Column
    private String content; // 正文

    @Column
    private String coverImgUrl; // 封面图片地址

    @Column
    private String coverImgType; // 封面图片类型（1：缩略图 2：长图）

    @Column
    private int browseCount; // 浏览量

    @Column
    private int relayCount; // 转发量

    @Column
    private int likeCount; // 点赞数

    @Column
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime effectDate; // 生效时间

    @Column
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime cancelDate; // 失效时间

    @Column
    private String status; // 发布状态(0：隐藏，1：发布)

    @Column
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdDate; // 发布时间

    @Column
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updatedDate; // 更新时间

    @Column
    private String isTop; // 是否置顶（0：不置顶，1：置顶）

}

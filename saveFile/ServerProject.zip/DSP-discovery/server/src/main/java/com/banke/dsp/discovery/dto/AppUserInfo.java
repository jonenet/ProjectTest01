package com.banke.dsp.discovery.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

import javax.persistence.Column;
import java.time.LocalDateTime;

/**
 * Created by luoyifei on 2017/12/26.
 */

@Data
@NoArgsConstructor
public class AppUserInfo {
    @NonNull
    @Column(nullable = false)
    private String mongoId;

    //业务城市
    @Column(nullable = false)
    private String businessCityid;

    //手机号码
    @Column(nullable = false)
    private String cellphone;

    //用户星级
    @Column(nullable = false)
    private Integer star;

    //用户名
    @Column(nullable = false)
    private String userName;

    //微信用户名
    @Column(nullable = false)
    private String wechatUsername;


    // 来源
    @Column(nullable = false)
    private String source;


}

package com.banke.dsp.discovery.util;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Table;

import org.apache.commons.lang.StringUtils;
import org.apache.ibatis.jdbc.SQL;

import com.banke.bkc.framework.exception.BusinessException;
import com.banke.bkc.framework.util.ContextHolder;
import com.banke.bkc.framework.util.Formatter;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class SQLUtil {
    @SuppressWarnings("rawtypes")
	private static final Map<Class, Map<String, String>> typeFieldMap = Maps.newHashMap();

    @SuppressWarnings("rawtypes")
    private static final Map<Class, Map<String, String>> typeUkMap = Maps.newHashMap();

    private static final char UNDERLINE = '_';

    private static String tableName(Object obj) throws Exception {
        Table table = obj.getClass().getAnnotation(Table.class);
        if (table != null)
            return table.name();
        else
            throw new Exception("实体类未定义@Table");
    }

    private static String camelToUnderline(String param) {
        int len = param.length();
        StringBuilder sb = new StringBuilder(len);
        for (int i = 0; i < len; i++) {
            char c = param.charAt(i);
            if (Character.isUpperCase(c)) {
                sb.append(UNDERLINE);
                sb.append(Character.toLowerCase(c));
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    private Map<String, String> getFieldMap(Object obj) {
        Map<String, String> fieldMap = typeFieldMap.get(obj.getClass());
        if (fieldMap == null) {
            fieldMap = Maps.newHashMap();
            Map<String, String> ukMap = Maps.newHashMap();
            Field[] fields = obj.getClass().getDeclaredFields();
            List<Field> fieldList = Lists.newArrayList(fields);
            for (Field field : fieldList) {
                Column colDef = field.getAnnotation(Column.class);
                if (colDef != null) {
                    String columnName = colDef.name();
                    if (StringUtils.isEmpty(columnName)) {
                        columnName = camelToUnderline(field.getName());
                    }
                    fieldMap.put(columnName, field.getName());
                    if (colDef.unique()) {
                        ukMap.put(columnName, field.getName());
                    }
                }
            }
            fieldMap.remove("created_date");
            fieldMap.remove("created_by");
            fieldMap.remove("updated_date");
            fieldMap.remove("updated_by");
            typeFieldMap.put(obj.getClass(), fieldMap);
            typeUkMap.put(obj.getClass(), ukMap);
        }
        return fieldMap;
    }

    public String insert(Object obj) throws Exception {
        Map<String, String> finalFieldMap = getFieldMap(obj);
        return new SQL() {{
            INSERT_INTO(tableName(obj));
            finalFieldMap.forEach((c, f) -> VALUES(c, "#{" + f + "}"));
            VALUES("created_date", "now()");
            VALUES("created_by", "'" + ContextHolder.getUserId() + "'");
            VALUES("updated_date", "now()");
            VALUES("updated_by", "'" + ContextHolder.getUserId() + "'");
        }}.toString();
    }

    public String updateById(Object obj) throws Exception {
        Map<String, String> finalFieldMap = getFieldMap(obj);
        return new SQL() {{
            UPDATE(tableName(obj));
            finalFieldMap.forEach((c, f) -> SET(Formatter.f("{0}=#{{1}}", c, f)));
            SET("created_date=now()");
            SET("created_by='" + ContextHolder.getUserId() + "'");
            SET("updated_date=now()");
            SET("updated_by='" + ContextHolder.getUserId() + "'");
            WHERE("id=#{id}");
        }}.toString();
    }

    public String updateByUK(Object obj) throws Exception {
        Map<String, String> finalFieldMap = getFieldMap(obj);
        Map<String, String> ukMap = typeUkMap.get(obj.getClass());
        if (ukMap.isEmpty()) {
            throw new BusinessException("7000", "实体类未定义UK字段");
        }
        return new SQL() {{
            UPDATE(tableName(obj));
            finalFieldMap.forEach((c, f) -> SET(Formatter.f("{0}=#{{1}}", c, f)));
            SET("created_date=now()");
            SET("created_by='" + ContextHolder.getUserId() + "'");
            SET("updated_date=now()");
            SET("updated_by='" + ContextHolder.getUserId() + "'");
            ukMap.forEach((c, f) -> WHERE(Formatter.f("{0}=#{{1}}", c, f)));
        }}.toString();
    }
}

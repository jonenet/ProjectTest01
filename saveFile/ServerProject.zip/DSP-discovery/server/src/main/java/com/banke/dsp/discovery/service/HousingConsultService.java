package com.banke.dsp.discovery.service;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.banke.dsp.discovery.dao.HousingConsultDao;
import com.banke.dsp.discovery.dto.HousingConsultInfoDto;
import com.banke.dsp.discovery.sao.UploadImageSao;
import com.banke.dsp.discovery.util.ImageBase64;
import com.banke.dsp.discovery.util.UnicodeUtil;
import com.banke.dsp.discovery.util.WebFileUtils;
import com.google.common.collect.Maps;
import org.apache.commons.codec.binary.Base64;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.bkc.service.util.ContextHolder;

import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.multipart.MultipartFile;

/**
 * Created by luoyifei on 2017/11/3.
 */
@Slf4j
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class HousingConsultService {

    @NonNull
    private HousingConsultDao housingConsultDao;

    @NonNull
    private UploadImageSao uploadImageSao;

    public ResponseInfo<?> createImg(String imageData) {
        String bizId = "A00000000";
        Map<String, Object> map = Maps.newHashMap();
        String newData = imageData.replace(" ", "+");
        log.info("改装之后的base64: " + newData);
        File file  = new File("");
        MultipartFile multipartFile = WebFileUtils.createImg(new ImageBase64().getImgData(newData));
        ResponseInfo<String> response = uploadImageSao.upload(multipartFile, bizId, null);
        if(response.isSuccess()) {
            String imageId = response.getData();
            String imageUrl = "/api/info/down?imgId=" + imageId;
            map.put("succeed", Boolean.TRUE);
            map.put("message", "图片上传成功");
            map.put("data", imageUrl);
            
        } else {
        	map.put("succeed", Boolean.FALSE);
            map.put("message", "图片上传失败");
            map.put("data", "");
            log.info("图片上传失败");
            // return null;
        }
        return ResponseInfo.success(map);
    }
    /**
     * 用户请求时插入状态（前端调用接口）
     * @param housingConsultInfoDto
     * @return
     */
    public ResponseInfo<?> insertHousingConsultQueue(HousingConsultInfoDto housingConsultInfoDto) {
        try {
            Map<String, Object> resultMap = new HashMap();
            String userId = ContextHolder.getAgentNo();
            String randomId = UUID.randomUUID().toString().replaceAll("-", "").toString();
            housingConsultInfoDto.setUserId(userId);
            // 先根据dto获取表里是否有数据
            housingConsultInfoDto.setStatus("0");
            housingConsultInfoDto.setRandomId(randomId);
            housingConsultDao.insert(housingConsultInfoDto);
            // 根据生成的随机id判断状态是否已翻转
            HousingConsultInfoDto newDto = housingConsultDao.getByUUID(randomId);
            Long id = newDto.getId();
            return ResponseInfo.success(id);
        } catch (Exception e) {
            return ResponseInfo.error(null);
        }
    }

    public ResponseInfo<?> getResultInfoById(Long id) {
        try {
            HousingConsultInfoDto housingConsultInfoDto = housingConsultDao.findHousingConsultInfoById(id);
            return ResponseInfo.success(housingConsultInfoDto);
        } catch (Exception e) {
            return ResponseInfo.error(null);
        }
    }

    /**
     * C# 调用更新查询状态
     * @param id
     * @param propertyStatus
     * @param mortgagee
     * @param mortgageDate
     * @param housingType
     * @param buildingArea
     * @param registrationPrice
     * @param completionDate
     * @return
     */
    public ResponseInfo<?> updateHousingConsultInfoById(@Param("id") Long id, @Param("status") String status, @Param("propertyStatus") String propertyStatus, @Param("mortgagee") String mortgagee, @Param("mortgageDate") String mortgageDate, @Param("housingType") String housingType, @Param("buildingArea") String buildingArea, @Param("registrationPrice") String registrationPrice, @Param("completionDate") String completionDate, @Param("imgId") String imgId) {
        HousingConsultInfoDto housingConsultInfoDto = housingConsultDao.findHousingConsultInfoById(id);
        HousingConsultInfoDto newDto = new HousingConsultInfoDto();
        newDto.setId(housingConsultInfoDto.getId());
        newDto.setPropertyType(housingConsultInfoDto.getPropertyType());
        newDto.setCousultingWay(housingConsultInfoDto.getCousultingWay());
        newDto.setCertificateNumber(housingConsultInfoDto.getCertificateNumber());
        newDto.setName(housingConsultInfoDto.getName());
        newDto.setIdNumber(housingConsultInfoDto.getIdNumber());
        newDto.setWordNumber(housingConsultInfoDto.getWordNumber());
        newDto.setUserId(housingConsultInfoDto.getUserId());
        newDto.setStatus(status);
        if(propertyStatus != null) {
            newDto.setPropertyStatus(UnicodeUtil.unicodeToCn(propertyStatus));
        }
        if(mortgagee != null) {
            newDto.setMortgagee(UnicodeUtil.unicodeToCn(mortgagee));
        }
        if(mortgageDate != null) {
            newDto.setMortgageDate(mortgageDate);
        }
        if(housingType != null) {
            newDto.setHousingType(UnicodeUtil.unicodeToCn(housingType));
        }
        if(buildingArea != null) {
            newDto.setBuildingArea(buildingArea);
        }
        if(registrationPrice != null) {
            newDto.setRegistrationPrice(registrationPrice.replace("RMB", ""));
        }
        if(completionDate != null) {
            newDto.setCompletionDate(completionDate.replace("/", "-"));
        }
        if(imgId != null) {
            newDto.setImgId(imgId);
        }
        housingConsultDao.updateById(newDto);
        return ResponseInfo.success(newDto);
    }

    /**
     * C# 调用获取任务
     * @return
     * @throws Exception
     */
    public ResponseInfo<?> getTask() throws Exception {
        HousingConsultInfoDto housingConsultInfoDto = housingConsultDao.getTask();
        return ResponseInfo.success(housingConsultInfoDto);
    }


}

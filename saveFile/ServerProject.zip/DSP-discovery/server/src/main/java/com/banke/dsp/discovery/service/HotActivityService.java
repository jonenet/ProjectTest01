package com.banke.dsp.discovery.service;

import com.banke.bkc.framework.util.MultipartFileWrap;
import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.bkc.framework.util.UUIDUtil;
import com.banke.dsp.discovery.dao.HotActivityDao;
import com.banke.dsp.discovery.dao.InfoDao;
import com.banke.dsp.discovery.dto.HotActivityDto;
import com.banke.dsp.discovery.dto.InfoDto;
import com.banke.dsp.discovery.dto.InfoQueryRequest;
import com.banke.dsp.discovery.sao.UploadImageSao;
import com.banke.dsp.discovery.util.ImageBase64;
import com.banke.dsp.discovery.util.MultipartFileImpl;
import com.google.common.collect.Maps;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by luoyifei on 2017/5/11.
 */
@Slf4j
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class HotActivityService {

    @NonNull
    private UploadImageSao uploadImageSao;

    @NonNull
    private HotActivityDao hotActivityDao;

    /**
     * 根据id查询热门资讯详情
     * @param id
     * @return
     */
    public ResponseInfo<?> findInfoById(Long id, String source) {
        HotActivityDto dto = hotActivityDao.findInfoById(id);
        if(null == dto) {
            return new ResponseInfo<>("9999", "找不到该资讯", null);
        }
        if(! "WRK".equals(source)) {
            // 说明不是wrk操作
            // 判断文章状态是不是隐藏状态
            if ("0".equals(dto.getStatus())) {
                return new ResponseInfo<>("1111", "文章飘走了", null);
            }
        }
        return ResponseInfo.success(dto);
    }

    /**
     * 发布热门资讯入口
     * @param infoDto
     * @return
     */
    public ResponseInfo<?> createInfo(HotActivityDto activityDto) {
        try {
            if (StringUtils.isEmpty(activityDto.getTitle())) {
                return new ResponseInfo<>("1001", "标题不能为空", null);
            }
            if (StringUtils.isEmpty(activityDto.getCoverImgUrl())) {
                return new ResponseInfo<>("1004", "封面不能为空", null);
            }
            // 如果没有输入生效时间，则默认立即生效
            if (null == activityDto.getEffectDate()) {
                activityDto.setEffectDate(LocalDateTime.now());
            }
            // 如果没有输入失效时间，则默认永久生效
            if (null == activityDto.getCancelDate()) {
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                activityDto.setCancelDate(LocalDateTime.parse("9999-12-31 23:59:59", dtf));
            }
            hotActivityDao.insert(activityDto);
            return ResponseInfo.success(null);
        } catch (Exception e) {
            return ResponseInfo.error(e);
        }
    }

    /**
     * 根据id更新热门资讯
     * @param hotActivityDto
     * @return
     */
    public ResponseInfo<?> updateInfoById(HotActivityDto hotActivityDto) {
        try {
            if (StringUtils.isEmpty(hotActivityDto.getTitle())) {
                return new ResponseInfo<>("1001", "标题不能为空", null);
            }
            if (StringUtils.isEmpty(hotActivityDto.getCoverImgUrl())) {
                return new ResponseInfo<>("1004", "封面不能为空", null);
            }
            // 如果没有输入生效时间，则默认立即生效
            if (null == hotActivityDto.getEffectDate()) {
                hotActivityDto.setEffectDate(LocalDateTime.now());
            }
            // 如果没有输入失效时间，则默认永久生效
            if (null == hotActivityDto.getCancelDate()) {
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                hotActivityDto.setCancelDate(LocalDateTime.parse("9999-12-31 23:59:59", dtf));
            }
            hotActivityDao.updateById(hotActivityDto);
            return ResponseInfo.success(null);
        } catch (Exception e) {
            return ResponseInfo.error(null);
        }
    }

    /**
     * 根据id翻转热门资讯的发布状态或者置顶状态
     * @param id
     * @return
     */
    public ResponseInfo<?> updateInfoStatusOrIsTopById(Long id, String status, String isTop) {
        try {
            HotActivityDto infoDto = hotActivityDao.findInfoById(id);
            if (null != infoDto) {
                if (! StringUtils.isEmpty(status)) {
                    // 表中的状态
                    String origialStatus = infoDto.getStatus();
                    if ("0".equals(origialStatus)) {
                        // 如果原先的状态为隐藏，则翻转为发布
                        infoDto.setStatus("1");
                    } else if("1".equals(origialStatus)) {
                        // 如果原先的状态为发布，则反转为隐藏
                        infoDto.setStatus("0");
                    }
                }
                if (! StringUtils.isEmpty(isTop)) {
                    // 如果传入是否置顶不为空
                    String originalIsTop = infoDto.getIsTop();
                    if("0".equals(originalIsTop)) {
                        // 如果原先的状态是隐藏，则翻转为显示
                        infoDto.setIsTop("1");
                    } else if("1".equals(originalIsTop)) {
                        // 如果原先的状态是显示，则翻转为隐藏
                        infoDto.setIsTop("0");
                    }
                }
                hotActivityDao.updateById(infoDto);
            }
            return ResponseInfo.success(null);
        } catch (Exception e) {
            return ResponseInfo.error(null);
        }
    }

    /**
     * 根据id删除热门资讯
     * @param id
     * @throws Exception
     */
    public void deleteActivityById(Long id) throws Exception {

    }

    /**
     * 上传封面图片
     * @param imageData 参数为base64
     * @return
     */
    public ResponseInfo<?> uploadCoverImg(String imageData) {
        String bizId = "A00000000";
        Map<String, Object> map = Maps.newHashMap();
        if (StringUtils.isEmpty(imageData)) {
            map.put("succeed", Boolean.FALSE);
            map.put("message", "图片不能为空");
            map.put("data", "");
            return ResponseInfo.success(map);
        }
        byte[] imgData = new ImageBase64().getImgData(imageData);
        InputStream is = new ByteArrayInputStream(imgData);
        MultipartFileImpl mf = new MultipartFileImpl(is, imgData);
        MultipartFile newImage = new MultipartFileWrap(mf) {
            @Override
            public String getName() {
                return "file";
            }
            @Override
            public String getOriginalFilename() {
                String imageName = UUIDUtil.getUid("RES");
                return imageName+".jpg";
            }
        };
        log.info("image flieName is {}",newImage.getOriginalFilename());
        ResponseInfo<String> response = uploadImageSao.upload(newImage, bizId, null);
        if(response.isSuccess()) {
            String imageId = response.getData();
//            String imageUrl = "/attachments/" + imageId;
            String imageUrl = "/api/info/down?imgId=" + imageId;
            map.put("succeed", Boolean.TRUE);
            map.put("message", "图片上传成功");
            map.put("data", imageUrl);
        } else {
            map.put("succeed", Boolean.FALSE);
            map.put("message", "图片上传失败");
            map.put("data", "");
        }
        return ResponseInfo.success(map);
    }

    /**
     * 分页获取热门资讯列表
     * @param pageNum
     * @param pageSize
     * @param source
     * @return
     */
    public ResponseInfo<?> findList(Integer pageNum, Integer pageSize, String source) {
        Map<String, Object> map = new HashMap();
        pageNum = (pageNum - 1) * pageSize;
        Integer count = hotActivityDao.findCount();
        List<HotActivityDto> list = hotActivityDao.findList(pageNum, pageSize, source);
        map.put("list", list);
        map.put("count", count);
        return ResponseInfo.success(map);
    }

}

package com.banke.dsp.discovery;

import com.banke.bkc.framework.starter.Starter;
import com.banke.bkc.message.annotation.EnableMessage;
import com.banke.bkc.service.annotation.EnableService;

@EnableMessage
@EnableService
public class App {
    public static void main(String[] args) {
        Starter.run(args);
    }
}


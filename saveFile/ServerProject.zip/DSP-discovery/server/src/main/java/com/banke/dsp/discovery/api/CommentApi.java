package com.banke.dsp.discovery.api;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.discovery.dto.CommentDto;
import com.banke.dsp.discovery.service.CommentService;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * Created by luoyifei on 2017/12/25.
 */
@Slf4j
@RestController
@RequestMapping(value = "/api/comment/", method = {RequestMethod.GET, RequestMethod.POST})
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CommentApi {

    @NonNull
    private CommentService commentService;

    /**
     * 发布评论
     * @param commentDto
     * @return
     */
    @RequestMapping("/insertComment")
    public ResponseInfo<?> insertComment(@RequestBody CommentDto commentDto, @RequestParam("source") String source) {
        return commentService.insertComment(commentDto, source);
    }

    /**
     * 根据id删除评论
     * @param id
     * @return
     */
    @RequestMapping("/deleteComment")
    public ResponseInfo<?> deleteComment(@RequestParam("id") Long id, @RequestParam("source") String source) {
        return commentService.deleteComment(id, source);
    }

    /**
     * 根据id翻转评论状态或者置顶状态
     * WRK调用
     * @param id
     * @return
     */
    @RequestMapping("/updateStatusOrIstopCommentById")
    public ResponseInfo<?> updateStatusOrIstopCommentById(@RequestParam("id") Long id, @RequestParam("status") String status, @RequestParam("isTop") String isTop) {
        return commentService.updateStatusOrIstopCommentById(id, status, isTop);
    }

    /**
     * 根据id更新评论内容
     * WRK调用
     * @param id
     * @return
     */
    @RequestMapping("/updateCommentById")
    public ResponseInfo<?> updateCommentById(@RequestParam("id") Long id) {
        return commentService.updateCommentById(id);
    }

    /**
     * 根据文章id和文章类型获取评论列表（分WRK和disp）
     * @param articleId
     * @param articleType
     * @param source
     * @return
     */
    @RequestMapping("/getCommentListByArticleIdAndArticleType")
    public ResponseInfo<?> getCommentListByArticleIdAndArticleType(@RequestParam("articleId") Long articleId, @RequestParam("articleType") String articleType, @RequestParam(required = false, name = "source") String source) {
        return commentService.getCommentListByArticleIdAndArticleType(articleId, articleType, source);
    }

    /**
     * 评论点赞功能
     * @param commentDto
     * @return
     */
    @RequestMapping("/insertCommentList")
    public ResponseInfo<?> insertCommentList(@RequestBody CommentDto commentDto) {
        return commentService.insertCommentList(commentDto);
    }
}

package com.banke.dsp.discovery.dto;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * Created by luoyifei on 2017/12/31.
 */
@Data
public class InfoQueryRequest {

    private Long id;

    private String title; // 文章标题

    private String author; // 文章作者

    private String status; // 文章状态

    private LocalDateTime dateStartAt; // // 文章发布开始时间

    private LocalDateTime dateEndAt; // 文章发布结束时间


}

package com.banke.dsp.discovery.api;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.bkc.service.util.ContextHolder;
import com.banke.dsp.discovery.dto.InfoDto;
import com.banke.dsp.discovery.dto.InfoQueryRequest;
import com.banke.dsp.discovery.service.InfoService;
import com.sun.xml.internal.bind.v2.TODO;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

/**
 * Created by luoyifei on 2017/5/11.
 */
@Slf4j
@RestController
@RequestMapping(value = "/api/info/", method = {RequestMethod.GET, RequestMethod.POST})
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class InfoApi {

    @NonNull
    private InfoService infoService;

    /**
     * 发布平台上传文件接口（目前只支持上传图片）
     * WRK调用
     *
     * @param dir
     * @param imgFile
     * @throws Exception
     */
    @RequestMapping(value = "/fileUpload", method = RequestMethod.POST)
    public Map<String, Object> fileUpload(MultipartFile imgFile, String dir) {

        /**
         * 暂时对图片进行处理
         */
        if ("image".equals(dir)) {
            return infoService.fileUpload(imgFile);
        }

        return null;

    }

    /**
     * 查看图片接口
     * TODO 目前 房屋查档 功能也在使用此接口
     * @param imgId
     * @return
     * @throws Exception
     */
    @RequestMapping("down")
    public ResponseEntity<?> down(@RequestParam("imgId") String imgId) throws Exception {
        return infoService.down(imgId);
    }

    /**
     * 上传封面图片
     * @param imageData
     * @return
     */
    @RequestMapping("/uploadCoverImg")
    public ResponseInfo<?> uploadCoverImg(@RequestParam("imageData") String imageData) {
        return infoService.uploadCoverImg(imageData);
    }

    /**
     * 根据id删除热点资讯
     * WRK调用
     * @param id
     * @throws Exception
     */
    @RequestMapping("/deleteInfoById")
    public void deleteInfoById(@RequestParam("id") Long id) throws Exception {
        infoService.deleteInfoById(id);
    }

    /**
     * 根据id查询热点资讯详情
     * @param id
     * @return
     * @throws Exception
     */
    @RequestMapping("/findInfoById")
    public ResponseInfo<?> findInfoById(@RequestParam("id") Long id, @RequestParam(name = "source", required = false) String source) throws Exception {
        return infoService.findInfoById(id, source);
    }

    /**
     * 发布热门资讯
     * WRK调用
     * @param infoDto
     * @return
     */
    @RequestMapping("/createInfo")
    public ResponseInfo<?> createInfo(@RequestBody InfoDto infoDto) {
        return infoService.createInfo(infoDto);
    }

    /**
     * 根据id更新热门资讯
     * WRK调用
     * @param infoDto
     * @return
     */
    @RequestMapping("/updateInfoById")
    public ResponseInfo<?> updateInfoById(@RequestBody InfoDto infoDto) {
        return infoService.updateInfoById(infoDto);
    }


    /**
     * 根据id翻转热门资讯的发布状态或者置顶状态
     * WRK调用
     * @param id
     * @return
     */
    @RequestMapping("/updateInfoStatusOrIsTopById")
    public ResponseInfo<?> updateInfoStatusOrIsTopById(@RequestParam("id") Long id, @RequestParam("status") String status, @RequestParam("isTop") String isTop) {
        return infoService.updateInfoStatusOrIsTopById(id, status, isTop);
    }


    /**
     * 获取热点资讯列表
     * @param pageNum
     * @param pageSize
     * @param source
     * @return
     * @throws Exception
     */
    @RequestMapping("/findList")
    public ResponseInfo<?> findList(@RequestParam("pageNum") Integer pageNum, @RequestParam("pageSize") Integer pageSize, @RequestParam(name = "source", required = false) String source) throws Exception {
        return infoService.findList(pageNum, pageSize, source);
    }

    /**
     * 根据条件获取热点资讯列表
     * WRK调用
     * @param infoQueryRequest
     * @return
     */
    @RequestMapping("/queryInfoList")
    public ResponseInfo<?> queryInfoList(@RequestBody InfoQueryRequest infoQueryRequest) {
        return infoService.queryInfoList(infoQueryRequest);
    }
}

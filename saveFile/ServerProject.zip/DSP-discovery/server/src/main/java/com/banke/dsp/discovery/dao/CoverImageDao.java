package com.banke.dsp.discovery.dao;

import com.banke.dsp.discovery.dto.CoverImageDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.SelectProvider;

/**
 * 热门资讯
 * Created by luoyifei on 2017/5/11.
 */
@Mapper
public interface CoverImageDao extends BaseDao<CoverImageDto> {

    @SelectProvider(type =  CoverImageSql.class, method = "findCoverImageUrl")
    CoverImageDto findCoverImageUrl();

    class CoverImageSql {
        public String findCoverImageUrl() {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT cover_img_url, jump_img_url");
            sql.append(" FROM cover_image_info");
            sql.append(" order by created_date desc");
            sql.append(" limit 1");
            return sql.toString();
        }
    }
}

package com.banke.dsp.discovery.dao;

import com.banke.dsp.discovery.dto.HotActivityDto;
import com.banke.dsp.discovery.dto.InfoDto;
import com.banke.dsp.discovery.dto.InfoQueryRequest;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.SelectProvider;

import java.util.List;

/**
 * 热门资讯
 * Created by luoyifei on 2018/1/4.
 */
@Mapper
public interface HotActivityDao extends BaseDao<HotActivityDto> {

    @SelectProvider(type = HotActivitySql.class, method = "findCount")
    Integer findCount();

    /**
     * 获取热点资讯列表
     * @param pageNum
     * @param pageSize
     * @param source
     * @return
     */
    @SelectProvider(type = HotActivitySql.class, method = "findList")
    List<HotActivityDto> findList(@Param("pageNum") Integer pageNum, @Param("pageSize") Integer pageSize, @Param("source") String source);

    /**
     * 根据id获取资讯详情
     * @param id
     * @return
     */
    @SelectProvider(type = HotActivitySql.class, method = "findInfoById")
    HotActivityDto findInfoById(@Param("id") Long id);

    /**
     * 根据id删除资讯
     * @param id
     */
    @SelectProvider(type = HotActivitySql.class, method = "deleteActivityById")
    void deleteInfoById(@Param("id") Long id);

    /**
     * 更新转发量阅读量点赞量
     */
    @SelectProvider(type = HotActivitySql.class, method = "queryInfoList")
    List<HotActivityDto> queryInfoList(InfoQueryRequest infoQueryRequest);


    class HotActivitySql {
        public String findCount() {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT count(1)");
            sql.append(" FROM article_info");
            sql.append(" WHERE effect_date < NOW()");
            sql.append(" AND cancel_date > NOW()");
            return sql.toString();
        }

        public String findList(@Param("pageNum") Integer pageNum, @Param("pageSize") Integer pageSize, @Param("source") String source) {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT ai.id,");
            sql.append( "ai.title,");
            sql.append(" ai.author,");
            sql.append(" ai.cover_img_url,");
            sql.append(" ai.cover_img_type,");
            sql.append(" ai.summary,");
            sql.append(" ai.content,");
            sql.append(" ai.effect_date,");
            sql.append(" ai.cancel_date,");
            sql.append(" ai.relay_count,");
            sql.append(" ai.browse_count,");
            sql.append(" ai.like_count,");
            sql.append(" ai.status,");
            sql.append(" ai.is_top");
            sql.append(" FROM article_info ai");
            if (! "WRK".equals(source)) {
                // 如果不是从WRK请求的话，只显示生效的
                sql.append(" WHERE ai.effect_date < NOW()");
                sql.append(" AND ai.cancel_date > NOW()");
                sql.append(" AND ai.status='1'");
                sql.append(" ORDER BY ai.is_top DESC,");
                sql.append(" ai.effect_date DESC");
            } else {
                sql.append(" ORDER BY ai.created_date DESC");
            }
            sql.append(" LIMIT " + pageNum + ", " + pageSize);
            return sql.toString();
        }

        public String findInfoById(@Param("id") Long id) {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT ai.id,");
            sql.append( "ai.title,");
            sql.append(" ai.author,");
            sql.append(" ai.content,");
            sql.append(" ai.cover_img_url,");
            sql.append(" ai.cover_img_type,");
            sql.append(" ai.summary,");
            sql.append(" ai.effect_date,");
            sql.append(" ai.cancel_date,");
            sql.append(" ai.relay_count,");
            sql.append(" ai.browse_count,");
            sql.append(" ai.like_count,");
            sql.append(" ai.status,");
            sql.append(" ai.is_top");
            sql.append(" FROM article_info ai");
            sql.append(" WHERE ai.id = " + id);
            return sql.toString();
        }

        public String deleteActivityById(@Param("id") Long id) {
            StringBuilder sql = new StringBuilder();
            sql.append("DELETE FROM hot_activity");
            sql.append(" WHERE id = " + id);
            return sql.toString();
        }

        public String queryInfoList(InfoQueryRequest infoQueryRequest) {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT ai.id,");
            sql.append( "ai.title,");
            sql.append(" ai.author,");
            sql.append(" ai.cover_img_url,");
            sql.append(" ai.cover_img_type,");
            sql.append(" ai.summary,");
            sql.append(" ai.content,");
            sql.append(" ai.effect_date,");
            sql.append(" ai.cancel_date,");
            sql.append(" ai.relay_count,");
            sql.append(" ai.browse_count,");
            sql.append(" ai.like_count,");
            sql.append(" ai.status,");
            sql.append(" ai.is_top");
            sql.append(" WHERE 1 = 1");
            if (StringUtils.isNotEmpty(infoQueryRequest.getTitle())) {
                sql.append(" AND ai.title = " + infoQueryRequest.getTitle());
            }
            if (StringUtils.isNotEmpty(infoQueryRequest.getAuthor())) {
                sql.append(" AND ai.author = " + infoQueryRequest.getAuthor());
            }
            if (StringUtils.isNotEmpty(infoQueryRequest.getStatus())) {
                sql.append(" AND ai.status = " + infoQueryRequest.getStatus());
            }
            if (StringUtils.isNotEmpty(infoQueryRequest.getDateStartAt().toString())) {
                sql.append(" AND ai.created_date >= " + infoQueryRequest.getDateStartAt());
            }
            if (StringUtils.isNotEmpty(infoQueryRequest.getDateEndAt().toString())) {
                sql.append(" AND ai.created_date <= " + infoQueryRequest.getDateEndAt());
            }
            sql.append(" FROM article_info ai");
            sql.append(" ORDER BY ai.created_date DESC");
            return sql.toString();
        }
    }
}

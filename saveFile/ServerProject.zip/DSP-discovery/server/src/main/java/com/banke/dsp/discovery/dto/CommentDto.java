package com.banke.dsp.discovery.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * Created by luoyifei on 2017/12/25.
 *
 * 发现频道评论功能
 */

@Data
@EqualsAndHashCode
@NoArgsConstructor
@Table(name = "article_comment")
public class CommentDto {

    @Column
    private Long id; // 评论id

    @Column
    private Long articleId; // 评论文章id

    @Column
    private String articleType; // 评论文章类型（1： 热点资讯； 2：...）

    @Column
    private String commentContent; // 评论内容

    @Column
    private String commentUserId;  // 评论者mongoId

    @Column
    private Long replyId; // 被回复的评论id(嵌套评论功能暂未开发)

    @Column
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdDate; // 评论时间

    @Column
    private String status; // 评论的状态（显示/隐藏）

    @Column
    private String source; // 评论来源

    @Column
    private String isTop; // 是否置顶（0：不置顶，1：置顶）

    @Column
    private int likeCount; // 点赞数

}

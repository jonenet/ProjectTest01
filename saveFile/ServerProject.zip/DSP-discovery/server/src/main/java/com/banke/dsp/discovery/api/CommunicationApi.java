package com.banke.dsp.discovery.api;

import com.banke.bkc.framework.util.ResponseInfo;
import com.banke.dsp.discovery.dto.CommunicationDto;
import com.banke.dsp.discovery.service.CommunicationService;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * Created by luoyifei on 2017/5/11.
 */
@Slf4j
@RestController
@RequestMapping(value = "/api/communication/", method = {RequestMethod.GET, RequestMethod.POST})
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CommunicationApi {


    @NonNull
    private CommunicationService communicationService;

    /**
     * 产品交流发布问题
     * @param communicationDto
     * @return
     */
    @RequestMapping("/publishCommunication")
    public ResponseInfo<?> publishCommunication(@RequestBody CommunicationDto communicationDto) {
        return communicationService.publishCommunication(communicationDto);
    }

    /**
     * 根据id删除问题
     * WRK调用
     * @param id
     * @throws Exception
     */
    @RequestMapping("/deleteCommunicationById")
    public void deleteCommunicationById(@RequestParam("id") Long id) throws Exception {
        communicationService.deleteCommunicationById(id);
    }
}

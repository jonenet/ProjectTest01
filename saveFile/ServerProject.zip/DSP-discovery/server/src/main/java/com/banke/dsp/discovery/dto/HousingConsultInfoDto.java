package com.banke.dsp.discovery.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * Created by luoyifei on 2017/11/3.
 *
 * 房屋查档功能表
 */
@Data
@EqualsAndHashCode
@NoArgsConstructor
@Table(name = "housing_consult_info")
public class HousingConsultInfoDto {

    @Column
    private  Long id;

    /**
     * 产权书类型（房产证： realty；不动产证：estate）
     */
    @Column
    private String propertyType;

    /**
     * 查询方式（分户： household； 分栋： building）
     */
    @Column
    private String cousultingWay;

    /**
     * 房产证
     */
    @Column
    private String certificateNumber;

    /**
     * 姓名(或产权证上的机构名称)
     */
    @Column
    private String name;

    /**
     * 身份证号
     */
    @Column
    private String idNumber;

    /**
     * 字号
     */
    @Column
    private String wordNumber;

    /**
     * 不动产证号
     */
    @Column
    private String estateNumber;

    /**
     * 查询状态 (0 为 未查询， 1 为 已查询)
     */
    @Column
    private String status;

    /**
     * 查询的用户id
     */
    @Column
    private String userId;

    /******************* 以下字段为返回字段 ***********************/

    /**
     * 产权状态
     */
    @Column
    private String propertyStatus;

    /**
     * 抵押权人
     */
    @Column
    private String mortgagee;

    /**
     * 抵押日期
     */
    @Column
    private String mortgageDate;

    /**
     * 房屋类别
     */
    @Column
    private String housingType;

    /**
     * 房屋面积
     */
    @Column
    private String buildingArea;

    /**
     * 登记价
     */
    @Column
    private String registrationPrice;

    /**
     * 竣工时间
     */
    @Column
    private String completionDate;

    /**
     * 截图
     */
    @Column
    private String imgId;

    /**
     * 随机id
     */
    @Column
    private String randomId;

    @Column
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdDate; // 请求时间
}

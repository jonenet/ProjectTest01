package com.banke.dsp.discovery.util;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

public class ParamUtil extends StringUtils {
    public static boolean isAllBlank(CharSequence... param) {
        if (ArrayUtils.isEmpty(param)) {
            return true;
        }
        for (final CharSequence cs : param) {
            if (isNotBlank(cs)) {
                return false;
            }
        }
        return true;
    }
}

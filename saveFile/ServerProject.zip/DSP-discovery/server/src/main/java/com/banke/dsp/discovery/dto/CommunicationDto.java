package com.banke.dsp.discovery.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * Created by luoyifei on 2018/1/4.
 *
 * 发现频道产品交流
 */
@Data
@EqualsAndHashCode
@NoArgsConstructor
@Table(name = "production_communication")
public class CommunicationDto {

    @Column
    private  Long id;

    @Column
    private String type;  // 文章类型

    @Column
    private String title; // 标题

    @Column
    private String userId; // 提问者mongoId

    @Column
    private String content; // 提问内容

    @Column
    private int browseCount; // 浏览量

    @Column
    private String status; // 问题发布状态(0：隐藏，1：发布)

    @Column
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdDate; // 发布时间

    @Column
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updatedDate; // 更新时间

    @Column
    private String isTop; // 是否置顶（0：不置顶，1：置顶）

    @Column
    private String isEssence; // 是否精华（0：不是精华，1：精华）

}

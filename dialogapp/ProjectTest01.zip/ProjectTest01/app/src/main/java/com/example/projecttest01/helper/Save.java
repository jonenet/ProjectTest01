package com.example.projecttest01.helper;

/**
 * Created by ex-zhoulai on 2018/3/29.
 */

public class Save {

    //        OkGo.<String>head(Urls.URL_METHOD)//
//                .tag(this)//
//                .headers("header1", "headerValue1")//
//                .params("param1", "paramValue1")//
//                .execute(new StringDialogCallback(this) {
//                    @Override
//                    public void onSuccess(Response<String> response) {
//                        handleResponse(response);
//                    }
//
//                    @Override
//                    public void onError(Response<String> response) {
//                        handleError(response);
//                    }
//                });

//        OkGo.<LzyResponse<ServerModel>>options(Urls.URL_METHOD)//
//                .tag(this)//
//                .headers("header1", "headerValue1")//
//                .params("param1", "paramValue1")//
//                .execute(new DialogCallback<LzyResponse<ServerModel>>(this) {
//                    @Override
//                    public void onSuccess(Response<LzyResponse<ServerModel>> response) {
//                        handleResponse(response);
//                    }
//
//                    @Override
//                    public void onError(Response<LzyResponse<ServerModel>> response) {
//                        handleError(response);
//                    }
//                });
//
//        OkGo.<LzyResponse<ServerModel>>post(Urls.URL_METHOD)//
//                .tag(this)//
//                .headers("header1", "headerValue1")//
//                .params("param1", "paramValue1")//
//                .params("param2", "paramValue2")//
//                .params("param3", "paramValue3")//
//                .isMultipart(true)         //强制使用 multipart/form-data 表单上传（只是演示，不需要的话不要设置。默认就是false）
//                .execute(new DialogCallback<LzyResponse<ServerModel>>(this) {
//                    @Override
//                    public void onSuccess(Response<LzyResponse<ServerModel>> response) {
//                        handleResponse(response);
//                    }
//
//                    @Override
//                    public void onError(Response<LzyResponse<ServerModel>> response) {
//                        handleError(response);
//                    }
//                });

//        OkGo.<LzyResponse<ServerModel>>put(Urls.URL_METHOD)//
//                .tag(this)//
//                .headers("header1", "headerValue1")//
//                .params("param1", "paramValue1")//
//                .execute(new DialogCallback<LzyResponse<ServerModel>>(this) {
//                    @Override
//                    public void onSuccess(Response<LzyResponse<ServerModel>> response) {
//                        handleResponse(response);
//                    }
//
//                    @Override
//                    public void onError(Response<LzyResponse<ServerModel>> response) {
//                        handleError(response);
//                    }
//                });
//
//        OkGo.<LzyResponse<ServerModel>>delete(Urls.URL_METHOD)//
//                .tag(this)//
//                .headers("header1", "headerValue1")//
//                .upString("这是要上传的数据")//
//                .execute(new DialogCallback<LzyResponse<ServerModel>>(this) {
//                    @Override
//                    public void onSuccess(Response<LzyResponse<ServerModel>> response) {
//                        handleResponse(response);
//                    }
//
//                    @Override
//                    public void onError(Response<LzyResponse<ServerModel>> response) {
//                        handleError(response);
//                    }
//                });

//        OkGo.<LzyResponse<ServerModel>>patch(Urls.URL_METHOD)//
//                .tag(this)//
//                .headers("header1", "headerValue1")//
//                .upString("这是要上传的数据")//
//                .execute(new DialogCallback<LzyResponse<ServerModel>>(this) {
//                    @Override
//                    public void onSuccess(Response<LzyResponse<ServerModel>> response) {
//                        handleResponse(response);
//                    }
//
//                    @Override
//                    public void onError(Response<LzyResponse<ServerModel>> response) {
//                        handleError(response);
//                    }
//                });
//        OkGo.<LzyResponse<ServerModel>>trace(Urls.URL_METHOD)//
//                .tag(this)//
//                .headers("header1", "headerValue1")//
//                .params("param1", "paramValue1")//
//                .execute(new DialogCallback<LzyResponse<ServerModel>>(this) {
//                    @Override
//                    public void onSuccess(Response<LzyResponse<ServerModel>> response) {
//                        handleResponse(response);
//                    }
//
//                    @Override
//                    public void onError(Response<LzyResponse<ServerModel>> response) {
//                        handleError(response);
//                    }
//                });
}

package com.example.projecttest01.dagger;

/**
 * Created by ex-zhoulai on 2018/4/3.
 */

public class AnimalBean {

    private String height;

    public AnimalBean(String height) {
        this.height = height;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }
}

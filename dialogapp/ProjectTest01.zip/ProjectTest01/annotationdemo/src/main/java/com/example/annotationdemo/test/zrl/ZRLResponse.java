package com.example.annotationdemo.test.zrl;

/**
 * Created by ex-zhoulai on 2018/5/3.
 */

public class ZRLResponse {


    public void print(int level) {
        System.out.println("print level = " + level);
    }
}
